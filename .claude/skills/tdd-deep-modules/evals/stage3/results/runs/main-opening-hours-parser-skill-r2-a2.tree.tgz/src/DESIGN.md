# Design note: `parseOpeningHours`

**Hidden decision:** the grammar of the opening-hours text, how it is split into
tokens, and which error (code and column) the first problem from the left maps to.

**Both designs**

- A: `parseOpeningHours(text): WeeklyHours`, throws `OpeningHoursError`.
- B: `parseOpeningHours(text): { ok: true; hours } | { ok: false; error }`.

Chosen: A, because a caller learns one function and one error class, and the
whole grammar, tokenizer and rule merging sit behind that single call. (A was
also what the given stub asked for.)

**Interface**

- `parseOpeningHours(text)` returns all seven days. Each day gets the ranges of
  the last rule that names it, sorted by start, or `[]` if it is closed. Each day
  gets its own copies of the range objects.
- `OpeningHoursError` has `code` and a 1-based `column` in the whole text.
  `message` is the description plus `(column N)`.
- `Day`, `TimeRange`, `WeeklyHours` and `OpeningHoursErrorCode` are unchanged
  from the stub.

**Inside** (private, tested only through the function)

- `tokenize`: one regex splits the text into words (`\p{L}+`), times (`[\d:]+`),
  `-`, `,`, `;` and skipped runs of spaces. Any other character (tab, newline, `#`)
  becomes an `other` token that never fits the grammar.
- `Parser`: recursive descent, one method per grammar rule, run in reading order.
  A check that needs a whole construct runs once that construct has been read:
  end before start, overlap, and duplicate day (checked against the whole day
  item). So `Mo-We,Tu-Fx` reports UNKNOWN_DAY at `Fx` (column 10), not
  DUPLICATE_DAY at `Tu`. In the same way, `08:00-12:00,10:00-09:00` reports
  END_BEFORE_START at the later range's start time, before any overlap check.
- Times are compared as `HH:MM` strings, which sort in time order (`24:00` last).

**Depth**

`depth_report src/openingHours.ts`:
`surface 10, size 154, ratio 15.4, classitis no, pass-through 0, tests 1, unused 0, duplicate 2 -> deep`.
Refactors: the split-based first version became a tokenizer plus parser. Later,
token kinds became explicit (`other`), `peekIs`/`next` became `accept`/`peek`/`next`,
and the two copies of the comma list with an "earlier items" check became one
`list` method.

**Open points**

- Only the space character counts as a space. Tabs and newlines are UNEXPECTED.
- A word is any run of Unicode letters, so `Mö` is one word: UNKNOWN_DAY at `M`.
- No extra rule for ranges past midnight (`22:00-02:00` is END_BEFORE_START), as specified.

**Proof:** `scripts/tdd_replay 5341314..HEAD` printed `REPLAY: ACCEPT`.
