export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}


const DAYS: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

// "other" is a character that belongs to no token; it never fits the format.
type TokenKind = "word" | "time" | "-" | "," | ";" | "other";

interface Token {
  kind: TokenKind;
  text: string;
  column: number;
}

const TOKEN = /(\p{L}+)|([\d:]+)|([-,;])|( +)|([^])/gu;

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  for (const match of text.matchAll(TOKEN)) {
    const [, word, time, punctuation, spaces] = match;
    if (spaces) continue;
    const kind: TokenKind = word ? "word" : time ? "time" : punctuation ? (punctuation as TokenKind) : "other";
    tokens.push({ kind, text: match[0], column: match.index + 1 });
  }
  return tokens;
}

function emptyWeek(): WeeklyHours {
  return { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };
}

/**
 * Recursive descent over the grammar in the order the text is read, so the
 * first problem from the left is the one thrown. Checks that need a whole
 * construct (end before start, overlap, duplicate day) run once it is read.
 */
class Parser {
  private position = 0;

  constructor(
    private readonly tokens: Token[],
    private readonly endColumn: number,
  ) {}

  spec(): WeeklyHours {
    const hours = emptyWeek();
    do this.rule(hours);
    while (this.accept(";"));
    const rest = this.peek();
    if (rest) throw this.unexpected(rest);
    return hours;
  }

  private rule(hours: WeeklyHours): void {
    const days = this.days();
    const ranges = this.accept("word", "off") ? [] : this.ranges();
    for (const day of days) hours[day] = ranges.map((range) => ({ ...range }));
  }

  private days(): Day[] {
    const items = this.list(
      () => this.dayItem(),
      (item, earlier, column) => {
        const repeated = item.find((day) => earlier.flat().includes(day));
        if (repeated) throw new OpeningHoursError("DUPLICATE_DAY", column, `${repeated} is named twice in this rule`);
      },
    );
    return items.flat();
  }

  private dayItem(): Day[] {
    const first = this.day();
    if (!this.accept("-")) return [first];
    const last = this.day();
    const days = [first];
    for (let i = DAYS.indexOf(first); DAYS[i] !== last; ) {
      i = (i + 1) % DAYS.length;
      days.push(DAYS[i]);
    }
    return days;
  }

  private day(): Day {
    const token = this.next("word");
    const day = DAYS.find((candidate) => candidate === token.text);
    if (!day) throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    return day;
  }

  private ranges(): TimeRange[] {
    const ranges = this.list(
      () => this.range(),
      (range, earlier, column) => {
        if (earlier.some((other) => other.from < range.to && range.from < other.to)) {
          throw new OpeningHoursError("OVERLAP", column, `${range.from}-${range.to} overlaps an earlier range`);
        }
      },
    );
    return ranges.sort((a, b) => (a.from < b.from ? -1 : 1));
  }

  /** item { "," item }; check sees each later item, the earlier ones and the column where it starts. */
  private list<T>(item: () => T, check: (item: T, earlier: T[], column: number) => void): T[] {
    const items = [item()];
    while (this.accept(",")) {
      const column = this.peek()?.column ?? this.endColumn;
      const next = item();
      check(next, items, column);
      items.push(next);
    }
    return items;
  }

  // "HH:MM" strings of equal shape compare in time order, "24:00" last.
  private range(): TimeRange {
    const start = this.time(false);
    this.next("-");
    const to = this.time(true).text;
    if (to <= start.text) {
      throw new OpeningHoursError("END_BEFORE_START", start.column, `Range ends at ${to}, not after ${start.text}`);
    }
    return { from: start.text, to };
  }

  private time(isEnd: boolean): Token {
    const token = this.next("time");
    const match = /^(\d\d):(\d\d)$/.exec(token.text);
    const valid =
      match !== null && ((Number(match[1]) <= 23 && Number(match[2]) <= 59) || (isEnd && token.text === "24:00"));
    if (!valid) throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    return token;
  }

  private peek(): Token | undefined {
    return this.tokens[this.position];
  }

  /** Consumes the next token if it has this kind (and text), and says whether it did. */
  private accept(kind: TokenKind, text?: string): boolean {
    const token = this.peek();
    const matches = token?.kind === kind && (text === undefined || token.text === text);
    if (matches) this.position++;
    return matches;
  }

  private next(kind: TokenKind): Token {
    const token = this.peek();
    if (!token) throw new OpeningHoursError("UNEXPECTED", this.endColumn, "Text ends too early");
    if (token.kind !== kind) throw this.unexpected(token);
    this.position++;
    return token;
  }

  private unexpected(token: Token): OpeningHoursError {
    return new OpeningHoursError("UNEXPECTED", token.column, `Unexpected "${token.text}"`);
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  const tokens = tokenize(text);
  if (tokens.length === 0) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  return new Parser(tokens, text.length + 1).spec();
}
