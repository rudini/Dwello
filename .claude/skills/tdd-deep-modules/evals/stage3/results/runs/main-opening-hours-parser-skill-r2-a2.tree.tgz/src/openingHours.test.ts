import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours, type OpeningHoursErrorCode, type WeeklyHours } from "./openingHours";

function week(hours: Partial<WeeklyHours>): WeeklyHours {
  return { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [], ...hours };
}

function parsed(text: string): unknown {
  try {
    return parseOpeningHours(text);
  } catch (error) {
    return error;
  }
}

function expectError(text: string, code: OpeningHoursErrorCode, column: number) {
  const caught = parsed(text);
  expect(caught).toBeInstanceOf(OpeningHoursError);
  const error = caught as OpeningHoursError;
  expect({ text, code: error.code, column: error.column }).toEqual({ text, code, column });
}

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

test("one day with one range gives that range and all other days closed", () => {
  expect(parsed("Mo 08:00-12:00")).toEqual(week({ Mo: [{ from: "08:00", to: "12:00" }] }));
});

test("off closes the named day", () => {
  expect(parsed("Su off")).toEqual(week({}));
});

test("several ranges in one rule are returned sorted by start time", () => {
  expect(parsed("Tu 13:30-18:30,08:00-12:00")).toEqual(
    week({ Tu: [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }] }),
  );
});

test("a day list applies the hours to each listed day", () => {
  const morning = [{ from: "08:00", to: "12:00" }];
  expect(parsed("Mo,We,Sa 08:00-12:00")).toEqual(week({ Mo: morning, We: morning, Sa: morning }));
});

test("a day range covers every day from first to last", () => {
  const day = [{ from: "09:00", to: "17:00" }];
  expect(parsed("Mo-Fr 09:00-17:00")).toEqual(week({ Mo: day, Tu: day, We: day, Th: day, Fr: day }));
});

test("a day range wraps around the week and a range from a day to itself is that day", () => {
  const day = [{ from: "10:00", to: "14:00" }];
  expect(parsed("Fr-Mo 10:00-14:00")).toEqual(week({ Fr: day, Sa: day, Su: day, Mo: day }));
  expect(parsed("We-We 10:00-14:00")).toEqual(week({ We: day }));
});

test("several rules separated by semicolons are all applied", () => {
  const weekday = [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }];
  expect(parsed("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual(
    week({ Mo: weekday, Tu: weekday, We: weekday, Th: weekday, Fr: weekday, Sa: [{ from: "09:00", to: "16:00" }] }),
  );
});

test("empty or only-space text is EMPTY at column 1, while spaces around tokens are ignored", () => {
  expect(parsed("  Mo , We 08:00 - 12:00  ")).toEqual(
    week({ Mo: [{ from: "08:00", to: "12:00" }], We: [{ from: "08:00", to: "12:00" }] }),
  );
  expectError("", "EMPTY", 1);
  expectError("    ", "EMPTY", 1);
});

test("text that ends too early is UNEXPECTED at its length plus one", () => {
  expectError("Mo 08:00-", "UNEXPECTED", 10);
  expectError("Mo", "UNEXPECTED", 3);
  expectError("Mo-Fr 08:00-12:00, ", "UNEXPECTED", 20);
});

test("a token that does not fit the format at its place, such as an empty rule, is UNEXPECTED at that token", () => {
  expectError("08:00-12:00", "UNEXPECTED", 1);
  expectError("Mo 08:00-noon", "UNEXPECTED", 10);
  expectError("Mo 08:00 12:00", "UNEXPECTED", 10);
  expectError("Mo Tu 08:00-12:00", "UNEXPECTED", 4);
  expectError("Mo off Tu off", "UNEXPECTED", 8);
  expectError("Mo off 08:00-12:00", "UNEXPECTED", 8);
  expectError("Mo off;", "UNEXPECTED", 8);
  expectError("Mo off;; Tu off", "UNEXPECTED", 8);
  expectError("; Mo off", "UNEXPECTED", 1);
});

test("a word where a day is expected that is not a day is UNKNOWN_DAY at that word", () => {
  expectError("mo 08:00-12:00", "UNKNOWN_DAY", 1);
  expectError("Mo-Fx 08:00-12:00", "UNKNOWN_DAY", 4);
  expectError("Mo, Thu 08:00-12:00", "UNKNOWN_DAY", 5);
  expectError("Mo off; off", "UNKNOWN_DAY", 9);
  expectError("Mo-off", "UNKNOWN_DAY", 4);
});

test("a malformed time is INVALID_TIME at that time, and 24:00 is valid only as an end", () => {
  expect(parsed("Sa 18:00-24:00")).toEqual(week({ Sa: [{ from: "18:00", to: "24:00" }] }));
  expectError("Mo 8:00-12:00", "INVALID_TIME", 4);
  expectError("Mo 08:00-1200", "INVALID_TIME", 10);
  expectError("Mo 08:00-12:000", "INVALID_TIME", 10);
  expectError("Mo 08:00:00-12:00", "INVALID_TIME", 4);
  expectError("Mo 08::0-12:00", "INVALID_TIME", 4);
  expectError("Mo 25:00-26:00", "INVALID_TIME", 4);
  expectError("Mo 08:00-12:60", "INVALID_TIME", 10);
  expectError("Mo 08:00-24:01", "INVALID_TIME", 10);
  expectError("Mo 24:00-24:00", "INVALID_TIME", 4);
  expectError("Mo 08", "INVALID_TIME", 4);
});

test("a range whose end is not later than its start is END_BEFORE_START at its start time", () => {
  expectError("Mo 12:00-08:00", "END_BEFORE_START", 4);
  expectError("Mo 08:00-12:00, 14:00 - 14:00", "END_BEFORE_START", 17);
});

test("ranges may touch, but a range overlapping an earlier one of the rule is OVERLAP at its start time", () => {
  expect(parsed("Mo 12:00-14:00,08:00-12:00")).toEqual(
    week({ Mo: [{ from: "08:00", to: "12:00" }, { from: "12:00", to: "14:00" }] }),
  );
  expectError("Mo 08:00-12:00,11:00-13:00", "OVERLAP", 16);
  expectError("Mo 14:00-18:00,08:00-12:00,07:00-20:00", "OVERLAP", 28);
  expectError("Mo 10:00-11:00,08:00-12:00", "OVERLAP", 16);
  expectError("Mo 08:00-12:00; Tu 08:00-12:00,09:00-10:00", "OVERLAP", 32);
});

test("a later rule replaces the hours of the days it names, but naming a day twice in one rule is DUPLICATE_DAY", () => {
  const day = [{ from: "08:00", to: "20:00" }];
  expect(parsed("Mo-Su 08:00-20:00; Su off")).toEqual(week({ Mo: day, Tu: day, We: day, Th: day, Fr: day, Sa: day }));
  const morning = [{ from: "08:00", to: "12:00" }];
  expect(parsed("Mo-Fr 08:00-12:00; We 14:00-18:00")).toEqual(
    week({ Mo: morning, Tu: morning, We: [{ from: "14:00", to: "18:00" }], Th: morning, Fr: morning }),
  );
  expectError("Mo,Mo off", "DUPLICATE_DAY", 4);
  expectError("Mo-Fr,We off", "DUPLICATE_DAY", 7);
  expectError("Mo,Fr-Mo off", "DUPLICATE_DAY", 4);
  expectError("Sa-Mo, Su off", "DUPLICATE_DAY", 8);
});

test("a character that belongs to no token is UNEXPECTED at that character", () => {
  expectError("Mo\n08:00-12:00", "UNEXPECTED", 3);
  expectError("Mo\t08:00-12:00", "UNEXPECTED", 3);
  expectError("Mo 08:00-12:00 #", "UNEXPECTED", 16);
  expectError("Mo 08:00–12:00", "UNEXPECTED", 9);
  expectError("Mo/Tu off", "UNEXPECTED", 3);
});
