# Opening hours parser: test list

**Hidden decision:** the grammar of the opening-hours text, how it is split into
tokens and which error (code and column) the first problem maps to; callers
only see a weekly schedule or one `OpeningHoursError`.

**Sketch A (chosen):** one function that returns the schedule or throws.

```ts
parseOpeningHours(text: string): WeeklyHours // throws OpeningHoursError
const hours = parseOpeningHours(form.value);
```

**Sketch B:** a result object, no exceptions.

```ts
parseOpeningHours(text: string): { ok: true; hours: WeeklyHours } | { ok: false; error: OpeningHoursError }
const result = parseOpeningHours(form.value); if (!result.ok) highlight(result.error.column);
```

Chosen: A, because a caller learns one function and one error class, and the
whole grammar, tokenizer and rule merging sit behind that single call.

## Behaviours (through `parseOpeningHours`)

- [x] one day with one range gives that range and all other six days closed
- [x] `off` closes the named day
- [x] several ranges in one rule are returned sorted by start time
- [x] a day list (`Mo,We`) applies the hours to each listed day
- [x] a day range (`Mo-Fr`) covers every day from first to last
- [x] a day range wraps around the week (`Fr-Mo`), `Mo-Mo` is Mo only
- [x] several rules separated by `;` are all applied
- [x] a later rule replaces the hours of every day it names (in the DUPLICATE_DAY test)
- [x] spaces between tokens and at both ends are ignored (in the EMPTY test)
- [x] touching ranges are allowed (in the OVERLAP test) and `24:00` is allowed as an end (in the INVALID_TIME test)
- [x] EMPTY for empty or only-space text, column 1
- [x] UNKNOWN_DAY for a word where a day is expected (incl. after `-`, `,`, `;`)
- [x] INVALID_TIME for malformed times (digits, hours, minutes, `24:00` as start)
- [x] END_BEFORE_START at the start time when end <= start
- [x] OVERLAP at the later-written range's start time
- [x] DUPLICATE_DAY at the day item naming an already named day
- [x] UNEXPECTED at length + 1 when the text ends too early
- [x] UNEXPECTED at an empty rule after `;` (in the UNEXPECTED token test)
- [x] UNEXPECTED at a character that belongs to no token (newline, tab, `#`, en dash)
- [x] UNEXPECTED at a token that does not fit (time where a day is expected, word where a time is expected, extra token after a rule)
- [x] the first problem from the left is the one reported: holds by construction (recursive descent in reading order); covered by the cases above, no separate red possible

Several behaviours already worked after an earlier green or refactor, so they
could not fail first on their own; they were folded into the error tests named
above, each of which failed first on its error assertions.
