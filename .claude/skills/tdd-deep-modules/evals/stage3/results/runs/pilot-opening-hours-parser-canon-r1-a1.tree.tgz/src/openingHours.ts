export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "other" | "end";

interface Token {
  kind: TokenKind;
  text: string;
  column: number;
}

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  const pattern = / +|(\p{L}+)|([0-9:]+)|([-,;])|(.)/suy;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(text)) !== null) {
    const column = match.index + 1;
    if (match[1] !== undefined) tokens.push({ kind: "word", text: match[1], column });
    else if (match[2] !== undefined) tokens.push({ kind: "time", text: match[2], column });
    else if (match[3] !== undefined) tokens.push({ kind: match[3] as TokenKind, text: match[3], column });
    else if (match[4] !== undefined) tokens.push({ kind: "other", text: match[4], column });
  }
  tokens.push({ kind: "end", text: "", column: text.length + 1 });
  return tokens;
}

class Parser {
  private position = 0;

  constructor(private readonly tokens: Token[]) {}

  parseSpec(): WeeklyHours {
    const hours = Object.fromEntries(DAYS.map((day) => [day, []])) as unknown as WeeklyHours;
    do this.parseRule(hours);
    while (this.accept(";"));
    this.expect("end");
    return hours;
  }

  private parseRule(hours: WeeklyHours): void {
    const days: Day[] = [];
    do this.parseDayItem(days);
    while (this.accept(","));
    const ranges = this.parseHours();
    for (const day of days) hours[day] = ranges.map((range) => ({ ...range }));
  }

  private parseHours(): TimeRange[] {
    if (this.peek().kind === "word" && this.peek().text === "off") {
      this.position++;
      return [];
    }
    const ranges: TimeRange[] = [];
    do {
      const column = this.peek().column;
      const range = this.parseRange();
      if (ranges.some((earlier) => range.from < earlier.to && earlier.from < range.to)) {
        throw new OpeningHoursError("OVERLAP", column, `Range ${range.from}-${range.to} overlaps an earlier range`);
      }
      ranges.push(range);
    } while (this.accept(","));
    return ranges.sort((a, b) => a.from.localeCompare(b.from));
  }

  private parseRange(): TimeRange {
    const start = this.expectTime(false);
    this.expect("-");
    const to = this.expectTime(true).text;
    if (to <= start.text) {
      throw new OpeningHoursError("END_BEFORE_START", start.column, `Range ends at ${to}, not after it starts`);
    }
    return { from: start.text, to };
  }

  private expectTime(isEnd: boolean): Token {
    const token = this.expect("time");
    const valid = /^([01][0-9]|2[0-3]):[0-5][0-9]$/.test(token.text) || (isEnd && token.text === "24:00");
    if (!valid) {
      throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    }
    return token;
  }

  /** Parses a day item and adds its days to `days`, the days already named in this rule. */
  private parseDayItem(days: Day[]): void {
    const column = this.peek().column;
    const first = this.expectDay();
    // Checked before reading on, so that the leftmost problem is reported.
    if (days.includes(first)) throw duplicateDay(first, column);
    const item = this.accept("-") ? dayRange(first, this.expectDay()) : [first];
    const duplicate = item.find((day) => days.includes(day));
    if (duplicate) throw duplicateDay(duplicate, column);
    days.push(...item);
  }

  private expectDay(): Day {
    const token = this.expect("word");
    if (!(DAYS as string[]).includes(token.text)) {
      throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    }
    return token.text as Day;
  }

  private peek(): Token {
    return this.tokens[this.position]!;
  }

  private accept(kind: TokenKind): boolean {
    if (this.peek().kind !== kind) return false;
    this.position++;
    return true;
  }

  private expect(kind: TokenKind): Token {
    const token = this.peek();
    if (token.kind !== kind) throw unexpected(token);
    this.position++;
    return token;
  }
}

/** The days from `first` to `last`, running forward and wrapping around the end of the week. */
function dayRange(first: Day, last: Day): Day[] {
  const start = DAYS.indexOf(first);
  const count = ((DAYS.indexOf(last) - start + 7) % 7) + 1;
  return Array.from({ length: count }, (_, i) => DAYS[(start + i) % 7]!);
}

function duplicateDay(day: Day, column: number): OpeningHoursError {
  return new OpeningHoursError("DUPLICATE_DAY", column, `${day} is already named in this rule`);
}

function unexpected(token: Token): OpeningHoursError {
  const what = token.kind === "end" ? "end of text" : `"${token.text}"`;
  return new OpeningHoursError("UNEXPECTED", token.column, `Unexpected ${what}`);
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) {
    throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  }
  return new Parser(tokenize(text)).parseSpec();
}
