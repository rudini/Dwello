import { describe, expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

function errorOf(text: string): { code: string; column: number } {
  try {
    parseOpeningHours(text);
  } catch (e) {
    if (e instanceof OpeningHoursError) return { code: e.code, column: e.column };
    throw e;
  }
  throw new Error(`expected "${text}" to fail`);
}

const closedWeek = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };

describe("parsing", () => {
  test("a single day with a single range", () => {
    expect(parseOpeningHours("Mo 08:00-12:00")).toEqual({
      ...closedWeek,
      Mo: [{ from: "08:00", to: "12:00" }],
    });
  });

  test("a day that is off", () => {
    expect(parseOpeningHours("Mo off")).toEqual(closedWeek);
  });

  test("a list of days", () => {
    const morning = [{ from: "08:00", to: "12:00" }];
    expect(parseOpeningHours("Mo,We,Su 08:00-12:00")).toEqual({
      ...closedWeek,
      Mo: morning,
      We: morning,
      Su: morning,
    });
  });

  test("day ranges run forward and may wrap around the week", () => {
    const morning = [{ from: "08:00", to: "12:00" }];
    expect(parseOpeningHours("Tu-Th 08:00-12:00")).toEqual({ ...closedWeek, Tu: morning, We: morning, Th: morning });
    expect(parseOpeningHours("Fr-Mo 08:00-12:00")).toEqual({ ...closedWeek, Fr: morning, Sa: morning, Su: morning, Mo: morning });
    expect(parseOpeningHours("We-We 08:00-12:00")).toEqual({ ...closedWeek, We: morning });
    expect(parseOpeningHours("Mo,Sa-Su 08:00-12:00")).toEqual({ ...closedWeek, Mo: morning, Sa: morning, Su: morning });
  });

  test("several rules; later rules replace the hours of the days they name", () => {
    const morning = [{ from: "08:00", to: "12:00" }];
    const afternoon = [{ from: "14:00", to: "18:00" }];
    expect(parseOpeningHours("Mo-Fr 08:00-12:00;We 14:00-18:00")).toEqual({
      ...closedWeek, Mo: morning, Tu: morning, We: afternoon, Th: morning, Fr: morning,
    });
    expect(parseOpeningHours("Mo-Su 08:00-12:00;Su off")).toEqual({
      ...closedWeek, Mo: morning, Tu: morning, We: morning, Th: morning, Fr: morning, Sa: morning,
    });
  });

  test("spaces between tokens carry no meaning", () => {
    const morning = [{ from: "08:00", to: "12:00" }];
    const expected = { ...closedWeek, Mo: morning, We: morning, Th: morning, Fr: morning };
    expect(parseOpeningHours("  Mo , We - Fr  08:00 - 12:00 ; Su off  ")).toEqual(expected);
    expect(parseOpeningHours("Mo,We-Fr08:00-12:00;Su off")).toEqual(expected);
  });

  test("24:00 is allowed as the end of a range", () => {
    expect(parseOpeningHours("Sa 18:00-24:00")).toEqual({ ...closedWeek, Sa: [{ from: "18:00", to: "24:00" }] });
  });

  test("the example from the form", () => {
    const weekday = [
      { from: "08:00", to: "12:00" },
      { from: "13:30", to: "18:30" },
    ];
    expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
      Mo: weekday, Tu: weekday, We: weekday, Th: weekday, Fr: weekday,
      Sa: [{ from: "09:00", to: "16:00" }],
      Su: [],
    });
  });

  test("days do not share their range arrays", () => {
    const hours = parseOpeningHours("Mo,We 08:00-12:00");
    hours.Mo.push({ from: "13:00", to: "14:00" });
    expect(hours.We).toEqual([{ from: "08:00", to: "12:00" }]);
  });

  test("several ranges are sorted by start time", () => {
    expect(parseOpeningHours("Mo 13:30-18:30,08:00-12:00")).toEqual({
      ...closedWeek,
      Mo: [
        { from: "08:00", to: "12:00" },
        { from: "13:30", to: "18:30" },
      ],
    });
  });
});

describe("errors", () => {
  test("empty text", () => {
    expect(errorOf("")).toEqual({ code: "EMPTY", column: 1 });
    expect(errorOf("   ")).toEqual({ code: "EMPTY", column: 1 });
  });

  test("unknown day", () => {
    expect(errorOf("Mo-Fx 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 4 });
    expect(errorOf(" mo off")).toEqual({ code: "UNKNOWN_DAY", column: 2 });
    expect(errorOf("Mo off; off")).toEqual({ code: "UNKNOWN_DAY", column: 9 });
    expect(errorOf("Mo,Tuesday off")).toEqual({ code: "UNKNOWN_DAY", column: 4 });
  });

  test("invalid time", () => {
    for (const time of ["8:00", "08:0", "0800", "08:00:00", "25:00", "08:60", ":", "24:01"]) {
      expect(errorOf(`Mo ${time}-23:00`)).toEqual({ code: "INVALID_TIME", column: 4 });
      expect(errorOf(`Mo 00:00-${time}`)).toEqual({ code: "INVALID_TIME", column: 10 });
    }
    expect(errorOf("Mo 24:00-24:00")).toEqual({ code: "INVALID_TIME", column: 4 });
    expect(errorOf("Mo 23:00-24:00,24:00-24:00")).toEqual({ code: "INVALID_TIME", column: 16 });
  });

  test("end not later than start", () => {
    expect(errorOf("Mo 12:00-08:00")).toEqual({ code: "END_BEFORE_START", column: 4 });
    expect(errorOf("Mo 08:00-08:00")).toEqual({ code: "END_BEFORE_START", column: 4 });
    expect(errorOf("Mo 06:00-07:00, 18:00 - 09:59 ; x")).toEqual({ code: "END_BEFORE_START", column: 17 });
  });

  test("overlapping ranges within a rule", () => {
    expect(errorOf("Mo 08:00-12:00,11:00-14:00")).toEqual({ code: "OVERLAP", column: 16 });
    expect(errorOf("Mo 11:00-14:00,08:00-12:00")).toEqual({ code: "OVERLAP", column: 16 });
    expect(errorOf("Mo 08:00-18:00,10:00-11:00")).toEqual({ code: "OVERLAP", column: 16 });
    expect(errorOf("Mo 08:00-09:00,10:00-11:00,07:00-20:00")).toEqual({ code: "OVERLAP", column: 28 });
    expect(errorOf("Mo 08:00-09:00,08:00-09:00")).toEqual({ code: "OVERLAP", column: 16 });
  });

  test("duplicate day within a rule", () => {
    expect(errorOf("Mo,Mo off")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
    expect(errorOf("Mo-We,Tu off")).toEqual({ code: "DUPLICATE_DAY", column: 7 });
    expect(errorOf("Mo,Fr-Mo off")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
    expect(errorOf("Tu,Fr-We off")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
    expect(errorOf("We,Mo-Fr off")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
    expect(errorOf("Mo,Mo-Xx off")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
    expect(errorOf("Mo,Fr-Xx off")).toEqual({ code: "UNKNOWN_DAY", column: 7 });
  });

  test("unexpected token, character or end of text", () => {
    const cases: [string, number][] = [
      ["Mo 08:00-", 10],
      ["Mo off;", 8],
      ["Mo off; ", 9],
      ["Mo", 3],
      ["Mo-", 4],
      ["Mo,", 4],
      ["Mo 08:00", 9],
      ["Mo 08:00-12:00,", 16],
      ["; Mo off", 1],
      ["Mo off;;Tu off", 8],
      ["08:00-12:00", 1],
      ["Mo off off", 8],
      ["Mo Off", 4],
      ["Mo Tu off", 4],
      ["Mo-08:00 off", 4],
      ["Mo,-Tu off", 4],
      ["Mo 08:00--12:00", 10],
      ["Mo 08:00-ab", 10],
      ["Mo 08:00-12:00,Tu off", 16],
      ["Mo 08:00-12:00 13:00-14:00", 16],
      ["Mo # off", 4],
      ["Mo\toff", 3],
      ["Mo off\n", 7],
      ["Mo off,", 7],
    ];
    for (const [text, column] of cases) {
      expect({ text, ...errorOf(text) }).toEqual({ text, code: "UNEXPECTED", column });
    }
  });

  test("the first problem from the left wins", () => {
    expect(errorOf("Mo 25:00-12:00 #")).toEqual({ code: "INVALID_TIME", column: 4 });
    expect(errorOf("Mo 12:00-08:00 #")).toEqual({ code: "END_BEFORE_START", column: 4 });
    expect(errorOf("Mo # 25:00")).toEqual({ code: "UNEXPECTED", column: 4 });
    expect(errorOf("Mo off; Xx 12:00-08:00")).toEqual({ code: "UNKNOWN_DAY", column: 9 });
  });

  test("the same day in different rules is fine", () => {
    expect(parseOpeningHours("Mo-Fr off; Fr,Mo 08:00-09:00").Fr).toEqual([{ from: "08:00", to: "09:00" }]);
  });

  test("touching ranges and overlaps in different rules are fine", () => {
    expect(parseOpeningHours("Mo 12:00-14:00,08:00-12:00").Mo).toEqual([
      { from: "08:00", to: "12:00" },
      { from: "12:00", to: "14:00" },
    ]);
    expect(parseOpeningHours("Mo 08:00-12:00; Mo 10:00-14:00").Mo).toEqual([{ from: "10:00", to: "14:00" }]);
  });
});
