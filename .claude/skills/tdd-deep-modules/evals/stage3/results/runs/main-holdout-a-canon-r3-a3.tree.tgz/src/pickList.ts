export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  items: { sku: string; qty: number }[];
  line: number;
}

/**
 * Parses the whole text before reporting, because an empty order is only noticed
 * below its ORDER line; the problem with the lowest line number is thrown.
 */
function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  for (const [index, rawLine] of ordersText.split("\n").entries()) {
    const lineNumber = index + 1;
    const line = rawLine.trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = /^ORDER +([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (orderMatch) {
      const id = orderMatch[1];
      if (orders.some((order) => order.id === id)) {
        problems.push(new OrderFormatError(lineNumber, `order id ${id} already used`));
      }
      orders.push({ id, priority: orderMatch[2] !== undefined, items: [], line: lineNumber });
      continue;
    }
    const itemMatch = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNumber, `cannot read "${line}"`));
      continue;
    }
    const order = orders.at(-1);
    if (!order) {
      problems.push(new OrderFormatError(lineNumber, "item before the first ORDER"));
      continue;
    }
    const [, sku, qty] = itemMatch;
    const existing = order.items.find((item) => item.sku === sku);
    if (existing) existing.qty += Number(qty);
    else order.items.push({ sku, qty: Number(qty) });
  }
  for (const order of orders) {
    if (order.items.length === 0) problems.push(new OrderFormatError(order.line, `order ${order.id} has no items`));
  }
  if (problems.length > 0) {
    throw problems.reduce((first, problem) => (problem.line < first.line ? problem : first));
  }
  return orders;
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Earliest best-before first, lots without a date last, ties by bin code. */
function compareLots(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const lots = stock
    .map((lot) => ({ ...lot }))
    .sort(compareLots);
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let wanted = item.qty;
      for (const lot of lots) {
        if (wanted === 0) break;
        if (lot.sku !== item.sku || lot.qty <= 0) continue;
        const taken = Math.min(wanted, lot.qty);
        lot.qty -= taken;
        wanted -= taken;
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (wanted > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: wanted });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}

/** Serpentine: aisles A→Z, racks up in odd visited aisles and down in even ones, levels up. */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const location = (bin: string) => {
    const [aisle, rack, level] = bin.split("-");
    return { aisle, rack: Number(rack), level: Number(level) };
  };
  const visitedAisles = [...new Set(picks.map((p) => location(p.bin).aisle))].sort(compareStrings);
  const descending = new Set(visitedAisles.filter((_, i) => i % 2 === 1));
  return [...picks].sort((a, b) => {
    const la = location(a.bin);
    const lb = location(b.bin);
    if (la.aisle !== lb.aisle) return compareStrings(la.aisle, lb.aisle);
    if (la.rack !== lb.rack) return descending.has(la.aisle) ? lb.rack - la.rack : la.rack - lb.rack;
    return la.level - lb.level;
  });
}
