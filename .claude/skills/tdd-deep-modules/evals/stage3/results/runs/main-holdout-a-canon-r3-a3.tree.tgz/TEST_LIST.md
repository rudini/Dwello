# Test list for `buildPickList`

## Allocation
- [x] one order, one item, one lot covering it → one pick, no shortages
- [x] no orders (empty text) → empty pick list
- [x] blank lines, `#` comments and surrounding whitespace are ignored
- [x] item split over several lots, earliest `expires` first
- [x] lots with `expires: null` come after dated lots
- [x] equal expiry → bin code decides
- [x] lots of other SKUs and empty lots (qty 0) are not used
- [x] not enough stock → everything available picked + shortage
- [x] no stock at all for a SKU → shortage only
- [x] stock taken by an earlier order is not available to later ones
- [x] priority orders are served first (in text order), then the rest
- [x] shortages listed in serving order
- [x] repeated SKU in an order is summed and keeps its first position
- [x] the `stock` array and its objects are not modified

## Walking order
- [x] aisles visited alphabetically
- [x] racks ascending in 1st/3rd/... visited aisle, descending in 2nd/4th/...
- [x] only aisles with picks count for the serpentine
- [x] levels ascending within a rack
- [x] picks at the same bin keep allocation order

## Format errors (`OrderFormatError` with 1-based line)
- [x] item line before the first `ORDER`
- [x] duplicate order id
- [x] `ORDER` without items (reported at its `ORDER` line), also as last order
- [x] invalid lines: `x0`, `x03`, lowercase SKU, missing `x`, missing space
- [x] invalid `ORDER` lines: no id, bad id chars, `!` glued to the id, trailing junk
- [x] line numbers count blank and comment lines
- [x] the first problem from the top is reported (e.g. empty order before a later bad line)

## Discovered along the way
- [x] an unreadable line is no item line, so the order above it counts as empty (reported first)
- [x] end-to-end: the example export from the spec, with Windows line endings
