import { describe, expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("the example morning export", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\r\n");
  const stock = [
    lot("B-04-1", "PASTA-1KG", 10, "2027-06-01"),
    lot("A-02-1", "OLIVE-500", 2, "2027-02-01"),
    lot("A-07-2", "OLIVE-500", 2, "2026-12-01"),
  ];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-07-2", sku: "OLIVE-500", qty: 2, orderId: "1002" },
      { bin: "B-04-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 1 }],
  });
});

describe("allocation", () => {
  test("one order, one item, one lot covering it", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
    expect(result).toEqual({
      picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
      shortages: [],
    });
  });

  test("no orders gives an empty pick list", () => {
    expect(buildPickList("", [lot("A-01-1", "OLIVE-500", 10)])).toEqual({ picks: [], shortages: [] });
  });

  test("blank lines, comments and surrounding whitespace are ignored", () => {
    const text = "# export 2026-10-12 06:00\n\n   \n\tORDER 1001  \n# OLIVE-500 x9\n  OLIVE-500    x3\t\n\n";
    expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 10)]).picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ]);
  });

  test("an item is split over several lots, earliest expiry first", () => {
    const stock = [
      lot("A-01-1", "OLIVE-500", 5, "2027-03-01"),
      lot("A-01-2", "OLIVE-500", 2, "2026-11-15"),
      lot("A-01-3", "OLIVE-500", 2, "2027-01-10"),
    ];
    const result = buildPickList("ORDER 1\nOLIVE-500 x7", stock);
    expect(result.picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1" },
      { bin: "A-01-2", sku: "OLIVE-500", qty: 2, orderId: "1" },
      { bin: "A-01-3", sku: "OLIVE-500", qty: 2, orderId: "1" },
    ]);
    expect(result.shortages).toEqual([]);
  });

  test("lots without expiry are used after all dated lots", () => {
    const stock = [lot("A-01-1", "SALT", 5, null), lot("A-01-2", "SALT", 2, "2030-01-01")];
    expect(buildPickList("ORDER 1\nSALT x3", stock).picks).toEqual([
      { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "1" },
      { bin: "A-01-2", sku: "SALT", qty: 2, orderId: "1" },
    ]);
  });

  test("equal expiry is decided by bin code", () => {
    const stock = [
      lot("A-01-3", "SALT", 5, "2027-01-01"),
      lot("A-01-2", "SALT", 5, "2027-01-01"),
      lot("A-01-4", "PEPPER", 5, null),
      lot("A-01-5", "PEPPER", 5, null),
    ];
    expect(buildPickList("ORDER 1\nSALT x6\nPEPPER x6", stock).picks).toEqual([
      { bin: "A-01-2", sku: "SALT", qty: 5, orderId: "1" },
      { bin: "A-01-3", sku: "SALT", qty: 1, orderId: "1" },
      { bin: "A-01-4", sku: "PEPPER", qty: 5, orderId: "1" },
      { bin: "A-01-5", sku: "PEPPER", qty: 1, orderId: "1" },
    ]);
  });

  test("empty lots and lots of other SKUs are not used", () => {
    const stock = [
      lot("A-01-1", "SALT", 0, "2026-10-13"),
      lot("A-01-2", "PEPPER", 9, "2026-10-13"),
      lot("A-01-3", "SALT", 4, "2027-01-01"),
    ];
    expect(buildPickList("ORDER 1\nSALT x2", stock)).toEqual({
      picks: [{ bin: "A-01-3", sku: "SALT", qty: 2, orderId: "1" }],
      shortages: [],
    });
  });

  test("not enough stock: everything available is picked and the rest reported", () => {
    const stock = [lot("A-01-1", "SALT", 2, "2027-01-01"), lot("A-01-2", "SALT", 1, null)];
    expect(buildPickList("ORDER 7\nSALT x5", stock)).toEqual({
      picks: [
        { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "7" },
        { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "7" },
      ],
      shortages: [{ orderId: "7", sku: "SALT", missing: 2 }],
    });
  });

  test("no stock at all for a SKU gives only a shortage", () => {
    expect(buildPickList("ORDER 7\nSALT x5", [lot("A-01-1", "PEPPER", 9)])).toEqual({
      picks: [],
      shortages: [{ orderId: "7", sku: "SALT", missing: 5 }],
    });
  });

  test("stock taken by an earlier order is not available to later ones", () => {
    const stock = [lot("A-01-1", "SALT", 3, "2027-01-01"), lot("A-01-2", "SALT", 3, "2028-01-01")];
    expect(buildPickList("ORDER 1\nSALT x4\nORDER 2\nSALT x4", stock)).toEqual({
      picks: [
        { bin: "A-01-1", sku: "SALT", qty: 3, orderId: "1" },
        { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "1" },
        { bin: "A-01-2", sku: "SALT", qty: 2, orderId: "2" },
      ],
      shortages: [{ orderId: "2", sku: "SALT", missing: 2 }],
    });
  });

  test("priority orders are served first in text order, then the others in text order", () => {
    const text = [
      "ORDER N1",
      "SALT x1",
      "ORDER P1 !",
      "SALT x1",
      "ORDER N2",
      "SALT x1",
      "ORDER P2    !",
      "SALT x1",
    ].join("\n");
    const result = buildPickList(text, [lot("A-01-1", "SALT", 3)]);
    expect(result.picks.map((p) => p.orderId)).toEqual(["P1", "P2", "N1"]);
    expect(result.shortages).toEqual([{ orderId: "N2", sku: "SALT", missing: 1 }]);
  });

  test("shortages are listed in serving order", () => {
    const text = "ORDER N1\nPEPPER x1\nSALT x1\nORDER P1 !\nSALT x2\nPEPPER x3";
    expect(buildPickList(text, []).shortages).toEqual([
      { orderId: "P1", sku: "SALT", missing: 2 },
      { orderId: "P1", sku: "PEPPER", missing: 3 },
      { orderId: "N1", sku: "PEPPER", missing: 1 },
      { orderId: "N1", sku: "SALT", missing: 1 },
    ]);
  });

  test("a repeated SKU is summed and keeps the position of its first appearance", () => {
    const text = "ORDER 1\nSALT x1\nPEPPER x1\nSALT x2";
    const stock = [lot("A-01-1", "SALT", 2, "2027-01-01"), lot("A-01-2", "SALT", 5, "2028-01-01")];
    expect(buildPickList(text, stock)).toEqual({
      picks: [
        { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "1" },
        { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "1" },
      ],
      shortages: [{ orderId: "1", sku: "PEPPER", missing: 1 }],
    });
    expect(buildPickList(text, []).shortages).toEqual([
      { orderId: "1", sku: "SALT", missing: 3 },
      { orderId: "1", sku: "PEPPER", missing: 1 },
    ]);
  });

  test("the stock array and its lots are not modified", () => {
    const stock = [lot("B-02-1", "SALT", 2, null), lot("A-01-1", "SALT", 2, "2027-01-01")];
    const snapshot = structuredClone(stock);
    const lotObjects = [...stock];
    buildPickList("ORDER 1\nSALT x3", stock);
    expect(stock).toEqual(snapshot);
    expect(stock[0]).toBe(lotObjects[0]);
    expect(stock[1]).toBe(lotObjects[1]);
  });
});

describe("walking order", () => {
  /** One order taking one unit of each given SKU; lot i holds SKU "S<i>" in bins[i]. */
  const walk = (bins: string[]): string[] => {
    const stock = bins.map((bin, i) => lot(bin, `S${i}`, 1));
    const text = ["ORDER 1", ...bins.map((_, i) => `S${i} x1`)].join("\n");
    return buildPickList(text, stock).picks.map((p) => p.bin);
  };

  test("aisles alphabetically, racks alternating up and down, levels ascending", () => {
    const bins = ["C-01-1", "B-01-2", "A-10-1", "B-10-1", "A-02-3", "C-12-1", "A-02-1", "B-01-1"];
    expect(walk(bins)).toEqual(["A-02-1", "A-02-3", "A-10-1", "B-10-1", "B-01-1", "B-01-2", "C-01-1", "C-12-1"]);
  });

  test("only aisles that contain a pick count for the serpentine", () => {
    const stock = [
      lot("A-01-1", "SALT", 5),
      lot("B-01-1", "UNUSED", 5),
      lot("C-01-1", "PEPPER", 1),
      lot("C-05-1", "OIL", 1),
      lot("D-01-1", "RICE", 1),
      lot("D-05-1", "PASTA", 1),
    ];
    const text = "ORDER 1\nSALT x1\nPEPPER x1\nOIL x1\nRICE x1\nPASTA x1";
    expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual([
      "A-01-1",
      "C-05-1",
      "C-01-1",
      "D-01-1",
      "D-05-1",
    ]);
  });

  test("picks at the same bin keep their allocation order", () => {
    const stock = [lot("A-01-1", "SALT", 5), lot("A-01-1", "PEPPER", 5)];
    const text = "ORDER 1\nPEPPER x1\nORDER 2 !\nSALT x1\nPEPPER x1\nORDER 3\nSALT x1";
    expect(buildPickList(text, stock).picks).toEqual([
      { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "2" },
      { bin: "A-01-1", sku: "PEPPER", qty: 1, orderId: "2" },
      { bin: "A-01-1", sku: "PEPPER", qty: 1, orderId: "1" },
      { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "3" },
    ]);
  });
});

describe("format errors", () => {
  const errorLine = (lines: string[]): number => {
    try {
      buildPickList(lines.join("\n"), []);
    } catch (error) {
      expect(error).toBeInstanceOf(OrderFormatError);
      return (error as OrderFormatError).line;
    }
    throw new Error("expected an OrderFormatError");
  };

  test("an item line before the first ORDER", () => {
    expect(errorLine(["# export", "", "SALT x1", "ORDER 1", "SALT x1"])).toBe(3);
  });

  test("an ORDER id that was already used", () => {
    expect(errorLine(["ORDER 1", "SALT x1", "ORDER 2", "SALT x1", "ORDER 1 !", "SALT x1"])).toBe(5);
  });

  test("an ORDER without items is reported at its ORDER line", () => {
    expect(errorLine(["ORDER 1", "SALT x1", "ORDER 2 !", "# nothing", "", "ORDER 3", "SALT x1"])).toBe(3);
    expect(errorLine(["ORDER 1", "SALT x1", "ORDER 2", "", "# end"])).toBe(3);
  });

  test.each([
    ["zero quantity", "SALT x0"],
    ["leading zero", "SALT x03"],
    ["negative quantity", "SALT x-1"],
    ["fractional quantity", "SALT x1.5"],
    ["lowercase SKU", "salt x1"],
    ["missing x", "SALT 1"],
    ["uppercase X", "SALT X1"],
    ["no space before x", "SALTx1"],
    ["space after x", "SALT x 1"],
    ["missing quantity", "SALT x"],
    ["trailing junk", "SALT x1 pcs"],
    ["bad SKU character", "SALT_FINE x1"],
  ])("an invalid item line (%s)", (_, badLine) => {
    expect(errorLine(["ORDER 1", "PEPPER x1", badLine, "OIL x1"])).toBe(3);
  });

  test.each([
    ["no id", "ORDER"],
    ["no id but priority", "ORDER !"],
    ["bad id character", "ORDER 10_02"],
    ["priority mark glued to the id", "ORDER 1002!"],
    ["trailing junk", "ORDER 1002 ! now"],
    ["two ids", "ORDER 1002 1003"],
    ["lowercase keyword", "order 1002"],
    ["no space after keyword", "ORDER1002"],
  ])("an invalid ORDER line (%s)", (_, badLine) => {
    expect(errorLine(["ORDER 1", "PEPPER x1", badLine, "OIL x1"])).toBe(3);
  });

  test("the first problem from the top is reported", () => {
    expect(errorLine(["ORDER 1", "ORDER 2", "SALT x1", "SALT x0"])).toBe(1);
    expect(errorLine(["ORDER 1", "SALT x1", "ORDER 1", "SALT x0", "ORDER 3"])).toBe(3);
    // an unreadable line is no item line, so the order above it is empty
    expect(errorLine(["# export", "ORDER 1", "salt x1", "ORDER 2", "SALT x1"])).toBe(2);
    expect(errorLine(["ORDER 1", "SALT x1", "ORDER 2", "PEPPER x1", "oil x1"])).toBe(5);
  });

  test("valid ORDER lines with mixed-case ids and extra spaces", () => {
    const text = "ORDER ab-12\nSALT x1\nORDER   Xy-9   !\nSALT x1";
    expect(buildPickList(text, []).shortages.map((s) => s.orderId)).toEqual(["Xy-9", "ab-12"]);
  });
});
