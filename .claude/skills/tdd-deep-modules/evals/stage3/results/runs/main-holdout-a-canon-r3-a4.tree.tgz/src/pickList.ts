export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Item {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: Item[];
}

/**
 * Problems are collected rather than thrown immediately: an empty order is only
 * noticed after the lines below it, yet it may be the first problem from the top.
 */
function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  const lines = ordersText.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const lineNumber = index + 1;
    const line = lines[index]!.trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = /^ORDER ([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (orderMatch) {
      checkNotEmpty(orders, problems);
      if (orders.some((o) => o.id === orderMatch[1])) {
        problems.push(new OrderFormatError(lineNumber, `order id ${orderMatch[1]} already used`));
      }
      orders.push({ id: orderMatch[1]!, priority: orderMatch[2] !== undefined, line: lineNumber, items: [] });
      continue;
    }
    const itemMatch = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNumber, `unrecognized line "${line}"`));
      continue;
    }
    const [, sku, qty] = itemMatch;
    const current = orders[orders.length - 1];
    if (!current) {
      problems.push(new OrderFormatError(lineNumber, "item line before the first ORDER"));
      continue;
    }
    const existing = current.items.find((i) => i.sku === sku);
    if (existing) existing.qty += Number(qty);
    else current.items.push({ sku: sku!, qty: Number(qty) });
  }
  checkNotEmpty(orders, problems);
  if (problems.length > 0) {
    throw problems.reduce((first, p) => (p.line < first.line ? p : first));
  }
  return orders;
}

/** The latest order is complete; it must have received at least one item. */
function checkNotEmpty(orders: Order[], problems: OrderFormatError[]): void {
  const last = orders[orders.length - 1];
  if (last && last.items.length === 0) {
    problems.push(new OrderFormatError(last.line, `order ${last.id} has no items`));
  }
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** First expiring first, undated lots last, ties by bin code. */
function byExpiryThenBin(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "", level = ""] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/**
 * Serpentine: visited aisles alphabetically, racks ascending in the 1st, 3rd, ...
 * visited aisle and descending in the others, levels ascending. The sort is
 * stable, so picks at the same bin keep their allocation order.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((p) => parseBin(p.bin).aisle))].sort(compareStrings);
  return [...picks].sort((a, b) => {
    const binA = parseBin(a.bin);
    const binB = parseBin(b.bin);
    if (binA.aisle !== binB.aisle) return compareStrings(binA.aisle, binB.aisle);
    if (binA.rack !== binB.rack) {
      const ascending = aisles.indexOf(binA.aisle) % 2 === 0;
      return ascending ? binA.rack - binB.rack : binB.rack - binA.rack;
    }
    return binA.level - binB.level;
  });
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);
  // copies track the remaining quantity without touching the caller's stock
  const lots = stock.map((l) => ({ ...l })).sort(byExpiryThenBin);
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const source of lots) {
        if (needed === 0) break;
        if (source.sku !== item.sku || source.qty === 0) continue;
        const taken = Math.min(needed, source.qty);
        source.qty -= taken;
        needed -= taken;
        picks.push({ bin: source.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}
