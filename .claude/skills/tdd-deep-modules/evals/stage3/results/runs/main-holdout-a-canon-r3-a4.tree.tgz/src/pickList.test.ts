import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

// Test list:
// [x] empty text -> empty pick list
// [x] one order, one item, one lot -> one pick
// [x] comments and blank lines are ignored
// [x] no stock -> shortage for the whole quantity
// [x] partial stock -> pick what is there plus shortage
// [x] FEFO: earliest expiry first, one pick per lot touched
// [x] null expiry after dated lots; ties broken by bin
// [x] stock taken by earlier orders is gone for later ones
// [x] priority orders are served first, in text order
// [x] duplicate SKU within an order is summed at first position
// [x] errors: item before ORDER, duplicate id, empty ORDER, malformed lines
// [x] the first problem from the top is reported
// [x] serpentine walking order of picks
// [x] aisles without picks do not count for the serpentine (discovered)
// [x] picks at the same bin keep allocation order
// [x] stock input is not modified
// [x] empty lots yield no picks (discovered)
// [x] end-to-end: the morning export example (discovered)

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({ bin, sku, qty, expires });

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("empty text gives an empty pick list", () => {
  expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
});

test("one order with one item takes it from the matching lot", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("comments and blank lines are ignored", () => {
  const text = "# export 2026-10-12 06:00\n\nORDER 1001\n   \n  # note\n  OLIVE-500 x3\n";
  const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result.picks).toEqual([{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }]);
});

test("an item without any stock is reported as shortage", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "PASTA-1KG", 10)]);
  expect(result).toEqual({ picks: [], shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }] });
});

test("partial stock is picked and the rest reported as shortage", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x5", [lot("A-01-1", "OLIVE-500", 2)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
  });
});

test("lots with the earliest best-before date are used first", () => {
  const stock = [
    lot("A-01-1", "OLIVE-500", 4, "2027-03-01"),
    lot("A-01-2", "OLIVE-500", 4, "2026-11-01"),
    lot("A-01-3", "OLIVE-500", 4, "2027-01-01"),
  ];
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x6", stock);
  expect(result.picks).toEqual([
    { bin: "A-01-2", sku: "OLIVE-500", qty: 4, orderId: "1001" },
    { bin: "A-01-3", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("undated lots come after dated ones; ties are broken by bin", () => {
  const stock = [
    lot("A-01-1", "SALT", 1, null),
    lot("A-01-4", "SALT", 1, "2027-01-01"),
    lot("A-01-3", "SALT", 1, "2027-01-01"),
    lot("A-01-0", "SALT", 1, null),
  ];
  const result = buildPickList("ORDER 1001\n  SALT x3", stock);
  expect(result.picks.map((p) => p.bin).sort()).toEqual(["A-01-0", "A-01-3", "A-01-4"]);
});

test("stock taken by an earlier order is no longer available", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n  OLIVE-500 x3";
  const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 4)]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    ],
    shortages: [{ orderId: "1002", sku: "OLIVE-500", missing: 2 }],
  });
});

test("priority orders are served first, in text order", () => {
  const text = [
    "ORDER 1001",
    "  OLIVE-500 x1",
    "ORDER 1002 !",
    "  OLIVE-500 x1",
    "ORDER 1003",
    "  OLIVE-500 x1",
    "ORDER 1004   !",
    "  OLIVE-500 x1",
  ].join("\n");
  const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 2)]);
  expect(result.picks.map((p) => p.orderId)).toEqual(["1002", "1004"]);
  expect(result.shortages.map((s) => s.orderId)).toEqual(["1001", "1003"]);
});

test("a SKU repeated within an order is summed at its first position", () => {
  const text = "ORDER 1001\n  OLIVE-500 x1\n  PASTA-1KG x1\n  OLIVE-500 x2";
  const result = buildPickList(text, []);
  expect(result.shortages).toEqual([
    { orderId: "1001", sku: "OLIVE-500", missing: 3 },
    { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
  ]);
});

function errorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  return undefined;
}

test("an item line before the first ORDER is an error", () => {
  expect(errorLine("# export\n\n  OLIVE-500 x3\nORDER 1001\n  OLIVE-500 x1")).toBe(3);
});

test("an ORDER id used twice is an error", () => {
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n  OLIVE-500 x1\nORDER 1001 !\n  OLIVE-500 x1")).toBe(5);
});

test("an ORDER without items is reported at its ORDER line", () => {
  expect(errorLine("ORDER 1001\n# nothing\n\nORDER 1002\n  OLIVE-500 x1")).toBe(1);
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002 !\n\n")).toBe(3);
});

test.each([
  "OLIVE-500 x0",
  "OLIVE-500 x03",
  "olive-500 x3",
  "OLIVE-500 3",
  "OLIVE-500x3",
  "OLIVE-500 x-3",
  "OLIVE-500 x1.5",
  "OLIVE_500 x3",
  "ORDER 1003!",
  "ORDER 10 03",
  "ORDER",
  "order 1003",
  "ORDER 1003 ! !",
])("malformed line %p is an error", (bad) => {
  expect(errorLine(`ORDER 1001\n  OLIVE-500 x1\n  ${bad}\n  PASTA-1KG x1`)).toBe(3);
});

test("the first problem from the top is reported", () => {
  // the order on line 2 has no item lines; the malformed line below it comes later
  expect(errorLine("# export\nORDER 1001\n  OLIVE-500 x0\nORDER 1002\n  OLIVE-500 x1")).toBe(2);
  expect(errorLine("# export\nORDER 1001\n  OLIVE-500 x0\n")).toBe(2);
  // an empty order comes before the duplicate id that follows it
  expect(errorLine("ORDER 1001\nORDER 1001\n  OLIVE-500 x1")).toBe(1);
  // a malformed line comes before a later duplicate
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\n  bad\nORDER 1001\n  OLIVE-500 x1")).toBe(3);
});

test("picks follow the serpentine walk through the visited aisles", () => {
  const bins = ["D-01-1", "A-02-1", "C-01-2", "A-10-1", "D-07-1", "A-02-0", "C-12-1", "B-05-1", "B-03-1", "C-01-1"];
  // aisle A ascending, B descending, C ascending, D descending; levels always ascending
  const walk = ["A-02-0", "A-02-1", "A-10-1", "B-05-1", "B-03-1", "C-01-1", "C-01-2", "C-12-1", "D-07-1", "D-01-1"];
  const stock = bins.map((bin) => lot(bin, `SKU-${bin}`, 1));
  const text = "ORDER 1001\n" + bins.map((bin) => `  SKU-${bin} x1`).join("\n");
  expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual(walk);
});

test("aisles without picks do not count for the serpentine", () => {
  const stock = [lot("A-01-1", "X", 1), lot("A-02-1", "X", 1), lot("B-09-1", "Y", 5), lot("C-01-1", "Z", 1), lot("C-02-1", "Z", 1)];
  // aisle B has stock but no picks: C is the 2nd visited aisle and is walked descending
  const result = buildPickList("ORDER 1001\n  X x2\n  Z x2", stock);
  expect(result.picks.map((p) => p.bin)).toEqual(["A-01-1", "A-02-1", "C-02-1", "C-01-1"]);
});

test("picks at the same bin keep their allocation order", () => {
  const text = "ORDER 1001\n  OLIVE-500 x1\nORDER 1002 !\n  OLIVE-500 x1\nORDER 1003\n  OLIVE-500 x1";
  const stock = [lot("B-04-1", "OLIVE-500", 10), lot("A-01-1", "PASTA-1KG", 1)];
  const result = buildPickList(text + "\n  PASTA-1KG x1", stock);
  expect(result.picks.map((p) => `${p.bin} ${p.orderId}`)).toEqual([
    "A-01-1 1003",
    "B-04-1 1002",
    "B-04-1 1001",
    "B-04-1 1003",
  ]);
});

test("the stock input is not modified", () => {
  const stock = [lot("B-04-1", "OLIVE-500", 2, "2027-01-01"), lot("A-01-1", "OLIVE-500", 5, null)];
  const snapshot = structuredClone(stock);
  const objects = [...stock];
  buildPickList("ORDER 1001\n  OLIVE-500 x4", stock);
  expect(stock).toEqual(snapshot);
  expect(stock[0]).toBe(objects[0]!);
  expect(stock[1]).toBe(objects[1]!);
});

test("empty lots yield no picks", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 0, "2026-10-20"), lot("A-01-2", "OLIVE-500", 1, "2027-01-01")];
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x2", stock);
  expect(result).toEqual({
    picks: [{ bin: "A-01-2", sku: "OLIVE-500", qty: 1, orderId: "1001" }],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 1 }],
  });
});

test("the morning export example", () => {
  const text = ["# export 2026-10-12 06:00", "ORDER 1001", "  OLIVE-500 x3", "  PASTA-1KG x1", "ORDER 1002 !", "  OLIVE-500 x2"].join("\n");
  const stock = [
    lot("B-02-1", "OLIVE-500", 2, "2027-02-01"),
    lot("A-05-3", "OLIVE-500", 1, "2026-12-01"),
    lot("B-07-2", "PASTA-1KG", 4, null),
  ];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-05-3", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-07-2", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 2 }],
  });
});
