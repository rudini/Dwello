import { findProduct, VAT_RATES, type Catalog, type VatCategory } from "./catalog";
import { formatChf, roundHalfUp, roundToRappen, vatIncluded } from "./money";
import { discountFor, findPromotion, type Promotion } from "./promotions";

export interface CartLine {
  sku: string;
  qty: number;
}

export interface ReceiptLine {
  sku: string;
  name: string;
  qty: number;
  unitCents: number;
  lineCents: number;
  vat: VatCategory;
}

export interface Receipt {
  lines: ReceiptLine[];
  subtotalCents: number;
  couponCode?: string;
  discountCents: number;
  totalCents: number;
  vat: Record<VatCategory, number>;
  notice?: string;
}

export function checkout(
  cart: CartLine[],
  catalog: Catalog,
  promotions: Promotion[] = [],
  couponCode?: string,
): Receipt {
  const lines: ReceiptLine[] = cart.map(({ sku, qty }) => {
    const product = findProduct(catalog, sku);
    return {
      sku,
      name: product.name,
      qty,
      unitCents: product.priceCents,
      lineCents: product.priceCents * qty,
      vat: product.vat,
    };
  });

  const subtotalCents = lines.reduce((sum, l) => sum + l.lineCents, 0);

  let discountCents = 0;
  let notice: string | undefined;
  if (couponCode !== undefined) {
    const promotion = findPromotion(promotions, couponCode);
    const minimum = promotion.minSubtotalCents;
    if (minimum !== undefined && subtotalCents < minimum) {
      notice = `Coupon ${couponCode} requires a minimum order of ${formatChf(minimum)}`;
    } else {
      discountCents = Math.min(discountFor(promotion, lines), subtotalCents);
    }
  }

  const gross: Record<VatCategory, number> = { standard: 0, reduced: 0 };
  for (const l of lines) gross[l.vat] += l.lineCents;

  // The discount is split between the rates in proportion to their share of the subtotal.
  const reducedDiscount =
    subtotalCents > 0 ? roundHalfUp(discountCents * gross.reduced, subtotalCents) : 0;
  const discountShare: Record<VatCategory, number> = {
    reduced: reducedDiscount,
    standard: discountCents - reducedDiscount,
  };

  const vat: Record<VatCategory, number> = { standard: 0, reduced: 0 };
  for (const category of Object.keys(vat) as VatCategory[]) {
    vat[category] = vatIncluded(gross[category] - discountShare[category], VAT_RATES[category]);
  }

  return {
    lines,
    subtotalCents,
    couponCode,
    discountCents,
    totalCents: roundToRappen(subtotalCents - discountCents),
    vat,
    ...(notice !== undefined && { notice }),
  };
}
