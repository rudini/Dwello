import { expect, test } from "bun:test";
import { roundHalfUp } from "./money";

test("roundHalfUp rounds a quotient to the nearest integer, halves up", () => {
  expect(roundHalfUp(5000 * 2500, 7000)).toBe(1786);
  expect(roundHalfUp(500 * 2500, 4000)).toBe(313);
  expect(roundHalfUp(500 * 2500, 4001)).toBe(312);
});
