export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

function splitFields(text: string): string[] {
  const fields: string[] = [];
  let i = 0;
  while (true) {
    while (text[i] === " " || text[i] === "\t") i++;
    let value = "";
    if (text[i] === '"') {
      i++;
      while (i < text.length) {
        if (text[i] === '"' && text[i + 1] === '"') {
          value += '"';
          i += 2;
        } else if (text[i] === '"') {
          i++;
          break;
        } else value += text[i++];
      }
      while (i < text.length && text[i] !== ",") i++;
    } else {
      const end = text.indexOf(",", i);
      value = text.slice(i, end < 0 ? text.length : end).trim();
      i = end < 0 ? text.length : end;
    }
    fields.push(value);
    if (i >= text.length) return fields;
    i++;
  }
}

function isCalendarDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== undefined && day >= 1 && day <= daysInMonth;
}

const COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof COLUMNS)[number];

interface Header {
  index: Record<Column, number>;
  width: number;
}

interface Expense {
  date: string;
  employee: string;
  category: string;
  /** The amount as written, in cents of its own currency. */
  amountCents: number;
  currency: string;
  chfCents: number;
  receipt: boolean;
}

function readHeader(text: string): Header {
  const names = splitFields(text).map((name) => name.trim().toLowerCase());
  const index = {} as Record<Column, number>;
  for (const column of COLUMNS) {
    index[column] = names.indexOf(column);
    if (index[column] < 0) throw new ExpenseFileError(`Missing column: ${column}`);
  }
  return { index, width: names.length };
}

/** cents * rate rounded half up, computed on the decimal digits of the rate so binary floats cannot tip a half. */
function convertCents(cents: number, rate: number): number {
  const [mantissa, exponent = "0"] = String(rate).split("e");
  const [whole, fraction = ""] = mantissa.split(".");
  const scale = fraction.length - Number(exponent);
  const product = BigInt(cents) * BigInt(whole + fraction);
  if (scale <= 0) return Number(product * 10n ** BigInt(-scale));
  const divisor = 10n ** BigInt(scale);
  return Number((product * 2n + divisor) / (divisor * 2n));
}

/** The expense in a data row, or the reason the row is rejected. */
function readRow(text: string, header: Header, policy: Policy, fxRates: FxRates): Expense | string {
  const fields = splitFields(text);
  if (fields.length !== header.width) return "wrong number of fields";
  const get = (column: Column) => fields[header.index[column]].trim();
  const date = get("date");
  if (!isCalendarDate(date)) return "invalid date";
  const employee = get("employee");
  if (employee === "") return "missing employee";
  const category = get("category");
  if (!Object.hasOwn(policy.categories, category)) return "unknown category";
  const amount = /^(\d+)(?:\.(\d{1,2}))?$/.exec(get("amount"));
  const amountCents = amount ? Number(amount[1]) * 100 + Number((amount[2] ?? "").padEnd(2, "0")) : 0;
  if (amountCents <= 0) return "invalid amount";
  const currency = get("currency");
  if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) return "unknown currency";
  const receipt = get("receipt").toLowerCase();
  if (receipt !== "yes" && receipt !== "no") return "invalid receipt flag";
  const chfCents = convertCents(amountCents, currency === "CHF" ? 1 : fxRates[currency]);
  return { date, employee, category, amountCents, currency, chfCents, receipt: receipt === "yes" };
}

/** What the policy remembers of the accepted rows above the current one. */
interface History {
  seen: Set<string>;
  dayTotals: Map<string, number>;
}

/** The violations of an accepted row, in the fixed order; records the row in the history. */
function checkPolicy(expense: Expense, policy: Policy, history: History): Violation[] {
  const { date, employee, category, amountCents, currency, chfCents } = expense;
  const violations: Violation[] = [];
  const key = JSON.stringify([employee, date, category, amountCents, currency]);
  if (history.seen.has(key)) violations.push("DUPLICATE");
  history.seen.add(key);
  const limits = policy.categories[category];
  if (limits.perItemLimitCents !== undefined && chfCents > limits.perItemLimitCents) violations.push("OVER_ITEM_LIMIT");
  const dayKey = JSON.stringify([employee, date, category]);
  const dayTotal = (history.dayTotals.get(dayKey) ?? 0) + chfCents;
  history.dayTotals.set(dayKey, dayTotal);
  if (limits.dailyLimitCents !== undefined && dayTotal > limits.dailyLimitCents) violations.push("OVER_DAILY_LIMIT");
  if (!expense.receipt && chfCents > policy.receiptRequiredAboveCents) violations.push("NO_RECEIPT");
  return violations;
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const lines = csv.split(/\r?\n/);
  const headerIndex = lines.findIndex((text) => text.trim() !== "");
  if (headerIndex < 0) throw new ExpenseFileError("Missing header");
  const header = readHeader(lines[headerIndex]);
  const report: ExpenseReport = { lines: [], rejected: [], totals: {} };
  const history: History = { seen: new Set(), dayTotals: new Map() };
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();
  for (let i = headerIndex + 1; i < lines.length; i++) {
    if (lines[i].trim() === "") continue;
    const expense = readRow(lines[i], header, policy, fxRates);
    if (typeof expense === "string") {
      report.rejected.push({ line: i + 1, reason: expense });
      continue;
    }
    const { date, employee, category, chfCents } = expense;
    const violations = checkPolicy(expense, policy, history);
    report.lines.push({ line: i + 1, date, employee, category, amountChfCents: chfCents, violations });
    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    totals.set(employee, total);
    if (violations.length > 0) total.flaggedCents += chfCents;
    else total.approvedCents += chfCents;
  }
  report.totals = Object.fromEntries(totals);
  return report;
}
