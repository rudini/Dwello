# Expense review: design note

**Hidden decision:** how the travel app's CSV export is read (line splitting, quoting, header lookup,
row validation) and how the company policy and the CHF conversion are applied to it. Callers hand
over text, policy and rates and get a finished report.

## Both designs

- **A, one general call:** `reviewExpenses(csv, policy, fxRates): ExpenseReport`.
- **B, a pipeline:** `parseExpenseCsv`, `validateRows`, `applyPolicy`, `totalPerEmployee`, called in
  that order by the caller.

**Chosen:** A, because the caller learns one name, and the CSV dialect, the validation order, the
rounding rule and the running daily totals all stay hidden behind it. B leaks the intermediate row
shape and the call order into every caller.

## Interface

- `reviewExpenses(csv, policy, fxRates)` returns the accepted lines with their violations, the
  rejected lines with the reason of their first failing check, and approved/flagged totals per
  employee. It throws `ExpenseFileError` (`Missing header`, `Missing column: <name>`) when the file
  as a whole cannot be read.
- The types `Policy`, `CategoryPolicy`, `FxRates`, `Violation`, `ReviewedLine`, `RejectedLine` and
  `ExpenseReport` are unchanged from the stub.

Inside, all private: `splitFields` (the CSV dialect), `readHeader`, `readRow` (the expense or its
rejection reason), `isCalendarDate`, `convertCents` and `checkPolicy` (with the history of earlier
accepted rows).

## Depth

`depth_report`: `src/expenseReview.ts: surface 13, size 167, ratio 12.8, classitis no,
pass-through 0, tests 1, unused 0, duplicate 4`. The four "duplicates" are field declarations that
`Expense` shares with `ReviewedLine`. The refactors replaced repeated rejection branches with
`readRow`, moved header lookup into `readHeader`, kept the written amount and currency on the expense
for the duplicate check, and moved the four policy checks into `checkPolicy`.

## Decisions and open points

- **Exact rounding:** CHF cents are worked out on the decimal digits of the rate (BigInt), so a
  float product such as `45 * 0.7 = 31.4999…` still rounds half up to 32.
- **Trimming:** every value is trimmed, including quoted values, so a quoted `"  "` employee counts
  as missing.
- **Object keys:** category and currency are matched with `Object.hasOwn`, so `toString` is not a
  category. Totals are built from a `Map`, so an employee called `__proto__` gets a normal entry.
- **Not supported:** quoted fields that span lines. Each physical line is one row, as the line
  numbering rule requires. Amounts with more than about 15 digits lose precision.
- **Not tested separately:** "only the first failing check is reported". `readRow` returns at the
  first failure, so a test for it could never fail first and so could not have a red step.

## Proof

`scripts/tdd_replay f500d81..HEAD` printed `REPLAY: ACCEPT`. It proves phase order, test counts and
exit codes, but not how strong the assertions are.
