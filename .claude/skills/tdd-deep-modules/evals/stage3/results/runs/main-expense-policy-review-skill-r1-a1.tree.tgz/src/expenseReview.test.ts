import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type FxRates, type Policy } from "./expenseReview";

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};
const rates: FxRates = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";

function review(...rows: string[]) {
  return reviewExpenses([HEADER, ...rows].join("\n"), policy, rates);
}

test("throws Missing header when the file has no non-blank line", () => {
  expect(() => reviewExpenses(" \n\r\n\t\n", policy, rates)).toThrow(new ExpenseFileError("Missing header"));
  expect(() => reviewExpenses("", policy, rates)).toThrow(ExpenseFileError);
});

test("reviews a single CHF row", () => {
  expect(review("2026-09-01,Anna,taxi,12.50,CHF,yes")).toEqual({
    lines: [
      { line: 2, date: "2026-09-01", employee: "Anna", category: "taxi", amountChfCents: 1250, violations: [] },
    ],
    rejected: [],
    totals: { Anna: { approvedCents: 1250, flaggedCents: 0 } },
  });
});

test("throws Missing column naming the first missing column in spec order", () => {
  expect(() => reviewExpenses("receipt,date,amount,employee\n", policy, rates)).toThrow(
    new ExpenseFileError("Missing column: category"),
  );
  expect(() => reviewExpenses("date,employee,category,amount,currency", policy, rates)).toThrow(
    new ExpenseFileError("Missing column: receipt"),
  );
});

test("reads a reordered header with extra columns, CRLF, blank lines and quoted fields", () => {
  const csv = [
    "",
    ' Receipt , "Note", AMOUNT,Currency,category,EMPLOYEE,Date ',
    "   ",
    'no,"Dinner, with ""client""",  7.5 ,CHF,meals,"Müller, Hans",2026-09-02',
    "",
  ].join("\r\n");
  expect(reviewExpenses(csv, policy, rates)).toEqual({
    lines: [
      { line: 4, date: "2026-09-02", employee: "Müller, Hans", category: "meals", amountChfCents: 750, violations: [] },
    ],
    rejected: [],
    totals: { "Müller, Hans": { approvedCents: 750, flaggedCents: 0 } },
  });
});

test("rejects a row with the wrong number of fields", () => {
  expect(review("2026-09-01,Anna,taxi,12.50,CHF,yes,extra", "2026-09-01,Anna,taxi,12.50,CHF")).toEqual({
    lines: [],
    rejected: [
      { line: 2, reason: "wrong number of fields" },
      { line: 3, reason: "wrong number of fields" },
    ],
    totals: {},
  });
});

function reasons(...rows: string[]) {
  return review(...rows).rejected.map((rejected) => rejected.reason);
}

test("rejects an invalid date", () => {
  const dates = ["2026-02-30", "2025-02-29", "2026-13-01", "2026-00-10", "2026-09-00", "2026-9-01", "01.09.2026", "2026-09-01x", ""];
  expect(reasons(...dates.map((date) => `${date},Anna,taxi,10,CHF,yes`))).toEqual(dates.map(() => "invalid date"));
  expect(review("2024-02-29,Anna,taxi,10,CHF,yes", "2026-12-31,Anna,taxi,10,CHF,yes").rejected).toEqual([]);
});

test("accepts calendar dates in any four-digit year", () => {
  expect(reasons("0024-02-29,Anna,taxi,10,CHF,yes", "0000-01-01,Anna,taxi,10,CHF,yes", "2000-02-29,Anna,taxi,10,CHF,yes")).toEqual([]);
  expect(reasons("1900-02-29,Anna,taxi,10,CHF,yes")).toEqual(["invalid date"]);
});

test("rejects a missing employee", () => {
  expect(reasons("2026-09-01,,taxi,10,CHF,yes", '2026-09-01,"  ",taxi,10,CHF,yes')).toEqual([
    "missing employee",
    "missing employee",
  ]);
});

test("rejects an unknown category", () => {
  expect(reasons("2026-09-01,Anna,Meals,10,CHF,yes", "2026-09-01,Anna,flights,10,CHF,yes", "2026-09-01,Anna,,10,CHF,yes")).toEqual([
    "unknown category",
    "unknown category",
    "unknown category",
  ]);
});

test("rejects an invalid amount", () => {
  const amounts = ["0", "0.00", "-5", "+5", "1.234", "12.", ".5", "1,5", "abc", "", "1e3", "1 000"];
  expect(reasons(...amounts.map((amount) => `2026-09-01,Anna,taxi,"${amount}",CHF,yes`))).toEqual(
    amounts.map(() => "invalid amount"),
  );
  expect(reasons("2026-09-01,Anna,taxi,0.01,CHF,yes", "2026-09-01,Anna,taxi,007.5,CHF,yes")).toEqual([]);
});

test("rejects an unknown currency", () => {
  expect(reasons("2026-09-01,Anna,taxi,10,XYZ,yes", "2026-09-01,Anna,taxi,10,eur,yes", "2026-09-01,Anna,taxi,10,,yes")).toEqual([
    "unknown currency",
    "unknown currency",
    "unknown currency",
  ]);
  expect(reasons("2026-09-01,Anna,taxi,10,EUR,yes", "2026-09-01,Anna,taxi,10,USD,yes")).toEqual([]);
});

test("rejects an invalid receipt flag", () => {
  expect(reasons("2026-09-01,Anna,taxi,10,CHF,y", "2026-09-01,Anna,taxi,10,CHF,true", "2026-09-01,Anna,taxi,10,CHF,")).toEqual([
    "invalid receipt flag",
    "invalid receipt flag",
    "invalid receipt flag",
  ]);
  expect(reasons("2026-09-01,Anna,taxi,10,CHF,YES", "2026-09-01,Anna,taxi,10,CHF,No")).toEqual([]);
});

test("converts foreign currencies to CHF cents, rounding halves up exactly", () => {
  const fx: FxRates = { EUR: 0.9412, GBP: 1.15, SEK: 0.7, XAU: 1.005, CHF: 2 };
  const rows = [
    "12.50,EUR", // 1176.5
    "0.10,EUR", // 9.412
    "0.50,GBP", // 57.5
    "0.45,SEK", // 31.5
    "1,XAU", // 100.5
    "3,CHF", // CHF is always 1
  ].map((amount) => `2026-09-01,Anna,taxi,${amount},yes`);
  const report = reviewExpenses([HEADER, ...rows].join("\n"), policy, fx);
  expect(report.lines.map((line) => line.amountChfCents)).toEqual([1177, 9, 58, 32, 101, 300]);
});

function violations(...rows: string[]) {
  return review(...rows).lines.map((line) => line.violations);
}

test("flags a duplicate of an earlier accepted row, comparing the amount as a value", () => {
  expect(
    violations(
      "2026-09-01,Anna,taxi,12.5,CHF,yes",
      "2026-09-01,Anna,taxi,12.50,CHF,no", // duplicate: receipt flag is not compared
      "2026-09-01,Anna,taxi,12.50,EUR,yes", // other currency
      "2026-09-01,Ben,taxi,12.50,CHF,yes", // other employee
      "2026-09-02,Anna,taxi,12.50,CHF,yes", // other date
      "2026-09-01,Anna,hotel,12.50,CHF,yes", // other category
      "2026-09-01,Anna,taxi,12.51,CHF,yes", // other amount
      "2026-09-01,Anna,taxi,12.5,CHF,yes", // duplicate again
    ),
  ).toEqual([[], ["DUPLICATE"], [], [], [], [], [], ["DUPLICATE"]]);
  expect(violations("2026-09-03,Anna,taxi,5,CHF,maybe", "2026-09-03,Anna,taxi,5,CHF,yes")).toEqual([[]]);
});

test("flags a CHF amount above the per-item limit of its category", () => {
  expect(
    violations(
      "2026-09-01,Anna,meals,50.00,CHF,yes", // at the limit
      "2026-09-02,Anna,meals,50.01,CHF,yes",
      "2026-09-03,Anna,meals,53.13,EUR,yes", // 5000.59 -> 5001
      "2026-09-04,Anna,meals,53.12,EUR,yes", // 4999.65 -> 5000
      "2026-09-05,Anna,hotel,250.01,CHF,yes",
      "2026-09-06,Anna,taxi,9999,CHF,yes", // no limit
    ),
  ).toEqual([[], ["OVER_ITEM_LIMIT"], ["OVER_ITEM_LIMIT"], [], ["OVER_ITEM_LIMIT"], []]);
});

test("flags a running daily total above the daily limit per employee, date and category", () => {
  expect(
    violations(
      "2026-09-01,Anna,meals,30,CHF,yes", // 3000
      "2026-09-01,Anna,meals,29.99,CHF,yes", // 5999
      "2026-09-01,Ben,meals,40,CHF,yes", // other employee
      "2026-09-02,Anna,meals,45,CHF,yes", // other date
      "2026-09-01,Anna,taxi,45,CHF,yes", // other category
      "2026-09-01,Anna,meals,20.01,CHF,yes", // 8000, at the limit
      "2026-09-01,Anna,meals,0.50,CHF,yes", // 8050
      "2026-09-01,Anna,meals,1,CHF,yes", // 8150
      "2026-09-03,Anna,meals,40,CHF,yes", // 4000
      "2026-09-03,Anna,meals,30,CHF,yes", // 7000
      "2026-09-03,Anna,meals,50,XYZ,yes", // rejected, not counted
      "2026-09-03,Anna,meals,10,CHF,yes", // 8000
      "2026-09-04,Anna,meals,45,CHF,yes", // 4500
      "2026-09-04,Anna,meals,45,CHF,yes", // 9000, duplicates count too
    ),
  ).toEqual([
    [], [], [], [], [], [],
    ["OVER_DAILY_LIMIT"], ["OVER_DAILY_LIMIT"],
    [], [], [],
    [], ["DUPLICATE", "OVER_DAILY_LIMIT"],
  ]);
});

test("flags a missing receipt for a CHF amount above the receipt threshold", () => {
  expect(
    violations(
      "2026-09-01,Anna,taxi,20.00,CHF,no", // at the threshold
      "2026-09-02,Anna,taxi,20.01,CHF,no",
      "2026-09-03,Anna,taxi,30,CHF,yes",
      "2026-09-04,Anna,taxi,25,CHF,NO",
      "2026-09-05,Anna,taxi,21.26,EUR,no", // 2000.99 -> 2001
      "2026-09-06,Anna,taxi,21.25,EUR,no", // 2000.05 -> 2000
    ),
  ).toEqual([[], ["NO_RECEIPT"], [], ["NO_RECEIPT"], ["NO_RECEIPT"], []]);
});

test("splits totals per employee into approved and flagged, whatever the employee is called", () => {
  const report = review(
    "2026-09-01,Anna,taxi,10,CHF,yes",
    "2026-09-01,__proto__,taxi,10,CHF,yes",
    "2026-09-01,constructor,taxi,30,CHF,no", // NO_RECEIPT
    "2026-09-02,Anna,meals,60,CHF,yes", // OVER_ITEM_LIMIT
    "2026-09-02,Anna,meals,25,CHF,no", // OVER_DAILY_LIMIT, NO_RECEIPT
    "2026-09-03,Anna,taxi,5.55,CHF,yes",
    "2026-09-03,Ben,taxi,1,CHF,maybe", // rejected
  );
  expect(Object.entries(report.totals)).toEqual([
    ["Anna", { approvedCents: 1555, flaggedCents: 8500 }],
    ["__proto__", { approvedCents: 1000, flaggedCents: 0 }],
    ["constructor", { approvedCents: 0, flaggedCents: 3000 }],
  ]);
  expect(report.lines[4].violations).toEqual(["OVER_DAILY_LIMIT", "NO_RECEIPT"]);
});
