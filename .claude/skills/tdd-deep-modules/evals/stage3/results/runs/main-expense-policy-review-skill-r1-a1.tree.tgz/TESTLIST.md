# Expense review: test list

**Hidden decision:** how the travel app's CSV export is read (line splitting, quoting, header lookup,
row validation) and how the company policy and CHF conversion are applied to it; callers only hand
over text, policy and rates and get a finished report.

**Design A (one general call):**
`reviewExpenses(csv, policy, fxRates): ExpenseReport`
call site: `const report = reviewExpenses(await file.text(), policy, rates);`

**Design B (pipeline of special calls):**
`parseExpenseCsv(csv): Row[]`, `validateRows(rows, policy, rates): { accepted, rejected }`,
`applyPolicy(accepted, policy): ReviewedLine[]`, `totalPerEmployee(lines)`
call site: `const { accepted, rejected } = validateRows(parseExpenseCsv(csv), policy, rates); ...`

**Chosen:** design A, because the caller learns one name and the CSV dialect, validation order,
rounding rule and running daily totals all stay hidden behind it (B leaks the intermediate row shape
and the call order into every caller).

## Behaviours (through `reviewExpenses`)

- [x] throws `Missing header` when the file has no non-blank line
- [x] reviews a single CHF row: line number, fields, cents, no violations, approved total
- [x] throws `Missing column: <name>` naming the first missing column in spec order
- [x] reads a reordered, case-insensitive header with extra columns, CRLF, blank lines (counted for
      line numbers) and quoted fields (one test: each part alone already passed after the first rows)
- [x] rejects a row with the wrong number of fields
- [x] rejects an invalid date (format and calendar, leap years)
- [x] accepts calendar dates in any four-digit year (found while writing the date check)
- [x] rejects a missing employee
- [x] rejects an unknown category
- [x] rejects an invalid amount (zero, negative, three decimals, text)
- [x] rejects an unknown currency
- [x] rejects an invalid receipt flag
- [ ] reports only the first failing check of a row: holds by construction (`readRow` returns at the
      first failure), no separate test since it could not fail first
- [x] converts foreign currency to CHF cents, rounding halves up exactly
- [x] flags a duplicate of an earlier accepted row (amount compared as a value)
- [x] flags an amount above the per-item limit
- [x] flags a running daily total above the daily limit (also covers DUPLICATE before OVER_DAILY_LIMIT)
- [x] flags a missing receipt above the receipt threshold
- [x] splits totals per employee into approved and flagged, also for employees called `__proto__`
      or `constructor` (also covers OVER_DAILY_LIMIT before NO_RECEIPT)
