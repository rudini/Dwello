# Test list

Ticked items are covered by a test in `src/expenseReview.test.ts`.

## File / header
- [x] empty file → `Missing header`
- [x] whitespace-only file → `Missing header`
- [x] missing column → `Missing column: <name>`, first missing in spec order
- [x] header names case-insensitive and trimmed, any order, extra columns ignored
- [x] blank lines before the header are skipped, line numbers still count physical lines
- [x] header only → empty report

## Line splitting
- [x] `\n` and `\r\n` line endings
- [x] blank / whitespace-only data lines skipped but counted
- [x] trailing newline does not create a row

## Fields
- [x] spaces around unquoted values trimmed
- [x] quoted field with comma
- [x] `""` inside quotes is one `"`

## Row rejection (in order)
- [x] wrong number of fields (too few / too many)
- [x] invalid date: wrong format, impossible date (2025-02-30), leap year 2024-02-29 ok, 2023-02-29 not
- [x] missing employee (empty, whitespace only)
- [x] unknown category (exact match, case-sensitive)
- [x] invalid amount: zero, negative, three decimals, `.5`, `5.`, letters, empty
- [x] unknown currency
- [x] invalid receipt flag; `YES` / `No` accepted
- [x] first failing check wins (e.g. bad date and bad amount → invalid date)
- [x] rejected rows take no part in duplicates / daily totals / totals

## Conversion
- [x] CHF amount converted to cents
- [x] foreign currency multiplied by rate, rounded half up (exact, no float error)
- [x] CHF uses rate 1 even if fxRates has a CHF entry

## Violations
- [x] DUPLICATE on second identical row, not first; `12.5` equals `12.50`
- [x] not a duplicate when any key field differs
- [x] OVER_ITEM_LIMIT above limit, not at limit
- [x] OVER_DAILY_LIMIT on running total, per employee/date/category, includes duplicates
- [x] NO_RECEIPT only when receipt=no and above threshold
- [x] several violations in fixed order

## Result
- [x] lines carry trimmed date/employee/category and line number
- [x] totals approved vs flagged per employee
- [x] employees with only rejected rows have no totals entry
- [x] values (quoted or not) are trimmed before checks; reported values are trimmed
- [x] employee names like `__proto__` / `constructor` are ordinary totals keys
- [x] rates in exponent notation convert exactly
