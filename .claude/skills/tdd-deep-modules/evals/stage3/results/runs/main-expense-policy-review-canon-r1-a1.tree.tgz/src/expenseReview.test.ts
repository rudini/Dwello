import { describe, expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type FxRates, type Policy } from "./expenseReview";

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};
const fx: FxRates = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";

const review = (csv: string, p: Policy = policy, rates: FxRates = fx) => reviewExpenses(csv, p, rates);
const fileError = (csv: string) => {
  try {
    review(csv);
  } catch (e) {
    expect(e).toBeInstanceOf(ExpenseFileError);
    return (e as Error).message;
  }
  throw new Error("expected ExpenseFileError");
};

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

describe("header", () => {
  test("empty file has no header", () => {
    expect(fileError("")).toBe("Missing header");
  });

  test("whitespace-only file has no header", () => {
    expect(fileError("  \r\n\t\n\n")).toBe("Missing header");
  });

  test("names the first missing column in spec order", () => {
    expect(fileError("receipt,amount,employee\n")).toBe("Missing column: date");
    expect(fileError("date,employee,amount,receipt\n")).toBe("Missing column: category");
    expect(fileError("date,employee,category,amount,currency\n")).toBe("Missing column: receipt");
  });

  test("header only gives an empty report", () => {
    expect(review(HEADER + "\n")).toEqual({ lines: [], rejected: [], totals: {} });
  });
});

describe("accepted rows", () => {
  test("a clean CHF row is approved", () => {
    expect(review(`${HEADER}\n2025-03-04,Anna,taxi,12.50,CHF,yes\n`)).toEqual({
      lines: [
        { line: 2, date: "2025-03-04", employee: "Anna", category: "taxi", amountChfCents: 1250, violations: [] },
      ],
      rejected: [],
      totals: { Anna: { approvedCents: 1250, flaggedCents: 0 } },
    });
  });

  test("header columns in any order, any case, with extra columns; blank lines counted", () => {
    const csv = [
      "",
      "  ",
      " Receipt ,NOTE, AMOUNT,Currency,category,EMPLOYEE,Date",
      "yes,lunch,10,CHF,taxi,Anna,2025-03-04",
      "\t",
      "no,x,5.5,CHF,taxi,Ben,2025-03-05",
      "",
    ].join("\r\n");
    const report = review(csv);
    expect(report.rejected).toEqual([]);
    expect(report.lines.map((l) => [l.line, l.employee, l.date, l.amountChfCents])).toEqual([
      [4, "Anna", "2025-03-04", 1000],
      [6, "Ben", "2025-03-05", 550],
    ]);
  });

  test("quoted fields may contain commas and doubled quotes; unquoted values are trimmed", () => {
    const csv = `${HEADER}\n  2025-03-04 , "Doe, ""JD"" Jane" ,"taxi",  "10.00",CHF ,yes\n`;
    const [line] = review(csv).lines;
    expect(line).toEqual({
      line: 2,
      date: "2025-03-04",
      employee: 'Doe, "JD" Jane',
      category: "taxi",
      amountChfCents: 1000,
      violations: [],
    });
  });
});

const rejectReason = (row: string, rates: FxRates = fx) => {
  const report = review(`${HEADER}\n${row}`, policy, rates);
  expect(report.lines).toEqual([]);
  expect(report.rejected).toHaveLength(1);
  expect(report.rejected[0].line).toBe(2);
  return report.rejected[0].reason;
};

const violations = (...rows: string[]) => review([HEADER, ...rows].join("\n")).lines.map((l) => l.violations);

describe("policy checks", () => {
  test("OVER_ITEM_LIMIT when the CHF amount is above the per-item limit", () => {
    expect(
      violations(
        "2025-03-04,Anna,hotel,250.00,CHF,yes",
        "2025-03-05,Anna,hotel,250.01,CHF,yes",
        "2025-03-06,Anna,hotel,265.00,EUR,yes", // 249.42 CHF
        "2025-03-07,Anna,taxi,9999,CHF,yes", // no limit
      ),
    ).toEqual([[], ["OVER_ITEM_LIMIT"], [], []]);
  });

  test("NO_RECEIPT when there is no receipt and the CHF amount is above the threshold", () => {
    expect(
      violations(
        "2025-03-04,Anna,taxi,20.00,CHF,no",
        "2025-03-04,Anna,taxi,20.01,CHF,NO",
        "2025-03-04,Anna,taxi,99,CHF,yes",
        "2025-03-04,Anna,taxi,21.25,EUR,no", // 20.00 CHF
        "2025-03-04,Anna,taxi,21.26,EUR,no", // 20.01 CHF
      ),
    ).toEqual([[], ["NO_RECEIPT"], [], [], ["NO_RECEIPT"]]);
  });

  test("OVER_DAILY_LIMIT once the running total per employee, date and category is above the limit", () => {
    expect(
      violations(
        "2025-03-04,Anna,meals,40,CHF,yes", // 40
        "2025-03-04,Ben,meals,45,CHF,yes", // other employee
        "2025-03-05,Anna,meals,45,CHF,yes", // other date
        "2025-03-04,Anna,hotel,45,CHF,yes", // other category
        "2025-03-04,Anna,meals,30,CHF,yes", // 70
        "2025-03-04,Anna,meals,10,CHF,yes", // 80, at the limit
        "2025-03-04,Anna,meals,0.01,CHF,yes", // 80.01
        "2025-03-05,Anna,meals,35.01,CHF,yes", // 80.01 on the 5th
      ),
    ).toEqual([[], [], [], [], [], [], ["OVER_DAILY_LIMIT"], ["OVER_DAILY_LIMIT"]]);
  });

  test("rejected rows do not count towards the daily total", () => {
    expect(
      violations("2025-03-04,Anna,meals,50,CHF,yes", "2025-03-04,Anna,meals,50,CHF,maybe", "2025-03-04,Anna,meals,30,CHF,yes"),
    ).toEqual([[], []]);
  });

  test("categories without a daily limit are never over it", () => {
    expect(violations("2025-03-04,Anna,taxi,5000,CHF,yes", "2025-03-04,Anna,taxi,5000,CHF,yes").map((v) => v.includes("OVER_DAILY_LIMIT"))).toEqual([false, false]);
  });

  test("DUPLICATE when an earlier accepted row has the same employee, date, category, amount and currency", () => {
    expect(
      violations(
        "2025-03-04,Anna,taxi,12.5,EUR,yes",
        "2025-03-04,Anna,taxi,12.50,EUR,no", // same amount as a value; receipt does not matter
        "2025-03-04,Anna,taxi,012.50,EUR,yes",
        "2025-03-04,Ben,taxi,12.5,EUR,yes",
        "2025-03-05,Anna,taxi,12.5,EUR,yes",
        "2025-03-04,Anna,meals,12.5,EUR,yes",
        "2025-03-04,Anna,taxi,12.51,EUR,yes",
        "2025-03-04,Anna,taxi,12.5,CHF,yes",
      ),
    ).toEqual([[], ["DUPLICATE"], ["DUPLICATE"], [], [], [], [], []]);
  });

  test("a rejected row is not the original of a duplicate", () => {
    expect(violations("2025-03-04,Anna,taxi,10,CHF,maybe", "2025-03-04,Anna,taxi,10,CHF,yes")).toEqual([[]]);
  });

  test("duplicates count towards the daily total and violations come in a fixed order", () => {
    expect(
      violations("2025-03-04,Anna,meals,60,CHF,no", "2025-03-04,Anna,meals,60,CHF,no"),
    ).toEqual([
      ["OVER_ITEM_LIMIT", "NO_RECEIPT"],
      ["DUPLICATE", "OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
    ]);
  });

  test("flagged amounts are totalled separately", () => {
    const report = review(
      [HEADER, "2025-03-04,Anna,hotel,300,CHF,yes", "2025-03-05,Anna,hotel,100,CHF,yes", "2025-03-05,Ben,taxi,1,CHF,yes"].join("\n"),
    );
    expect(report.totals).toEqual({
      Anna: { approvedCents: 10000, flaggedCents: 30000 },
      Ben: { approvedCents: 100, flaggedCents: 0 },
    });
  });
});

describe("report", () => {
  test("quoted values with spaces are reported trimmed and grouped with their trimmed employee", () => {
    const report = review(`${HEADER}\n"2025-03-04"," Anna ",taxi,10,CHF,yes\n2025-03-04,Anna,taxi,10,CHF,yes\n`);
    expect(report.lines.map((l) => [l.employee, l.violations])).toEqual([
      ["Anna", []],
      ["Anna", ["DUPLICATE"]],
    ]);
    expect(report.totals).toEqual({ Anna: { approvedCents: 1000, flaggedCents: 1000 } });
  });

  test("employees with only rejected rows have no totals entry", () => {
    expect(review(`${HEADER}\n2025-03-04,Ben,taxi,10,CHF,maybe`).totals).toEqual({});
  });

  test("employee names that are object properties are ordinary keys", () => {
    const report = review(`${HEADER}\n2025-03-04,__proto__,taxi,10,CHF,yes\n2025-03-04,constructor,taxi,10,CHF,yes`);
    expect(Object.keys(report.totals)).toEqual(["__proto__", "constructor"]);
    expect(report.totals["constructor"]).toEqual({ approvedCents: 1000, flaggedCents: 0 });
  });

  test("a whole month", () => {
    const csv = [
      "Date,Employee,Category,Amount,Currency,Receipt,Comment",
      "2025-03-03,Anna Muster,meals,45.00,CHF,yes,lunch",
      "2025-03-03,Anna Muster,meals,45.00,CHF,yes,lunch again",
      "",
      "2025-03-03,Ben Beispiel,hotel,280.00,EUR,yes,Paris",
      "2025-03-31,Ben Beispiel,taxi,30,USD,no,airport",
      "2025-02-30,Ben Beispiel,taxi,30,USD,no,typo",
      '2025-03-04,"Muster, Anna",taxi,15.5,CHF,no,"said ""cheap"""',
      "2025-03-05,Carla,meals,10,GBP,yes,London",
    ].join("\r\n");
    expect(review(csv)).toEqual({
      lines: [
        { line: 2, date: "2025-03-03", employee: "Anna Muster", category: "meals", amountChfCents: 4500, violations: [] },
        { line: 3, date: "2025-03-03", employee: "Anna Muster", category: "meals", amountChfCents: 4500, violations: ["DUPLICATE", "OVER_DAILY_LIMIT"] },
        { line: 5, date: "2025-03-03", employee: "Ben Beispiel", category: "hotel", amountChfCents: 26354, violations: ["OVER_ITEM_LIMIT"] },
        { line: 6, date: "2025-03-31", employee: "Ben Beispiel", category: "taxi", amountChfCents: 2400, violations: ["NO_RECEIPT"] },
        { line: 8, date: "2025-03-04", employee: "Muster, Anna", category: "taxi", amountChfCents: 1550, violations: [] },
      ],
      rejected: [
        { line: 7, reason: "invalid date" },
        { line: 9, reason: "unknown currency" },
      ],
      totals: {
        "Anna Muster": { approvedCents: 4500, flaggedCents: 4500 },
        "Ben Beispiel": { approvedCents: 0, flaggedCents: 28754 },
        "Muster, Anna": { approvedCents: 1550, flaggedCents: 0 },
      },
    });
  });
});

describe("conversion to CHF", () => {
  const chf = (amount: string, currency: string, rates: FxRates) =>
    review(`${HEADER}\n2025-03-04,Anna,taxi,${amount},${currency},yes`, policy, rates).lines[0].amountChfCents;

  test("multiplies by the rate and rounds to the nearest cent", () => {
    expect(chf("100", "EUR", { EUR: 0.9412 })).toBe(9412);
    expect(chf("10.01", "USD", { USD: 0.8 })).toBe(801); // 800.8
    expect(chf("10.03", "USD", { USD: 0.8 })).toBe(802); // 802.4
  });

  test("halves round up, without floating point error", () => {
    expect(chf("12.50", "EUR", { EUR: 0.9412 })).toBe(1177); // 1176.5
    expect(chf("1.15", "X", { X: 0.5 })).toBe(58); // 57.5
    expect(chf("0.01", "X", { X: 0.5 })).toBe(1); // 0.5
    expect(chf("10.05", "X", { X: 1.1 })).toBe(1106); // 1105.5
    expect(chf("0.90", "X", { X: 0.35 })).toBe(32); // 31.5, float gives 31.499999999999996
    expect(chf("0.50", "X", { X: 1.15 })).toBe(58); // 57.5, float gives 57.49999999999999
  });

  test("CHF always uses rate 1", () => {
    expect(chf("12.34", "CHF", { CHF: 2 })).toBe(1234);
  });

  test("rates in exponent notation", () => {
    expect(chf("1000000", "X", { X: 5.5e-7 })).toBe(55); // 55.0
    expect(chf("100000", "X", { X: 5.5e-7 })).toBe(6); // 5.5
  });
});

describe("rejected rows", () => {
  test("wrong number of fields", () => {
    expect(rejectReason("2025-03-04,Anna,taxi,10,CHF")).toBe("wrong number of fields");
    expect(rejectReason("2025-03-04,Anna,taxi,10,CHF,yes,extra")).toBe("wrong number of fields");
    expect(rejectReason('2025-03-04,"Anna, B",taxi,10,CHF,yes,')).toBe("wrong number of fields");
  });

  test.each(["", "2025-3-04", "04.03.2025", "2025/03/04", "2025-02-30", "2023-02-29", "2025-13-01", "2025-00-10",
    "2025-04-31", "2025-01-00", "12025-01-01", "2025-01-01T10:00"])("invalid date %p", (date) => {
    expect(rejectReason(`${date},Anna,taxi,10,CHF,yes`)).toBe("invalid date");
  });

  test.each(["2024-02-29", "2000-02-29", "2025-12-31", "2025-01-01"])("valid date %p", (date) => {
    expect(review(`${HEADER}\n${date},Anna,taxi,10,CHF,yes`).lines[0].date).toBe(date);
  });

  test("1900 is not a leap year", () => {
    expect(rejectReason("1900-02-29,Anna,taxi,10,CHF,yes")).toBe("invalid date");
  });

  test("missing employee", () => {
    expect(rejectReason("2025-03-04,,taxi,10,CHF,yes")).toBe("missing employee");
    expect(rejectReason("2025-03-04,   ,taxi,10,CHF,yes")).toBe("missing employee");
    expect(rejectReason('2025-03-04,"",taxi,10,CHF,yes')).toBe("missing employee");
  });

  test("unknown category is an exact, case-sensitive match", () => {
    expect(rejectReason("2025-03-04,Anna,flights,10,CHF,yes")).toBe("unknown category");
    expect(rejectReason("2025-03-04,Anna,Taxi,10,CHF,yes")).toBe("unknown category");
    expect(rejectReason("2025-03-04,Anna,,10,CHF,yes")).toBe("unknown category");
    expect(rejectReason("2025-03-04,Anna,toString,10,CHF,yes")).toBe("unknown category");
    expect(rejectReason("2025-03-04,Anna,__proto__,10,CHF,yes")).toBe("unknown category");
  });

  test.each(["", "0", "0.00", "0.0", "-5", "+5", "1.234", ".5", "5.", "1,5", "1e3", "abc", "1 000", "12.5.0"])(
    "invalid amount %p",
    (amount) => {
      expect(rejectReason(`2025-03-04,Anna,taxi,"${amount}",CHF,yes`)).toBe("invalid amount");
    },
  );

  test.each([["0.01", 1], ["7", 700], ["7.5", 750], ["007.05", 705], ["1234567.89", 123456789]])(
    "valid amount %p",
    (amount, cents) => {
      expect(review(`${HEADER}\n2025-03-04,Anna,taxi,${amount},CHF,yes`).lines[0].amountChfCents).toBe(cents);
    },
  );

  test("unknown currency", () => {
    expect(rejectReason("2025-03-04,Anna,taxi,10,GBP,yes")).toBe("unknown currency");
    expect(rejectReason("2025-03-04,Anna,taxi,10,chf,yes")).toBe("unknown currency");
    expect(rejectReason("2025-03-04,Anna,taxi,10,eur,yes")).toBe("unknown currency");
    expect(rejectReason("2025-03-04,Anna,taxi,10,,yes")).toBe("unknown currency");
    expect(rejectReason("2025-03-04,Anna,taxi,10,constructor,yes")).toBe("unknown currency");
    expect(review(`${HEADER}\n2025-03-04,Anna,taxi,10,CHF,yes`, policy, {}).lines).toHaveLength(1);
  });

  test("invalid receipt flag", () => {
    expect(rejectReason("2025-03-04,Anna,taxi,10,CHF,y")).toBe("invalid receipt flag");
    expect(rejectReason("2025-03-04,Anna,taxi,10,CHF,")).toBe("invalid receipt flag");
    expect(rejectReason("2025-03-04,Anna,taxi,10,CHF,true")).toBe("invalid receipt flag");
    const ok = review(`${HEADER}\n2025-03-04,Anna,taxi,10,CHF,YES\n2025-03-04,Anna,taxi,11,CHF,No\n`);
    expect(ok.lines).toHaveLength(2);
  });

  test("the first failing check wins", () => {
    expect(rejectReason("bad,,nope,0,XXX,maybe,extra")).toBe("wrong number of fields");
    expect(rejectReason("bad,,nope,0,XXX,maybe")).toBe("invalid date");
    expect(rejectReason("2025-03-04,,nope,0,XXX,maybe")).toBe("missing employee");
    expect(rejectReason("2025-03-04,Anna,nope,0,XXX,maybe")).toBe("unknown category");
    expect(rejectReason("2025-03-04,Anna,taxi,0,XXX,maybe")).toBe("invalid amount");
    expect(rejectReason("2025-03-04,Anna,taxi,1,XXX,maybe")).toBe("unknown currency");
    expect(rejectReason("2025-03-04,Anna,taxi,1,CHF,maybe")).toBe("invalid receipt flag");
  });
});
