export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const physicalLines = csv.split(/\r?\n/);
  const headerIndex = physicalLines.findIndex((l) => l.trim() !== "");
  if (headerIndex < 0) throw new ExpenseFileError("Missing header");
  const names = splitFields(physicalLines[headerIndex]).map((n) => n.trim().toLowerCase());
  for (const column of COLUMNS) {
    if (!names.includes(column)) throw new ExpenseFileError(`Missing column: ${column}`);
  }
  const col = (column: (typeof COLUMNS)[number]) => names.indexOf(column);

  const readRow = (rawFields: string[]): Row | string => {
    if (rawFields.length !== names.length) return "wrong number of fields";
    const field = (column: (typeof COLUMNS)[number]) => rawFields[col(column)].trim();
    const date = field("date");
    if (!isCalendarDate(date)) return "invalid date";
    const employee = field("employee");
    if (employee === "") return "missing employee";
    const category = field("category");
    if (!Object.hasOwn(policy.categories, category)) return "unknown category";
    const amountCents = parseAmountCents(field("amount"));
    if (amountCents === undefined) return "invalid amount";
    const currency = field("currency");
    if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) return "unknown currency";
    const receipt = field("receipt").toLowerCase();
    if (receipt !== "yes" && receipt !== "no") return "invalid receipt flag";
    return {
      date,
      employee,
      category,
      amountChfCents: convertCents(amountCents, currency === "CHF" ? 1 : fxRates[currency]),
      hasReceipt: receipt === "yes",
      duplicateKey: JSON.stringify([employee, date, category, String(amountCents), currency]),
    };
  };

  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();
  const dailyTotals = new Map<string, number>();
  const seen = new Set<string>();
  for (let i = headerIndex + 1; i < physicalLines.length; i++) {
    if (physicalLines[i].trim() === "") continue;
    const row = readRow(splitFields(physicalLines[i]));
    if (typeof row === "string") {
      rejected.push({ line: i + 1, reason: row });
      continue;
    }
    const { date, employee, category, amountChfCents } = row;
    const limits = policy.categories[category];
    const violations: Violation[] = [];
    if (seen.has(row.duplicateKey)) violations.push("DUPLICATE");
    seen.add(row.duplicateKey);
    if (limits.perItemLimitCents !== undefined && amountChfCents > limits.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }
    const dayKey = JSON.stringify([employee, date, category]);
    const dayTotal = (dailyTotals.get(dayKey) ?? 0) + amountChfCents;
    dailyTotals.set(dayKey, dayTotal);
    if (limits.dailyLimitCents !== undefined && dayTotal > limits.dailyLimitCents) violations.push("OVER_DAILY_LIMIT");
    if (!row.hasReceipt && amountChfCents > policy.receiptRequiredAboveCents) violations.push("NO_RECEIPT");
    lines.push({ line: i + 1, date, employee, category, amountChfCents, violations });

    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
    totals.set(employee, total);
  }
  return { lines, rejected, totals: Object.fromEntries(totals) };
}

function isCalendarDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number);
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== undefined && day >= 1 && day <= daysInMonth;
}

/** Amount as written, in cents, or undefined unless it is a positive `digits[.d[d]]`. */
function parseAmountCents(text: string): bigint | undefined {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(text);
  if (!match) return undefined;
  const cents = BigInt(match[1]) * 100n + BigInt((match[2] ?? "").padEnd(2, "0"));
  return cents > 0n ? cents : undefined;
}

/**
 * `cents * rate`, rounded to the nearest cent with halves up. The rate is taken
 * as the decimal it prints as (0.35 is 35/100, not the nearest binary double),
 * so the multiplication is exact.
 */
function convertCents(cents: bigint, rate: number): number {
  const [mantissa, exponentText = "0"] = String(rate).split("e");
  const [whole, fraction = ""] = mantissa.split(".");
  const exponent = Number(exponentText) - fraction.length;
  let numerator = cents * BigInt(whole + fraction);
  let denominator = 1n;
  if (exponent >= 0) numerator *= 10n ** BigInt(exponent);
  else denominator = 10n ** BigInt(-exponent);
  return Number((2n * numerator + denominator) / (2n * denominator));
}

interface Row {
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  hasReceipt: boolean;
  /** Equal for rows with the same employee, date, category, amount (as a value) and currency. */
  duplicateKey: string;
}

/**
 * Splits one CSV line into fields. Unquoted values are trimmed; inside double
 * quotes a comma is literal and `""` is one `"`. Spaces around quotes are dropped.
 */
function splitFields(line: string): string[] {
  const fields: string[] = [];
  let pos = 0;
  while (true) {
    while (line[pos] === " " || line[pos] === "\t") pos++;
    let value = "";
    if (line[pos] === '"') {
      pos++;
      while (pos < line.length) {
        if (line[pos] === '"') {
          if (line[pos + 1] !== '"') {
            pos++;
            break;
          }
          pos++;
        }
        value += line[pos++];
      }
      // Anything between the closing quote and the next comma is kept as written.
      const end = line.indexOf(",", pos);
      const rest = line.slice(pos, end < 0 ? undefined : end);
      value += rest.trim();
      pos += rest.length;
    } else {
      const end = line.indexOf(",", pos);
      value = line.slice(pos, end < 0 ? undefined : end).trim();
      pos = end < 0 ? line.length : end;
    }
    fields.push(value);
    if (pos >= line.length) return fields;
    pos++; // skip the comma
  }
}

const COLUMNS =["date", "employee", "category", "amount", "currency", "receipt"] as const;
