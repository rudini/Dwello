export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

const REQUIRED_COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof REQUIRED_COLUMNS)[number];

const BYTE_ORDER_MARK = String.fromCharCode(0xfeff);

const hasOwn = (obj: object, key: string): boolean => Object.prototype.hasOwnProperty.call(obj, key);

/** Splits one CSV line into fields; returns null if a quoted field is malformed. */
function parseCsvLine(line: string): string[] | null {
  const fields: string[] = [];
  let i = 0;
  for (;;) {
    while (line[i] === " " || line[i] === "\t") i++;
    if (line[i] === '"') {
      let value = "";
      i++;
      for (;;) {
        if (i >= line.length) return null; // unterminated quote
        if (line[i] === '"') {
          if (line[i + 1] === '"') {
            value += '"';
            i += 2;
          } else {
            i++;
            break;
          }
        } else {
          value += line[i++];
        }
      }
      while (line[i] === " " || line[i] === "\t") i++;
      fields.push(value);
      if (i >= line.length) return fields;
      if (line[i] !== ",") return null; // text after the closing quote
      i++;
    } else {
      const end = line.indexOf(",", i);
      const raw = end === -1 ? line.slice(i) : line.slice(i, end);
      if (raw.includes('"')) return null; // stray quote inside an unquoted field
      fields.push(raw.trim());
      if (end === -1) return fields;
      i = end + 1;
    }
  }
}

function isValidDate(value: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!m) return false;
  const year = Number(m[1]);
  const month = Number(m[2]);
  const day = Number(m[3]);
  if (month < 1 || month > 12 || day < 1) return false;
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]!;
  return day <= daysInMonth;
}

/** Parses an amount like "12", "12.5" or "12.50" into cents; null if malformed or not positive. */
function parseAmountCents(value: string): bigint | null {
  const m = /^(\d+)(?:\.(\d{1,2}))?$/.exec(value);
  if (!m) return null;
  const cents = BigInt(m[1]!) * 100n + BigInt((m[2] ?? "").padEnd(2, "0"));
  return cents > 0n ? cents : null;
}

interface Fraction {
  num: bigint;
  den: bigint;
}

/** Converts a positive finite rate to the exact fraction of its decimal representation. */
function rateToFraction(rate: number): Fraction | null {
  if (typeof rate !== "number" || !Number.isFinite(rate) || rate <= 0) return null;
  const m = /^(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/.exec(String(rate));
  if (!m) return null;
  const frac = m[2] ?? "";
  let num = BigInt(m[1]! + frac);
  let den = 10n ** BigInt(frac.length);
  const exp = Number(m[3] ?? "0");
  if (exp > 0) num *= 10n ** BigInt(exp);
  else if (exp < 0) den *= 10n ** BigInt(-exp);
  return { num, den };
}

/** amountCents * rate, rounded to the nearest cent with halves up (exact, no float error). */
function convertCents(amountCents: bigint, rate: Fraction): number {
  return Number((2n * amountCents * rate.num + rate.den) / (2n * rate.den));
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const physicalLines = csv.split("\n").map((l) => (l.endsWith("\r") ? l.slice(0, -1) : l));
  if (physicalLines[0]!.startsWith(BYTE_ORDER_MARK)) physicalLines[0] = physicalLines[0]!.slice(1);

  const headerIndex = physicalLines.findIndex((l) => l.trim() !== "");
  if (headerIndex === -1) throw new ExpenseFileError("Missing header");

  const header = (parseCsvLine(physicalLines[headerIndex]!) ?? []).map((h) => h.trim().toLowerCase());
  const columnIndex = {} as Record<Column, number>;
  for (const name of REQUIRED_COLUMNS) {
    const index = header.indexOf(name);
    if (index === -1) throw new ExpenseFileError(`Missing column: ${name}`);
    columnIndex[name] = index;
  }

  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const totals: ExpenseReport["totals"] = {};
  const seen = new Set<string>();
  const dailyTotals = new Map<string, number>();

  for (let i = headerIndex + 1; i < physicalLines.length; i++) {
    const text = physicalLines[i]!;
    if (text.trim() === "") continue;
    const line = i + 1;
    const reject = (reason: string) => rejected.push({ line, reason });

    const fields = parseCsvLine(text);
    if (fields === null || fields.length !== header.length) {
      reject("wrong number of fields");
      continue;
    }
    const get = (name: Column) => fields[columnIndex[name]]!;

    const date = get("date");
    if (!isValidDate(date)) {
      reject("invalid date");
      continue;
    }
    const employee = get("employee").trim();
    if (employee === "") {
      reject("missing employee");
      continue;
    }
    const category = get("category");
    if (!hasOwn(policy.categories, category)) {
      reject("unknown category");
      continue;
    }
    const amountCents = parseAmountCents(get("amount"));
    if (amountCents === null) {
      reject("invalid amount");
      continue;
    }
    const currency = get("currency");
    const rate =
      currency === "CHF" ? { num: 1n, den: 1n } : hasOwn(fxRates, currency) ? rateToFraction(fxRates[currency]!) : null;
    if (rate === null) {
      reject("unknown currency");
      continue;
    }
    const receipt = get("receipt").toLowerCase();
    if (receipt !== "yes" && receipt !== "no") {
      reject("invalid receipt flag");
      continue;
    }

    const amountChfCents = convertCents(amountCents, rate);
    const categoryPolicy = policy.categories[category]!;
    const violations: Violation[] = [];

    const duplicateKey = JSON.stringify([employee, date, category, amountCents.toString(), currency]);
    if (seen.has(duplicateKey)) violations.push("DUPLICATE");
    seen.add(duplicateKey);

    if (categoryPolicy.perItemLimitCents !== undefined && amountChfCents > categoryPolicy.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }

    const dailyKey = JSON.stringify([employee, date, category]);
    const dailyTotal = (dailyTotals.get(dailyKey) ?? 0) + amountChfCents;
    dailyTotals.set(dailyKey, dailyTotal);
    if (categoryPolicy.dailyLimitCents !== undefined && dailyTotal > categoryPolicy.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }

    if (receipt === "no" && amountChfCents > policy.receiptRequiredAboveCents) {
      violations.push("NO_RECEIPT");
    }

    lines.push({ line, date, employee, category, amountChfCents, violations });

    if (!hasOwn(totals, employee)) {
      // defineProperty so that names like "__proto__" become ordinary keys
      Object.defineProperty(totals, employee, {
        value: { approvedCents: 0, flaggedCents: 0 },
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    const total = totals[employee]!;
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
  }

  return { lines, rejected, totals };
}
