import { describe, expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type FxRates, type Policy } from "./expenseReview";

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};
const fx: FxRates = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";

describe("header", () => {
  test("missing header", () => {
    expect(() => reviewExpenses("", policy, fx)).toThrow(new ExpenseFileError("Missing header"));
    expect(() => reviewExpenses("  \r\n\n \n", policy, fx)).toThrow(new ExpenseFileError("Missing header"));
  });

  test("missing column names the first one in listed order", () => {
    expect(() => reviewExpenses("employee,date,amount,receipt\n", policy, fx)).toThrow(
      new ExpenseFileError("Missing column: category"),
    );
    expect(() => reviewExpenses("foo\n", policy, fx)).toThrow(new ExpenseFileError("Missing column: date"));
  });

  test("any order, case-insensitive, extra columns, blank lines before header", () => {
    const csv = "\n  \r\n Receipt ,NOTE,Currency,AMOUNT,Category,Employee,Date\r\nyes,hi,CHF,10,taxi,Ann,2026-09-01\r\n";
    const r = reviewExpenses(csv, policy, fx);
    expect(r.rejected).toEqual([]);
    expect(r.lines).toEqual([
      { line: 4, date: "2026-09-01", employee: "Ann", category: "taxi", amountChfCents: 1000, violations: [] },
    ]);
  });
});

describe("row reading", () => {
  test("rejection reasons in check order and line numbering", () => {
    const csv = [
      HEADER,
      "2026-09-01,Ann,taxi,10,CHF",
      "",
      "2026-02-29,Ann,taxi,10,CHF,yes",
      "2026-9-01,Ann,taxi,10,CHF,yes",
      "2026-09-01,  ,taxi,10,CHF,yes",
      "2026-09-01,Ann,Taxi,10,CHF,yes",
      "2026-09-01,Ann,toString,10,CHF,yes",
      "2026-09-01,Ann,taxi,0.00,CHF,yes",
      "2026-09-01,Ann,taxi,1.234,CHF,yes",
      "2026-09-01,Ann,taxi,-1,CHF,yes",
      "2026-09-01,Ann,taxi,.5,CHF,yes",
      "2026-09-01,Ann,taxi,10,GBP,yes",
      "2026-09-01,Ann,taxi,10,eur,yes",
      "2026-09-01,Ann,taxi,10,CHF,y",
      "bad,,nope,x,GBP,maybe",
      "2024-02-29,Ann,taxi,10,CHF,YES",
    ].join("\n");
    const r = reviewExpenses(csv, policy, fx);
    expect(r.rejected).toEqual([
      { line: 2, reason: "wrong number of fields" },
      { line: 4, reason: "invalid date" },
      { line: 5, reason: "invalid date" },
      { line: 6, reason: "missing employee" },
      { line: 7, reason: "unknown category" },
      { line: 8, reason: "unknown category" },
      { line: 9, reason: "invalid amount" },
      { line: 10, reason: "invalid amount" },
      { line: 11, reason: "invalid amount" },
      { line: 12, reason: "invalid amount" },
      { line: 13, reason: "unknown currency" },
      { line: 14, reason: "unknown currency" },
      { line: 15, reason: "invalid receipt flag" },
      { line: 16, reason: "invalid date" },
    ]);
    expect(r.lines.map((l) => l.line)).toEqual([17]);
  });

  test("quoted fields", () => {
    const csv = [
      "date,employee,category,amount,currency,receipt,note",
      ' "2026-09-01" , "Doe, ""J""" ,taxi,10,CHF,no,"a, b"',
      '2026-09-01,"Ann,taxi,10,CHF,no,x',
    ].join("\n");
    const r = reviewExpenses(csv, policy, fx);
    expect(r.lines[0]!.employee).toBe('Doe, "J"');
    expect(r.rejected).toEqual([{ line: 3, reason: "wrong number of fields" }]);
  });

  test("currency conversion rounds halves up exactly", () => {
    const csv = [
      HEADER,
      "2026-09-01,Ann,taxi,10.00,EUR,yes", // 941.2 -> 941
      "2026-09-02,Ann,taxi,0.05,USD,yes", // 4 exactly
      "2026-09-03,Ann,taxi,1.05,CHF,yes",
    ].join("\n");
    const r = reviewExpenses(csv, policy, { ...fx, USD: 0.8, CHF: 2 });
    expect(r.lines.map((l) => l.amountChfCents)).toEqual([941, 4, 105]);
    const half = reviewExpenses(`${HEADER}\n2026-09-01,Ann,taxi,0.01,X,yes\n2026-09-01,Ann,taxi,1.15,Y,yes`, policy, {
      X: 0.5,
      Y: 1.1,
    });
    // 0.5 -> 1 cent; 115 * 1.1 = 126.5 -> 127 (float would give 126.49999...)
    expect(half.lines.map((l) => l.amountChfCents)).toEqual([1, 127]);
  });
});

describe("policy checks", () => {
  test("violations in order and totals", () => {
    const csv = [
      HEADER,
      "2026-09-01,Ann,meals,30,CHF,yes", // 3000
      "2026-09-01,Ann,meals,30.0,CHF,yes", // dup, running 6000
      "2026-09-01,Ann,meals,30.00,CHF,no", // dup, running 9000 > 8000, no receipt
      "2026-09-01,Ann,meals,60,CHF,no", // item, daily, receipt
      "2026-09-01,Bob,meals,30,CHF,yes",
      "2026-09-01,Ann,meals,30,EUR,yes", // not a dup (currency), over daily
      "2026-09-02,Ann,hotel,300,CHF,yes",
      "2026-09-02,Ann,taxi,20,CHF,no", // exactly at receipt threshold
    ].join("\n");
    const r = reviewExpenses(csv, policy, fx);
    expect(r.lines.map((l) => l.violations)).toEqual([
      [],
      ["DUPLICATE"],
      ["DUPLICATE", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
      ["OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
      [],
      ["OVER_DAILY_LIMIT"],
      ["OVER_ITEM_LIMIT"],
      [],
    ]);
    expect(r.totals).toEqual({
      Ann: { approvedCents: 3000 + 2000, flaggedCents: 3000 + 3000 + 6000 + 2824 + 30000 },
      Bob: { approvedCents: 3000, flaggedCents: 0 },
    });
  });

  test("rejected rows do not count", () => {
    const csv = [HEADER, "2026-09-01,Ann,meals,30,CHF,maybe", "2026-09-01,Ann,meals,30,CHF,yes"].join("\n");
    const r = reviewExpenses(csv, policy, fx);
    expect(r.lines[0]!.violations).toEqual([]);
    expect(Object.keys(r.totals)).toEqual(["Ann"]);
  });

  test("employee names that collide with object properties", () => {
    const r = reviewExpenses(`${HEADER}\n2026-09-01,__proto__,taxi,1,CHF,yes`, policy, fx);
    expect(Object.keys(r.totals)).toEqual(["__proto__"]);
    expect(r.totals["__proto__"]).toEqual({ approvedCents: 100, flaggedCents: 0 });
  });
});
