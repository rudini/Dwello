# Design note: team board (`src/board.ts`)

**Hidden decision:** how each card's position, start/finish moments and blocked periods are
recorded, and how cycle time is derived from them. Callers only issue commands and ask questions.

**Both designs**

- A: stateful board object: `createBoard({ columns, now })` returning `addCard / move / block /
  unblock / cardsIn / cycleTime`.
- B: an event log plus pure projections: `apply(log, event)`, `cycleTime(log, id)`.

Chosen: A, because callers never see an event shape or timestamps. B would push both into every
call site.

**Interface** (unchanged from the stub)

- `addCard(title)`: appends to the first column and returns `C<n>`, numbered by successful adds.
  Throws `EMPTY_TITLE` or `WIP_LIMIT`.
- `move(id, column)`: appends to the target. Checks run in this order: `UNKNOWN_CARD`,
  `UNKNOWN_COLUMN`, `SAME_COLUMN`, `BLOCKED`, `SKIP_NOT_ALLOWED`, `WIP_LIMIT`.
- `block(id, reason)` / `unblock(id)`: throw `UNKNOWN_CARD`, `ALREADY_BLOCKED` or `NOT_BLOCKED`.
- `cardsIn(column)`: a copy of the ids in arrival order. Throws `UNKNOWN_COLUMN`.
- `cycleTime(id)`: `null` unless the card is in the last column. Otherwise
  `{ totalMs, blockedMs }`, with blocked spans clipped to [first start, latest finish].
- Every check runs before any change, so a failed call leaves the board unchanged.

**Depth**

`src/board.ts: surface 10, size 121, ratio 12.1, classitis no, pass-through 0 -> deep`.

Refactors:

1. Columns became records (index, limit, cards), with one shared WIP check.
2. The parallel maps were merged into one `Card` record (column, started, finished,
   blockedSince, blockedSpans).
3. The clock is now read once per move.

**Open points**

- The block `reason` is accepted but not stored, because nothing reads it.
- An open block never counts toward `blockedMs`. A blocked card can't move, so any block that is
  still open started after the card's latest arrival in the last column.
- There is no separate test for the order of the move checks. Each check has its own test, and the
  code runs them in the spec's order.

**Proof**

`scripts/tdd_replay ee98432..HEAD` printed `REPLAY: ACCEPT`. That proves phase order, test counts
and exit codes. It does not prove the assertions are strong.
