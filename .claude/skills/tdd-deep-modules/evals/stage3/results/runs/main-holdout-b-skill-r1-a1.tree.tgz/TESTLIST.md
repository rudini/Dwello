# Team board: test list

**Hidden decision:** how a card's position and blocked periods are recorded over time, and how
started/finished/blocked time are derived from that record; callers only ask questions
(`cardsIn`, `cycleTime`) and issue commands (`addCard`, `move`, `block`, `unblock`).

**Sketch A — stateful board object (the given `Board` interface):**
`const b = createBoard({ columns, now }); b.move(b.addCard("x"), "Doing"); b.cycleTime("C1")`

**Sketch B — event log + pure projections:**
`let log = apply(log, { type: "move", card: "C1", to: "Doing", at: now() }); cycleTime(log, "C1")`

**Chosen: Sketch A**, because the caller never sees the event/timestamp format or rule order;
Sketch B leaks the event shape and time-stamping into every call site.

## Behaviours

- [x] addCard returns "C1" and the card is listed in the first column
- [x] ids count up C1, C2, ... in order of successful adds; cards listed in arrival order
- [x] addCard rejects a blank title with EMPTY_TITLE and does not consume an id
- [x] addCard rejects with WIP_LIMIT when the first column is full
- [x] cardsIn rejects an unknown column with UNKNOWN_COLUMN
- [x] move puts the card at the end of the next column
- [x] move rejects an unknown card with UNKNOWN_CARD
- [x] move rejects an unknown column with UNKNOWN_COLUMN
- [x] move rejects the current column with SAME_COLUMN
- [x] move rejects a blocked card with BLOCKED
- [x] move rejects forward skips with SKIP_NOT_ALLOWED; backwards moves of any distance are allowed
- [x] move rejects with WIP_LIMIT when the target is full (blocked cards count)
- [x] move checks errors in the documented order (covered by the per-error tests; a dedicated
      test would pass without new code, so it got no red of its own)
- [x] block/unblock: unknown card UNKNOWN_CARD, ALREADY_BLOCKED, NOT_BLOCKED
- [x] cycleTime rejects an unknown card with UNKNOWN_CARD
- [x] cycleTime is null unless the card is in the last column (folded into the totalMs test)
- [x] cycleTime totalMs = arrival in last column - first departure from first column
- [x] blockedMs counts blocked time while in progress
- [x] trips back to the first column do not reset start; finish is the latest arrival in last
      column; blockedMs counts only blocked time inside [started, finished], including open blocks
