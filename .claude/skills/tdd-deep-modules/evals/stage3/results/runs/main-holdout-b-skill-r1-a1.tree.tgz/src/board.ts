export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Column extends ColumnConfig {
  index: number;
  cards: string[];
}

interface Card {
  id: string;
  column: Column;
  /** When the card first left the first column. */
  started?: number;
  /** When the card most recently arrived in the last column. */
  finished?: number;
  blockedSince?: number;
  blockedSpans: { from: number; to: number }[];
}

export function createBoard(options: BoardOptions): Board {
  const columns: Column[] = options.columns.map((c, index) => ({ ...c, index, cards: [] }));
  const first = columns[0];
  const last = columns[columns.length - 1];
  const cards = new Map<string, Card>();

  function column(name: string): Column {
    const found = columns.find((c) => c.name === name);
    if (!found) throw new BoardError("UNKNOWN_COLUMN", `Unknown column ${name}`);
    return found;
  }

  function card(id: string): Card {
    const found = cards.get(id);
    if (!found) throw new BoardError("UNKNOWN_CARD", `Unknown card ${id}`);
    return found;
  }

  function checkRoom(to: Column): void {
    if (to.wipLimit !== undefined && to.cards.length >= to.wipLimit) {
      throw new BoardError("WIP_LIMIT", `Column ${to.name} is full`);
    }
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Title is empty");
      checkRoom(first);
      const id = `C${cards.size + 1}`;
      cards.set(id, { id, column: first, blockedSpans: [] });
      first.cards.push(id);
      return id;
    },
    move(cardId, toColumn) {
      const moving = card(cardId);
      const from = moving.column;
      const to = column(toColumn);
      if (to === from) throw new BoardError("SAME_COLUMN", `Card ${cardId} is already in ${to.name}`);
      if (moving.blockedSince !== undefined) throw new BoardError("BLOCKED", `Card ${cardId} is blocked`);
      if (to.index > from.index + 1) throw new BoardError("SKIP_NOT_ALLOWED", "Cards cannot skip columns");
      checkRoom(to);
      const now = options.now();
      from.cards.splice(from.cards.indexOf(cardId), 1);
      to.cards.push(cardId);
      moving.column = to;
      if (from === first) moving.started ??= now;
      if (to === last) moving.finished = now;
    },
    block(cardId) {
      const blocking = card(cardId);
      if (blocking.blockedSince !== undefined) {
        throw new BoardError("ALREADY_BLOCKED", `Card ${cardId} is already blocked`);
      }
      blocking.blockedSince = options.now();
    },
    unblock(cardId) {
      const unblocking = card(cardId);
      if (unblocking.blockedSince === undefined) throw new BoardError("NOT_BLOCKED", `Card ${cardId} is not blocked`);
      unblocking.blockedSpans.push({ from: unblocking.blockedSince, to: options.now() });
      unblocking.blockedSince = undefined;
    },
    cardsIn(name) {
      return [...column(name).cards];
    },
    cycleTime(cardId) {
      const { column: at, started, finished, blockedSpans } = card(cardId);
      if (at !== last || started === undefined || finished === undefined) return null;
      // A blocked card cannot move, so a still-open block began after `finished` and never counts.
      let blockedMs = 0;
      for (const span of blockedSpans) {
        blockedMs += Math.max(0, Math.min(span.to, finished) - Math.max(span.from, started));
      }
      return { totalMs: finished - started, blockedMs };
    },
  };
}
