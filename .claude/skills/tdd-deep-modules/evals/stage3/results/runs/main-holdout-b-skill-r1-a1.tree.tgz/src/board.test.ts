import { expect, test } from "bun:test";
import { BoardError, createBoard, type Board, type ColumnConfig } from "./board";

const defaultColumns: ColumnConfig[] = [{ name: "Backlog" }, { name: "Doing" }, { name: "Review" }, { name: "Done" }];

function setup(columns: ColumnConfig[] = defaultColumns) {
  const clock = { t: 0 };
  const board: Board = createBoard({ columns, now: () => clock.t });
  return { board, clock };
}

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

test("addCard returns C1 and lists the card in the first column", () => {
  const { board } = setup();
  const id = board.addCard("Fix login");
  expect({ id, backlog: board.cardsIn("Backlog") }).toEqual({ id: "C1", backlog: ["C1"] });
});

test("ids count up in order of adds and cards are listed in arrival order", () => {
  const { board } = setup();
  expect([board.addCard("a"), board.addCard("b"), board.addCard("c")]).toEqual(["C1", "C2", "C3"]);
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2", "C3"]);
});

function codeOf(action: () => unknown): string | undefined {
  try {
    action();
  } catch (error) {
    return error instanceof BoardError ? error.code : `not a BoardError: ${error}`;
  }
  return undefined;
}

test("addCard rejects a blank title with EMPTY_TITLE without consuming an id", () => {
  const { board } = setup();
  expect(codeOf(() => board.addCard("   "))).toBe("EMPTY_TITLE");
  expect(board.cardsIn("Backlog")).toEqual([]);
  expect(board.addCard("real")).toBe("C1");
});

test("addCard rejects with WIP_LIMIT when the first column is full", () => {
  const { board } = setup([{ name: "Backlog", wipLimit: 2 }, { name: "Done" }]);
  board.addCard("a");
  board.addCard("b");
  expect(codeOf(() => board.addCard("c"))).toBe("WIP_LIMIT");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("cardsIn rejects an unknown column with UNKNOWN_COLUMN", () => {
  const { board } = setup();
  expect(codeOf(() => board.cardsIn("Archive"))).toBe("UNKNOWN_COLUMN");
});

test("move puts the card at the end of the next column", () => {
  const { board } = setup();
  board.addCard("a");
  board.addCard("b");
  board.addCard("c");
  board.move("C2", "Doing");
  board.move("C1", "Doing");
  expect(board.cardsIn("Backlog")).toEqual(["C3"]);
  expect(board.cardsIn("Doing")).toEqual(["C2", "C1"]);
  expect(board.addCard("d")).toBe("C4");
});

test("move rejects an unknown card with UNKNOWN_CARD", () => {
  const { board } = setup();
  expect(codeOf(() => board.move("C9", "Doing"))).toBe("UNKNOWN_CARD");
});

test("move rejects an unknown column with UNKNOWN_COLUMN and leaves the card in place", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.move("C1", "Archive"))).toBe("UNKNOWN_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("move rejects the card's current column with SAME_COLUMN and keeps its position", () => {
  const { board } = setup();
  board.addCard("a");
  board.addCard("b");
  expect(codeOf(() => board.move("C1", "Backlog"))).toBe("SAME_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("move rejects a blocked card with BLOCKED", () => {
  const { board } = setup();
  board.addCard("a");
  board.block("C1", "waiting for customer");
  expect(codeOf(() => board.move("C1", "Doing"))).toBe("BLOCKED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("move rejects forward skips with SKIP_NOT_ALLOWED but allows any backward move", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.move("C1", "Review"))).toBe("SKIP_NOT_ALLOWED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  board.move("C1", "Doing");
  board.move("C1", "Review");
  board.move("C1", "Done");
  board.move("C1", "Backlog");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  expect(board.cardsIn("Done")).toEqual([]);
});

test("move rejects with WIP_LIMIT when the target is full, counting blocked cards", () => {
  const { board } = setup([{ name: "Backlog" }, { name: "Doing", wipLimit: 1 }, { name: "Done" }]);
  board.addCard("a");
  board.addCard("b");
  board.move("C1", "Doing");
  board.block("C1", "waiting");
  expect(codeOf(() => board.move("C2", "Doing"))).toBe("WIP_LIMIT");
  expect(board.cardsIn("Backlog")).toEqual(["C2"]);
  expect(board.cardsIn("Doing")).toEqual(["C1"]);
});

test("block rejects unknown cards and double blocking; unblock rejects unknown and unblocked cards", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.block("C9", "x"))).toBe("UNKNOWN_CARD");
  expect(codeOf(() => board.unblock("C9"))).toBe("UNKNOWN_CARD");
  expect(codeOf(() => board.unblock("C1"))).toBe("NOT_BLOCKED");
  board.block("C1", "waiting");
  expect(codeOf(() => board.block("C1", "again"))).toBe("ALREADY_BLOCKED");
  board.unblock("C1");
  board.move("C1", "Doing");
  expect(board.cardsIn("Doing")).toEqual(["C1"]);
});

test("cycleTime rejects an unknown card with UNKNOWN_CARD", () => {
  const { board } = setup();
  expect(codeOf(() => board.cycleTime("C1"))).toBe("UNKNOWN_CARD");
});

test("cycleTime is null until the card is done, then runs from leaving the first column to arriving in the last", () => {
  const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
  clock.t = 1_000;
  board.addCard("a");
  expect(board.cycleTime("C1")).toBeNull();
  clock.t = 5_000;
  board.move("C1", "Doing");
  expect(board.cycleTime("C1")).toBeNull();
  clock.t = 12_000;
  board.move("C1", "Done");
  clock.t = 20_000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 0 });
});

test("cycleTime counts time spent blocked while in progress", () => {
  const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
  board.addCard("a");
  clock.t = 1_000;
  board.move("C1", "Doing");
  clock.t = 2_000;
  board.block("C1", "waiting");
  clock.t = 3_500;
  board.unblock("C1");
  clock.t = 4_000;
  board.block("C1", "again");
  clock.t = 4_200;
  board.unblock("C1");
  clock.t = 6_000;
  board.move("C1", "Done");
  expect(board.cycleTime("C1")).toEqual({ totalMs: 5_000, blockedMs: 1_700 });
});

test("cycleTime keeps the first start and latest finish, counting only blocked time between them", () => {
  const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
  board.addCard("a");
  clock.t = 100;
  board.block("C1", "before start");
  clock.t = 300;
  board.unblock("C1");
  clock.t = 1_000;
  board.move("C1", "Doing");
  clock.t = 2_000;
  board.move("C1", "Done");
  clock.t = 2_500;
  board.block("C1", "reopened");
  clock.t = 2_600;
  board.unblock("C1");
  clock.t = 3_000;
  board.move("C1", "Backlog");
  clock.t = 3_200;
  board.block("C1", "back in backlog");
  clock.t = 3_700;
  board.unblock("C1");
  clock.t = 4_000;
  board.move("C1", "Doing");
  clock.t = 5_000;
  board.move("C1", "Done");
  clock.t = 5_500;
  board.block("C1", "after finish");
  clock.t = 5_800;
  board.unblock("C1");
  clock.t = 6_000;
  board.block("C1", "still open");
  clock.t = 9_000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 4_000, blockedMs: 600 });
});
