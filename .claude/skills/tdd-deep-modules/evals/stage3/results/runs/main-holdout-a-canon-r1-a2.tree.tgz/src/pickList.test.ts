import { describe, expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

describe("allocation", () => {
  test("one order, one item, one lot covering it gives one pick", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
    expect(result).toEqual({
      picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
      shortages: [],
    });
  });

  test("empty text gives an empty pick list", () => {
    expect(buildPickList("", [lot("A-01-1", "OLIVE-500", 10)])).toEqual({ picks: [], shortages: [] });
  });

  test("comment and blank lines are ignored", () => {
    const text = "# export 2026-10-12 06:00\n\nORDER 1001\n   \n  # a note\n  OLIVE-500 x3\n";
    expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 10)]).picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ]);
  });

  test("an item takes from the lot with the earliest best-before date first", () => {
    const stock = [
      lot("A-01-3", "PASTA-1KG", 9, "2026-10-01"),
      lot("A-01-2", "OLIVE-500", 2, "2026-12-01"),
      lot("A-01-1", "OLIVE-500", 2, "2026-11-01"),
    ];
    expect(buildPickList("ORDER 1001\n  OLIVE-500 x3", stock).picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-01-2", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    ]);
  });

  test("lots without a best-before date come after all dated lots", () => {
    const stock = [lot("A-01-2", "SALT", 2, null), lot("A-01-1", "SALT", 2, "2030-01-01")];
    expect(buildPickList("ORDER 1\n SALT x3", stock).picks).toEqual([
      { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "1" },
      { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "1" },
    ]);
  });

  test("equal best-before dates are broken by bin code", () => {
    const stock = [
      lot("A-01-4", "SALT", 2, null),
      lot("A-01-3", "SALT", 2, null),
      lot("A-01-2", "SALT", 2, "2027-01-01"),
      lot("A-01-1", "SALT", 2, "2027-01-01"),
    ];
    expect(buildPickList("ORDER 1\n SALT x5", stock).picks).toEqual([
      { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "1" },
      { bin: "A-01-2", sku: "SALT", qty: 2, orderId: "1" },
      { bin: "A-01-3", sku: "SALT", qty: 1, orderId: "1" },
    ]);
  });

  test("lots without stock yield no pick", () => {
    const stock = [lot("A-01-1", "SALT", 0, "2026-01-01"), lot("A-01-2", "SALT", 5, "2027-01-01")];
    expect(buildPickList("ORDER 1\n SALT x1", stock).picks).toEqual([
      { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "1" },
    ]);
  });

  test("not enough stock picks what is there and reports the rest as missing", () => {
    const result = buildPickList("ORDER 1\n SALT x5\n OIL x2", [lot("A-01-1", "SALT", 3)]);
    expect(result).toEqual({
      picks: [{ bin: "A-01-1", sku: "SALT", qty: 3, orderId: "1" }],
      shortages: [
        { orderId: "1", sku: "SALT", missing: 2 },
        { orderId: "1", sku: "OIL", missing: 2 },
      ],
    });
  });

  test("stock taken by an earlier order is not available to a later one", () => {
    const result = buildPickList("ORDER 1\n SALT x2\nORDER 2\n SALT x2", [lot("A-01-1", "SALT", 3)]);
    expect(result).toEqual({
      picks: [
        { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "1" },
        { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "2" },
      ],
      shortages: [{ orderId: "2", sku: "SALT", missing: 1 }],
    });
  });

  test("priority orders are served first, in text order", () => {
    const text = "ORDER 1\n SALT x1\nORDER 2 !\n SALT x1\nORDER 3\n SALT x1\nORDER 4   !\n SALT x1";
    const result = buildPickList(text, [lot("A-01-1", "SALT", 2)]);
    expect(result.picks.map((p) => p.orderId)).toEqual(["2", "4"]);
    expect(result.shortages.map((s) => s.orderId)).toEqual(["1", "3"]);
  });

  test("a SKU repeated within an order is summed and keeps its first position", () => {
    const result = buildPickList("ORDER 1\n SALT x2\n OIL x1\n SALT x3", []);
    expect(result.shortages).toEqual([
      { orderId: "1", sku: "SALT", missing: 5 },
      { orderId: "1", sku: "OIL", missing: 1 },
    ]);
  });

  test("the stock array and its lots are left untouched", () => {
    const stock = [lot("A-01-2", "SALT", 2, null), lot("A-01-1", "SALT", 2, "2027-01-01")];
    const snapshot = structuredClone(stock);
    const lots = [...stock];
    buildPickList("ORDER 1\n SALT x3", stock);
    expect(stock).toEqual(snapshot);
    expect(stock.every((l, i) => l === lots[i])).toBe(true);
  });
});

describe("walking order", () => {
  test("aisles alphabetically, levels ascending within a rack", () => {
    const stock = [lot("B-01-1", "TEA", 1), lot("A-01-2", "OIL", 1), lot("A-01-1", "SALT", 1)];
    const result = buildPickList("ORDER 1\n TEA x1\n OIL x1\n SALT x1", stock);
    expect(result.picks.map((p) => p.bin)).toEqual(["A-01-1", "A-01-2", "B-01-1"]);
  });

  test("every second visited aisle is walked with racks descending; aisles without picks do not count", () => {
    const bins = ["A-01-2", "A-02-1", "C-01-1", "C-10-1", "C-10-2", "D-03-1", "D-04-1", "F-02-1", "F-01-1"];
    // B and E hold stock, but nothing is picked from them.
    const stock = [
      ...bins.map((bin, i) => lot(bin, `SKU-${i}`, 1)),
      lot("B-01-1", "UNUSED", 1),
      lot("E-01-1", "UNUSED", 1),
    ];
    const text = "ORDER 1\n" + [...bins].reverse().map((_, i) => ` SKU-${bins.length - 1 - i} x1`).join("\n");
    expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual([
      "A-01-2",
      "A-02-1",
      "C-10-1",
      "C-10-2",
      "C-01-1",
      "D-03-1",
      "D-04-1",
      "F-02-1",
      "F-01-1",
    ]);
  });

  test("picks at the same bin keep the order in which they were allocated", () => {
    const stock = [lot("B-01-1", "SALT", 9), lot("A-01-1", "OIL", 9)];
    const text = "ORDER 1\n SALT x1\nORDER 2 !\n SALT x2\n OIL x1\nORDER 3\n SALT x3";
    expect(buildPickList(text, stock).picks).toEqual([
      { bin: "A-01-1", sku: "OIL", qty: 1, orderId: "2" },
      { bin: "B-01-1", sku: "SALT", qty: 2, orderId: "2" },
      { bin: "B-01-1", sku: "SALT", qty: 1, orderId: "1" },
      { bin: "B-01-1", sku: "SALT", qty: 3, orderId: "3" },
    ]);
  });
});

function formatErrorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  return undefined;
}

describe("format errors", () => {
  test("an item line before the first ORDER", () => {
    expect(formatErrorLine("# header\n\n  SALT x1\nORDER 1\n SALT x1")).toBe(3);
  });

  test("an ORDER whose id was already used", () => {
    expect(formatErrorLine("ORDER 1\n SALT x1\nORDER 2\n SALT x1\nORDER 1 !\n SALT x1")).toBe(5);
  });

  test("an ORDER without item lines is reported at its ORDER line", () => {
    expect(formatErrorLine("ORDER 1\n SALT x1\nORDER 2\n# nothing\n\nORDER 3\n SALT x1")).toBe(3);
    expect(formatErrorLine("ORDER 1\n SALT x1\nORDER 2\n\n")).toBe(3);
  });

  test.each([
    ["zero quantity", "SALT x0"],
    ["leading zero", "SALT x03"],
    ["lowercase SKU", "salt x1"],
    ["missing x", "SALT 1"],
    ["no space before x", "SALTx1"],
    ["negative quantity", "SALT x-1"],
    ["fractional quantity", "SALT x1.5"],
    ["trailing text", "SALT x1 please"],
    ["SKU with invalid character", "SALT_FINE x1"],
    ["unknown keyword", "ORDERS 2"],
    ["lowercase keyword", "order 2"],
    ["ORDER without id", "ORDER"],
    ["id with invalid character", "ORDER 2_b"],
    ["priority mark glued to id", "ORDER 2!"],
    ["something other than ! after id", "ORDER 2 ?"],
  ])("a line that matches neither form: %s", (_, badLine) => {
    expect(formatErrorLine(`ORDER 1\n SALT x1\n  ${badLine}\n SALT x1`)).toBe(3);
  });

  test("the first problem from the top is reported", () => {
    // empty order (line 1) before a malformed line (2) and a duplicate id (3)
    expect(formatErrorLine("ORDER 1\n salt x1\nORDER 1\n SALT x1")).toBe(1);
    // malformed line (2) inside an order that does get an item later
    expect(formatErrorLine("ORDER 1\n salt x1\n SALT x1\nORDER 1\n SALT x1")).toBe(2);
    // duplicate id (3) before an empty order (5)
    expect(formatErrorLine("ORDER 1\n SALT x1\nORDER 1\n SALT x1\nORDER 2")).toBe(3);
    // item before the first ORDER (1) before an empty order (2)
    expect(formatErrorLine("SALT x1\nORDER 1\nORDER 2\n SALT x0")).toBe(1);
  });
});

test("the example batch from the export", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const stock = [
    lot("B-02-1", "OLIVE-500", 3, "2027-03-01"),
    lot("A-05-2", "OLIVE-500", 1, "2026-11-15"),
    lot("B-07-1", "PASTA-1KG", 4, null),
  ];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-05-2", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-07-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 1 }],
  });
});

describe("whitespace", () => {
  test("indentation, several spaces, tabs and CRLF line endings are tolerated", () => {
    const text = "\t# export\r\n  ORDER   A-1   !  \r\n\t SALT    x2\r\n";
    expect(buildPickList(text, [lot("A-01-1", "SALT", 5)])).toEqual({
      picks: [{ bin: "A-01-1", sku: "SALT", qty: 2, orderId: "A-1" }],
      shortages: [],
    });
  });
});
