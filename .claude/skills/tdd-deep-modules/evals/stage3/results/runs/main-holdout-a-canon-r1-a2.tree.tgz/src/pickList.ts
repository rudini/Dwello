export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

function compare(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Earliest best-before date first, undated lots last, ties by bin code. */
function byExpiryThenBin(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compare(a.expires, b.expires);
  }
  return compare(a.bin, b.bin);
}

interface Order {
  id: string;
  priority: boolean;
  /** Line number of the ORDER line. */
  line: number;
  /** Quantity per SKU, in order of first appearance. */
  items: Map<string, number>;
}

/** Parses the orders text; throws an OrderFormatError for the topmost problem. */
function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  let current: Order | undefined;
  for (const [index, raw] of ordersText.split("\n").entries()) {
    const lineNumber = index + 1;
    const line = raw.trim();
    if (line === "" || line.startsWith("#")) continue;
    const order = /^ORDER\s+([A-Za-z0-9-]+)(\s+!)?$/.exec(line);
    if (order) {
      const id = order[1]!;
      current = { id, priority: order[2] !== undefined, line: lineNumber, items: new Map() };
      if (orders.some((o) => o.id === id)) {
        problems.push(new OrderFormatError(lineNumber, `order id ${id} already used`));
      } else {
        orders.push(current);
      }
      continue;
    }
    const item = /^([A-Z0-9-]+)\s+x([1-9][0-9]*)$/.exec(line);
    if (!item) {
      problems.push(new OrderFormatError(lineNumber, `neither an ORDER nor an item line: ${line}`));
      continue;
    }
    if (!current) {
      problems.push(new OrderFormatError(lineNumber, "item line before the first ORDER"));
      continue;
    }
    const sku = item[1]!;
    current.items.set(sku, (current.items.get(sku) ?? 0) + Number(item[2]));
  }
  for (const order of orders) {
    if (order.items.size === 0) {
      problems.push(new OrderFormatError(order.line, `order ${order.id} has no items`));
    }
  }
  const [first] = problems.sort((a, b) => a.line - b.line);
  if (first) throw first;
  return orders;
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  const lots = stock.map((l) => ({ ...l })).sort(byExpiryThenBin);
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  for (const { id: orderId, items } of servingOrder) {
    for (const [sku, qty] of items) {
      const missing = allocate(lots, sku, qty, (bin, taken) => picks.push({ bin, sku, qty: taken, orderId }));
      if (missing > 0) shortages.push({ orderId, sku, missing });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}

/**
 * Takes up to `wanted` of `sku` from `lots` (already in allocation order), reducing their
 * remaining quantities and reporting each lot taken from. Returns the quantity still missing.
 */
function allocate(lots: StockLot[], sku: string, wanted: number, take: (bin: string, qty: number) => void): number {
  for (const lot of lots) {
    if (wanted === 0) break;
    if (lot.sku !== sku || lot.qty === 0) continue;
    const qty = Math.min(wanted, lot.qty);
    lot.qty -= qty;
    wanted -= qty;
    take(lot.bin, qty);
  }
  return wanted;
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "", level = ""] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/**
 * Serpentine walk: visited aisles alphabetically, racks ascending in the 1st, 3rd, ...
 * visited aisle and descending in the 2nd, 4th, ...; levels ascending. Stable for equal bins.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((p) => parseBin(p.bin).aisle))].sort(compare);
  const descending = new Set(aisles.filter((_, i) => i % 2 === 1));
  return [...picks].sort((p, q) => {
    const a = parseBin(p.bin);
    const b = parseBin(q.bin);
    const rackDirection = descending.has(a.aisle) ? -1 : 1;
    return compare(a.aisle, b.aisle) || rackDirection * (a.rack - b.rack) || a.level - b.level;
  });
}
