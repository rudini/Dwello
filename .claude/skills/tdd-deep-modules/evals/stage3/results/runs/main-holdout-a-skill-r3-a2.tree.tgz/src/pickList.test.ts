import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

// Returns the pick list, or the thrown error, so that every outcome is checked by an assertion.
const outcome = (ordersText: string, stock: StockLot[]): unknown => {
  try {
    return buildPickList(ordersText, stock);
  } catch (error) {
    return error;
  }
};

const expectFormatErrorAt = (ordersText: string, line: number) => {
  const error = outcome(ordersText, []);
  expect(error).toBeInstanceOf(OrderFormatError);
  expect(error).toMatchObject({ line });
};

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("one order, one item, one lot: one pick", () => {
  expect(outcome("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)])).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("an item takes from several lots, earliest best-before first", () => {
  const stock = [
    lot("A-03-1", "OLIVE-500", 9, "2027-01-15"),
    lot("A-02-1", "OLIVE-500", 4, "2026-12-01"),
    lot("A-01-1", "OLIVE-500", 2, "2026-11-01"),
  ];
  expect(outcome("ORDER 1001\n  OLIVE-500 x7", stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-02-1", sku: "OLIVE-500", qty: 4, orderId: "1001" },
      { bin: "A-03-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    ],
    shortages: [],
  });
});

test("undated lots come after dated lots; ties are broken by bin code", () => {
  const stock = [
    lot("A-04-1", "OLIVE-500", 5, "2026-11-01"),
    lot("A-01-1", "OLIVE-500", 5, "2026-11-01"),
    lot("A-05-1", "PASTA-1KG", 5, null),
    lot("A-03-1", "PASTA-1KG", 5, null),
    lot("A-02-1", "PASTA-1KG", 1, "2027-06-30"),
  ];
  expect(outcome("ORDER 1001\n  OLIVE-500 x1\n  PASTA-1KG x2", stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
      { bin: "A-02-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      { bin: "A-03-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
    ],
    shortages: [],
  });
});

test("an uncovered item picks what is there and reports a shortage", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 2, "2026-11-01"), lot("A-02-1", "PASTA-1KG", 3, null)];
  expect(outcome("ORDER 1001\n  OLIVE-500 x5\n  RICE-1KG x2\n  PASTA-1KG x3", stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-02-1", sku: "PASTA-1KG", qty: 3, orderId: "1001" },
    ],
    shortages: [
      { orderId: "1001", sku: "OLIVE-500", missing: 3 },
      { orderId: "1001", sku: "RICE-1KG", missing: 2 },
    ],
  });
});

test("stock taken by an earlier order is not available to a later one", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 4, "2026-11-01"), lot("A-02-1", "OLIVE-500", 1, "2026-12-01")];
  expect(outcome("ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n  OLIVE-500 x4", stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "A-02-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    ],
    shortages: [{ orderId: "1002", sku: "OLIVE-500", missing: 2 }],
  });
});

test("priority orders are served before the others, in text order", () => {
  const text = "ORDER 1001\n  OLIVE-500 x1\nORDER 1002 !\n  OLIVE-500 x1\nORDER 1003   !\n  OLIVE-500 x1\nORDER 1004\n  OLIVE-500 x1";
  expect(outcome(text, [lot("A-01-1", "OLIVE-500", 3, null)])).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1003" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    ],
    shortages: [{ orderId: "1004", sku: "OLIVE-500", missing: 1 }],
  });
});

test("a repeated SKU in an order is summed at the position of its first appearance", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 3, null), lot("A-02-1", "PASTA-1KG", 1, null)];
  expect(outcome("ORDER 1001\n  OLIVE-500 x2\n  PASTA-1KG x2\n  OLIVE-500 x2", stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
      { bin: "A-02-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
    ],
    shortages: [
      { orderId: "1001", sku: "OLIVE-500", missing: 1 },
      { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
    ],
  });
});

test("picks follow aisles alphabetically, racks in a serpentine, levels ascending; stock stays untouched", () => {
  const bins = ["C-10-1", "B-01-1", "A-03-1", "B-02-3", "A-01-2", "C-01-1", "B-02-1", "A-01-1"];
  const stock = bins.map((bin) => lot(bin, `SKU-${bin}`, 5, "2026-11-01"));
  const before = structuredClone(stock);
  const text = ["ORDER 1001", ...bins.map((bin) => `  SKU-${bin} x2`)].join("\n");
  const walked = ["A-01-1", "A-01-2", "A-03-1", "B-02-1", "B-02-3", "B-01-1", "C-01-1", "C-10-1"];
  expect(outcome(text, stock)).toEqual({
    picks: walked.map((bin) => ({ bin, sku: `SKU-${bin}`, qty: 2, orderId: "1001" })),
    shortages: [],
  });
  expect(stock).toEqual(before);
});

test("the serpentine direction counts only aisles that contain picks", () => {
  const bins = ["A-01-1", "A-02-1", "C-01-1", "C-02-1", "D-01-1", "D-02-1"];
  const stock = [...bins.map((bin) => lot(bin, `SKU-${bin}`, 5, null)), lot("B-01-1", "UNUSED", 5, null)];
  const text = ["ORDER 1001", ...bins.map((bin) => `  SKU-${bin} x1`)].join("\n");
  const walked = ["A-01-1", "A-02-1", "C-02-1", "C-01-1", "D-01-1", "D-02-1"];
  expect(outcome(text, stock)).toEqual({
    picks: walked.map((bin) => ({ bin, sku: `SKU-${bin}`, qty: 1, orderId: "1001" })),
    shortages: [],
  });
});

test("an item line before the first ORDER is an error", () => {
  expectFormatErrorAt("# export\n\n  OLIVE-500 x1\nORDER 1001\n  OLIVE-500 x1", 3);
});

test("an ORDER line with an id already used is an error", () => {
  expectFormatErrorAt("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n  OLIVE-500 x1\nORDER 1001 !\n  OLIVE-500 x1", 5);
});

test("an ORDER without item lines is an error at its ORDER line", () => {
  expectFormatErrorAt("ORDER 1001\n  OLIVE-500 x1\nORDER 1002 !\n# nothing here\n\nORDER 1003\n  OLIVE-500 x1", 3);
  expectFormatErrorAt("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n", 3);
});

test("a line that is neither an ORDER nor an item line is an error", () => {
  const malformed = [
    "OLIVE-500 x0",
    "OLIVE-500 x03",
    "olive-500 x1",
    "OLIVE_500 x1",
    "OLIVE-500 3",
    "OLIVE-500x3",
    "OLIVE-500 x-1",
    "OLIVE-500 x1.5",
    "OLIVE-500 x 1",
    "ORDER 1002!",
    "ORDER 10_02",
    "ORDER",
    "ORDER 1002 ! !",
    "hello",
  ];
  for (const line of malformed) expectFormatErrorAt(`ORDER 1001\n  OLIVE-500 x1\n  ${line}\nORDER 1003\n  PASTA-1KG x1`, 3);
});
