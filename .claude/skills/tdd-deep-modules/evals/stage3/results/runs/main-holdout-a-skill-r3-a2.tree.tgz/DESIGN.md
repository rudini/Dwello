# Pick list: design note

**Hidden decision:** how the orders text is parsed and validated, how stock is
allocated (priority, best-before, bin tie-break) and how picks are ordered for
the serpentine walk. Callers hand in text and stock and get a pick list.

**Both designs:**

- A: `buildPickList(ordersText, stock): PickList`, throws `OrderFormatError`.
- B: `parseOrders(text)`, `allocate(orders, stock)`, `walkOrder(picks)` as three exports.

Chosen: A, because the caller learns one name and two inputs, while B would leak the
order model and the pipeline sequence into every call site.

**Interface** (`src/pickList.ts`):

- `buildPickList(ordersText, stock)` returns `{ picks, shortages }`: picks in walking
  order, shortages in serving order. It never modifies `stock`.
- `OrderFormatError` carries the 1-based `line` of the first problem from the top.
- The types `StockLot`, `Pick`, `Shortage`, `PickList` are unchanged from the stub.

Behind it, three private functions: `parseOrders` (one pass, throws at the first
problem), `allocate` (priority first, lots sorted once by best-before then bin,
remaining quantities kept in a `Map` so the input stays untouched) and
`inWalkingOrder` (stable sort on aisle, serpentine rack, level).

**Depth:** `src/pickList.ts: surface 10, size 112, ratio 11.2, classitis no,
pass-through 0, tests 1, unused 0, duplicate 6`. The surface is mostly the
prescribed types; the 6 "duplicate" lines are their repeated field declarations
(`sku: string;` etc.) and closing braces, not copied logic. Refactors split parsing
from allocation, moved the walk into its own function, and replaced a sentinel
date with an explicit null rule in the lot comparison.

**Open points / interpretations:**

- An order's emptiness is detected when the next `ORDER` line or the end is reached.
  So `ORDER 1\nbad line` reports line 2 (the bad line), while `ORDER 1\nORDER 2`
  reports line 1.
- A line like `ORDER x3` is read as an ORDER with id `x3`, not as an item of SKU `ORDER`.
- Racks are compared numerically and levels numerically; bins are assumed to be well
  formed (`<aisle>-<rack>-<level>`) as the stock comes from the system, not from the text.
- Lots with quantity 0 never produce picks.

**Proof:** `scripts/tdd_replay 450df2e..HEAD` printed `REPLAY: ACCEPT`.
