export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  items: { sku: string; qty: number }[];
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  return allocate(parseOrders(ordersText), stock);
}

/**
 * Reads the orders top to bottom and throws at the first problem. An order's emptiness is
 * known only when the next ORDER line or the end of the text is reached.
 */
function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  let current: (Order & { line: number }) | undefined;
  const requireItemsInCurrent = () => {
    if (current && current.items.length === 0) throw new OrderFormatError(current.line, "order without item lines");
  };
  for (const [index, raw] of ordersText.split("\n").entries()) {
    const lineNo = index + 1;
    const line = raw.trim();
    if (line === "" || line.startsWith("#")) continue;

    const order = /^ORDER ([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (order) {
      const [, id, priorityMark] = order;
      requireItemsInCurrent();
      if (orders.some((o) => o.id === id)) throw new OrderFormatError(lineNo, `order id ${id} already used`);
      current = { id, priority: priorityMark !== undefined, items: [], line: lineNo };
      orders.push(current);
      continue;
    }

    const item = /^([A-Z0-9-]+) +x([1-9]\d*)$/.exec(line);
    if (!item) throw new OrderFormatError(lineNo, `not an ORDER or item line: ${line}`);
    if (!current) throw new OrderFormatError(lineNo, "item line before the first ORDER");
    const [, sku, qty] = item;
    const same = current.items.find((i) => i.sku === sku);
    if (same) same.qty += Number(qty);
    else current.items.push({ sku, qty: Number(qty) });
  }
  requireItemsInCurrent();
  return orders;
}

/** Serves priority orders first, then the rest; each item takes from its lots, earliest best-before first. */
function allocate(orders: Order[], stock: StockLot[]): PickList {
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  // Stock left per lot, kept apart so the caller's lots stay untouched.
  const remaining = new Map(stock.map((lot) => [lot, lot.qty]));
  const lotsInTakingOrder = [...stock].sort(byBestBeforeThenBin);
  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const { id: orderId, items } of served) {
    for (const { sku, qty: wanted } of items) {
      let missing = wanted;
      for (const lot of lotsInTakingOrder) {
        if (missing === 0) break;
        if (lot.sku !== sku) continue;
        const qty = Math.min(missing, remaining.get(lot)!);
        if (qty === 0) continue;
        remaining.set(lot, remaining.get(lot)! - qty);
        picks.push({ bin: lot.bin, sku, qty, orderId });
        missing -= qty;
      }
      if (missing > 0) shortages.push({ orderId, sku, missing });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}

/**
 * Serpentine walk: aisles alphabetically (only those with picks), racks ascending in the
 * 1st, 3rd, ... visited aisle and descending in the others, levels ascending. The sort is
 * stable, so picks at the same bin keep their allocation order.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((p) => p.bin.split("-")[0]))].sort();
  const walkKey = (bin: string): [string, number, number] => {
    const [aisle, rack, level] = bin.split("-");
    const descending = aisles.indexOf(aisle) % 2 === 1;
    return [aisle, descending ? -Number(rack) : Number(rack), Number(level)];
  };
  return [...picks].sort((p, q) => {
    const a = walkKey(p.bin);
    const b = walkKey(q.bin);
    for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
    return 0;
  });
}

function byBestBeforeThenBin(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return a.expires < b.expires ? -1 : 1;
  }
  return a.bin < b.bin ? -1 : a.bin > b.bin ? 1 : 0;
}
