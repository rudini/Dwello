# Pick list: test list

**Hidden decision:** how the orders text is parsed and validated, how stock is
allocated (priority, best-before, bin tie-break) and how picks are ordered for
the serpentine walk. Callers only hand in text and stock and get a pick list.

**Design A (one general call, given by the task):**
`buildPickList(ordersText, stock): PickList`, throws `OrderFormatError`.
Call site: `const { picks, shortages } = buildPickList(text, stock);`

**Design B (several special calls):**
`parseOrders(text): Order[]`, `allocate(orders, stock): Allocation`,
`walkOrder(picks): Pick[]`.
Call site: `walkOrder(allocate(parseOrders(text), stock).picks)`.

**Chosen: Design A**, because the caller needs to know one name and two inputs,
while B leaks the order model and the pipeline sequence into every call site.

## Behaviours (through `buildPickList`)

- [x] one order, one item, one lot: one pick
- [x] an item takes from several lots, earliest best-before first
- [x] undated lots come after dated lots; ties broken by bin code
- [x] uncovered item picks what is there and reports a shortage
- [x] stock taken by an earlier order is not available to a later one
- [x] priority orders (`!`) are served before others, in text order
- [x] repeated SKU in an order is summed at the position of its first appearance
- [x] comments, blank lines and surrounding spaces are ignored
      (no own test: passed from the start; covered by the line numbers in the error tests
      and the indented item lines everywhere)
- [x] stock array and its objects are not modified (asserted in the walking-order test)
- [x] picks follow aisles alphabetically, racks serpentine, levels ascending
- [x] serpentine direction counts only aisles that contain picks
- [x] picks at the same bin keep their allocation order
      (no own test: covered by the priority and earlier-order tests)
- [x] error: item line before the first ORDER
- [x] error: duplicate order id
- [x] error: ORDER without items, reported at its ORDER line (also at end of text)
- [x] error: malformed lines (x0, x03, lowercase SKU, missing x, `!` without space)
- [x] error: the first problem from the top is reported
      (no own test: the parser reads top to bottom and throws at once, so no red was possible)
