import { describe, expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

/** One order with one item per bin, so every lot yields exactly one pick. */
function walk(bins: string[]): string[] {
  const text = ["ORDER 1", ...bins.map((_, i) => `SKU-${i} x1`)].join("\n");
  const stock = bins.map((bin, i) => lot(bin, `SKU-${i}`, 1));
  return buildPickList(text, stock).picks.map((p) => p.bin);
}

test("morning export from the specification", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const stock = [
    lot("B-04-1", "OLIVE-500", 2, "2027-03-01"),
    lot("A-07-2", "OLIVE-500", 2, "2026-11-15"),
    lot("B-01-3", "PASTA-1KG", 5, null),
  ];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-07-2", sku: "OLIVE-500", qty: 2, orderId: "1002" },
      { bin: "B-04-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "B-01-3", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 1 }],
  });
});

describe("walking order", () => {
  test("aisles are visited alphabetically", () => {
    expect(walk(["C-01-1", "A-01-1", "B-01-1"])).toEqual(["A-01-1", "B-01-1", "C-01-1"]);
  });

  test("racks alternate ascending and descending over the visited aisles", () => {
    expect(walk(["D-12-1", "C-02-1", "A-10-1", "D-03-1", "A-02-1", "C-11-1"])).toEqual([
      "A-02-1",
      "A-10-1",
      "C-11-1",
      "C-02-1",
      "D-03-1",
      "D-12-1",
    ]);
  });

  test("levels within a rack are visited ascending, also in descending aisles", () => {
    expect(walk(["A-01-3", "A-01-1", "B-05-2", "B-05-1", "B-01-4", "B-01-2"])).toEqual([
      "A-01-1",
      "A-01-3",
      "B-05-1",
      "B-05-2",
      "B-01-2",
      "B-01-4",
    ]);
  });

  test("several picks at the same bin keep their allocation order", () => {
    const text = "ORDER 1\nOLIVE-500 x1\nPASTA-1KG x1\nORDER 2 !\nOLIVE-500 x1\nORDER 3\nOLIVE-500 x1";
    const stock = [lot("B-01-1", "OLIVE-500", 9), lot("A-01-1", "PASTA-1KG", 9)];
    expect(buildPickList(text, stock).picks).toEqual([
      { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "1" },
      { bin: "B-01-1", sku: "OLIVE-500", qty: 1, orderId: "2" },
      { bin: "B-01-1", sku: "OLIVE-500", qty: 1, orderId: "1" },
      { bin: "B-01-1", sku: "OLIVE-500", qty: 1, orderId: "3" },
    ]);
  });
});

function errorLine(text: string): number {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  throw new Error("expected an OrderFormatError");
}

describe("format errors", () => {
  test("item line before the first ORDER", () => {
    expect(errorLine("# header\n\nOLIVE-500 x1\nORDER 1\nOLIVE-500 x1")).toBe(3);
  });

  test("ORDER id used twice, with or without priority mark", () => {
    expect(errorLine("ORDER 1\nOLIVE-500 x1\nORDER 2\nOLIVE-500 x1\nORDER 1 !\nOLIVE-500 x1")).toBe(5);
  });

  test("ORDER without items is reported at its ORDER line", () => {
    expect(errorLine("ORDER 1\nOLIVE-500 x1\nORDER 2\n# nothing here\nORDER 3\nOLIVE-500 x1")).toBe(3);
    expect(errorLine("ORDER 1\nOLIVE-500 x1\nORDER 2 !\n\n")).toBe(3);
  });

  test.each([
    "OLIVE-500 x0",
    "OLIVE-500 x03",
    "olive-500 x1",
    "OLIVE-500 1",
    "OLIVE-500x1",
    "OLIVE-500 x-1",
    "OLIVE-500 x1.5",
    "OLIVE_500 x1",
    "ORDER",
    "ORDER 1003!",
    "ORDER 10 03",
    "ORDER 1003 ?",
    "order 1003",
    "just some text",
  ])("malformed line %p is reported", (bad) => {
    expect(errorLine(`ORDER 1\nOLIVE-500 x1\n${bad}\nPASTA-1KG x1`)).toBe(3);
  });

  test("the first problem from the top is reported", () => {
    expect(errorLine("ORDER 1\nOLIVE-500 x1\nbad\nORDER 1\nOLIVE-500 x1")).toBe(3);
    expect(errorLine("ORDER 1\nOLIVE-500 x1\nORDER 1\nbad")).toBe(3);
  });

  test("an empty order above a malformed line is reported first", () => {
    expect(errorLine("ORDER 1\nOLIVE-500 x0\nORDER 2\nOLIVE-500 x1")).toBe(1);
    expect(errorLine("ORDER 1\n\nolive x1")).toBe(1);
  });

  test("a malformed line inside an order with valid items is reported at its line", () => {
    expect(errorLine("ORDER 1\nOLIVE-500 x0\nOLIVE-500 x1")).toBe(2);
  });
});

describe("allocation", () => {
  test("empty orders text gives an empty pick list", () => {
    expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
  });

  test("single item is picked from its lot", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
    expect(result).toEqual({
      picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
      shortages: [],
    });
  });

  test("item without stock is reported as shortage", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x3", []);
    expect(result).toEqual({
      picks: [],
      shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
    });
  });

  test("partial stock is picked and the rest reported missing", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x5", [lot("A-01-1", "OLIVE-500", 2)]);
    expect(result).toEqual({
      picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
      shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
    });
  });

  test("an item spanning several lots yields one pick per lot", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x5", [
      lot("A-01-1", "OLIVE-500", 2),
      lot("A-01-2", "OLIVE-500", 2),
      lot("A-01-3", "OLIVE-500", 9),
    ]);
    expect(result.picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-01-2", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-01-3", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    ]);
    expect(result.shortages).toEqual([]);
  });

  test("stock taken by an earlier order is not available to later ones", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x3\nORDER 1002\nOLIVE-500 x3", [
      lot("A-01-1", "OLIVE-500", 4),
    ]);
    expect(result.picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    ]);
    expect(result.shortages).toEqual([{ orderId: "1002", sku: "OLIVE-500", missing: 2 }]);
  });

  test("lots with the earliest best-before date are used first", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x3", [
      lot("A-01-1", "OLIVE-500", 5, "2026-12-01"),
      lot("A-01-2", "OLIVE-500", 5, "2026-11-01"),
      lot("A-01-3", "OLIVE-500", 5, "2027-01-01"),
    ]);
    expect(result.picks).toEqual([{ bin: "A-01-2", sku: "OLIVE-500", qty: 3, orderId: "1001" }]);
  });

  test("lots without best-before date come after all dated lots", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x3", [
      lot("A-01-1", "OLIVE-500", 5, null),
      lot("A-01-2", "OLIVE-500", 5, "2030-01-01"),
    ]);
    expect(result.picks).toEqual([{ bin: "A-01-2", sku: "OLIVE-500", qty: 3, orderId: "1001" }]);
  });

  test("lots with equal dates are taken in bin code order", () => {
    const result = buildPickList("ORDER 1001\nOLIVE-500 x3\nPASTA-1KG x3", [
      lot("B-01-1", "OLIVE-500", 5, "2026-12-01"),
      lot("A-02-1", "OLIVE-500", 5, "2026-12-01"),
      lot("C-01-1", "PASTA-1KG", 5, null),
      lot("B-07-1", "PASTA-1KG", 5, null),
    ]);
    expect(result.picks).toEqual([
      { bin: "A-02-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
      { bin: "B-07-1", sku: "PASTA-1KG", qty: 3, orderId: "1001" },
    ]);
  });

  test("priority orders are served first, then the others, each in text order", () => {
    const text = ["ORDER 1", "OLIVE-500 x1", "ORDER 2 !", "OLIVE-500 x1", "ORDER 3", "OLIVE-500 x1", "ORDER 4 !", "OLIVE-500 x1"].join("\n");
    const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 2)]);
    expect(result.picks.map((p) => p.orderId)).toEqual(["2", "4"]);
    expect(result.shortages).toEqual([
      { orderId: "1", sku: "OLIVE-500", missing: 1 },
      { orderId: "3", sku: "OLIVE-500", missing: 1 },
    ]);
  });

  test("repeated SKUs in an order are summed at their first position", () => {
    const text = "ORDER 1001\nOLIVE-500 x2\nPASTA-1KG x1\nOLIVE-500 x3";
    const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 1), lot("A-01-2", "PASTA-1KG", 0)]);
    expect(result.picks).toEqual([{ bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" }]);
    expect(result.shortages).toEqual([
      { orderId: "1001", sku: "OLIVE-500", missing: 4 },
      { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
    ]);
  });

  test("comments, blank lines and extra whitespace are tolerated", () => {
    const text = [
      "# export 2026-10-12 06:00",
      "",
      "  ORDER 1001-A    !  ",
      "\tOLIVE-500    x3\r",
      "   ",
      "  # a comment between items",
      "  PASTA-1KG x1",
    ].join("\n");
    const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 9), lot("A-01-2", "PASTA-1KG", 9)]);
    expect(result.picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001-A" },
      { bin: "A-01-2", sku: "PASTA-1KG", qty: 1, orderId: "1001-A" },
    ]);
  });

  test("the stock array and its lots are not modified", () => {
    const stock = [lot("B-02-1", "OLIVE-500", 4, "2026-12-01"), lot("A-01-1", "OLIVE-500", 4, null)];
    const snapshot = structuredClone(stock);
    const lotObjects = [...stock];
    buildPickList("ORDER 1001\nOLIVE-500 x6", stock);
    expect(stock).toEqual(snapshot);
    expect(stock[0]).toBe(lotObjects[0]!);
    expect(stock[1]).toBe(lotObjects[1]!);
  });
});
