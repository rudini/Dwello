export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  items: { sku: string; qty: number }[];
}

const ORDER_LINE = /^ORDER ([A-Za-z0-9-]+)( +!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/;

/**
 * Parses the whole text before reporting, because whether an order is empty
 * is only known after the lines below it; the topmost problem wins.
 */
function parseOrders(ordersText: string): Order[] {
  const orders: (Order & { line: number })[] = [];
  const problems: OrderFormatError[] = [];
  for (const [index, rawLine] of ordersText.split("\n").entries()) {
    const lineNumber = index + 1;
    const line = rawLine.trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = ORDER_LINE.exec(line);
    if (orderMatch) {
      const id = orderMatch[1]!;
      if (orders.some((order) => order.id === id)) {
        problems.push(new OrderFormatError(lineNumber, `order id ${id} already used`));
      }
      orders.push({ id, priority: orderMatch[2] !== undefined, items: [], line: lineNumber });
      continue;
    }
    const itemMatch = ITEM_LINE.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNumber, `unrecognized line "${line}"`));
      continue;
    }
    const current = orders[orders.length - 1];
    if (!current) {
      problems.push(new OrderFormatError(lineNumber, "item line before the first ORDER"));
      continue;
    }
    const sku = itemMatch[1]!;
    const qty = Number(itemMatch[2]);
    const existing = current.items.find((item) => item.sku === sku);
    if (existing) existing.qty += qty;
    else current.items.push({ sku, qty });
  }
  for (const order of orders) {
    if (order.items.length === 0) {
      problems.push(new OrderFormatError(order.line, `order ${order.id} has no items`));
    }
  }
  const first = problems.reduce<OrderFormatError | undefined>(
    (earliest, problem) => (earliest && earliest.line <= problem.line ? earliest : problem),
    undefined,
  );
  if (first) throw first;
  return orders;
}

/** First expired, first out; undated lots last; ties by bin code. */
function compareLots(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return a.expires < b.expires ? -1 : 1;
  }
  return a.bin < b.bin ? -1 : a.bin > b.bin ? 1 : 0;
}

function parseBin(bin: string) {
  const [aisle, rack, level] = bin.split("-");
  return { aisle: aisle!, rack: Number(rack), level: Number(level) };
}

/** Serpentine walk: aisles alphabetically, racks alternating up and down per visited aisle. */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((pick) => parseBin(pick.bin).aisle))].sort();
  const key = (pick: Pick): number[] => {
    const { aisle, rack, level } = parseBin(pick.bin);
    const visit = aisles.indexOf(aisle);
    return [visit, visit % 2 === 0 ? rack : -rack, level];
  };
  // Array.prototype.sort is stable, so picks at the same bin keep allocation order.
  return [...picks].sort((a, b) => {
    const [ka, kb] = [key(a), key(b)];
    return ka.reduce((result, value, i) => result || value - kb[i]!, 0);
  });
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const lots = stock.map((lot) => ({ ...lot })).sort(compareLots);
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const lot of lots.filter((l) => l.sku === item.sku && l.qty > 0)) {
        if (needed === 0) break;
        const taken = Math.min(needed, lot.qty);
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
        lot.qty -= taken;
        needed -= taken;
      }
      if (needed > 0) {
        shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
      }
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}
