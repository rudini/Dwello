export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

/**
 * Splits one CSV line into fields. A field may be enclosed in double quotes, inside which a comma
 * is literal and `""` stands for one `"`. Spaces around values (and around quotes) are trimmed.
 */
function parseFields(text: string): string[] {
  const fields: string[] = [];
  let pos = 0;
  while (true) {
    while (text[pos] === " " || text[pos] === "\t") pos++;
    let value = "";
    if (text[pos] === '"') {
      pos++;
      while (pos < text.length) {
        if (text[pos] === '"') {
          if (text[pos + 1] !== '"') {
            pos++;
            break;
          }
          pos++;
        }
        value += text[pos++];
      }
    }
    let end = text.indexOf(",", pos);
    if (end < 0) end = text.length;
    fields.push(value + text.slice(pos, end).trim());
    pos = end;
    if (pos >= text.length) return fields;
    pos++; // skip the comma
  }
}

const REQUIRED_COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type ColumnIndex = Record<(typeof REQUIRED_COLUMNS)[number], number>;

interface Row {
  date: string;
  employee: string;
  category: string;
  /** The amount as written, in cents of `currency`. */
  amountCents: bigint;
  currency: string;
  amountChfCents: number;
  hasReceipt: boolean;
}

function isCalendarDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number);
  const isLeapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, isLeapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return month >= 1 && month <= 12 && day >= 1 && day <= daysInMonth[month - 1];
}

/** Reads an amount written as digits with an optional `.` and one or two decimals, in cents. */
function parseCents(text: string): bigint | null {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(text);
  if (!match) return null;
  return BigInt(match[1]) * 100n + BigInt((match[2] ?? "").padEnd(2, "0"));
}

/** Writes a rate as the exact fraction numerator / denominator of its shortest decimal form. */
function rateAsFraction(rate: number): { numerator: bigint; denominator: bigint } {
  const [mantissa, exponentText = "0"] = String(rate).split("e");
  const [integerPart, fractionPart = ""] = mantissa.split(".");
  const exponent = Number(exponentText) - fractionPart.length;
  const digits = BigInt(integerPart + fractionPart);
  return exponent >= 0
    ? { numerator: digits * 10n ** BigInt(exponent), denominator: 1n }
    : { numerator: digits, denominator: 10n ** BigInt(-exponent) };
}

/** Converts cents with a rate, rounding to the nearest cent with halves up, without float drift. */
function convertCents(cents: bigint, rate: number): number {
  const { numerator, denominator } = rateAsFraction(rate);
  return Number((2n * cents * numerator + denominator) / (2n * denominator));
}

/** Applies the row checks in order; returns the reason of the first failing check, or the row. */
function readRow(fields: string[], fieldCount: number, column: ColumnIndex, policy: Policy, fxRates: FxRates): Row | string {
  if (fields.length !== fieldCount) return "wrong number of fields";
  const field = (name: keyof ColumnIndex) => fields[column[name]].trim();
  const date = field("date");
  if (!isCalendarDate(date)) return "invalid date";
  const employee = field("employee");
  if (employee === "") return "missing employee";
  const category = field("category");
  if (!Object.hasOwn(policy.categories, category)) return "unknown category";
  const amountCents = parseCents(field("amount"));
  if (amountCents === null || amountCents <= 0n) return "invalid amount";
  const currency = field("currency");
  if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) return "unknown currency";
  const receipt = field("receipt").toLowerCase();
  if (receipt !== "yes" && receipt !== "no") return "invalid receipt flag";
  const amountChfCents = currency === "CHF" ? Number(amountCents) : convertCents(amountCents, fxRates[currency]);
  return { date, employee, category, amountCents, currency, amountChfCents, hasReceipt: receipt === "yes" };
}

/** Returns a function that checks the accepted rows, in file order, against the policy. */
function createPolicyChecker(policy: Policy): (row: Row) => Violation[] {
  const seenExpenses = new Set<string>();
  const dailyTotals = new Map<string, number>();
  return ({ date, employee, category, amountCents, currency, amountChfCents, hasReceipt }) => {
    const limits = policy.categories[category];
    const violations: Violation[] = [];
    const expenseKey = JSON.stringify([employee, date, category, String(amountCents), currency]);
    if (seenExpenses.has(expenseKey)) violations.push("DUPLICATE");
    seenExpenses.add(expenseKey);
    if (limits.perItemLimitCents !== undefined && amountChfCents > limits.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }
    const dayKey = JSON.stringify([employee, date, category]);
    const dailyTotal = (dailyTotals.get(dayKey) ?? 0) + amountChfCents;
    dailyTotals.set(dayKey, dailyTotal);
    if (limits.dailyLimitCents !== undefined && dailyTotal > limits.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }
    if (!hasReceipt && amountChfCents > policy.receiptRequiredAboveCents) {
      violations.push("NO_RECEIPT");
    }
    return violations;
  };
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const report: ExpenseReport = { lines: [], rejected: [], totals: {} };
  const physicalLines = csv.split(/\r?\n/);
  const headerIndex = physicalLines.findIndex((text) => text.trim() !== "");
  if (headerIndex < 0) throw new ExpenseFileError("Missing header");
  const header = parseFields(physicalLines[headerIndex]).map((name) => name.trim().toLowerCase());
  const column = {} as ColumnIndex;
  for (const name of REQUIRED_COLUMNS) {
    column[name] = header.indexOf(name);
    if (column[name] < 0) throw new ExpenseFileError(`Missing column: ${name}`);
  }
  const checkPolicy = createPolicyChecker(policy);
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();
  for (let i = headerIndex + 1; i < physicalLines.length; i++) {
    if (physicalLines[i].trim() === "") continue;
    const row = readRow(parseFields(physicalLines[i]), header.length, column, policy, fxRates);
    if (typeof row === "string") {
      report.rejected.push({ line: i + 1, reason: row });
      continue;
    }
    const { date, employee, category, amountChfCents } = row;
    const violations = checkPolicy(row);
    report.lines.push({ line: i + 1, date, employee, category, amountChfCents, violations });
    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    totals.set(employee, total);
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
  }
  // defineProperty keeps names such as "__proto__" as ordinary own keys
  for (const [employee, total] of totals) {
    Object.defineProperty(report.totals, employee, { value: total, enumerable: true, writable: true, configurable: true });
  }
  return report;
}
