import { describe, expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type FxRates, type Policy } from "./expenseReview";

const HEADER = "date,employee,category,amount,currency,receipt";

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};

const fx: FxRates = { EUR: 0.9412, USD: 0.8 };

function review(...rows: string[]) {
  return reviewExpenses([HEADER, ...rows].join("\n"), policy, fx);
}

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

describe("file structure", () => {
  test("an empty or blank file has no header", () => {
    for (const csv of ["", "\n", "  \r\n\t\n   "]) {
      expect(() => reviewExpenses(csv, policy, fx)).toThrow(new ExpenseFileError("Missing header"));
    }
  });

  test("a missing column is named, the first one in the documented order", () => {
    expect(() => reviewExpenses("date,employee,category,amount,currency\n", policy, fx)).toThrow(
      new ExpenseFileError("Missing column: receipt"),
    );
    expect(() => reviewExpenses("receipt,date,amount\n", policy, fx)).toThrow(
      new ExpenseFileError("Missing column: employee"),
    );
  });

  test("header names are case-insensitive, trimmed, in any order, with extra columns ignored", () => {
    const csv = " Receipt ,note,AMOUNT,Currency, employee,Category,DATE\nyes,lunch with client,12.50,CHF,anna,taxi,2025-03-04";
    const report = reviewExpenses(csv, policy, fx);
    expect(report.rejected).toEqual([]);
    expect(report.lines).toEqual([
      { line: 2, date: "2025-03-04", employee: "anna", category: "taxi", amountChfCents: 1250, violations: [] },
    ]);
  });

  test("a leading byte-order mark is ignored", () => {
    const report = reviewExpenses(`﻿${HEADER}\n2025-03-04,anna,taxi,1,CHF,yes`, policy, fx);
    expect(report.lines).toHaveLength(1);
  });

  test("blank lines are skipped but counted, CRLF line endings are accepted", () => {
    const csv = `\r\n  \r\n${HEADER}\r\n\r\n2025-03-04,anna,taxi,12.50,CHF,yes\r\n \t \r\n2025-03-05,ben,taxi,3,CHF,yes\r\n`;
    const report = reviewExpenses(csv, policy, fx);
    expect(report.rejected).toEqual([]);
    expect(report.lines.map((l) => [l.line, l.employee, l.amountChfCents])).toEqual([
      [5, "anna", 1250],
      [7, "ben", 300],
    ]);
  });

  test("quoted fields may contain commas and doubled quotes; unquoted values are trimmed", () => {
    const csv = `"date",employee,category,amount,currency,receipt\n 2025-03-04 , "Muster, Anna" ,"taxi", 12.50 ,"CHF",yes\n2025-03-04,"Ben ""the boss""",taxi,1,CHF,yes`;
    const report = reviewExpenses(csv, policy, fx);
    expect(report.rejected).toEqual([]);
    expect(report.lines.map((l) => [l.date, l.employee, l.category, l.amountChfCents])).toEqual([
      ["2025-03-04", "Muster, Anna", "taxi", 1250],
      ["2025-03-04", 'Ben "the boss"', "taxi", 100],
    ]);
  });
});

describe("rejected rows", () => {
  test("a row must have as many fields as the header", () => {
    const report = review("2025-03-04,anna,taxi,12.50,CHF", "2025-03-04,anna,taxi,12.50,CHF,yes,extra", "2025-03-04,anna,taxi,1,CHF,yes");
    expect(report.rejected).toEqual([
      { line: 2, reason: "wrong number of fields" },
      { line: 3, reason: "wrong number of fields" },
    ]);
    expect(report.lines.map((l) => l.line)).toEqual([4]);
    expect(report.totals).toEqual({ anna: { approvedCents: 100, flaggedCents: 0 } });
  });

  test("the date must be a real calendar date written YYYY-MM-DD", () => {
    const bad = ["", "2025-3-04", "04.03.2025", "2025-02-29", "2025-04-31", "2025-13-01", "2025-00-10", "2025-01-00", "20250-01-01", "2025-01-01T00:00"];
    const report = review(...bad.map((date) => `${date},anna,taxi,1,CHF,yes`), "2024-02-29,anna,taxi,1,CHF,yes");
    expect(report.rejected).toEqual(bad.map((_, i) => ({ line: i + 2, reason: "invalid date" })));
    expect(report.lines.map((l) => l.date)).toEqual(["2024-02-29"]);
  });

  test("leap years follow the Gregorian rules, also for years below 100", () => {
    const report = review("0024-02-29,anna,taxi,1,CHF,yes", "2000-02-29,anna,taxi,1,CHF,yes", "1900-02-29,anna,taxi,1,CHF,yes");
    expect(report.lines.map((l) => l.date)).toEqual(["0024-02-29", "2000-02-29"]);
    expect(report.rejected).toEqual([{ line: 4, reason: "invalid date" }]);
  });

  test("the employee must not be empty", () => {
    const report = review("2025-03-04,,taxi,1,CHF,yes", "2025-03-04,   ,taxi,1,CHF,yes");
    expect(report.rejected).toEqual([
      { line: 2, reason: "missing employee" },
      { line: 3, reason: "missing employee" },
    ]);
    expect(report.totals).toEqual({});
  });

  test("date, employee and category are trimmed even when quoted", () => {
    const report = review('" 2025-03-04 "," anna ", "taxi " ,1,CHF,yes', '2025-03-04,"   ",taxi,1,CHF,yes');
    expect(report.lines.map((l) => [l.date, l.employee, l.category])).toEqual([["2025-03-04", "anna", "taxi"]]);
    expect(report.rejected).toEqual([{ line: 3, reason: "missing employee" }]);
  });

  test("the category must be a key of the policy, matched exactly", () => {
    const bad = ["Taxi", "flight", "", "toString", "__proto__"];
    const report = review(...bad.map((category) => `2025-03-04,anna,${category},1,CHF,yes`));
    expect(report.rejected).toEqual(bad.map((_, i) => ({ line: i + 2, reason: "unknown category" })));
  });

  test("the amount must be digits with up to two decimals and greater than zero", () => {
    const bad = ["", "0", "0.00", "-5", "+5", "1.234", "1.", ".5", "1e3", "1'000", "1,5", "abc", "0x10", "Infinity"];
    const good = ["7", "7.5", "07.05", "1000000"];
    const report = review(...[...bad, ...good].map((amount) => `2025-03-04,anna,taxi,"${amount}",CHF,yes`));
    expect(report.rejected).toEqual(bad.map((_, i) => ({ line: i + 2, reason: "invalid amount" })));
    expect(report.lines.map((l) => l.amountChfCents)).toEqual([700, 750, 705, 100000000]);
  });

  test("the currency must be CHF or a key of the rates, matched exactly", () => {
    const bad = ["chf", "eur", "GBP", "", "toString"];
    const report = review(...bad.map((currency) => `2025-03-04,anna,taxi,1,${currency},yes`), "2025-03-04,anna,taxi,1,EUR,yes");
    expect(report.rejected).toEqual(bad.map((_, i) => ({ line: i + 2, reason: "unknown currency" })));
    expect(report.lines).toHaveLength(1);
  });

  test("the receipt flag must be yes or no, case-insensitive", () => {
    const bad = ["", "y", "n", "true", "1", "yess"];
    const good = ["yes", "YES", "No", "nO"];
    const report = review(...[...bad, ...good].map((receipt) => `2025-03-04,anna,taxi,1,CHF,${receipt}`));
    expect(report.rejected).toEqual(bad.map((_, i) => ({ line: i + 2, reason: "invalid receipt flag" })));
    expect(report.lines).toHaveLength(good.length);
  });

  test("the checks are applied in order and only the first failure is reported", () => {
    const report = review(
      "2025-02-30,,flight,0,XYZ,maybe",
      "2025-03-04,,flight,0,XYZ,maybe",
      "2025-03-04,anna,flight,0,XYZ,maybe",
      "2025-03-04,anna,taxi,0,XYZ,maybe",
      "2025-03-04,anna,taxi,1,XYZ,maybe",
      "2025-03-04,anna,taxi,1,CHF,maybe",
    );
    expect(report.rejected.map((r) => r.reason)).toEqual([
      "invalid date",
      "missing employee",
      "unknown category",
      "invalid amount",
      "unknown currency",
      "invalid receipt flag",
    ]);
  });
});

describe("accepted rows", () => {
  test("a single CHF row is reviewed and totalled", () => {
    const report = review("2025-03-04,anna,taxi,12.50,CHF,yes");
    expect(report).toEqual({
      lines: [
        { line: 2, date: "2025-03-04", employee: "anna", category: "taxi", amountChfCents: 1250, violations: [] },
      ],
      rejected: [],
      totals: { anna: { approvedCents: 1250, flaggedCents: 0 } },
    });
  });

  test("foreign amounts are converted to CHF cents, rounding halves up exactly", () => {
    const rates: FxRates = { EUR: 0.9412, GBP: 1.15, JPY: 0.005, CHF: 2 };
    const csv = [
      HEADER,
      "2025-03-04,anna,taxi,12.50,EUR,yes", // 1176.5 -> 1177
      "2025-03-04,anna,taxi,12.49,EUR,yes", // 1175.5588 -> 1176
      "2025-03-04,anna,taxi,0.10,GBP,yes", // 11.5 (float: 11.4999...) -> 12
      "2025-03-04,anna,taxi,1,JPY,yes", // 0.5 -> 1
      "2025-03-04,anna,taxi,3,CHF,yes", // CHF is always 1
    ].join("\n");
    const report = reviewExpenses(csv, policy, rates);
    expect(report.lines.map((l) => l.amountChfCents)).toEqual([1177, 1176, 12, 1, 300]);
  });

  test("rates written in exponent notation are converted exactly", () => {
    const rates: FxRates = { VEF: 2.5e-7, XAU: 1.5e21 };
    const csv = [HEADER, "2025-03-04,anna,taxi,1000000,VEF,yes", "2025-03-04,anna,taxi,0.01,XAU,yes"].join("\n");
    const report = reviewExpenses(csv, policy, rates);
    expect(report.lines.map((l) => l.amountChfCents)).toEqual([25, 1.5e21]);
  });
});

describe("policy checks", () => {
  const violationsOf = (...rows: string[]) => review(...rows).lines.map((l) => l.violations);

  test("an item above the per-item limit of its category is flagged", () => {
    expect(
      violationsOf(
        "2025-03-04,anna,hotel,250.00,CHF,yes",
        "2025-03-05,anna,hotel,250.01,CHF,yes",
        "2025-03-06,anna,taxi,9999,CHF,yes", // taxi has no limits
      ),
    ).toEqual([[], ["OVER_ITEM_LIMIT"], []]);
  });

  test("the per-item limit applies to the converted CHF amount", () => {
    // 265.62 EUR * 0.9412 = 250.0015 CHF -> 25000 cents, 265.64 EUR -> 25002 cents
    expect(violationsOf("2025-03-04,anna,hotel,265.62,EUR,yes", "2025-03-05,anna,hotel,265.64,EUR,yes")).toEqual([
      [],
      ["OVER_ITEM_LIMIT"],
    ]);
  });

  test("an expense above the receipt threshold without a receipt is flagged", () => {
    expect(
      violationsOf(
        "2025-03-04,anna,taxi,20.00,CHF,no",
        "2025-03-05,anna,taxi,20.01,CHF,NO",
        "2025-03-06,anna,taxi,20.01,CHF,yes",
        "2025-03-07,anna,taxi,21.26,EUR,no", // 20.0099 CHF -> 2001 cents
      ),
    ).toEqual([[], ["NO_RECEIPT"], [], ["NO_RECEIPT"]]);
  });

  test("the running daily total per employee, date and category is checked against the daily limit", () => {
    const report = review(
      "2025-03-04,anna,meals,30,CHF,yes", // anna 03-04: 3000
      "2025-03-04,ben,meals,45,CHF,yes", // ben is separate
      "2025-03-05,anna,meals,45,CHF,yes", // another day is separate
      "2025-03-04,anna,meals,99,XYZ,yes", // rejected rows do not count
      "2025-03-04,anna,meals,50,CHF,yes", // 8000: exactly at the limit
      "2025-03-04,anna,meals,0.01,CHF,yes", // 8001: above
      "2025-03-04,anna,meals,1,CHF,yes", // 8101: still above
      "2025-03-04,anna,hotel,1,CHF,yes", // other category, and hotel has no daily limit
    );
    expect(report.lines.map((l) => [l.line, l.violations])).toEqual([
      [2, []],
      [3, []],
      [4, []],
      [6, []],
      [7, ["OVER_DAILY_LIMIT"]],
      [8, ["OVER_DAILY_LIMIT"]],
      [9, []],
    ]);
  });

  test("a row repeating an earlier accepted row's employee, date, category, amount and currency is a duplicate", () => {
    expect(
      violationsOf(
        "2025-03-04,anna,taxi,12.5,CHF,yes",
        "2025-03-04,anna,taxi,12.50,CHF,no", // same value as written; receipt flag does not matter
        "2025-03-04,anna,taxi,12.50,EUR,yes", // other currency
        "2025-03-04,anna,taxi,012.50,EUR,yes", // duplicate of the EUR row
        "2025-03-04,ben,taxi,12.50,CHF,yes", // other employee
        "2025-03-05,anna,taxi,12.50,CHF,yes", // other date
        "2025-03-04,anna,hotel,12.50,CHF,yes", // other category
        "2025-03-04,anna,taxi,12.51,CHF,yes", // other amount
        "2025-03-06,anna,taxi,5,CHF,maybe", // rejected, does not count
        "2025-03-06,anna,taxi,5,CHF,yes",
      ),
    ).toEqual([[], ["DUPLICATE"], [], ["DUPLICATE"], [], [], [], [], []]);
  });

  test("violations are listed in the documented order; duplicates count towards the daily total", () => {
    expect(violationsOf("2025-03-04,anna,meals,60,CHF,no", "2025-03-04,anna,meals,60.00,CHF,no")).toEqual([
      ["OVER_ITEM_LIMIT", "NO_RECEIPT"],
      ["DUPLICATE", "OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
    ]);
  });
});

describe("totals", () => {
  test("each employee with accepted rows gets approved and flagged sums", () => {
    const report = review(
      "2025-03-04,anna,taxi,10,CHF,yes", // approved 1000
      "2025-03-04,anna,hotel,300,CHF,yes", // flagged 30000
      "2025-03-04,ben,taxi,5,EUR,yes", // approved 471 (4.706)
      "2025-03-05,ben,taxi,5,EUR,yes", // approved 471
      "2025-03-04,carla,taxi,25,CHF,no", // flagged 2500
      "2025-03-04,dora,taxi,1,XYZ,yes", // rejected: no entry
    );
    expect(report.totals).toEqual({
      anna: { approvedCents: 1000, flaggedCents: 30000 },
      ben: { approvedCents: 942, flaggedCents: 0 },
      carla: { approvedCents: 0, flaggedCents: 2500 },
    });
  });

  test("employee names that clash with object properties are totalled like any other", () => {
    const report = review("2025-03-04,constructor,taxi,1,CHF,yes", "2025-03-04,__proto__,taxi,2,CHF,yes");
    expect(Object.keys(report.totals)).toEqual(["constructor", "__proto__"]);
    expect(report.totals["constructor"]).toEqual({ approvedCents: 100, flaggedCents: 0 });
    expect(Object.getOwnPropertyDescriptor(report.totals, "__proto__")?.value).toEqual({ approvedCents: 200, flaggedCents: 0 });
  });
});
