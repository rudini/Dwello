import { describe, expect, test } from "bun:test";
import { createCatalog } from "./catalog";
import { checkout } from "./checkout";
import type { Promotion } from "./promotions";

const catalog = createCatalog([
  { sku: "BROT", name: "Ruchbrot", priceCents: 290, vat: "reduced" },
  { sku: "KAFFEE", name: "Kaffeebohnen 500g", priceCents: 1250, vat: "reduced" },
  { sku: "TASSE", name: "Espressotasse", priceCents: 1500, vat: "standard" },
]);

const promotions: Promotion[] = [
  { code: "ZEHN", kind: "percent", percent: 10 },
  { code: "TASSE3", kind: "multibuy", sku: "TASSE", buy: 3, pay: 2 },
];

describe("checkout", () => {
  test("sums the lines", () => {
    const receipt = checkout(
      [
        { sku: "BROT", qty: 2 },
        { sku: "KAFFEE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.lines.map((l) => l.lineCents)).toEqual([580, 1250]);
    expect(receipt.subtotalCents).toBe(1830);
    expect(receipt.totalCents).toBe(1830);
  });

  test("includes VAT per rate", () => {
    const receipt = checkout(
      [
        { sku: "KAFFEE", qty: 1 },
        { sku: "TASSE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.vat).toEqual({ reduced: 32, standard: 112 });
  });

  test("applies a percent coupon", () => {
    const receipt = checkout([{ sku: "KAFFEE", qty: 4 }], catalog, promotions, "ZEHN");
    expect(receipt.discountCents).toBe(500);
    expect(receipt.totalCents).toBe(4500);
  });

  test("buy three, pay two", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 3 }], catalog, promotions, "TASSE3");
    expect(receipt.discountCents).toBe(1500);
    expect(receipt.totalCents).toBe(3000);
  });

  test("buy three, pay two only counts complete groups", () => {
    expect(checkout([{ sku: "TASSE", qty: 2 }], catalog, promotions, "TASSE3").discountCents).toBe(0);
    expect(checkout([{ sku: "TASSE", qty: 4 }], catalog, promotions, "TASSE3").discountCents).toBe(1500);
    expect(checkout([{ sku: "TASSE", qty: 6 }], catalog, promotions, "TASSE3").discountCents).toBe(3000);
  });

  test("keeps line amounts exact and rounds only the total to 5 Rappen", () => {
    const gum = createCatalog([{ sku: "GUM", name: "Kaugummi", priceCents: 99, vat: "reduced" }]);
    const receipt = checkout([{ sku: "GUM", qty: 3 }], gum);
    expect(receipt.lines[0].lineCents).toBe(297);
    expect(receipt.subtotalCents).toBe(297);
    expect(receipt.totalCents).toBe(295);
  });

  test("caps a fixed voucher at the subtotal", () => {
    const receipt = checkout([{ sku: "BROT", qty: 2 }], catalog, [
      { code: "FUENFZIG", kind: "fixed", amountCents: 5000 },
    ], "FUENFZIG");
    expect(receipt.discountCents).toBe(580);
    expect(receipt.totalCents).toBe(0);
    expect(receipt.vat).toEqual({ standard: 0, reduced: 0 });
  });

  test("reduces VAT by the coupon", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 4 }], catalog, promotions, "ZEHN");
    expect(receipt.totalCents).toBe(5400);
    expect(receipt.vat).toEqual({ standard: 405, reduced: 0 });
  });

  test("splits the discount between VAT rates by their share of the subtotal", () => {
    // subtotal 2750: reduced 1250, standard 1500; discount 275 -> reduced 125, standard 150
    const receipt = checkout(
      [
        { sku: "KAFFEE", qty: 1 },
        { sku: "TASSE", qty: 1 },
      ],
      catalog,
      promotions,
      "ZEHN",
    );
    expect(receipt.discountCents).toBe(275);
    expect(receipt.vat).toEqual({ reduced: 29, standard: 101 });
  });

  test("coupon with a minimum order value", () => {
    const withMin: Promotion[] = [{ code: "ZEHN50", kind: "percent", percent: 10, minSubtotalCents: 5000 }];
    const below = checkout([{ sku: "TASSE", qty: 3 }], catalog, withMin, "ZEHN50");
    expect(below.discountCents).toBe(0);
    expect(below.couponCode).toBe("ZEHN50");
    expect(below.totalCents).toBe(4500);
    expect(below.notice).toBe("Coupon ZEHN50 requires a minimum order of CHF 50.00");

    const above = checkout([{ sku: "TASSE", qty: 4 }], catalog, withMin, "ZEHN50");
    expect(above.discountCents).toBe(600);
    expect(above.notice).toBeUndefined();

    const exact = checkout([{ sku: "KAFFEE", qty: 4 }], catalog, withMin, "ZEHN50");
    expect(exact.discountCents).toBe(500);
    expect(exact.notice).toBeUndefined();
  });

  test("rejects unknown products and coupons", () => {
    expect(() => checkout([{ sku: "TEE", qty: 1 }], catalog)).toThrow("Unknown product: TEE");
    expect(() => checkout([{ sku: "BROT", qty: 1 }], catalog, promotions, "GRATIS")).toThrow(
      "Unknown coupon code: GRATIS",
    );
  });
});
