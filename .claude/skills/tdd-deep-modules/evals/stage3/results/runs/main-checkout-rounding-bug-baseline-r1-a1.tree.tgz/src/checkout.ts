import { findProduct, VAT_RATES, type Catalog, type VatCategory } from "./catalog";
import { formatChf, roundToRappen, vatIncluded } from "./money";
import { discountFor, findPromotion, type Promotion } from "./promotions";

export interface CartLine {
  sku: string;
  qty: number;
}

export interface ReceiptLine {
  sku: string;
  name: string;
  qty: number;
  unitCents: number;
  lineCents: number;
  vat: VatCategory;
}

export interface Receipt {
  lines: ReceiptLine[];
  subtotalCents: number;
  couponCode?: string;
  discountCents: number;
  totalCents: number;
  vat: Record<VatCategory, number>;
  notice?: string;
}

export function checkout(
  cart: CartLine[],
  catalog: Catalog,
  promotions: Promotion[] = [],
  couponCode?: string,
): Receipt {
  const lines: ReceiptLine[] = cart.map(({ sku, qty }) => {
    const product = findProduct(catalog, sku);
    return {
      sku,
      name: product.name,
      qty,
      unitCents: product.priceCents,
      lineCents: product.priceCents * qty,
      vat: product.vat,
    };
  });

  const subtotalCents = lines.reduce((sum, l) => sum + l.lineCents, 0);

  let discountCents = 0;
  let notice: string | undefined;
  if (couponCode !== undefined) {
    const promotion = findPromotion(promotions, couponCode);
    if (promotion.minSubtotalCents !== undefined && subtotalCents < promotion.minSubtotalCents) {
      notice = `Coupon ${couponCode} requires a minimum order of ${formatChf(promotion.minSubtotalCents)}`;
    } else {
      discountCents = Math.min(discountFor(promotion, lines), subtotalCents);
    }
  }

  const grossOf = (category: VatCategory) =>
    lines.filter((l) => l.vat === category).reduce((sum, l) => sum + l.lineCents, 0);
  const reducedGross = grossOf("reduced");
  const standardGross = grossOf("standard");

  // Split the discount between the VAT rates in proportion to their share of the subtotal.
  const reducedDiscount =
    subtotalCents > 0 ? Math.round((discountCents * reducedGross) / subtotalCents) : 0;
  const standardDiscount = discountCents - reducedDiscount;

  const vat: Record<VatCategory, number> = {
    standard: vatIncluded(standardGross - standardDiscount, VAT_RATES.standard),
    reduced: vatIncluded(reducedGross - reducedDiscount, VAT_RATES.reduced),
  };

  return {
    lines,
    subtotalCents,
    couponCode,
    discountCents,
    totalCents: roundToRappen(subtotalCents - discountCents),
    vat,
    notice,
  };
}
