export type Promotion = (
  | { code: string; kind: "percent"; percent: number }
  | { code: string; kind: "fixed"; amountCents: number }
  | { code: string; kind: "multibuy"; sku: string; buy: number; pay: number }
) & {
  /** The coupon only applies if the subtotal is at least this amount. */
  minSubtotalCents?: number;
};

export interface PricedLine {
  sku: string;
  qty: number;
  unitCents: number;
  lineCents: number;
}

export function findPromotion(promotions: Promotion[], code: string): Promotion {
  const promotion = promotions.find((p) => p.code === code);
  if (!promotion) throw new Error(`Unknown coupon code: ${code}`);
  return promotion;
}

/** Discount in cents that a promotion grants on the given lines. */
export function discountFor(promotion: Promotion, lines: PricedLine[]): number {
  switch (promotion.kind) {
    case "percent": {
      const subtotal = lines.reduce((sum, l) => sum + l.lineCents, 0);
      return Math.round((subtotal * promotion.percent) / 100);
    }
    case "fixed":
      return promotion.amountCents;
    case "multibuy": {
      const matching = lines.filter((l) => l.sku === promotion.sku);
      if (matching.length === 0) return 0;
      const qty = matching.reduce((sum, l) => sum + l.qty, 0);
      const groups = Math.floor(qty / promotion.buy);
      return groups * (promotion.buy - promotion.pay) * matching[0].unitCents;
    }
  }
}
