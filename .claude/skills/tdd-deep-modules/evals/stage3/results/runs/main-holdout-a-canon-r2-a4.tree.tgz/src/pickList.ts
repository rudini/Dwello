export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Item {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: Item[];
}

const ORDER_LINE = /^ORDER\s+([A-Za-z0-9-]+)(\s+!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+)\s+x([1-9]\d*)$/;

/**
 * Parses the orders text. Problems are collected while parsing because an empty
 * order is only recognized after its ORDER line; the topmost problem is thrown.
 */
function parseOrders(text: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  const lines = text.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const lineNumber = index + 1;
    const line = lines[index].trim();
    if (line === "" || line.startsWith("#")) continue;

    const orderMatch = ORDER_LINE.exec(line);
    if (orderMatch) {
      const [, id, priorityMark] = orderMatch;
      if (orders.some((order) => order.id === id)) {
        problems.push(new OrderFormatError(lineNumber, `duplicate order id ${id}`));
      }
      orders.push({ id, priority: priorityMark !== undefined, line: lineNumber, items: [] });
      continue;
    }

    const itemMatch = ITEM_LINE.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNumber, `unrecognized line "${line}"`));
      continue;
    }
    const order = orders.at(-1);
    if (!order) {
      problems.push(new OrderFormatError(lineNumber, "item line before the first ORDER"));
      continue;
    }
    const [, sku, qty] = itemMatch;
    const existing = order.items.find((item) => item.sku === sku);
    if (existing) existing.qty += Number(qty);
    else order.items.push({ sku, qty: Number(qty) });
  }

  for (const order of orders) {
    if (order.items.length === 0) problems.push(new OrderFormatError(order.line, `order ${order.id} has no items`));
  }
  if (problems.length > 0) {
    throw problems.reduce((first, problem) => (problem.line < first.line ? problem : first));
  }
  return orders;
}

function compare(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

function byExpiry(a: StockLot, b: StockLot): number {
  if (a.expires === b.expires) return compare(a.bin, b.bin);
  if (a.expires === null) return 1;
  if (b.expires === null) return -1;
  return compare(a.expires, b.expires);
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle, rack, level] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/** Serpentine walk: aisles alphabetically, racks up in every other visited aisle and down in the rest. */
function walkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((pick) => parseBin(pick.bin).aisle))].sort(compare);
  const descending = new Set(aisles.filter((_, index) => index % 2 === 1));
  return [...picks].sort((a, b) => {
    const binA = parseBin(a.bin);
    const binB = parseBin(b.bin);
    if (binA.aisle !== binB.aisle) return compare(binA.aisle, binB.aisle);
    if (binA.rack !== binB.rack) {
      const racks = binA.rack - binB.rack;
      return descending.has(binA.aisle) ? -racks : racks;
    }
    return binA.level - binB.level;
  });
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  // private copies whose qty tracks what is still left, so the caller's stock stays untouched
  const lots = stock.map((lot) => ({ ...lot })).sort(byExpiry);
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let open = item.qty;
      for (const lot of lots) {
        if (open === 0) break;
        if (lot.sku !== item.sku || lot.qty <= 0) continue;
        const taken = Math.min(open, lot.qty);
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
        lot.qty -= taken;
        open -= taken;
      }
      if (open > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: open });
    }
  }
  return { picks: walkingOrder(picks), shortages };
}
