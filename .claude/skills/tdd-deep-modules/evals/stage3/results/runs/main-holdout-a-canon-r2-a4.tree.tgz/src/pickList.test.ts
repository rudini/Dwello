import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("empty text yields an empty pick list", () => {
  expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
});

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("an item covered by one lot yields one pick", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3";
  expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 10)])).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("an item without stock is reported as a shortage", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3";
  expect(buildPickList(text, [lot("A-01-1", "PASTA-1KG", 10)])).toEqual({
    picks: [],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
  });
});

test("partial stock is picked and the rest reported missing", () => {
  const text = "ORDER 1001\n  OLIVE-500 x5";
  expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 2)])).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
  });
});

test("lots with the earliest best-before date are used first", () => {
  const text = "ORDER 1001\n  OLIVE-500 x5";
  const stock = [
    lot("A-01-1", "OLIVE-500", 10, "2027-03-01"),
    lot("A-01-2", "OLIVE-500", 3, "2026-11-01"),
    lot("A-01-3", "OLIVE-500", 10, "2026-12-01"),
  ];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-2", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    { bin: "A-01-3", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("lots without best-before date come after all dated lots", () => {
  const text = "ORDER 1001\n  SALT x4";
  const stock = [lot("A-01-1", "SALT", 10, null), lot("A-01-2", "SALT", 10, "2099-12-31")];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-2", sku: "SALT", qty: 4, orderId: "1001" },
  ]);
});

test("lots with equal best-before dates are used in bin order", () => {
  const text = "ORDER 1001\n  SALT x4\n  OLIVE-500 x1";
  const stock = [
    lot("B-02-1", "SALT", 10, null),
    lot("A-05-1", "SALT", 10, null),
    lot("B-01-1", "OLIVE-500", 10, "2026-11-01"),
    lot("A-09-1", "OLIVE-500", 10, "2026-11-01"),
  ];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-05-1", sku: "SALT", qty: 4, orderId: "1001" },
    { bin: "A-09-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
  ]);
});

test("stock taken by an earlier order is not available to later ones", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n  OLIVE-500 x3";
  const stock = [lot("A-01-1", "OLIVE-500", 4, "2026-11-01"), lot("A-01-2", "OLIVE-500", 1, "2026-12-01")];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "A-01-2", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    ],
    shortages: [{ orderId: "1002", sku: "OLIVE-500", missing: 1 }],
  });
});

test("priority orders are served first, in text order", () => {
  const text = [
    "ORDER 1001",
    "  OLIVE-500 x1",
    "ORDER 1002 !",
    "  OLIVE-500 x1",
    "ORDER 1003",
    "  OLIVE-500 x1",
    "ORDER 1004   !",
    "  OLIVE-500 x1",
  ].join("\n");
  const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 2)]);
  expect(result.picks.map((p) => p.orderId)).toEqual(["1002", "1004"]);
  expect(result.shortages.map((s) => s.orderId)).toEqual(["1001", "1003"]);
});

test("a SKU listed twice in an order is summed at its first position", () => {
  const text = "ORDER 1001\n  OLIVE-500 x2\n  PASTA-1KG x1\n  OLIVE-500 x3";
  expect(buildPickList(text, []).shortages).toEqual([
    { orderId: "1001", sku: "OLIVE-500", missing: 5 },
    { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
  ]);
});

test("comments, blank lines and surrounding whitespace are ignored", () => {
  const text = "# export 2026-10-12 06:00\r\n\r\n   ORDER 1001   \r\n  # note\r\n\tOLIVE-500   x3\t\r\n\r\n";
  expect(buildPickList(text, []).shortages).toEqual([{ orderId: "1001", sku: "OLIVE-500", missing: 3 }]);
});

function errorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  return undefined;
}

test("an item line before the first ORDER is an error", () => {
  expect(errorLine("# header\n\n  OLIVE-500 x3\nORDER 1001\n  OLIVE-500 x1")).toBe(3);
});

test("an ORDER id that was already used is an error", () => {
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n  OLIVE-500 x1\nORDER 1001 !\n  OLIVE-500 x1")).toBe(5);
});

test("an ORDER without items is reported at its ORDER line", () => {
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002 !\n# nothing\n\nORDER 1003\n  OLIVE-500 x1")).toBe(3);
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n# nothing\n")).toBe(3);
});

test.each([
  ["zero quantity", "OLIVE-500 x0"],
  ["leading zero", "OLIVE-500 x03"],
  ["lowercase sku", "olive-500 x3"],
  ["missing x", "OLIVE-500 3"],
  ["missing space", "OLIVE-500x3"],
  ["uppercase X", "OLIVE-500 X3"],
  ["negative quantity", "OLIVE-500 x-3"],
  ["fraction", "OLIVE-500 x1.5"],
  ["extra token", "OLIVE-500 x3 extra"],
  ["sku with underscore", "OLIVE_500 x3"],
  ["bad order id", "ORDER 10_01"],
  ["order without id", "ORDER"],
  ["priority mark without space", "ORDER 1003!"],
  ["lowercase keyword", "order 1003"],
  ["something else", "hello"],
])("malformed line (%s) is an error", (_name, badLine) => {
  expect(errorLine(`ORDER 1001\n  PASTA-1KG x1\n  ${badLine}\nORDER 1002\n  PASTA-1KG x1`)).toBe(3);
});

test("the problem closest to the top is reported", () => {
  // order 1002 has no item lines; its ORDER line precedes the malformed line
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n  olive x1\nORDER 1001\n  OLIVE-500 x1")).toBe(3);
  // a later valid item makes the order non-empty, so the malformed line is first
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n  olive x1\n  OLIVE-500 x1\nORDER 1001")).toBe(4);
  // empty order 1001 precedes the duplicate id on the next ORDER line
  expect(errorLine("ORDER 1001\nORDER 1001\n  OLIVE-500 x1")).toBe(1);
});

const binsOf = (result: { picks: { bin: string }[] }) => result.picks.map((p) => p.bin);

test("picks are walked through the aisles in alphabetical order", () => {
  const text = "ORDER 1001\n  C x1\n  A x1\n  B x1";
  const stock = [lot("C-01-1", "C", 5), lot("A-01-1", "A", 5), lot("B-01-1", "B", 5)];
  expect(binsOf(buildPickList(text, stock))).toEqual(["A-01-1", "B-01-1", "C-01-1"]);
});

test("racks are walked ascending and descending in alternating visited aisles", () => {
  const text = "ORDER 1001\n  P x6";
  const stock = ["D-02-1", "C-01-1", "A-10-1", "C-12-1", "A-02-1", "D-11-1"].map((bin) => lot(bin, "P", 1));
  expect(binsOf(buildPickList(text, stock))).toEqual(["A-02-1", "A-10-1", "C-12-1", "C-01-1", "D-02-1", "D-11-1"]);
});

test("levels within a rack are visited in ascending order, in either direction", () => {
  const text = "ORDER 1001\n  P x6";
  // allocated (by expiry) in the order B-03-4, B-03-2, B-03-1, A-01-3, A-01-1, B-07-2
  const stock = [
    lot("B-03-1", "P", 1, "2026-11-03"),
    lot("A-01-3", "P", 1, "2026-11-04"),
    lot("B-03-4", "P", 1, "2026-11-01"),
    lot("A-01-1", "P", 1, "2026-11-05"),
    lot("B-07-2", "P", 1, "2026-11-06"),
    lot("B-03-2", "P", 1, "2026-11-02"),
  ];
  expect(binsOf(buildPickList(text, stock))).toEqual(["A-01-1", "A-01-3", "B-07-2", "B-03-1", "B-03-2", "B-03-4"]);
});

test("picks at the same bin keep their allocation order", () => {
  const text = "ORDER 1001\n  P x1\n  Q x1\nORDER 1002 !\n  Q x1\n  P x1";
  const stock = [lot("A-01-1", "P", 5), lot("A-01-1", "Q", 5), lot("A-01-1", "P", 5, "2026-11-01")];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-1", sku: "Q", qty: 1, orderId: "1002" },
    { bin: "A-01-1", sku: "P", qty: 1, orderId: "1002" },
    { bin: "A-01-1", sku: "P", qty: 1, orderId: "1001" },
    { bin: "A-01-1", sku: "Q", qty: 1, orderId: "1001" },
  ]);
});

test("the stock array and its lots are not modified", () => {
  const stock = [lot("B-01-1", "P", 2, "2026-12-01"), lot("A-01-1", "P", 2, "2026-11-01")];
  const snapshot = structuredClone(stock);
  const lots = [...stock];
  buildPickList("ORDER 1001\n  P x3\nORDER 1002\n  P x3", stock);
  expect(stock).toEqual(snapshot);
  expect(stock[0]).toBe(lots[0]);
  expect(stock[1]).toBe(lots[1]);
});

test("empty lots yield no picks", () => {
  const stock = [lot("A-01-1", "P", 0, "2026-11-01"), lot("A-01-2", "P", 1, "2026-12-01")];
  expect(buildPickList("ORDER 1001\n  P x2", stock)).toEqual({
    picks: [{ bin: "A-01-2", sku: "P", qty: 1, orderId: "1001" }],
    shortages: [{ orderId: "1001", sku: "P", missing: 1 }],
  });
});

test("the morning export example", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const stock = [
    lot("B-04-1", "OLIVE-500", 2, "2027-01-01"),
    lot("B-02-3", "OLIVE-500", 1, "2026-11-15"),
    lot("A-07-2", "PASTA-1KG", 5, null),
  ];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-07-2", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      { bin: "B-04-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-04-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
      { bin: "B-02-3", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 2 }],
  });
});

test("well-formed variants are accepted", () => {
  const text = "ORDER A-17b\n  X-1 x10\nORDER 9    !\n  9Z   x1";
  expect(buildPickList(text, []).shortages).toEqual([
    { orderId: "9", sku: "9Z", missing: 1 },
    { orderId: "A-17b", sku: "X-1", missing: 10 },
  ]);
});
