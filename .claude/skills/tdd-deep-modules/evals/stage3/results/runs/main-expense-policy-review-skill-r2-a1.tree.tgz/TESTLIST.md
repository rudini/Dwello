# Expense review: test list

**Hidden decision:** how the monthly CSV export is read and judged (quoting, header
lookup, row validation, exact CHF rounding, duplicate keys, running daily totals) —
callers hand over the raw text and get a finished report.

**Design A:** one call, `reviewExpenses(csv, policy, fxRates): ExpenseReport`.
`const report = reviewExpenses(text, policy, rates);`

**Design B:** a pipeline of special calls, `parseExpenseCsv(csv) -> rows`,
`validateRow(row, policy, rates) -> Expense | Rejection`, `applyPolicy(expenses, policy) -> ReviewedLine[]`,
`totalPerEmployee(lines)`.
`const report = totalPerEmployee(applyPolicy(rows.map(r => validateRow(r, policy, rates)), policy));`

**Chosen:** Design A, because the caller learns one name and the CSV format, check order,
rounding and running-total rules stay hidden instead of leaking into four signatures.

## Behaviours (through `reviewExpenses`)

- [x] a single CHF row is reviewed with line number, fields, cents, no violations and an approved total
- [x] a foreign amount is converted with the rate and rounded to the nearest cent, halves up
- [x] a file without a header line throws `Missing header`
- [x] a missing required column throws `Missing column: <first missing>`
- [x] header columns match in any order, case-insensitively, trimmed, extra columns ignored
- [x] blank lines are skipped but counted, CRLF endings work
- [x] quoted fields keep commas and turn `""` into `"`
- [x] a row with the wrong number of fields is rejected
- [x] an impossible or badly written date is rejected
- [x] dates in the first century are real calendar dates too (added: `Date.UTC` maps years 0–99 to 19xx)
- [x] a row without employee is rejected
- [x] an unknown category is rejected
- [x] a malformed or non-positive amount is rejected
- [x] an unknown currency is rejected
- [x] a receipt flag other than yes/no is rejected; the flag is case-insensitive
- [ ] ~~the first failing check gives the reason~~ dropped: `readRow` already checks in table order, so no test for it could fail first
- [x] a repeat of an earlier accepted row is flagged DUPLICATE, amounts compared as values
- [x] an amount above the per-item limit is flagged OVER_ITEM_LIMIT
- [x] a running daily total above the daily limit is flagged OVER_DAILY_LIMIT
- [x] an amount above the receipt threshold without receipt is flagged NO_RECEIPT
- [x] several violations come in the fixed order (asserted in the totals test)
- [x] totals split approved and flagged amounts per employee
