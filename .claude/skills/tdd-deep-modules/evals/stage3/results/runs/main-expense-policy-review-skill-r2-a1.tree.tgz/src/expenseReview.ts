export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

/** One CSV line split into trimmed fields; quotes protect commas and `""` stands for `"`. */
function splitFields(text: string): string[] {
  const fields: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i <= text.length; i++) {
    const char = text[i];
    if (char === undefined || (char === "," && !quoted)) {
      fields.push(field.trim());
      field = "";
    } else if (char === '"' && quoted && text[i + 1] === '"') {
      field += '"';
      i++;
    } else if (char === '"') {
      quoted = !quoted;
    } else {
      field += char;
    }
  }
  return fields;
}

/** amountCents * rate rounded to whole cents, halves up, in exact decimal arithmetic. */
function convert(amountCents: number, rate: number): number {
  const [mantissa, exponent = "0"] = String(rate).toLowerCase().split("e");
  const [whole, fraction = ""] = mantissa!.split(".");
  const scale = fraction.length - Number(exponent);
  const product = BigInt(amountCents) * BigInt(whole! + fraction);
  if (scale <= 0) return Number(product * 10n ** BigInt(-scale));
  const divisor = 10n ** BigInt(scale);
  return Number((product * 2n + divisor) / (divisor * 2n));
}

const COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof COLUMNS)[number];

/** A data row by column name; no values when it has a different number of fields than the header. */
type Row = Pick<RejectedLine, "line"> & { values?: Record<Column, string> };

/** An accepted row, its amount both as written (in cents) and in CHF cents. */
type Expense = Omit<ReviewedLine, "violations"> & { amountCents: number; currency: string; receipt: boolean };

/** The data rows of the file with their physical line numbers, blank lines skipped. */
function readFile(csv: string): Row[] {
  const [header, ...lines] = csv
    .split("\n")
    .map((text, index) => ({ line: index + 1, text: text.replace(/\r$/, "") }))
    .filter(({ text }) => text.trim() !== "")
    .map(({ line, text }) => ({ line, fields: splitFields(text) }));
  if (!header) throw new ExpenseFileError("Missing header");
  const names = header.fields.map((name) => name.toLowerCase());
  const columns = {} as Record<Column, number>;
  for (const name of COLUMNS) {
    columns[name] = names.indexOf(name);
    if (columns[name] < 0) throw new ExpenseFileError(`Missing column: ${name}`);
  }
  return lines.map(({ line, fields }) => ({
    line,
    values:
      fields.length === names.length
        ? (Object.fromEntries(COLUMNS.map((name) => [name, fields[columns[name]]!])) as Record<Column, string>)
        : undefined,
  }));
}

function isCalendarDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number) as [number, number, number];
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== undefined && day >= 1 && day <= daysInMonth;
}

/** The expense in a row, or the reason the row is rejected. */
function readRow({ line, values }: Row, policy: Policy, fxRates: FxRates): Expense | string {
  if (!values) return "wrong number of fields";
  const { date, employee, category, currency } = values;
  if (!isCalendarDate(date)) return "invalid date";
  if (employee === "") return "missing employee";
  if (!Object.hasOwn(policy.categories, category)) return "unknown category";
  const amount = /^(\d+)(?:\.(\d{1,2}))?$/.exec(values.amount);
  const amountCents = amount ? Number(amount[1]) * 100 + Number((amount[2] ?? "").padEnd(2, "0")) : 0;
  if (amountCents <= 0) return "invalid amount";
  if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) return "unknown currency";
  const receipt = values.receipt.toLowerCase();
  if (receipt !== "yes" && receipt !== "no") return "invalid receipt flag";
  const amountChfCents = convert(amountCents, currency === "CHF" ? 1 : fxRates[currency]!);
  return { line, date, employee, category, amountCents, currency, receipt: receipt === "yes", amountChfCents };
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const rows = readFile(csv);
  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();
  const seen = new Set<string>();
  const dailyTotals = new Map<string, number>();
  for (const row of rows) {
    const expense = readRow(row, policy, fxRates);
    if (typeof expense === "string") {
      rejected.push({ line: row.line, reason: expense });
      continue;
    }
    const { line, date, employee, category, amountChfCents, amountCents, currency } = expense;
    const violations: Violation[] = [];
    const key = JSON.stringify([employee, date, category, amountCents, currency]);
    if (seen.has(key)) violations.push("DUPLICATE");
    seen.add(key);
    const limits = policy.categories[category]!;
    if (limits.perItemLimitCents !== undefined && amountChfCents > limits.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }
    const day = JSON.stringify([employee, date, category]);
    dailyTotals.set(day, (dailyTotals.get(day) ?? 0) + amountChfCents);
    if (limits.dailyLimitCents !== undefined && dailyTotals.get(day)! > limits.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }
    if (!expense.receipt && amountChfCents > policy.receiptRequiredAboveCents) violations.push("NO_RECEIPT");
    lines.push({ line, date, employee, category, amountChfCents, violations });
    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
    totals.set(employee, total);
  }
  return { lines, rejected, totals: Object.fromEntries(totals) };
}
