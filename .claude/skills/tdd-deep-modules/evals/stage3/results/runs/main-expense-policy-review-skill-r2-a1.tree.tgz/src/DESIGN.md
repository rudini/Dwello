# Expense review: design note

**Hidden decision:** how the monthly CSV export is read and judged. That covers quoting, header lookup, row validation, exact CHF rounding, duplicate keys and running daily totals. Callers pass in the raw text and get back a finished report.

## Both designs

- **A: one call.** `reviewExpenses(csv, policy, fxRates): ExpenseReport`
- **B: a pipeline of special calls.** `parseExpenseCsv`, `validateRow`, `applyPolicy`, `totalPerEmployee`, which callers chain themselves.

**Chosen:** A. With A the caller learns one name. The CSV format, the check order, the rounding and the running-total rules stay hidden instead of leaking into four signatures.

## Interface

- `reviewExpenses(csv, policy, fxRates)` returns the accepted lines, the rejected lines and the per-employee totals, all in file order. It throws `ExpenseFileError` only when the header is missing or incomplete.
- The types (`Policy`, `FxRates`, `ExpenseReport`, …) and `ExpenseFileError` are unchanged from the stub.

Private steps behind the interface: `readFile` (lines, blanks, header, columns), `splitFields` (quoting), `readRow` (checks in table order, giving an expense or a reason), `isCalendarDate`, and `convert` (exact half-up rounding). `convert` multiplies in BigInt using the rate's decimal string, so `0.35 × 0.7` gives 25 cents and not 24.

## Depth

`src/expenseReview.ts: surface 13, size 146, ratio 11.2, classitis no, pass-through 0, tests 1, unused 0, duplicate 1 -> deep`

Changes made during refactors:
- Row reading was split out of the main loop.
- The private types are derived from the public ones, which removed duplicated field lines.
- The field splitter was simplified.
- Rows now reach `readRow` keyed by column name, so `readRow` no longer needs the column indices.

## Open points

- Check order (the first failing check gives the reason) is set by how `readRow` is built. It has no test of its own, because such a test could not have failed first.
- All field values are trimmed, quoted ones included. The spec only asks for trimming of unquoted values, but it also wants `date`, `employee` and `category` reported trimmed.
- A quoted field cannot span lines, because lines are split on `\n` before fields are parsed. An unclosed quote runs to the end of the line.
- Currency codes and categories are matched exactly (case-sensitive), and only against the object's own keys.
- Rates are assumed to be positive finite numbers.

## Proof

`scripts/tdd_replay cdafa0f..HEAD` printed `REPLAY: ACCEPT`. It checks phase order, test counts and exit codes, but not how strong the assertions are.
