import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type Policy } from "./expenseReview";

const HEADER = "date,employee,category,amount,currency,receipt";

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};

const rates = { EUR: 0.9412, USD: 0.5, GBP: 0.7 };

function csv(...lines: string[]): string {
  return lines.join("\n");
}

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

test("a single CHF row is reviewed with line number, fields, cents and an approved total", () => {
  const report = reviewExpenses(csv(HEADER, "2026-09-03,Anna,taxi,12.50,CHF,yes"), policy, rates);
  expect(report).toEqual({
    lines: [
      { line: 2, date: "2026-09-03", employee: "Anna", category: "taxi", amountChfCents: 1250, violations: [] },
    ],
    rejected: [],
    totals: { Anna: { approvedCents: 1250, flaggedCents: 0 } },
  });
});

test("a foreign amount is converted with the rate and rounded to the nearest cent, halves up", () => {
  const report = reviewExpenses(
    csv(HEADER, "2026-09-03,Anna,taxi,10.05,EUR,yes", "2026-09-04,Anna,taxi,1.25,USD,yes", "2026-09-05,Anna,taxi,0.35,GBP,yes"),
    policy,
    rates,
  );
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([946, 63, 25]);
});

test("a file without a header line throws Missing header", () => {
  expect(() => reviewExpenses(" \n\r\n\t", policy, rates)).toThrow(new ExpenseFileError("Missing header"));
});

test("a missing required column throws naming the first missing one", () => {
  expect(() => reviewExpenses("receipt,date,amount,employee\n", policy, rates)).toThrow(
    new ExpenseFileError("Missing column: category"),
  );
});

test("header columns match in any order, case-insensitively and trimmed, extra columns ignored", () => {
  const file = csv(" Receipt ,note,CURRENCY,  Amount,Category,employee ,Date", "yes,lunch,CHF,8,meals,Ben,2026-09-01");
  expect(() => reviewExpenses(file, policy, rates)).not.toThrow();
  expect(reviewExpenses(file, policy, rates).lines).toEqual([
    { line: 2, date: "2026-09-01", employee: "Ben", category: "meals", amountChfCents: 800, violations: [] },
  ]);
});

test("blank lines are skipped but counted, CRLF line endings work", () => {
  const file = ["", HEADER, "  ", "2026-09-01,Ben,taxi,3,CHF,yes", "\t", "2026-09-02,Ben,taxi,4,CHF,yes", ""].join("\r\n");
  expect(() => reviewExpenses(file, policy, rates)).not.toThrow();
  expect(reviewExpenses(file, policy, rates).lines).toEqual([
    { line: 4, date: "2026-09-01", employee: "Ben", category: "taxi", amountChfCents: 300, violations: [] },
    { line: 6, date: "2026-09-02", employee: "Ben", category: "taxi", amountChfCents: 400, violations: [] },
  ]);
});

test("quoted fields keep commas and turn doubled quotes into one, unquoted values are trimmed", () => {
  const file = csv(HEADER, ' 2026-09-01 ,"Meier, Hans ""Hansi""", taxi ,"3",CHF, yes');
  expect(() => reviewExpenses(file, policy, rates)).not.toThrow();
  expect(reviewExpenses(file, policy, rates).lines).toEqual([
    { line: 2, date: "2026-09-01", employee: 'Meier, Hans "Hansi"', category: "taxi", amountChfCents: 300, violations: [] },
  ]);
});

test("a row with the wrong number of fields is rejected", () => {
  const file = csv(HEADER, "2026-09-01,Ben,taxi,3,CHF,yes,extra", "2026-09-01,Ben,taxi", "2026-09-01,Ben,taxi,3,CHF,yes");
  expect(() => reviewExpenses(file, policy, rates)).not.toThrow();
  const report = reviewExpenses(file, policy, rates);
  expect(report.rejected).toEqual([
    { line: 2, reason: "wrong number of fields" },
    { line: 3, reason: "wrong number of fields" },
  ]);
  expect(report.lines.map((l) => l.line)).toEqual([4]);
});

test("an impossible or badly written date is rejected", () => {
  const dates = ["2026-02-30", "2026-13-01", "2026-00-10", "2026-09-00", "2026-9-03", "03.09.2026", "2100-02-29", "", "2024-02-29", "2000-02-29", "2026-12-31"];
  const report = reviewExpenses(csv(HEADER, ...dates.map((d) => `${d},Ben,taxi,3,CHF,yes`)), policy, rates);
  expect(report.rejected).toEqual([2, 3, 4, 5, 6, 7, 8, 9].map((line) => ({ line, reason: "invalid date" })));
  expect(report.lines.map((l) => l.date)).toEqual(["2024-02-29", "2000-02-29", "2026-12-31"]);
});

test("dates in the first century are real calendar dates too", () => {
  const dates = ["0099-03-01", "0004-02-29", "0003-02-29"];
  const report = reviewExpenses(csv(HEADER, ...dates.map((d) => `${d},Ben,taxi,3,CHF,yes`)), policy, rates);
  expect(report.lines.map((l) => l.date)).toEqual(["0099-03-01", "0004-02-29"]);
  expect(report.rejected).toEqual([{ line: 4, reason: "invalid date" }]);
});

test("a row without employee is rejected", () => {
  const report = reviewExpenses(csv(HEADER, "2026-09-01,,taxi,3,CHF,yes", '2026-09-01,"  ",taxi,3,CHF,yes'), policy, rates);
  expect(report.rejected).toEqual([
    { line: 2, reason: "missing employee" },
    { line: 3, reason: "missing employee" },
  ]);
  expect(report.lines).toEqual([]);
  expect(report.totals).toEqual({});
});

test("an unknown category is rejected", () => {
  const categories = ["Meals", "train", "toString", "", "meals"];
  const report = reviewExpenses(csv(HEADER, ...categories.map((c) => `2026-09-01,Ben,${c},3,CHF,yes`)), policy, rates);
  expect(report.rejected).toEqual([2, 3, 4, 5].map((line) => ({ line, reason: "unknown category" })));
  expect(report.lines.map((l) => l.category)).toEqual(["meals"]);
});

test("a malformed or non-positive amount is rejected", () => {
  const amounts = ["0", "0.00", "-3", "3.", ".5", "3.456", "abc", '"1,5"', "", "+3", "1e3", "0.01", "007.5"];
  const file = csv(HEADER, ...amounts.map((a) => `2026-09-01,Ben,taxi,${a},CHF,yes`));
  expect(() => reviewExpenses(file, policy, rates)).not.toThrow();
  const report = reviewExpenses(file, policy, rates);
  expect(report.rejected).toEqual([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((line) => ({ line, reason: "invalid amount" })));
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([1, 750]);
});

test("an unknown currency is rejected", () => {
  const currencies = ["chf", "XYZ", "toString", "", "EUR", "CHF"];
  const file = csv(HEADER, ...currencies.map((c) => `2026-09-01,Ben,taxi,10,${c},yes`));
  expect(() => reviewExpenses(file, policy, rates)).not.toThrow();
  const report = reviewExpenses(file, policy, rates);
  expect(report.rejected).toEqual([2, 3, 4, 5].map((line) => ({ line, reason: "unknown currency" })));
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([941, 1000]);
});

test("a receipt flag other than yes or no is rejected, the flag is case-insensitive", () => {
  const flags = ["y", "true", "", "ja", "YES", "No", "nO", "yes"];
  const report = reviewExpenses(csv(HEADER, ...flags.map((f) => `2026-09-01,Ben,taxi,3,CHF,${f}`)), policy, rates);
  expect(report.rejected).toEqual([2, 3, 4, 5].map((line) => ({ line, reason: "invalid receipt flag" })));
  expect(report.lines.map((l) => l.line)).toEqual([6, 7, 8, 9]);
});

test("a repeat of an earlier accepted row is flagged DUPLICATE, amounts compared as values", () => {
  const report = reviewExpenses(
    csv(
      HEADER,
      "2026-09-01,Anna,taxi,12.5,CHF,maybe",
      "2026-09-01,Anna,taxi,12.5,CHF,yes",
      "2026-09-01,Anna,taxi,12.50,CHF,no",
      "2026-09-01,Anna,taxi,12.5,CHF,yes",
      "2026-09-01,Anna,taxi,12.5,EUR,yes",
      "2026-09-01,Ben,taxi,12.5,CHF,yes",
      "2026-09-02,Anna,taxi,12.5,CHF,yes",
      "2026-09-01,Anna,meals,12.5,CHF,yes",
      "2026-09-01,Anna,taxi,12.51,CHF,yes",
    ),
    policy,
    rates,
  );
  expect(report.lines.map((l) => [l.line, l.violations])).toEqual([
    [3, []],
    [4, ["DUPLICATE"]],
    [5, ["DUPLICATE"]],
    [6, []],
    [7, []],
    [8, []],
    [9, []],
    [10, []],
  ]);
});

test("a CHF amount above the per-item limit is flagged OVER_ITEM_LIMIT", () => {
  const report = reviewExpenses(
    csv(
      HEADER,
      "2026-09-01,Anna,meals,50.00,CHF,yes",
      "2026-09-02,Anna,meals,50.01,CHF,yes",
      "2026-09-03,Anna,meals,53.13,EUR,yes",
      "2026-09-04,Anna,meals,53.12,EUR,yes",
      "2026-09-05,Anna,taxi,1000,CHF,yes",
      "2026-09-06,Anna,hotel,250.01,CHF,yes",
    ),
    policy,
    rates,
  );
  expect(report.lines.map((l) => [l.amountChfCents, l.violations])).toEqual([
    [5000, []],
    [5001, ["OVER_ITEM_LIMIT"]],
    [5001, ["OVER_ITEM_LIMIT"]],
    [5000, []],
    [100000, []],
    [25001, ["OVER_ITEM_LIMIT"]],
  ]);
});

test("a running daily total above the daily limit is flagged OVER_DAILY_LIMIT", () => {
  const report = reviewExpenses(
    csv(
      HEADER,
      "2026-09-01,Anna,meals,40,CHF,yes",
      "2026-09-01,Anna,meals,40.00,CHF,yes",
      "2026-09-01,Ben,meals,30,CHF,yes",
      "2026-09-02,Anna,meals,45,CHF,yes",
      "2026-09-01,Anna,taxi,100,CHF,yes",
      "2026-09-01,Anna,meals,0.01,CHF,yes",
      "2026-09-01,Anna,meals,5,CHF,x",
      "2026-09-01,Anna,meals,1,CHF,yes",
    ),
    policy,
    rates,
  );
  expect(report.lines.map((l) => [l.line, l.violations])).toEqual([
    [2, []],
    [3, ["DUPLICATE"]],
    [4, []],
    [5, []],
    [6, []],
    [7, ["OVER_DAILY_LIMIT"]],
    [9, ["OVER_DAILY_LIMIT"]],
  ]);
});

test("a CHF amount above the receipt threshold without receipt is flagged NO_RECEIPT", () => {
  const report = reviewExpenses(
    csv(
      HEADER,
      "2026-09-01,Anna,taxi,20,CHF,no",
      "2026-09-02,Anna,taxi,20.01,CHF,no",
      "2026-09-03,Anna,taxi,30,CHF,yes",
      "2026-09-04,Anna,taxi,21.26,EUR,no",
      "2026-09-05,Anna,taxi,25,CHF,NO",
    ),
    policy,
    rates,
  );
  expect(report.lines.map((l) => [l.amountChfCents, l.violations])).toEqual([
    [2000, []],
    [2001, ["NO_RECEIPT"]],
    [3000, []],
    [2001, ["NO_RECEIPT"]],
    [2500, ["NO_RECEIPT"]],
  ]);
});

test("totals split approved and flagged amounts per employee, violations in fixed order", () => {
  const report = reviewExpenses(
    csv(
      HEADER,
      "2026-09-01,Anna,taxi,10,CHF,yes",
      "2026-09-02,Anna,meals,60,CHF,no",
      "2026-09-02,Anna,meals,60,CHF,no",
      "2026-09-01,Anna,taxi,10,CHF,yes",
      "2026-09-01,Ben,taxi,5,CHF,yes",
      "2026-09-01,__proto__,taxi,3,CHF,yes",
      "2026-09-01,Cleo,taxi,3,CHF,maybe",
    ),
    policy,
    rates,
  );
  expect(report.lines[2]!.violations).toEqual(["DUPLICATE", "OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"]);
  expect(Object.entries(report.totals)).toEqual([
    ["Anna", { approvedCents: 1000, flaggedCents: 13000 }],
    ["Ben", { approvedCents: 500, flaggedCents: 0 }],
    ["__proto__", { approvedCents: 300, flaggedCents: 0 }],
  ]);
});
