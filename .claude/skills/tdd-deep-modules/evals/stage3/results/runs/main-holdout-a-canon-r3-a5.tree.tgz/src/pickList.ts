export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: { sku: string; qty: number }[];
}

const ORDER_LINE = /^ORDER +([A-Za-z0-9-]+)(?: +(!))?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/;

function requireItems(order: Order | undefined): void {
  if (order && order.items.length === 0) {
    throw new OrderFormatError(order.line, `order ${order.id} has no items`);
  }
}

/**
 * Lines are checked top to bottom and the first problem is thrown. A malformed
 * line fails on its own before the order above it is checked for emptiness, so
 * an order counts as empty only if nothing but blanks or comments follow it.
 */
function parseOrders(text: string): Order[] {
  const orders: Order[] = [];
  const lines = text.split("\n");
  for (const [index, raw] of lines.entries()) {
    const lineNumber = index + 1;
    const line = raw.trim();
    if (line === "" || line.startsWith("#")) continue;
    const order = ORDER_LINE.exec(line);
    if (order) {
      requireItems(orders[orders.length - 1]);
      if (orders.some((o) => o.id === order[1])) {
        throw new OrderFormatError(lineNumber, `order id ${order[1]} used twice`);
      }
      orders.push({ id: order[1]!, priority: order[2] !== undefined, line: lineNumber, items: [] });
      continue;
    }
    const item = ITEM_LINE.exec(line);
    if (!item) throw new OrderFormatError(lineNumber, `unrecognised line "${line}"`);
    const current = orders[orders.length - 1];
    if (!current) throw new OrderFormatError(lineNumber, "item line before the first ORDER");
    const sku = item[1]!;
    const qty = Number(item[2]);
    const items = current.items;
    const existing = items.find((i) => i.sku === sku);
    if (existing) existing.qty += qty;
    else items.push({ sku, qty });
  }
  requireItems(orders[orders.length - 1]);
  return orders;
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Earliest best-before first, undated lots last, ties by bin code. */
function byExpiryThenBin(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "", level = ""] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/**
 * Serpentine walk: aisles alphabetically, racks ascending in every odd visited
 * aisle and descending in every even one, levels ascending. The sort is stable,
 * so picks at the same bin stay in allocation order.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((p) => parseBin(p.bin).aisle))].sort(compareStrings);
  const visit = new Map(aisles.map((aisle, i) => [aisle, i]));
  return [...picks].sort((a, b) => {
    const x = parseBin(a.bin);
    const y = parseBin(b.bin);
    if (x.aisle !== y.aisle) return visit.get(x.aisle)! - visit.get(y.aisle)!;
    if (x.rack !== y.rack) return visit.get(x.aisle)! % 2 === 0 ? x.rack - y.rack : y.rack - x.rack;
    return x.level - y.level;
  });
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const remaining = stock.map((lot) => ({ ...lot })).sort(byExpiryThenBin);
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const lot of remaining) {
        if (needed === 0) break;
        if (lot.sku !== item.sku || lot.qty === 0) continue;
        const taken = Math.min(lot.qty, needed);
        lot.qty -= taken;
        needed -= taken;
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}
