import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

/*
 * Test list:
 * [x] empty text -> nothing
 * [x] one order, one item, one covering lot -> one pick
 * [x] no stock -> shortage
 * [x] partial stock -> pick what is there plus shortage
 * [x] lots by earliest expiry, null last, ties by bin
 * [x] stock consumed by earlier orders
 * [x] priority orders first, in text order
 * [x] duplicate SKU in an order summed, first position kept
 * [x] comments, empty lines, surrounding whitespace ignored
 * [x] format errors (item before ORDER, duplicate id, empty order, bad lines, first from top)
 * [x] serpentine walking order
 * [x] picks at same bin keep allocation order
 * [x] stock is not modified
 * [x] the example from the task end to end
 */

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

function formatErrorOf(text: string): OrderFormatError {
  try {
    buildPickList(text, []);
  } catch (error) {
    if (error instanceof OrderFormatError) return error;
    throw error;
  }
  throw new Error("expected an OrderFormatError");
}

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("empty text yields an empty pick list", () => {
  expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
});

test("a single item covered by a single lot yields one pick", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("an item without any stock is reported as shortage", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "PASTA-1KG", 10)]);
  expect(result).toEqual({
    picks: [],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
  });
});

test("insufficient stock is picked completely and the rest reported missing", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x7", [
    lot("A-01-1", "OLIVE-500", 2),
    lot("A-01-2", "OLIVE-500", 3),
  ]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-01-2", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 2 }],
  });
});

test("lots are used earliest expiry first, undated last, ties by bin", () => {
  const { picks, shortages } = buildPickList("ORDER 1001\n  OLIVE-500 x12", [
    lot("A-01-1", "OLIVE-500", 5, null),
    lot("A-01-2", "OLIVE-500", 5, "2026-12-01"),
    lot("A-01-4", "OLIVE-500", 5, "2026-11-01"),
    lot("A-01-3", "OLIVE-500", 5, "2026-11-01"),
  ]);
  const takenPerBin = Object.fromEntries(picks.map((p) => [p.bin, p.qty]));
  expect(takenPerBin).toEqual({ "A-01-3": 5, "A-01-4": 5, "A-01-2": 2 });
  expect(shortages).toEqual([]);
});

test("priority orders are served first, each group in text order", () => {
  const text = [
    "ORDER A1",
    "  OLIVE-500 x1",
    "ORDER P1 !",
    "  OLIVE-500 x2",
    "ORDER A2",
    "  OLIVE-500 x3",
    "ORDER P2   !",
    "  OLIVE-500 x4",
  ].join("\n");
  const { picks, shortages } = buildPickList(text, [lot("A-01-1", "OLIVE-500", 7)]);
  expect(picks.map((p) => [p.orderId, p.qty])).toEqual([
    ["P1", 2],
    ["P2", 4],
    ["A1", 1],
  ]);
  expect(shortages).toEqual([{ orderId: "A2", sku: "OLIVE-500", missing: 3 }]);
});

test("repeated SKUs within an order are summed at their first position", () => {
  const text = "ORDER 1\n  OLIVE-500 x2\n  PASTA-1KG x1\n  OLIVE-500 x3";
  const { shortages } = buildPickList(text, []);
  expect(shortages).toEqual([
    { orderId: "1", sku: "OLIVE-500", missing: 5 },
    { orderId: "1", sku: "PASTA-1KG", missing: 1 },
  ]);
});

test("comments, blank lines and surrounding whitespace are ignored", () => {
  const text = "# export 2026-10-12 06:00\r\n\n   \t\n\tORDER 1001  \r\n  # note\n   OLIVE-500    x3\t\n\n";
  const { shortages } = buildPickList(text, []);
  expect(shortages).toEqual([{ orderId: "1001", sku: "OLIVE-500", missing: 3 }]);
});

test("an item line before the first ORDER is an error", () => {
  expect(formatErrorOf("# header\n\n  OLIVE-500 x3\nORDER 1\n  OLIVE-500 x1").line).toBe(3);
});

test("an ORDER id used twice is an error at the second ORDER line", () => {
  expect(formatErrorOf("ORDER 1\n  OLIVE-500 x1\nORDER 2\n  OLIVE-500 x1\nORDER 1 !\n  OLIVE-500 x1").line).toBe(5);
});

test("an ORDER without items is an error at its ORDER line", () => {
  expect(formatErrorOf("ORDER 1\n  OLIVE-500 x1\nORDER 2\n# nothing\n\nORDER 3\n  OLIVE-500 x1").line).toBe(3);
  expect(formatErrorOf("ORDER 1\n  OLIVE-500 x1\nORDER 2\n# nothing\n").line).toBe(3);
});

test("the first problem from the top is reported", () => {
  expect(formatErrorOf("ORDER 1\nORDER 1\n  OLIVE-500 x1").line).toBe(1);
  expect(formatErrorOf("ORDER 1\nORDER 2\n  OLIVE-500 x0").line).toBe(1);
  expect(formatErrorOf("ORDER 1\n  OLIVE-500 x0\nORDER 1").line).toBe(2);
});

test.each([
  "OLIVE-500 x0",
  "OLIVE-500 x03",
  "OLIVE-500 x-1",
  "OLIVE-500 x1.5",
  "OLIVE-500 x",
  "olive-500 x3",
  "OLIVE_500 x3",
  "OLIVE-500 3",
  "OLIVE-500x3",
  "OLIVE-500 X3",
  "OLIVE-500 x3 extra",
  "ORDER",
  "ORDER 10_01",
  "ORDER 1002!",
  "ORDER 1002 ! !",
  "order 1002",
  "something else",
])("an unrecognised line %p is an error", (bad) => {
  expect(formatErrorOf(`ORDER 1\n  OLIVE-500 x1\n  ${bad}\n  OLIVE-500 x1`).line).toBe(3);
});

test("picks follow the serpentine walk through aisles that have picks", () => {
  const bins = ["D-05-1", "C-01-1", "A-02-1", "C-03-2", "A-01-2", "D-02-1", "C-03-1", "A-01-1"];
  const stock = [...bins.map((bin, i) => lot(bin, `SKU-${i}`, 1)), lot("B-01-1", "UNUSED", 1)];
  const text = ["ORDER 1", ...bins.map((_, i) => `  SKU-${i} x1`)].join("\n");
  const { picks } = buildPickList(text, stock);
  expect(picks.map((p) => p.bin)).toEqual([
    "A-01-1",
    "A-01-2",
    "A-02-1",
    "C-03-1",
    "C-03-2",
    "C-01-1",
    "D-02-1",
    "D-05-1",
  ]);
});

test("several picks at the same bin keep their allocation order", () => {
  const text = "ORDER N1\n  OLIVE-500 x1\n  PASTA-1KG x1\nORDER P1 !\n  PASTA-1KG x1\n  OLIVE-500 x1";
  const { picks } = buildPickList(text, [
    lot("B-02-1", "PASTA-1KG", 5),
    lot("A-01-1", "OLIVE-500", 5, "2026-11-01"),
    lot("B-02-1", "OLIVE-500", 5, "2026-12-01"),
    lot("A-01-1", "OLIVE-500", 1, "2026-10-20"),
  ]);
  expect(picks.map((p) => `${p.bin} ${p.orderId} ${p.sku}`)).toEqual([
    "A-01-1 P1 OLIVE-500",
    "A-01-1 N1 OLIVE-500",
    "B-02-1 P1 PASTA-1KG",
    "B-02-1 N1 PASTA-1KG",
  ]);
});

test("the stock array and its lots are left untouched", () => {
  const stock = [lot("A-02-1", "OLIVE-500", 2, null), lot("A-01-1", "OLIVE-500", 2, "2026-11-01")];
  const before = structuredClone(stock);
  const lots = [...stock];
  Object.freeze(stock);
  stock.forEach((l) => Object.freeze(l));
  buildPickList("ORDER 1\n  OLIVE-500 x9", stock);
  expect(stock).toEqual(before);
  expect(stock).toEqual(lots);
  stock.forEach((l, i) => expect(l).toBe(lots[i]!));
});

test("the morning export example", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const result = buildPickList(text, [
    lot("B-07-1", "OLIVE-500", 2, "2027-01-31"),
    lot("A-03-2", "OLIVE-500", 1, "2026-11-30"),
    lot("A-01-1", "PASTA-1KG", 10, null),
  ]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      { bin: "A-03-2", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-07-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-07-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 2 }],
  });
});

test("stock taken by an earlier order is not available to a later one", () => {
  const result = buildPickList("ORDER 1\n  OLIVE-500 x4\nORDER 2\n  OLIVE-500 x4", [
    lot("A-01-1", "OLIVE-500", 5),
  ]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 4, orderId: "1" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "2" },
    ],
    shortages: [{ orderId: "2", sku: "OLIVE-500", missing: 3 }],
  });
});
