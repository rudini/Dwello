export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: readonly Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "other" | "end";

interface Token {
  kind: TokenKind;
  text: string;
  column: number; // 1-based
}

/**
 * Splits the text into tokens. Characters that belong to no token become
 * "other" tokens so the parser reports them only when it reaches them,
 * keeping errors in left-to-right order.
 */
function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (ch === " ") {
      i++;
      continue;
    }
    const start = i;
    let kind: TokenKind;
    if (/\p{L}/u.test(ch)) {
      while (i < text.length && /\p{L}/u.test(text[i])) i++;
      kind = "word";
    } else if (/[0-9:]/.test(ch)) {
      while (i < text.length && /[0-9:]/.test(text[i])) i++;
      kind = "time";
    } else if (ch === "-" || ch === "," || ch === ";") {
      i++;
      kind = ch;
    } else {
      i += text.codePointAt(i)! > 0xffff ? 2 : 1;
      kind = "other";
    }
    tokens.push({ kind, text: text.slice(start, i), column: start + 1 });
  }
  tokens.push({ kind: "end", text: "", column: text.length + 1 });
  return tokens;
}

interface ParsedRange extends TimeRange {
  start: number; // minutes since midnight
  end: number;
}

class Parser {
  private pos = 0;

  constructor(private readonly tokens: Token[]) {}

  private peek(): Token {
    return this.tokens[this.pos];
  }

  private next(): Token {
    const token = this.tokens[this.pos];
    if (token.kind !== "end") this.pos++;
    return token;
  }

  private unexpected(token: Token): never {
    if (token.kind === "end") {
      throw new OpeningHoursError("UNEXPECTED", token.column, "Unexpected end of text");
    }
    throw new OpeningHoursError("UNEXPECTED", token.column, `Unexpected "${token.text}"`);
  }

  parseSpec(): WeeklyHours {
    const result = Object.fromEntries(DAYS.map((day) => [day, []])) as unknown as WeeklyHours;
    for (;;) {
      const { days, ranges } = this.parseRule();
      for (const day of days) {
        result[day] = ranges.map(({ from, to }) => ({ from, to }));
      }
      const token = this.next();
      if (token.kind === "end") return result;
      if (token.kind !== ";") this.unexpected(token);
    }
  }

  private parseRule(): { days: Set<Day>; ranges: ParsedRange[] } {
    const days = new Set<Day>();
    this.parseDayItem(days);
    while (this.peek().kind === ",") {
      this.next();
      this.parseDayItem(days);
    }

    const token = this.peek();
    if (token.kind === "word" && token.text === "off") {
      this.next();
      return { days, ranges: [] };
    }
    if (token.kind !== "time") this.unexpected(token);

    const ranges: ParsedRange[] = [this.parseRange([])];
    while (this.peek().kind === ",") {
      this.next();
      ranges.push(this.parseRange(ranges));
    }
    ranges.sort((a, b) => a.start - b.start);
    return { days, ranges };
  }

  private parseDay(): { day: Day; column: number } {
    const token = this.next();
    if (token.kind !== "word") this.unexpected(token);
    const index = DAYS.indexOf(token.text as Day);
    if (index < 0) {
      throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    }
    return { day: DAYS[index], column: token.column };
  }

  private parseDayItem(days: Set<Day>): void {
    const first = this.parseDay();
    const duplicate = (): never => {
      throw new OpeningHoursError("DUPLICATE_DAY", first.column, `Day "${first.day}" is named twice`);
    };
    // A repeated first day is detectable before the rest of the item is read.
    if (days.has(first.day)) duplicate();
    const item: Day[] = [first.day];

    if (this.peek().kind === "-") {
      this.next();
      const last = this.parseDay();
      let index = DAYS.indexOf(first.day);
      while (DAYS[index] !== last.day) {
        index = (index + 1) % DAYS.length;
        item.push(DAYS[index]);
      }
      if (item.some((day) => days.has(day))) duplicate();
    }

    for (const day of item) days.add(day);
  }

  private parseTime(isEnd: boolean): { text: string; minutes: number; column: number } {
    const token = this.next();
    if (token.kind !== "time") this.unexpected(token);
    const match = /^(\d\d):(\d\d)$/.exec(token.text);
    const hours = match ? Number(match[1]) : NaN;
    const minutes = match ? Number(match[2]) : NaN;
    const valid = (hours <= 23 && minutes <= 59) || (isEnd && hours === 24 && minutes === 0);
    if (!valid) {
      throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    }
    return { text: token.text, minutes: hours * 60 + minutes, column: token.column };
  }

  private parseRange(earlier: ParsedRange[]): ParsedRange {
    const from = this.parseTime(false);
    const dash = this.next();
    if (dash.kind !== "-") this.unexpected(dash);
    const to = this.parseTime(true);
    if (to.minutes <= from.minutes) {
      throw new OpeningHoursError(
        "END_BEFORE_START",
        from.column,
        `End time ${to.text} is not later than start time ${from.text}`,
      );
    }
    for (const other of earlier) {
      if (from.minutes < other.end && other.start < to.minutes) {
        throw new OpeningHoursError(
          "OVERLAP",
          from.column,
          `Range ${from.text}-${to.text} overlaps ${other.from}-${other.to}`,
        );
      }
    }
    return { from: from.text, to: to.text, start: from.minutes, end: to.minutes };
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) {
    throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  }
  return new Parser(tokenize(text)).parseSpec();
}
