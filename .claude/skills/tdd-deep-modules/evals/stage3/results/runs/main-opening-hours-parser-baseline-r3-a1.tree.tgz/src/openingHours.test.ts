import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours, type OpeningHoursErrorCode } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

const closed = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };

function expectError(text: string, code: OpeningHoursErrorCode, column: number) {
  let error: unknown;
  try {
    parseOpeningHours(text);
  } catch (e) {
    error = e;
  }
  expect(error).toBeInstanceOf(OpeningHoursError);
  const { code: actualCode, column: actualColumn } = error as OpeningHoursError;
  expect({ text, code: actualCode, column: actualColumn }).toEqual({ text, code, column });
}

test("parses the example from the specification", () => {
  const split = [
    { from: "08:00", to: "12:00" },
    { from: "13:30", to: "18:30" },
  ];
  expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
    Mo: split,
    Tu: split,
    We: split,
    Th: split,
    Fr: split,
    Sa: [{ from: "09:00", to: "16:00" }],
    Su: [],
  });
});

test("unnamed days are closed and spaces are free", () => {
  expect(parseOpeningHours("  Mo , We 08:00 - 12:00 ")).toEqual({
    ...closed,
    Mo: [{ from: "08:00", to: "12:00" }],
    We: [{ from: "08:00", to: "12:00" }],
  });
});

test("day ranges wrap around the week", () => {
  const hours = [{ from: "10:00", to: "24:00" }];
  expect(parseOpeningHours("Fr-Mo 10:00-24:00")).toEqual({ ...closed, Fr: hours, Sa: hours, Su: hours, Mo: hours });
  expect(parseOpeningHours("Mo-Mo 10:00-24:00")).toEqual({ ...closed, Mo: hours });
});

test("ranges are sorted and may touch", () => {
  expect(parseOpeningHours("Mo 12:00-14:00,08:00-12:00").Mo).toEqual([
    { from: "08:00", to: "12:00" },
    { from: "12:00", to: "14:00" },
  ]);
});

test("later rules replace earlier ones", () => {
  expect(parseOpeningHours("Mo-Su 08:00-20:00; Su off").Su).toEqual([]);
  const result = parseOpeningHours("Mo-Fr 08:00-12:00; We 14:00-18:00");
  expect(result.We).toEqual([{ from: "14:00", to: "18:00" }]);
  expect(result.Th).toEqual([{ from: "08:00", to: "12:00" }]);
});

test("reports errors with their column", () => {
  expectError("", "EMPTY", 1);
  expectError("   ", "EMPTY", 1);
  expectError("Mo-Fx 08:00-12:00", "UNKNOWN_DAY", 4);
  expectError("off", "UNKNOWN_DAY", 1);
  expectError("mo 08:00-12:00", "UNKNOWN_DAY", 1);
  expectError("Mo 08:00-", "UNEXPECTED", 10);
  expectError("Mo off;", "UNEXPECTED", 8);
  expectError("Mo off; ", "UNEXPECTED", 9);
  expectError("Mo", "UNEXPECTED", 3);
  expectError("Mo Off", "UNEXPECTED", 4);
  expectError("Mo Tu off", "UNEXPECTED", 4);
  expectError(";Mo off", "UNEXPECTED", 1);
  expectError("Mo off 08:00-09:00", "UNEXPECTED", 8);
  expectError("Mo 08:00 12:00", "UNEXPECTED", 10);
  expectError("Mo-Fx @", "UNKNOWN_DAY", 4);
  expectError("Mo off @", "UNEXPECTED", 8);
  expectError("Mo 8:00-12:00", "INVALID_TIME", 4);
  expectError("Mo 08:60-12:00", "INVALID_TIME", 4);
  expectError("Mo 24:00-24:00", "INVALID_TIME", 4);
  expectError("Mo 08:00-24:01", "INVALID_TIME", 10);
  expectError("Mo 08:00-1200", "INVALID_TIME", 10);
  expectError("Mo 12:00-08:00", "END_BEFORE_START", 4);
  expectError("Mo 08:00-08:00", "END_BEFORE_START", 4);
  expectError("Mo 08:00-12:00, 11:00-13:00", "OVERLAP", 17);
  expectError("Mo 10:00-12:00,07:00-20:00", "OVERLAP", 16);
  expectError("Mo-We,Tu 08:00-12:00", "DUPLICATE_DAY", 7);
  expectError("Tu,Mo-We 08:00-12:00", "DUPLICATE_DAY", 4);
  expectError("Mo,Mo-Xx 08:00-12:00", "DUPLICATE_DAY", 4);
});
