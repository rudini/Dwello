# Design note: `parseOpeningHours`

**Hidden decision:** how the opening-hours text is tokenised, parsed and validated,
including which problem counts as the first one and which column it is reported at.
Callers see either a complete seven-day schedule or a single `OpeningHoursError`.

## Both designs

- **A (chosen):** `parseOpeningHours(text): WeeklyHours`, which throws `OpeningHoursError { code, column }`.
- **B:** `parseOpeningHours(text): { ok: true, hours } | { ok: false, code, column }`.

Chosen: A. One call and one error type hide the tokenizer, the grammar, day-range
expansion and rule merging, and the spec already fixes this interface. B would only
turn the `try` into an `if` without hiding anything more.

## Interface

- `parseOpeningHours(text)` returns all seven days. Ranges in each rule are sorted by
  start time, a later rule replaces the days it names, and any day that no rule names
  is closed (`[]`).
- `OpeningHoursError` has `code` (one of seven) and `column` (1-based, at the first
  character of the offending token, or `length + 1` when the text ends too early).

Everything else is private to `src/openingHours.ts`:

- a `Cursor` over the tokens. Every token has a column, and an end-of-text token
  sits at `length + 1`.
- the recursive-descent functions `parseDays`, `parseDay`, `parseRanges` and
  `parseTime`.

Tokens are produced eagerly. A stray character becomes a one-character token and is
only rejected when the parser reaches it, so "first problem from the left" holds.

## Depth

`depth_report src/openingHours.ts`:
`surface 10, size 135, ratio 13.5, classitis no, pass-through 0, tests 1, unused 0, duplicate 2 -> deep`

Refactors:

1. Replaced the split-based prototype with a cursor over tokens that carry columns.
2. Named the token patterns and sent every UNEXPECTED through one path in the cursor.
3. Let the parse helpers return tokens, so columns no longer have to be captured
   separately.

## Open points and known limits

- **Checks run only once an item is complete.** DUPLICATE_DAY is checked after the
  whole day item has been read, so `Mo,Mo-Xx` reports UNKNOWN_DAY at `Xx`. In the same
  way, END_BEFORE_START and OVERLAP are checked once both times of a range are read.
- **What counts as a letter or a space.** "Letters" are Unicode letters (`\p{L}`), so
  `Moé` is one unknown word. Only the space character counts as a space: tabs and
  newlines are UNEXPECTED.
- **"off" and words after the days.** `off` in a day position is an UNKNOWN_DAY. Any
  other word right after the days (`Mo Tu off`) is UNEXPECTED, because a day is not
  expected there.
- **How columns are counted.** Columns count UTF-16 code units, so a character outside
  the BMP (an emoji, for example) shifts every later column by one.

## Proof

`scripts/tdd_replay d964e55..HEAD` printed ACCEPT (it proves phase order, test counts
and exit codes, not how strong the assertions are).
