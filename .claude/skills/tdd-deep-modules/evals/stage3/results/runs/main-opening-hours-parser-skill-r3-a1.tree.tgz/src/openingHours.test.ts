import { describe, expect, test } from "bun:test";
import {
  OpeningHoursError,
  parseOpeningHours,
  type OpeningHoursErrorCode,
  type WeeklyHours,
} from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

function week(open: Partial<WeeklyHours>): WeeklyHours {
  return { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [], ...open };
}

type Failure = { code: OpeningHoursErrorCode; column: number } | { thrown: string };

/** The schedule, or what was thrown, as a value an assertion can compare. */
function parse(text: string): WeeklyHours | Failure {
  try {
    return parseOpeningHours(text);
  } catch (error) {
    if (error instanceof OpeningHoursError) return { code: error.code, column: error.column };
    return { thrown: String(error) };
  }
}

function fails(code: OpeningHoursErrorCode, column: number): Failure {
  return { code, column };
}

describe("parseOpeningHours", () => {
  test("one day with one range returns all seven days, the others closed", () => {
    expect(parse("Mo 08:00-12:00")).toEqual(
      week({ Mo: [{ from: "08:00", to: "12:00" }] }),
    );
  });

  test("several comma-separated ranges in one rule", () => {
    expect(parse("Tu 08:00-12:00,13:30-18:30")).toEqual(
      week({
        Tu: [
          { from: "08:00", to: "12:00" },
          { from: "13:30", to: "18:30" },
        ],
      }),
    );
  });

  test("a comma-separated list of days", () => {
    const range = [{ from: "09:00", to: "17:00" }];
    expect(parse("Mo,We,Sa 09:00-17:00")).toEqual(week({ Mo: range, We: range, Sa: range }));
  });

  test("a day range Mo-Fr expands to every day in between", () => {
    const range = [{ from: "07:00", to: "19:00" }];
    expect(parse("Tu-Fr,Su 07:00-19:00")).toEqual(
      week({ Tu: range, We: range, Th: range, Fr: range, Su: range }),
    );
  });

  test("a day range wraps around the week, Mo-Mo is one day", () => {
    const range = [{ from: "10:00", to: "14:00" }];
    expect(parse("Fr-Mo 10:00-14:00")).toEqual(week({ Fr: range, Sa: range, Su: range, Mo: range }));
    expect(parse("We-We 10:00-14:00")).toEqual(week({ We: range }));
  });

  test("off closes the named days", () => {
    expect(parse("Mo-Fr off")).toEqual(week({}));
  });

  test("several rules separated by semicolons", () => {
    expect(parse("Mo 08:00-12:00;Sa 09:00-16:00;Su off")).toEqual(
      week({ Mo: [{ from: "08:00", to: "12:00" }], Sa: [{ from: "09:00", to: "16:00" }] }),
    );
  });

  test("a later rule replaces the hours of the days it names", () => {
    const allDay = [{ from: "08:00", to: "20:00" }];
    expect(parse("Mo-Su 08:00-20:00;Su off")).toEqual(
      week({ Mo: allDay, Tu: allDay, We: allDay, Th: allDay, Fr: allDay, Sa: allDay }),
    );
    const morning = [{ from: "08:00", to: "12:00" }];
    expect(parse("Mo-Fr 08:00-12:00;We 14:00-18:00")).toEqual(
      week({ Mo: morning, Tu: morning, We: [{ from: "14:00", to: "18:00" }], Th: morning, Fr: morning }),
    );
  });

  test("spaces between tokens and around the text carry no meaning", () => {
    const ranges = [
      { from: "08:00", to: "12:00" },
      { from: "13:00", to: "14:00" },
    ];
    expect(parse("  Mo , We-Th 08:00 - 12:00 ,13:00-14:00 ; Su   off  ")).toEqual(
      week({ Mo: ranges, We: ranges, Th: ranges }),
    );
    expect(parse("Mo,We 08:00 - 12:00")).toEqual(
      week({ Mo: [ranges[0]], We: [ranges[0]] }),
    );
  });

  test("ranges within a rule are returned sorted by start time", () => {
    expect(parse("Th 17:00-19:00,08:00-09:30,12:15-13:00")).toEqual(
      week({
        Th: [
          { from: "08:00", to: "09:30" },
          { from: "12:15", to: "13:00" },
          { from: "17:00", to: "19:00" },
        ],
      }),
    );
  });

  test("EMPTY for empty or blank text", () => {
    expect(parse("")).toEqual(fails("EMPTY", 1));
    expect(parse("    ")).toEqual(fails("EMPTY", 1));
  });

  test("UNKNOWN_DAY at the word that is not a day", () => {
    expect(parse("Mo-Fx 08:00-12:00")).toEqual(fails("UNKNOWN_DAY", 4));
    expect(parse(" mo 08:00-12:00")).toEqual(fails("UNKNOWN_DAY", 2));
    expect(parse("Mo,Tu,off")).toEqual(fails("UNKNOWN_DAY", 7));
    expect(parse("Mo off; Monday off")).toEqual(fails("UNKNOWN_DAY", 9));
  });

  test("INVALID_TIME for a malformed time token", () => {
    expect(parse("Mo 8:00-12:00")).toEqual(fails("INVALID_TIME", 4));
    expect(parse("Mo 08:00-1200")).toEqual(fails("INVALID_TIME", 10));
    expect(parse("Mo 08:00-12:00:00")).toEqual(fails("INVALID_TIME", 10));
    expect(parse("Mo 08:00-12:0")).toEqual(fails("INVALID_TIME", 10));
    expect(parse("Mo 08:00-09:00, :: - 10:00")).toEqual(fails("INVALID_TIME", 17));
  });

  test("INVALID_TIME for hours or minutes out of range", () => {
    expect(parse("Mo 25:00-26:00")).toEqual(fails("INVALID_TIME", 4));
    expect(parse("Mo 08:60-12:00")).toEqual(fails("INVALID_TIME", 4));
    expect(parse("Mo 08:00-24:01")).toEqual(fails("INVALID_TIME", 10));
    expect(parse("Mo 08:00-24:30")).toEqual(fails("INVALID_TIME", 10));
    expect(parse("Mo 00:00-23:59")).toEqual(week({ Mo: [{ from: "00:00", to: "23:59" }] }));
  });

  test("INVALID_TIME for 24:00 as a start, 24:00 as an end is fine", () => {
    expect(parse("Sa 24:00-24:00")).toEqual(fails("INVALID_TIME", 4));
    expect(parse("Sa 18:00-20:00, 24:00 - 02:00")).toEqual(fails("INVALID_TIME", 17));
    expect(parse("Sa 18:00-24:00")).toEqual(week({ Sa: [{ from: "18:00", to: "24:00" }] }));
  });

  test("END_BEFORE_START at the start time when the end is not later", () => {
    expect(parse("Mo 12:00-08:00")).toEqual(fails("END_BEFORE_START", 4));
    expect(parse("Mo 09:00-12:00, 14:00 - 14:00")).toEqual(fails("END_BEFORE_START", 17));
  });

  test("OVERLAP at the start of the later-written range, touching ranges are fine", () => {
    expect(parse("Mo 08:00-12:00,11:00-13:00")).toEqual(fails("OVERLAP", 16));
    expect(parse("Mo 10:00-12:00, 09:00-10:30")).toEqual(fails("OVERLAP", 17));
    expect(parse("Mo 08:00-18:00,09:00-10:00")).toEqual(fails("OVERLAP", 16));
    expect(parse("Mo 08:00-10:00,12:00-13:00,09:00-09:30")).toEqual(fails("OVERLAP", 28));
    expect(parse("Mo 12:00-14:00,08:00-12:00")).toEqual(
      week({
        Mo: [
          { from: "08:00", to: "12:00" },
          { from: "12:00", to: "14:00" },
        ],
      }),
    );
  });

  test("DUPLICATE_DAY at the day item naming an already named day", () => {
    expect(parse("Mo,Tu,Mo 08:00-09:00")).toEqual(fails("DUPLICATE_DAY", 7));
    expect(parse("Tu, Mo-We off")).toEqual(fails("DUPLICATE_DAY", 5));
    expect(parse("Fr-Mo,Su off")).toEqual(fails("DUPLICATE_DAY", 7));
    expect(parse("Sa off; Mo off; Mo,Sa,We-Tu off")).toEqual(fails("DUPLICATE_DAY", 23));
  });

  test("UNEXPECTED at length + 1 when the text ends too early", () => {
    expect(parse("Mo 08:00-")).toEqual(fails("UNEXPECTED", 10));
    expect(parse("Mo off;")).toEqual(fails("UNEXPECTED", 8));
    expect(parse("Mo")).toEqual(fails("UNEXPECTED", 3));
    expect(parse("Mo- ")).toEqual(fails("UNEXPECTED", 5));
    expect(parse("Mo 08:00-12:00,  ")).toEqual(fails("UNEXPECTED", 18));
  });

  test("UNEXPECTED at a token that does not fit the format", () => {
    expect(parse(";Mo off")).toEqual(fails("UNEXPECTED", 1));
    expect(parse("Mo off;;Tu off")).toEqual(fails("UNEXPECTED", 8));
    expect(parse("08:00-12:00")).toEqual(fails("UNEXPECTED", 1));
    expect(parse("Mo,;")).toEqual(fails("UNEXPECTED", 4));
    expect(parse("Mo-Fr-Sa off")).toEqual(fails("UNEXPECTED", 6));
    expect(parse("Mo Tu off")).toEqual(fails("UNEXPECTED", 4));
    expect(parse("Mo 08:00 12:00")).toEqual(fails("UNEXPECTED", 10));
    expect(parse("Mo 08:00-12:00, Tu off")).toEqual(fails("UNEXPECTED", 17));
    expect(parse("Mo 08:00-12:00 Tu off")).toEqual(fails("UNEXPECTED", 16));
    expect(parse("Mo off, Tu off")).toEqual(fails("UNEXPECTED", 7));
    expect(parse("Mo off 08:00-09:00")).toEqual(fails("UNEXPECTED", 8));
  });

  test("UNEXPECTED at a character that belongs to no token", () => {
    expect(parse("Mo 08:00-12:00 .")).toEqual(fails("UNEXPECTED", 16));
    expect(parse("Mo–Fr off")).toEqual(fails("UNEXPECTED", 3));
    expect(parse("Mo\t08:00-09:00")).toEqual(fails("UNEXPECTED", 3));
    expect(parse("\t")).toEqual(fails("UNEXPECTED", 1));
    expect(parse(" Mo off\n")).toEqual(fails("UNEXPECTED", 8));
  });

  test("the first problem from the left is reported, a run of letters is one word", () => {
    expect(parse("Moé off")).toEqual(fails("UNKNOWN_DAY", 1));
    expect(parse("Mo-Fx 08:00 .")).toEqual(fails("UNKNOWN_DAY", 4));
    expect(parse("Mo 08.00-09:00")).toEqual(fails("INVALID_TIME", 4));
    expect(parse("Mo 12:00-08:00, 25:00-26:00")).toEqual(fails("END_BEFORE_START", 4));
    expect(parse("Mo 08:00-12:00,11:00-10:00")).toEqual(fails("END_BEFORE_START", 16));
    expect(parse("Mo,Mo off;")).toEqual(fails("DUPLICATE_DAY", 4));
  });
});
