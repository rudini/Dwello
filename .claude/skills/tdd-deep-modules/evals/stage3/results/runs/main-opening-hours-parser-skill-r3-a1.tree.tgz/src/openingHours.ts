export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const WEEK: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

// A run of letters is a word, a run of digits and colons a time; any other
// character except a space is a token of its own ("-", ",", ";" or a stray one).
const WORD = /^\p{L}/u;
const TIME = /^[0-9:]/;
const TOKEN = /\p{L}+|[0-9:]+|[^ ]/gu;

interface Token {
  text: string; // "" for the end of the text
  column: number; // 1-based; the end of the text sits at length + 1
}

/** Reads the text token by token, left to right; spaces only separate tokens. */
class Cursor {
  private readonly tokens: Token[];
  private index = 0;

  constructor(text: string) {
    this.tokens = [...text.matchAll(TOKEN)].map((match) => ({
      text: match[0],
      column: match.index + 1,
    }));
    this.tokens.push({ text: "", column: text.length + 1 });
  }

  peek(): Token {
    return this.tokens[this.index];
  }

  /** Consumes the next token; it must match `pattern`, otherwise it is unexpected. */
  next(pattern: RegExp, expected: string): Token {
    const token = this.peek();
    if (this.atEnd() || !pattern.test(token.text)) this.unexpected(expected);
    this.index++;
    return token;
  }

  /** Consumes the next token if its text is `text`. */
  accept(text: string): boolean {
    const found = !this.atEnd() && this.peek().text === text;
    if (found) this.index++;
    return found;
  }

  expectEnd(): void {
    if (!this.atEnd()) this.unexpected('";"');
  }

  private atEnd(): boolean {
    return this.index === this.tokens.length - 1;
  }

  private unexpected(expected: string): never {
    const { text, column } = this.peek();
    const found = this.atEnd() ? "The text ends" : `"${text}" found`;
    throw new OpeningHoursError("UNEXPECTED", column, `${found}, ${expected} expected`);
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  const hours: WeeklyHours = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };
  const cursor = new Cursor(text);
  do {
    const days = parseDays(cursor);
    const ranges = cursor.accept("off") ? [] : parseRanges(cursor);
    for (const day of days) hours[day] = [...ranges];
  } while (cursor.accept(";"));
  cursor.expectEnd();
  return hours;
}

function parseDays(cursor: Cursor): Day[] {
  const days: Day[] = [];
  do {
    const first = parseDay(cursor);
    const last = cursor.accept("-") ? parseDay(cursor) : first;
    const start = WEEK.indexOf(first.day);
    const count = ((WEEK.indexOf(last.day) - start + 7) % 7) + 1;
    for (let i = 0; i < count; i++) {
      const day = WEEK[(start + i) % 7];
      if (days.includes(day)) {
        throw new OpeningHoursError("DUPLICATE_DAY", first.column, `${day} is already named`);
      }
      days.push(day);
    }
  } while (cursor.accept(","));
  return days;
}

function parseDay(cursor: Cursor): { day: Day; column: number } {
  const token = cursor.next(WORD, "a day");
  if (!WEEK.includes(token.text as Day)) {
    throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
  }
  return { day: token.text as Day, column: token.column };
}

function parseRanges(cursor: Cursor): TimeRange[] {
  const ranges: TimeRange[] = [];
  do {
    const start = parseTime(cursor, "start");
    cursor.next(/^-$/, '"-"');
    const end = parseTime(cursor, "end");
    const [from, to] = [start.text, end.text];
    if (to <= from) {
      throw new OpeningHoursError("END_BEFORE_START", start.column, `${to} is not later than ${from}`);
    }
    const earlier = ranges.find((range) => from < range.to && range.from < to);
    if (earlier) {
      throw new OpeningHoursError(
        "OVERLAP",
        start.column,
        `${from}-${to} overlaps ${earlier.from}-${earlier.to}`,
      );
    }
    ranges.push({ from, to });
  } while (cursor.accept(","));
  return ranges.sort((a, b) => (a.from < b.from ? -1 : 1));
}

/** "HH:MM" with hours 00-23 and minutes 00-59; 24:00 only as the end of a range. */
function parseTime(cursor: Cursor, role: "start" | "end"): Token {
  const token = cursor.next(TIME, "a time");
  const valid =
    /^([01]\d|2[0-3]):[0-5]\d$/.test(token.text) || (role === "end" && token.text === "24:00");
  if (!valid) {
    throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
  }
  return token;
}
