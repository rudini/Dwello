# parseOpeningHours: test list

**Hidden decision:** how the opening-hours text is tokenised, parsed and validated,
including which problem is "first" and at which column it is reported. Callers only
see a complete weekly schedule or one `OpeningHoursError`.

**Design A (chosen by the spec):** one function that returns the schedule or throws.

```ts
const hours = parseOpeningHours("Mo-Fr 08:00-12:00; Su off"); // throws OpeningHoursError
```

**Design B:** a result value.

```ts
const r = parseOpeningHours(text); // { ok: true, hours } | { ok: false, code, column }
if (!r.ok) highlight(r.column);
```

Chosen: A, because a single call returning the full seven-day schedule and a single
error type hides the tokenizer, grammar, day-range expansion and rule merging
completely, and the spec already fixes this interface (B would only move the
`try` into an `if` without hiding more).

## Behaviours (through `parseOpeningHours`)

- [x] one day with one range returns all seven days, the others closed
- [x] several comma-separated ranges in one rule
- [x] a comma-separated list of days
- [x] a day range Mo-Fr expands to every day in between
- [x] a day range wraps around the week (Fr-Mo), Mo-Mo is one day
- [x] `off` closes the named days
- [x] several rules separated by `;`
- [x] a later rule replaces the hours of the days it names
- [x] spaces between tokens and around the text carry no meaning
- [x] ranges within a rule are returned sorted by start time
- [x] touching ranges and 24:00 as an end are accepted (already passing on their own,
      so asserted inside the OVERLAP and 24:00-start tests)
- [x] EMPTY for empty or blank text
- [x] UNKNOWN_DAY at the word that is not a day
- [x] INVALID_TIME for a malformed time token
- [x] INVALID_TIME for hours or minutes out of range
- [x] INVALID_TIME for 24:00 as a start
- [x] END_BEFORE_START at the start time when the end is not later
- [x] OVERLAP at the start of the later-written range
- [x] DUPLICATE_DAY at the day item naming an already named day
- [x] UNEXPECTED at length + 1 when the text ends too early
- [x] UNEXPECTED at a character that belongs to no token
- [x] UNEXPECTED at a token that does not fit (empty rule, misplaced token)
- [x] the first problem from the left is reported
