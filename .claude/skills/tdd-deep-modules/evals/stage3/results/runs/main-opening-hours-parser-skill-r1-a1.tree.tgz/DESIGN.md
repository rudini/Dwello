# Opening hours parser: design note

**Hidden decision:** the text format of opening hours. This covers tokenising, the grammar, day ranges that wrap around the week, later rules replacing earlier ones, and which error (code and column) a broken text produces. Callers only ever see a `WeeklyHours` or an `OpeningHoursError`.

## Two designs

- **A (chosen):** `parseOpeningHours(text): WeeklyHours`, which throws `OpeningHoursError`.
  Call site: `try { hours = parseOpeningHours(value) } catch (e) { highlight(e.column) }`
- **B:** a stateful `OpeningHoursParser` with `feed(rule)` and `result()` returning a result object.
  Call site: `for (const r of text.split(";")) p.feed(r); p.result()`

Chosen: A, because one call hides tokenising, splitting the text into rules, column arithmetic and replacement semantics. B leaks the rule separator and column offsets to the caller.

## Interface

- `parseOpeningHours(text)` returns all seven days. A closed day is `[]`. Each day's ranges are sorted by start, and times are kept exactly as written.
- `OpeningHoursError` has a `code` (`EMPTY`, `UNKNOWN_DAY`, `INVALID_TIME`, `END_BEFORE_START`, `OVERLAP`, `DUPLICATE_DAY` or `UNEXPECTED`) and a 1-based `column`.

Internally there is a lazy tokenizer (a generator) and a recursive-descent parser over it. Because tokens are read lazily, a character that belongs to no token is reported only when the parser reaches it. This keeps the "first problem from the left" rule.

## Depth

`depth_report`: `src/openingHours.ts: surface 10, size 129, ratio 12.9, classitis no, pass-through 0, tests 1, unused 0, duplicate 2 -> deep`

Changes made during refactors:
- The day walk is bounded, and each day gets its own array.
- String splitting was replaced by a tokenizer and a parser.
- "Blank" means spaces only, matching the tokenizer.
- `skip(kind)` replaced the repeated separator handling.

## Open points

- Only the space character counts as whitespace. A tab or a newline is `UNEXPECTED`.
- A "word" is any run of Unicode letters, so `Mö` is `UNKNOWN_DAY` rather than a stray character.
- Duplicate days are checked once a day item is complete. So in `Mo,Mo!`, the stray `!` (which is read while checking for a `-`) is reported first.
- Overlap is checked only after the range has passed the end-after-start check.

## Proof

`scripts/tdd_replay fcc447a..f9d7e4b` printed `REPLAY: ACCEPT`.
