import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours } from "./openingHours";

const closedWeek = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };

test("a single day with a single range gives only that day hours", () => {
  expect(() => parseOpeningHours("Mo 08:00-12:00")).not.toThrow();
  expect(parseOpeningHours("Mo 08:00-12:00")).toEqual({
    ...closedWeek,
    Mo: [{ from: "08:00", to: "12:00" }],
  });
});

test("several ranges in a rule are returned sorted by start time", () => {
  expect(parseOpeningHours("Tu 13:30-18:30,08:00-12:00").Tu).toEqual([
    { from: "08:00", to: "12:00" },
    { from: "13:30", to: "18:30" },
  ]);
});

test("a day range names every day from start to end", () => {
  const morning = [{ from: "08:00", to: "12:00" }];
  expect(parseOpeningHours("Tu-Th 08:00-12:00")).toEqual({
    ...closedWeek,
    Tu: morning,
    We: morning,
    Th: morning,
  });
});

test("a day range wraps around the week, and a day to itself is that day only", () => {
  const morning = [{ from: "08:00", to: "12:00" }];
  expect(parseOpeningHours("Fr-Mo 08:00-12:00")).toEqual({
    ...closedWeek,
    Fr: morning,
    Sa: morning,
    Su: morning,
    Mo: morning,
  });
  expect(parseOpeningHours("Mo-Mo 08:00-12:00")).toEqual({ ...closedWeek, Mo: morning });
});

test("comma-separated day items name each day", () => {
  const morning = [{ from: "08:00", to: "12:00" }];
  expect(parseOpeningHours("Mo,We-Th,Sa 08:00-12:00")).toEqual({
    ...closedWeek,
    Mo: morning,
    We: morning,
    Th: morning,
    Sa: morning,
  });
});

test("off closes the named days", () => {
  expect(parseOpeningHours("Mo-Su off")).toEqual(closedWeek);
});

test("a later rule replaces the hours of the days it names", () => {
  const day = [{ from: "08:00", to: "20:00" }];
  expect(parseOpeningHours("Mo-Su 08:00-20:00;Su off;We 14:00-18:00")).toEqual({
    Mo: day,
    Tu: day,
    We: [{ from: "14:00", to: "18:00" }],
    Th: day,
    Fr: day,
    Sa: day,
    Su: [],
  });
});

test("spaces between tokens and around the text are ignored", () => {
  expect(parseOpeningHours("  Mo , We - Th 08:00 - 12:00 , 13:00-14:00 ;Fr off  ")).toEqual({
    ...closedWeek,
    Mo: [
      { from: "08:00", to: "12:00" },
      { from: "13:00", to: "14:00" },
    ],
    We: [
      { from: "08:00", to: "12:00" },
      { from: "13:00", to: "14:00" },
    ],
    Th: [
      { from: "08:00", to: "12:00" },
      { from: "13:00", to: "14:00" },
    ],
  });
  expect(parseOpeningHours("Mo08:00-12:00").Mo).toEqual([{ from: "08:00", to: "12:00" }]);
});

function errorOf(text: string) {
  try {
    parseOpeningHours(text);
  } catch (error) {
    const { code, column } = error as OpeningHoursError;
    return { isOpeningHoursError: error instanceof OpeningHoursError, code, column };
  }
  return "no error";
}

test("EMPTY for empty or blank text, at column 1", () => {
  expect(errorOf("")).toEqual({ isOpeningHoursError: true, code: "EMPTY", column: 1 });
  expect(errorOf("   ")).toEqual({ isOpeningHoursError: true, code: "EMPTY", column: 1 });
});

test("UNKNOWN_DAY for a word where a day is expected, at the word", () => {
  const unknownDay = (column: number) => ({ isOpeningHoursError: true, code: "UNKNOWN_DAY", column });
  expect(errorOf("Mo-Fx 08:00-12:00")).toEqual(unknownDay(4));
  expect(errorOf("  mo 08:00-12:00")).toEqual(unknownDay(3));
  expect(errorOf("Mo off; Sa,Sun off")).toEqual(unknownDay(12));
  expect(errorOf("off")).toEqual(unknownDay(1));
});

test("INVALID_TIME for a time that is not HH:MM in range, at the time; 24:00 only as an end", () => {
  const invalidTime = (column: number) => ({ isOpeningHoursError: true, code: "INVALID_TIME", column });
  expect(errorOf("Mo 8:00-12:00")).toEqual(invalidTime(4));
  expect(errorOf("Mo 08:00-1200")).toEqual(invalidTime(10));
  expect(errorOf("Mo 08:00-12:00:00")).toEqual(invalidTime(10));
  expect(errorOf("Mo 08:60-12:00")).toEqual(invalidTime(4));
  expect(errorOf("Mo 08:00-24:30")).toEqual(invalidTime(10));
  expect(errorOf("Mo 24:00-24:00")).toEqual(invalidTime(4));
  expect(errorOf("Mo 08:00-12:00,013:00-14:00")).toEqual(invalidTime(16));
  expect(parseOpeningHours("Mo 00:00-24:00").Mo).toEqual([{ from: "00:00", to: "24:00" }]);
});

test("END_BEFORE_START when the end is not later than the start, at the start time", () => {
  const endBeforeStart = (column: number) => ({ isOpeningHoursError: true, code: "END_BEFORE_START", column });
  expect(errorOf("Mo 12:00-08:00")).toEqual(endBeforeStart(4));
  expect(errorOf("Mo 08:00-12:00, 13:00 - 13:00")).toEqual(endBeforeStart(17));
});

test("OVERLAP when a range overlaps an earlier range of the rule, at the later-written range", () => {
  const overlap = (column: number) => ({ isOpeningHoursError: true, code: "OVERLAP", column });
  expect(errorOf("Mo 08:00-12:00,11:00-14:00")).toEqual(overlap(16));
  expect(errorOf("Mo 13:00-18:00,08:00-12:00,07:00-14:00")).toEqual(overlap(28));
  expect(errorOf("Mo 08:00-18:00,10:00-12:00")).toEqual(overlap(16));
  expect(parseOpeningHours("Mo 12:00-14:00,08:00-12:00").Mo).toEqual([
    { from: "08:00", to: "12:00" },
    { from: "12:00", to: "14:00" },
  ]);
  expect(parseOpeningHours("Mo 08:00-12:00;Mo 10:00-14:00").Mo).toEqual([{ from: "10:00", to: "14:00" }]);
});

test("DUPLICATE_DAY when a day item names a day already named in the rule, at the item", () => {
  const duplicateDay = (column: number) => ({ isOpeningHoursError: true, code: "DUPLICATE_DAY", column });
  expect(errorOf("Mo,Mo 08:00-12:00")).toEqual(duplicateDay(4));
  expect(errorOf("Mo-Fr, Sa, Th-Fr off")).toEqual(duplicateDay(12));
  expect(errorOf("We, Mo-Su off")).toEqual(duplicateDay(5));
  expect(errorOf("Fr-Mo,Su off")).toEqual(duplicateDay(7));
  expect(parseOpeningHours("Mo off;Mo,Tu 08:00-12:00").Mo).toEqual([{ from: "08:00", to: "12:00" }]);
});

test("UNEXPECTED for a token that does not fit, or at length + 1 when the text ends early", () => {
  const unexpected = (column: number) => ({ isOpeningHoursError: true, code: "UNEXPECTED", column });
  expect(errorOf("Mo 08:00-")).toEqual(unexpected(10));
  expect(errorOf("Mo 08:00-12:00,")).toEqual(unexpected(16));
  expect(errorOf("Mo  ")).toEqual(unexpected(5));
  expect(errorOf("Mo off;")).toEqual(unexpected(8));
  expect(errorOf(";Mo off")).toEqual(unexpected(1));
  expect(errorOf("Mo off;;Tu off")).toEqual(unexpected(8));
  expect(errorOf("Mo Off")).toEqual(unexpected(4));
  expect(errorOf("Mo 08:00 12:00")).toEqual(unexpected(10));
  expect(errorOf("Mo 08:00-12:00,Sa off")).toEqual(unexpected(16));
  expect(errorOf("Mo 08:00-12:00 Tu off")).toEqual(unexpected(16));
  expect(errorOf("Mo-08:00-12:00")).toEqual(unexpected(4));
  expect(errorOf("Mo,,Tu off")).toEqual(unexpected(4));
});

test("UNEXPECTED for a character that belongs to no token, reported in reading order", () => {
  const unexpected = (column: number) => ({ isOpeningHoursError: true, code: "UNEXPECTED", column });
  expect(errorOf("Mo 08:00-12:00!")).toEqual(unexpected(15));
  expect(errorOf("Mo\t08:00-12:00")).toEqual(unexpected(3));
  expect(errorOf("Mo .08:00-12:00")).toEqual(unexpected(4));
  expect(errorOf("Mo-Fx 08:00-12:00 / Sa off")).toEqual({ isOpeningHoursError: true, code: "UNKNOWN_DAY", column: 4 });
});

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});
