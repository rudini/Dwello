# Opening hours parser: test list

**Hidden decision:** the text format of opening hours — how the text is tokenised, the grammar, how day ranges wrap and later rules replace earlier ones, and which error (code and column) a broken text produces. Callers only see a `WeeklyHours` or an `OpeningHoursError`.

**Design A:** `parseOpeningHours(text: string): WeeklyHours`, throwing `OpeningHoursError`.
Call site: `try { hours = parseOpeningHours(field.value) } catch (e) { highlight(e.column) }`

**Design B:** `class OpeningHoursParser { feed(rule) ; result(): { ok: true, hours } | { ok: false, errors } }` — stateful, rule by rule.
Call site: `const p = new OpeningHoursParser(); for (const r of text.split(";")) p.feed(r); p.result()`

**Chosen:** Design A, because one call hides tokenising, rule splitting, column arithmetic and replacement semantics, while B leaks the rule separator and column offsets to the caller.

## Behaviours (through `parseOpeningHours`)

- [x] a single day with a single range gives that day the range and all other six days empty
- [x] several ranges in a rule are returned sorted by start time
- [x] a day range `Mo-Fr` names every day from start to end
- [x] a day range wraps around the week (`Fr-Mo`), and `Mo-Mo` is Monday only
- [x] comma-separated day items name each day
- [x] `off` closes the named days
- [x] a later rule replaces the hours of the days it names
- [x] spaces between tokens and around the text are ignored
- [x] `24:00` is allowed as the end of a range; touching ranges are allowed
- [x] EMPTY for empty or blank text, column 1
- [x] UNKNOWN_DAY for a word where a day is expected, at the word
- [x] INVALID_TIME for a malformed time, hour > 23, minute > 59, `24:00` as a start
- [x] END_BEFORE_START when the end is not later than the start, at the start time
- [x] OVERLAP when a range overlaps an earlier range of the rule, at the later-written range
- [x] DUPLICATE_DAY when a day item names a day already named in the rule, at the item
- [x] UNEXPECTED when the text ends too early, at length + 1
- [x] UNEXPECTED for an empty rule (`Mo off;`)
- [x] UNEXPECTED for a token that does not fit, at the token
- [x] UNEXPECTED for a character that belongs to no token
