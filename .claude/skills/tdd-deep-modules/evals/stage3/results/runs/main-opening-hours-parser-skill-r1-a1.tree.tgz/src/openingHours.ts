export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const WEEK: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "end";

interface Token {
  kind: TokenKind;
  text: string;
  column: number;
}

// A run of letters is a word, a run of digits and colons is a time,
// "-", "," and ";" stand alone; spaces only separate tokens.
const TOKEN = /(\p{L}+)|([\d:]+)|[-,;]/uy;

function* tokenize(text: string): Generator<Token, Token> {
  let index = 0;
  while (index < text.length) {
    if (text[index] === " ") {
      index++;
      continue;
    }
    TOKEN.lastIndex = index;
    const match = TOKEN.exec(text);
    if (!match) throw new OpeningHoursError("UNEXPECTED", index + 1, `Unexpected "${text[index]}"`);
    const kind = match[1] ? "word" : match[2] ? "time" : (match[0] as TokenKind);
    yield { kind, text: match[0], column: index + 1 };
    index += match[0].length;
  }
  return { kind: "end", text: "", column: text.length + 1 };
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  const tokens = tokenize(text);
  let current: Token | undefined;
  const peek = (): Token => (current ??= tokens.next().value);
  const next = (): Token => {
    const token = peek();
    if (token.kind !== "end") current = undefined;
    return token;
  };
  const take = (kind: TokenKind): Token => {
    const token = peek();
    if (token.kind !== kind) {
      const found = token.kind === "end" ? "end of text" : `"${token.text}"`;
      throw new OpeningHoursError("UNEXPECTED", token.column, `Unexpected ${found}`);
    }
    return next();
  };
  const skip = (kind: TokenKind): boolean => {
    if (peek().kind !== kind) return false;
    next();
    return true;
  };

  const takeDay = (): Day => {
    const token = take("word");
    if (!WEEK.includes(token.text as Day)) {
      throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    }
    return token.text as Day;
  };

  const parseDayItem = (named: Day[]): Day[] => {
    const column = peek().column;
    const first = takeDay();
    const last = skip("-") ? takeDay() : first;
    const start = WEEK.indexOf(first);
    const span = (WEEK.indexOf(last) - start + 7) % 7;
    const days = Array.from({ length: span + 1 }, (_, offset) => WEEK[(start + offset) % 7]);
    const repeated = days.find((day) => named.includes(day));
    if (repeated) throw new OpeningHoursError("DUPLICATE_DAY", column, `${repeated} is named twice`);
    return days;
  };

  const takeTime = (isEnd: boolean): Token => {
    const token = take("time");
    const valid = /^([01]\d|2[0-3]):[0-5]\d$/.test(token.text) || (isEnd && token.text === "24:00");
    if (!valid) throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    return token;
  };

  const parseRange = (earlier: TimeRange[]): TimeRange => {
    const start = takeTime(false);
    take("-");
    const to = takeTime(true).text;
    if (to <= start.text) {
      throw new OpeningHoursError("END_BEFORE_START", start.column, `${to} is not after ${start.text}`);
    }
    const clash = earlier.find((range) => range.from < to && start.text < range.to);
    if (clash) {
      throw new OpeningHoursError("OVERLAP", start.column, `Overlaps ${clash.from}-${clash.to}`);
    }
    return { from: start.text, to };
  };

  const parseRanges = (): TimeRange[] => {
    if (peek().kind === "word" && peek().text === "off") {
      next();
      return [];
    }
    const ranges = [parseRange([])];
    while (skip(",")) ranges.push(parseRange(ranges));
    return ranges.sort((a, b) => a.from.localeCompare(b.from));
  };

  const hours: WeeklyHours = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };
  const parseRule = () => {
    const days = parseDayItem([]);
    while (skip(",")) days.push(...parseDayItem(days));
    const ranges = parseRanges();
    for (const day of days) hours[day] = [...ranges];
  };

  do parseRule();
  while (skip(";"));
  take("end");
  return hours;
}
