import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type Policy } from "./expenseReview";

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};
const fx = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";

const review = (...rows: string[]) => reviewExpenses([HEADER, ...rows].join("\n"), policy, fx);

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

test("a single valid CHF row is reviewed and approved", () => {
  expect(review("2026-09-01,Anna,meals,12.50,CHF,yes")).toEqual({
    lines: [
      { line: 2, date: "2026-09-01", employee: "Anna", category: "meals", amountChfCents: 1250, violations: [] },
    ],
    rejected: [],
    totals: { Anna: { approvedCents: 1250, flaggedCents: 0 } },
  });
});

test("a file without any non-blank line has no header", () => {
  for (const csv of ["", "\n", "  \r\n\t\n"]) {
    expect(() => reviewExpenses(csv, policy, fx)).toThrow(ExpenseFileError);
    expect(() => reviewExpenses(csv, policy, fx)).toThrow("Missing header");
  }
});

test("a missing required column is named, the first one in spec order", () => {
  const missing = (header: string) => () => reviewExpenses(header + "\n", policy, fx);
  expect(missing("employee,category,amount,currency,receipt")).toThrow(ExpenseFileError);
  expect(missing("employee,category,amount,currency,receipt")).toThrow("Missing column: date");
  expect(missing("receipt,date,employee")).toThrow("Missing column: category");
  expect(missing("date,employee,category,amount,currency")).toThrow("Missing column: receipt");
});

test("header columns may come in any order, any case, padded, with extra columns", () => {
  const csv = " Receipt , note,AMOUNT,Category,currency , EMPLOYEE,Date\nno,lunch,7.00,meals,CHF,Ben,2026-09-02";
  expect(reviewExpenses(csv, policy, fx).lines).toEqual([
    { line: 2, date: "2026-09-02", employee: "Ben", category: "meals", amountChfCents: 700, violations: [] },
  ]);
});

test("blank lines are skipped but counted, CRLF line endings are accepted", () => {
  const csv = "\r\n  \r\n" + HEADER + "\r\n\r\n2026-09-01,Anna,taxi,10,CHF,yes\r\n \t \r\n2026-09-01,Ben,taxi,20,CHF,yes\r\n";
  const report = reviewExpenses(csv, policy, fx);
  expect(report.lines.map((l) => [l.line, l.employee, l.amountChfCents])).toEqual([
    [5, "Anna", 1000],
    [7, "Ben", 2000],
  ]);
  expect(report.rejected).toEqual([]);
});

test("quoted fields may contain commas and doubled quotes; unquoted values are trimmed", () => {
  const report = review(
    '"2026-09-01",  "Muster, Hans ""Hansi"""  , "meals",  "12.00" ,CHF,  yes  ',
    '2026-09-01,"",taxi,1,CHF,yes',
  );
  expect(report.lines).toEqual([
    {
      line: 2,
      date: "2026-09-01",
      employee: 'Muster, Hans "Hansi"',
      category: "meals",
      amountChfCents: 1200,
      violations: [],
    },
  ]);
  expect(report.rejected).toEqual([{ line: 3, reason: "missing employee" }]);
});

const rejections = (...rows: string[]) => review(...rows).rejected.map((r) => r.reason);

test("rows with a different number of fields than the header are rejected", () => {
  const report = review(
    "2026-09-01,Anna,meals,12.50,CHF",
    "2026-09-01,Anna,meals,12.50,CHF,yes,extra",
    '2026-09-01,"Anna, B",meals,12.50,CHF,yes',
  );
  expect(report.rejected).toEqual([
    { line: 2, reason: "wrong number of fields" },
    { line: 3, reason: "wrong number of fields" },
  ]);
  expect(report.lines.map((l) => l.line)).toEqual([4]);
});

test("dates must be real calendar dates written YYYY-MM-DD", () => {
  const bad = ["2026-9-01", "26-09-01", "2026/09/01", "2026-13-01", "2026-00-10", "2026-09-00", "2026-09-31",
    "2026-02-29", "1900-02-29", "2026-09-01x", "", "２０２６-09-01"];
  expect(rejections(...bad.map((d) => `${d},Anna,taxi,1,CHF,yes`))).toEqual(bad.map(() => "invalid date"));
  const good = ["2024-02-29", "2000-02-29", "2026-12-31", "2026-01-01"];
  expect(rejections(...good.map((d) => `${d},Anna,taxi,1,CHF,yes`))).toEqual([]);
});

test("an employee of only spaces counts as missing", () => {
  expect(rejections('2026-09-01,"   ",taxi,1,CHF,yes', "2026-09-01,  ,taxi,1,CHF,yes")).toEqual([
    "missing employee",
    "missing employee",
  ]);
});

test("categories must be policy keys, matched exactly", () => {
  const bad = ["Meals", "meal", "", "toString", "__proto__", "constructor"];
  expect(rejections(...bad.map((c) => `2026-09-01,Anna,${c},1,CHF,yes`))).toEqual(bad.map(() => "unknown category"));
  expect(rejections("2026-09-01,Anna, hotel ,1,CHF,yes")).toEqual([]);
});

test("amounts are digits with up to two decimals and above zero", () => {
  const bad = ["0", "0.00", "0.0", "-5", "+5", "1.234", "1.", ".5", "1,5", "1e3", "", "abc", "1 000", "0x10", "Infinity"];
  expect(rejections(...bad.map((a) => `2026-09-01,Anna,taxi,"${a}",CHF,yes`))).toEqual(bad.map(() => "invalid amount"));
  const report = review(...["0.01", "7", "7.5", "007.05", "1234.56"].map((a) => `2026-09-01,Anna,taxi,${a},CHF,yes`));
  expect(report.rejected).toEqual([]);
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([1, 700, 750, 705, 123456]);
});

test("currencies must be CHF or have an exchange rate", () => {
  const bad = ["chf", "eur", "GBP", "", "toString", "__proto__"];
  expect(rejections(...bad.map((c) => `2026-09-01,Anna,taxi,1,${c},yes`))).toEqual(bad.map(() => "unknown currency"));
  expect(rejections("2026-09-01,Anna,taxi,1,CHF,yes", "2026-09-01,Anna,taxi,1,EUR,yes")).toEqual([]);
});

test("receipt flags are yes or no in any case", () => {
  const bad = ["y", "n", "true", "", "yes!", "1"];
  expect(rejections(...bad.map((r) => `2026-09-01,Anna,taxi,1,CHF,"${r}"`))).toEqual(
    bad.map(() => "invalid receipt flag"),
  );
  expect(rejections(...["YES", "No", "nO", " yes "].map((r) => `2026-09-01,Anna,taxi,1,CHF,${r}`))).toEqual([]);
});

test("the first failing check gives the reason", () => {
  expect(
    rejections(
      "2026-02-30,,nope,0,XYZ,maybe",
      "2026-02-28,,nope,0,XYZ,maybe",
      "2026-02-28,Anna,nope,0,XYZ,maybe",
      "2026-02-28,Anna,taxi,0,XYZ,maybe",
      "2026-02-28,Anna,taxi,1,XYZ,maybe",
      "2026-02-28,Anna,taxi,1,CHF,maybe",
    ),
  ).toEqual(["invalid date", "missing employee", "unknown category", "invalid amount", "unknown currency", "invalid receipt flag"]);
});

test("amounts are converted to CHF cents, rounded half up without float errors", () => {
  const rates = { EUR: 0.9412, USD: 1.005, GBP: 0.145, JPY: 0.0055, XAU: 1e-7, CHF: 2 };
  const convert = (amount: string, currency: string) =>
    reviewExpenses(`${HEADER}\n2026-09-01,Anna,taxi,${amount},${currency},yes`, policy, rates).lines[0].amountChfCents;
  expect(convert("10.00", "EUR")).toBe(941); // 941.2
  expect(convert("1", "USD")).toBe(101); // 100.5
  expect(convert("1", "GBP")).toBe(15); // 14.5
  expect(convert("0.01", "USD")).toBe(1); // 1.005
  expect(convert("1", "JPY")).toBe(1); // 0.55
  expect(convert("0.9", "JPY")).toBe(0); // 0.495
  expect(convert("50000", "XAU")).toBe(1); // 0.5
  expect(convert("12.34", "CHF")).toBe(1234); // CHF is always 1
});

const violations = (...rows: string[]) => review(...rows).lines.map((l) => l.violations);

test("a row repeating an earlier accepted row is a duplicate", () => {
  expect(
    violations(
      "2026-09-01,Anna,taxi,12.5,CHF,yes",
      "2026-09-01,Anna,taxi,12.50,CHF,no", // same amount as a value; receipt does not matter
      "2026-09-01,Anna,taxi,12.50,CHF,yes", // duplicate again
      "2026-09-01,Ben,taxi,12.50,CHF,yes", // other employee
      "2026-09-02,Anna,taxi,12.50,CHF,yes", // other date
      "2026-09-01,Anna,meals,12.50,CHF,yes", // other category
      "2026-09-01,Anna,taxi,12.51,CHF,yes", // other amount
      "2026-09-01,Anna,taxi,12.50,EUR,yes", // other currency
      " 2026-09-01 , Anna , taxi ,012.5, CHF ,yes", // trimmed values, same amount
    ),
  ).toEqual([[], ["DUPLICATE"], ["DUPLICATE"], [], [], [], [], [], ["DUPLICATE"]]);
});

test("rejected rows do not make later rows duplicates", () => {
  expect(violations("2026-09-01,Anna,taxi,5,CHF,maybe", "2026-09-01,Anna,taxi,5,CHF,yes")).toEqual([[]]);
});

test("an expense above the category's per-item limit in CHF is flagged", () => {
  expect(
    violations(
      "2026-09-01,Anna,hotel,250.00,CHF,yes", // exactly the limit
      "2026-09-02,Anna,hotel,250.01,CHF,yes",
      "2026-09-03,Anna,hotel,265.62,EUR,yes", // 25000.15 cents -> 25000
      "2026-09-04,Anna,hotel,265.63,EUR,yes", // 25001.09 cents -> 25001
      "2026-09-05,Anna,taxi,9999,CHF,yes", // no limit
    ),
  ).toEqual([[], ["OVER_ITEM_LIMIT"], [], ["OVER_ITEM_LIMIT"], []]);
});

test("the running daily total per employee, date and category is checked against the daily limit", () => {
  expect(
    violations(
      "2026-09-01,Anna,meals,30,CHF,yes", // 30
      "2026-09-01,Ben,meals,45,CHF,yes", // other employee
      "2026-09-02,Anna,meals,45,CHF,yes", // other date
      "2026-09-01,Anna,taxi,45,CHF,yes", // other category (no daily limit)
      "2026-09-01,Anna,meals,abc,CHF,yes", // rejected, does not count
      "2026-09-01,Anna,meals,50,CHF,yes", // 80: exactly the limit
      "2026-09-01,Anna,meals,0.01,CHF,yes", // 80.01
      "2026-09-01,Anna,meals,0.01,CHF,yes", // duplicate, 80.02
    ),
  ).toEqual([[], [], [], [], [], ["OVER_DAILY_LIMIT"], ["DUPLICATE", "OVER_DAILY_LIMIT"]]);
});

test("duplicates count towards the running daily total", () => {
  expect(
    violations("2026-09-01,Anna,meals,40,CHF,yes", "2026-09-01,Anna,meals,40,CHF,yes", "2026-09-01,Anna,meals,1,CHF,yes"),
  ).toEqual([[], ["DUPLICATE"], ["OVER_DAILY_LIMIT"]]);
});

test("expenses without receipt above the threshold in CHF are flagged", () => {
  expect(
    violations(
      "2026-09-01,Anna,taxi,20.00,CHF,no", // exactly the threshold
      "2026-09-02,Anna,taxi,20.01,CHF,no",
      "2026-09-03,Anna,taxi,20.01,CHF,NO",
      "2026-09-04,Anna,taxi,25.00,CHF,yes",
      "2026-09-05,Anna,taxi,25.00,USD,no", // 20.00 CHF
    ),
  ).toEqual([[], ["NO_RECEIPT"], ["NO_RECEIPT"], [], []]);
});

test("all violations are listed in a fixed order", () => {
  expect(violations("2026-09-01,Anna,meals,90,CHF,no", "2026-09-01,Anna,meals,90,CHF,no")).toEqual([
    ["OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
    ["DUPLICATE", "OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
  ]);
});

test("totals split approved and flagged CHF amounts per employee with accepted rows", () => {
  const report = review(
    "2026-09-01,Anna,taxi,10,CHF,yes",
    "2026-09-02,Anna,taxi,15.50,CHF,yes",
    "2026-09-02,Anna,taxi,15.50,CHF,yes", // duplicate
    "2026-09-03,Anna,meals,60,CHF,yes", // over item limit
    "2026-09-01,Ben,taxi,10.00,EUR,yes", // 9.412 -> 941
    "2026-09-01,Carla,taxi,10,XYZ,yes", // rejected only
    "2026-09-01,__proto__,taxi,1,CHF,yes",
  );
  expect(report.totals).toEqual({
    Anna: { approvedCents: 2550, flaggedCents: 7550 },
    Ben: { approvedCents: 941, flaggedCents: 0 },
    ["__proto__"]: { approvedCents: 100, flaggedCents: 0 },
  });
  expect(Object.keys(report.totals)).toEqual(["Anna", "Ben", "__proto__"]);
});
