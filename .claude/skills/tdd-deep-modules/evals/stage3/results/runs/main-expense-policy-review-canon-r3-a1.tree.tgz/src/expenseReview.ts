export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

/** Splits one CSV line into fields; quoted parts keep commas, `""` is one `"`, unquoted spaces are trimmed. */
function splitFields(text: string): string[] {
  const fields: string[] = [];
  let pos = 0;
  for (;;) {
    let value = "";
    let unquoted = "";
    while (pos < text.length && text[pos] !== ",") {
      if (text[pos] === '"') {
        value += unquoted.trim();
        unquoted = "";
        pos++;
        while (pos < text.length) {
          if (text[pos] === '"' && text[pos + 1] === '"') {
            value += '"';
            pos += 2;
          } else if (text[pos] === '"') {
            pos++;
            break;
          } else {
            value += text[pos++];
          }
        }
      } else {
        unquoted += text[pos++];
      }
    }
    fields.push(value + unquoted.trim());
    if (pos >= text.length) return fields;
    pos++;
  }
}

function isCalendarDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number);
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== undefined && day >= 1 && day <= daysInMonth;
}

/** Parses an amount like `12`, `12.5` or `12.50` into cents; undefined when malformed. */
function parseCents(text: string): bigint | undefined {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(text);
  if (!match) return undefined;
  return BigInt(match[1]) * 100n + BigInt((match[2] ?? "").padEnd(2, "0"));
}

/** Writes a finite non-negative number exactly as digits scaled by a power of ten: value = digits / 10^scale. */
function toDecimal(value: number): { digits: bigint; scale: number } {
  const [mantissa, exponentText = "0"] = String(value).toLowerCase().split("e");
  const [whole, fraction = ""] = mantissa.split(".");
  const scale = fraction.length - Number(exponentText);
  return scale >= 0
    ? { digits: BigInt(whole + fraction), scale }
    : { digits: BigInt(whole + fraction) * 10n ** BigInt(-scale), scale: 0 };
}

/** cents * rate, rounded to the nearest cent with halves up, in exact decimal arithmetic. */
function convertCents(cents: bigint, rate: number): number {
  const { digits, scale } = toDecimal(rate);
  const divisor = 10n ** BigInt(scale);
  return Number((2n * cents * digits + divisor) / (2n * divisor));
}

const REQUIRED_COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof REQUIRED_COLUMNS)[number];

interface AcceptedRow {
  date: string;
  employee: string;
  category: string;
  amountCents: bigint;
  currency: string;
  hasReceipt: boolean;
  amountChfCents: number;
}

/** Validates one data row in the order of the spec; returns the parsed row or the rejection reason. */
function readRow(
  fields: string[],
  column: Record<Column, number>,
  fieldCount: number,
  policy: Policy,
  fxRates: FxRates,
): AcceptedRow | string {
  if (fields.length !== fieldCount) return "wrong number of fields";
  const [date, employee, category, amount, currency, receipt] = REQUIRED_COLUMNS.map((name) => fields[column[name]]);
  if (!isCalendarDate(date)) return "invalid date";
  if (employee.trim() === "") return "missing employee";
  if (!Object.hasOwn(policy.categories, category)) return "unknown category";
  const amountCents = parseCents(amount);
  if (amountCents === undefined || amountCents <= 0n) return "invalid amount";
  if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) return "unknown currency";
  const receiptFlag = receipt.toLowerCase();
  if (receiptFlag !== "yes" && receiptFlag !== "no") return "invalid receipt flag";
  const amountChfCents = convertCents(amountCents, currency === "CHF" ? 1 : fxRates[currency]);
  return { date, employee, category, amountCents, currency, hasReceipt: receiptFlag === "yes", amountChfCents };
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const physical = csv.split("\n").map((text) => (text.endsWith("\r") ? text.slice(0, -1) : text));
  const headerIndex = physical.findIndex((text) => text.trim() !== "");
  if (headerIndex < 0) throw new ExpenseFileError("Missing header");
  const header = splitFields(physical[headerIndex]).map((name) => name.trim().toLowerCase());
  const column = {} as Record<Column, number>;
  for (const name of REQUIRED_COLUMNS) {
    column[name] = header.indexOf(name);
    if (column[name] < 0) throw new ExpenseFileError(`Missing column: ${name}`);
  }
  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();
  const seen = new Set<string>();
  const dailyTotals = new Map<string, number>();
  for (let i = headerIndex + 1; i < physical.length; i++) {
    if (physical[i].trim() === "") continue;
    const row = readRow(splitFields(physical[i]), column, header.length, policy, fxRates);
    if (typeof row === "string") {
      rejected.push({ line: i + 1, reason: row });
      continue;
    }
    const { date, employee, category, amountCents, currency, amountChfCents } = row;
    const violations: Violation[] = [];
    const duplicateKey = JSON.stringify([employee, date, category, amountCents.toString(), currency]);
    if (seen.has(duplicateKey)) violations.push("DUPLICATE");
    seen.add(duplicateKey);
    const limits = policy.categories[category];
    if (limits.perItemLimitCents !== undefined && amountChfCents > limits.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }
    const dayKey = JSON.stringify([employee, date, category]);
    const dayTotal = (dailyTotals.get(dayKey) ?? 0) + amountChfCents;
    dailyTotals.set(dayKey, dayTotal);
    if (limits.dailyLimitCents !== undefined && dayTotal > limits.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }
    if (!row.hasReceipt &&amountChfCents > policy.receiptRequiredAboveCents) {
      violations.push("NO_RECEIPT");
    }
    lines.push({ line: i + 1, date, employee, category, amountChfCents, violations });
    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
    totals.set(employee, total);
  }
  return { lines, rejected, totals: Object.fromEntries(totals) };
}
