export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  const tokens = tokenize(text);
  let position = 0;
  /** The next token, which must match `pattern`; the end of the text never does. */
  const take = (pattern: RegExp): Token => {
    const token = tokens[position];
    if (!pattern.test(token.text)) throw unexpected(token);
    position++;
    return token;
  };
  const accept = (expected: string) => tokens[position].text === expected && ++position > 0;
  const separated = (separator: string, item: () => void) => {
    do item();
    while (accept(separator));
  };

  const day = (): Day => {
    const token = take(/^\p{L}/u);
    if (!WEEK.includes(token.text as Day)) {
      throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    }
    return token.text as Day;
  };

  const days = (): Day[] => {
    const named: Day[] = [];
    separated(",", () => {
      const column = tokens[position].column;
      const first = day();
      const item = daysFromTo(first, accept("-") ? day() : first);
      if (item.some((d) => named.includes(d))) {
        throw new OpeningHoursError("DUPLICATE_DAY", column, "A day is named twice in this rule");
      }
      named.push(...item);
    });
    return named;
  };

  const time = (isEnd: boolean): Token => {
    const token = take(/^[\d:]/);
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(token.text) && !(isEnd && token.text === "24:00")) {
      throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    }
    return token;
  };

  const ranges = (): TimeRange[] => {
    if (accept("off")) return [];
    const read: TimeRange[] = [];
    separated(",", () => {
      const from = time(false);
      take(/^-$/);
      const to = time(true);
      if (to.text <= from.text) {
        throw new OpeningHoursError("END_BEFORE_START", from.column, `${to.text} is not after ${from.text}`);
      }
      if (read.some((earlier) => earlier.from < to.text && from.text < earlier.to)) {
        throw new OpeningHoursError("OVERLAP", from.column, `${from.text}-${to.text} overlaps an earlier range`);
      }
      read.push({ from: from.text, to: to.text });
    });
    return read.sort((a, b) => a.from.localeCompare(b.from));
  };

  const hours: WeeklyHours = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };
  separated(";", () => {
    const named = days();
    const open = ranges();
    for (const day of named) hours[day] = [...open];
  });
  take(/^$/);
  return hours;
}

const WEEK: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

interface Token {
  text: string; // "" for the end of the text
  column: number;
}

/** Words, times and the single-character tokens, with spaces dropped and an end token appended. */
function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  for (const match of text.matchAll(/\p{L}+|[\d:]+|[^ ]/gu)) {
    tokens.push({ text: match[0], column: match.index + 1 });
  }
  tokens.push({ text: "", column: text.length + 1 });
  return tokens;
}

function unexpected(token: Token): OpeningHoursError {
  const description = token.text === "" ? "The text ends too early" : `Unexpected "${token.text}"`;
  return new OpeningHoursError("UNEXPECTED", token.column, description);
}

/** The days from `first` forward through the week to `last`, wrapping past Su. */
function daysFromTo(first: Day, last: Day): Day[] {
  const start = WEEK.indexOf(first);
  const length = ((WEEK.indexOf(last) - start + 7) % 7) + 1;
  return Array.from({ length }, (_, i) => WEEK[(start + i) % 7]);
}
