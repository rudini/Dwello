import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

const closedWeek = () => ({ Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] });
const range = (from: string, to: string) => ({ from, to });

// Returns the schedule, or the thrown error, so a failing parse shows up as an assertion failure.
function parse(text: string): unknown {
  try {
    return parseOpeningHours(text);
  } catch (error) {
    return error;
  }
}

function failure(text: string): unknown {
  const result = parse(text);
  return result instanceof OpeningHoursError ? { code: result.code, column: result.column } : result;
}

test("a single day with one range returns that range and six closed days", () => {
  expect(parse("Mo 08:00-12:00")).toEqual({ ...closedWeek(), Mo: [range("08:00", "12:00")] });
});

test("a day range covers every day from first to last", () => {
  const morning = [range("08:00", "12:00")];
  expect(parse("Tu-Fr 08:00-12:00")).toEqual({ ...closedWeek(), Tu: morning, We: morning, Th: morning, Fr: morning });
});

test("a rule with several ranges returns them sorted by start", () => {
  expect(parse("Sa 17:00-20:00,08:00-12:00,13:30-15:00")).toEqual({
    ...closedWeek(),
    Sa: [range("08:00", "12:00"), range("13:30", "15:00"), range("17:00", "20:00")],
  });
});

test("rules separated by ; each set their own days", () => {
  expect(parse("Mo-Tu 08:00-12:00;Sa 09:00-16:00")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00")],
    Tu: [range("08:00", "12:00")],
    Sa: [range("09:00", "16:00")],
  });
});

test("off closes the named days", () => {
  expect(parse("Sa 09:00-16:00;Su off")).toEqual({ ...closedWeek(), Sa: [range("09:00", "16:00")] });
});

test("a day list with commas names each day", () => {
  const morning = [range("08:00", "12:00")];
  expect(parse("Mo,We-Th,Sa 08:00-12:00")).toEqual({ ...closedWeek(), Mo: morning, We: morning, Th: morning, Sa: morning });
});

test("a day range wraps around the end of the week, and Mo-Mo is Mo only", () => {
  const morning = [range("08:00", "12:00")];
  expect(parse("Fr-Mo 08:00-12:00")).toEqual({ ...closedWeek(), Fr: morning, Sa: morning, Su: morning, Mo: morning });
  expect(parse("We-We 08:00-12:00")).toEqual({ ...closedWeek(), We: morning });
});

test("a later rule replaces the hours of the days it names", () => {
  const day = [range("08:00", "20:00")];
  expect(parse("Mo-Su 08:00-20:00; Su off")).toEqual({ Mo: day, Tu: day, We: day, Th: day, Fr: day, Sa: day, Su: [] });
  const morning = [range("08:00", "12:00")];
  expect(parse("Mo-Fr 08:00-12:00; We 14:00-18:00")).toEqual({
    ...closedWeek(),
    Mo: morning,
    Tu: morning,
    We: [range("14:00", "18:00")],
    Th: morning,
    Fr: morning,
  });
});

test("spaces between tokens and at both ends are ignored", () => {
  const morning = [range("08:00", "12:00")];
  expect(parse("  Mo , We - Th 08:00 - 12:00 , 13:30-14:00 ;  Sa  off ; Su 08:00 -12:00  ")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00"), range("13:30", "14:00")],
    We: [range("08:00", "12:00"), range("13:30", "14:00")],
    Th: [range("08:00", "12:00"), range("13:30", "14:00")],
    Su: morning,
  });
  expect(parse("Mo,We 08:00 - 12:00")).toEqual({ ...closedWeek(), Mo: morning, We: morning });
});

test("empty or blank text gives EMPTY at column 1", () => {
  expect(failure("")).toEqual({ code: "EMPTY", column: 1 });
  expect(failure("    ")).toEqual({ code: "EMPTY", column: 1 });
});

test("a non-day word where a day is expected gives UNKNOWN_DAY at the word", () => {
  expect(failure("Mo-Fx 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 4 });
  expect(failure("mo 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 1 });
  expect(failure("Mo 08:00-12:00; Sa,Sun off")).toEqual({ code: "UNKNOWN_DAY", column: 20 });
  expect(failure("Mo, off")).toEqual({ code: "UNKNOWN_DAY", column: 5 });
});

test("malformed times give INVALID_TIME at the time", () => {
  expect(failure("Mo 8:00-12:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(failure("Mo 08:00-1200")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(failure("Mo 08:00-12:60")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(failure("Mo 25:00-26:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(failure("Mo 08:00-24:01")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(failure("Mo 08:00:00-12:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(failure("Mo 08:00-12:00,13:00-018:00")).toEqual({ code: "INVALID_TIME", column: 22 });
});

test("24:00 is accepted as an end but gives INVALID_TIME as a start", () => {
  expect(parse("Fr 18:00-24:00")).toEqual({ ...closedWeek(), Fr: [range("18:00", "24:00")] });
  expect(failure("Fr 18:00-24:00,24:00-24:00")).toEqual({ code: "INVALID_TIME", column: 16 });
});

test("an end not later than its start gives END_BEFORE_START at the start time", () => {
  expect(failure("Mo 12:00-08:00")).toEqual({ code: "END_BEFORE_START", column: 4 });
  expect(failure("Mo 08:00-12:00, 14:00 - 14:00")).toEqual({ code: "END_BEFORE_START", column: 17 });
});

test("a range overlapping an earlier one of the rule gives OVERLAP at the later range's start", () => {
  expect(parse("Mo 12:00-14:00,08:00-12:00")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00"), range("12:00", "14:00")],
  });
  expect(failure("Mo 08:00-12:00,11:00-13:00")).toEqual({ code: "OVERLAP", column: 16 });
  expect(failure("Mo 14:00-16:00,08:00-10:00,09:00-09:30")).toEqual({ code: "OVERLAP", column: 28 });
  expect(failure("Mo 14:00-16:00,08:00-10:00,07:00-20:00")).toEqual({ code: "OVERLAP", column: 28 });
  expect(failure("Mo 08:00-12:00;Tu 10:00-11:00,10:30-12:00")).toEqual({ code: "OVERLAP", column: 31 });
});

test("a day named twice in a rule gives DUPLICATE_DAY at that day item", () => {
  expect(failure("Mo,Mo 08:00-12:00")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
  expect(failure("Mo-We, Tu off")).toEqual({ code: "DUPLICATE_DAY", column: 8 });
  expect(failure("Mo,Sa-Tu off")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
  expect(failure("Mo-Su,Fr-Mo off")).toEqual({ code: "DUPLICATE_DAY", column: 7 });
  expect(parse("Mo off;Mo off")).toEqual(closedWeek());
});

test("text ending too early gives UNEXPECTED at its length + 1", () => {
  expect(failure("Mo 08:00-")).toEqual({ code: "UNEXPECTED", column: 10 });
  expect(failure("Mo 08:00")).toEqual({ code: "UNEXPECTED", column: 9 });
  expect(failure("Mo 08:00-12:00,  ")).toEqual({ code: "UNEXPECTED", column: 18 });
  expect(failure("Mo")).toEqual({ code: "UNEXPECTED", column: 3 });
  expect(failure("Mo-")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(failure("Mo, ")).toEqual({ code: "UNEXPECTED", column: 5 });
});

test("an empty rule gives UNEXPECTED", () => {
  expect(failure("Mo off;")).toEqual({ code: "UNEXPECTED", column: 8 });
  expect(failure("Mo off; ;Tu off")).toEqual({ code: "UNEXPECTED", column: 9 });
  expect(failure(" ; Mo off")).toEqual({ code: "UNEXPECTED", column: 2 });
});

test("a character that belongs to no token gives UNEXPECTED at that character", () => {
  expect(failure("Mo 08:00-12:00 #")).toEqual({ code: "UNEXPECTED", column: 16 });
  expect(failure("Mo\t08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 3 });
  expect(failure("\t")).toEqual({ code: "UNEXPECTED", column: 1 });
  expect(failure("Mo 08:00–12:00")).toEqual({ code: "UNEXPECTED", column: 9 });
});
