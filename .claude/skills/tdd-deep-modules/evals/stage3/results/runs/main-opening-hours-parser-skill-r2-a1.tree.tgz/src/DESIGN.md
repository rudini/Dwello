# Design note: parseOpeningHours

**Hidden decision:** how the opening-hours text is tokenised and parsed (grammar, day wrap-around,
rule replacement, and which problem is reported at which column). Callers see only a schedule or one error.

## Both designs

- **A:** `parseOpeningHours(text: string): WeeklyHours`, throws `OpeningHoursError`.
  Call site: `const hours = parseOpeningHours(field.value);`
- **B:** `parseOpeningHours(text): { ok: true; hours } | { ok: false; error: { code, column, description } }`.
  Call site: `const r = parseOpeningHours(field.value); if (!r.ok) highlight(r.error.column);`

**Chosen: A**, because callers need to know only one function and one error type, and the grammar,
tokens and column rules stay hidden behind a single call (with B, every caller has to branch on success).

## Interface

- `parseOpeningHours(text)` returns all seven days. A closed day is `[]`, and each rule's ranges are
  sorted by start. Every day gets its own array.
- `OpeningHoursError` has a `code` (one of the seven `OpeningHoursErrorCode`s) and a 1-based `column`
  for the first problem, reading left to right.
- `Day`, `TimeRange`, `WeeklyHours` and `OpeningHoursErrorCode` are unchanged from the stub.

Nothing else is exported. The tokenizer, the recursive-descent closures (`day`, `days`, `time`,
`ranges`), `daysFromTo` and `unexpected` are private.

## Depth

`src/openingHours.ts: surface 10, size 114, ratio 11.4, classitis no, pass-through 0, tests 1, unused 0, duplicate 2 -> deep`

Refactors:
- Replaced the unbounded day-range walk (it looped forever on an unknown day name) with `daysFromTo`.
- Added `accept` for optional tokens.
- Added `take(pattern)` and `separated(separator, item)`, so each token check and list loop is written once.
- Built every UNEXPECTED error, including the end of the text, in `unexpected()`.

## Open points

- A day item is checked for DUPLICATE_DAY only once it is complete. In `Mo,Mo-Fx`, `Fx`
  (UNKNOWN_DAY, column 7) is reported before the duplicate.
- A word in the place of ranges/`off` that is not `off` (`Mo closed`) gives UNEXPECTED, not UNKNOWN_DAY,
  because no day is expected there.
- Only the space character is ignored. A tab or another whitespace character is UNEXPECTED.
- Columns count UTF-16 code units, so a character outside the BMP counts as two columns.
- Two behaviours got no red of their own: "a token out of place gives UNEXPECTED" and "the leftmost
  problem wins". Earlier cycles already made them work, so a red for them would have passed at once.
  Checked by hand: `Mo off 08:00` → 8, `Mo Tu 08:00` → 4, `Mo 08:00-12:00-14:00` → 15,
  `Mo-Fx 25:00` → UNKNOWN_DAY 4, `Mo,Mo 25:00` → DUPLICATE_DAY 4.

## Proof

`scripts/tdd_replay df30a4f..HEAD` printed `REPLAY: ACCEPT`. It proves phase order, test counts and exit
codes, not how strong the assertions are.
