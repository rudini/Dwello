# Test list: parseOpeningHours

**Hidden decision:** how the opening-hours text is tokenised and parsed (grammar, day wrap-around,
rule replacement, and which problem is reported at which column); callers only see a schedule or one error.

**Sketch A:** `parseOpeningHours(text: string): WeeklyHours`, throws `OpeningHoursError`.
Call site: `const hours = parseOpeningHours(field.value);`

**Sketch B:** `parseOpeningHours(text): { ok: true; hours } | { ok: false; error: { code, column, description } }`.
Call site: `const r = parseOpeningHours(field.value); if (!r.ok) highlight(r.error.column);`

**Chosen:** A, because a caller needs to know only one function and one error type, and the
grammar, tokens and column rules stay hidden behind a single call (B also makes every caller branch on success).

## Behaviours

- [x] a single day with one range returns that range and six closed days
- [x] a day range covers every day from first to last
- [x] a rule with several ranges returns them sorted by start
- [x] rules separated by `;` each set their own days
- [x] `off` closes the named days
- [x] a later rule replaces the hours of the days it names
- [x] a day list with commas names each day
- [x] a day range wraps around the end of the week; `Mo-Mo` is Mo only
- [x] spaces between tokens and at both ends are ignored
- [x] touching ranges and `24:00` as an end are accepted
- [x] empty or blank text gives EMPTY at column 1
- [x] a non-day word where a day is expected gives UNKNOWN_DAY at the word
- [x] malformed times give INVALID_TIME at the time
- [x] `24:00` as a start gives INVALID_TIME
- [x] an end not later than its start gives END_BEFORE_START at the start time
- [x] a range overlapping an earlier one of the rule gives OVERLAP at the later range's start
- [x] a day named twice in a rule gives DUPLICATE_DAY at that day item
- [x] text ending too early gives UNEXPECTED at length + 1
- [x] an empty rule after `;` gives UNEXPECTED
- [x] a character that belongs to no token gives UNEXPECTED at that character
- [x] a token out of place gives UNEXPECTED at that token
- [x] the leftmost problem wins
