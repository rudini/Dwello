export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: Map<string, number>;
}

const ORDER_LINE = /^ORDER +([A-Za-z0-9-]+)( +!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/;

function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const seenIds = new Set<string>();
  let current: Order | null = null;

  // An empty order is reported at its ORDER line once the next ORDER line or
  // the end of the text shows that no item followed.
  const closeCurrent = () => {
    if (current && current.items.size === 0) {
      throw new OrderFormatError(current.line, `order ${current.id} has no items`);
    }
  };

  const lines = ordersText.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const lineNo = i + 1;
    const line = lines[i]!.trim();
    if (line === "" || line.startsWith("#")) continue;

    const orderMatch = ORDER_LINE.exec(line);
    if (orderMatch) {
      closeCurrent();
      const id = orderMatch[1]!;
      if (seenIds.has(id)) throw new OrderFormatError(lineNo, `duplicate order id ${id}`);
      seenIds.add(id);
      current = { id, priority: orderMatch[2] !== undefined, line: lineNo, items: new Map() };
      orders.push(current);
      continue;
    }

    const itemMatch = ITEM_LINE.exec(line);
    if (itemMatch) {
      if (!current) throw new OrderFormatError(lineNo, "item line before the first ORDER line");
      const sku = itemMatch[1]!;
      current.items.set(sku, (current.items.get(sku) ?? 0) + Number(itemMatch[2]));
      continue;
    }

    // A malformed line right after an ORDER line is reported itself rather than
    // as an empty order: it was evidently meant as that order's item.
    throw new OrderFormatError(lineNo, `unrecognized line: ${line}`);
  }
  closeCurrent();
  return orders;
}

function compareLots(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return a.expires < b.expires ? -1 : 1;
  }
  if (a.bin !== b.bin) return a.bin < b.bin ? -1 : 1;
  return 0;
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "", level = ""] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

function sortByWalk(picks: Pick[]): Pick[] {
  const parsed = picks.map((pick, index) => ({ pick, index, ...parseBin(pick.bin) }));
  const aisles = [...new Set(parsed.map((p) => p.aisle))].sort();
  const descending = new Set(aisles.filter((_, i) => i % 2 === 1));
  parsed.sort((a, b) => {
    if (a.aisle !== b.aisle) return a.aisle < b.aisle ? -1 : 1;
    if (a.rack !== b.rack) return descending.has(a.aisle) ? b.rack - a.rack : a.rack - b.rack;
    if (a.level !== b.level) return a.level - b.level;
    if (a.pick.bin !== b.pick.bin) return a.pick.bin < b.pick.bin ? -1 : 1;
    return a.index - b.index;
  });
  return parsed.map((p) => p.pick);
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);
  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];

  // Remaining quantities are tracked separately so the caller's stock stays untouched.
  const lotsBySku = new Map<string, { lot: StockLot; left: number }[]>();
  for (const lot of stock) {
    let lots = lotsBySku.get(lot.sku);
    if (!lots) lotsBySku.set(lot.sku, (lots = []));
    lots.push({ lot, left: lot.qty });
  }
  for (const lots of lotsBySku.values()) lots.sort((a, b) => compareLots(a.lot, b.lot));

  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  for (const order of served) {
    for (const [sku, qty] of order.items) {
      let needed = qty;
      for (const entry of lotsBySku.get(sku) ?? []) {
        if (needed === 0) break;
        if (entry.left <= 0) continue;
        const taken = Math.min(entry.left, needed);
        entry.left -= taken;
        needed -= taken;
        picks.push({ bin: entry.lot.bin, sku, qty: taken, orderId: order.id });
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku, missing: needed });
    }
  }

  return { picks: sortByWalk(picks), shortages };
}
