import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({ bin, sku, qty, expires });

function lineOf(text: string): number {
  try {
    buildPickList(text, []);
  } catch (e) {
    if (e instanceof OrderFormatError) return e.line;
    throw e;
  }
  throw new Error("no error");
}

test("example: FEFO allocation, priority first, shortages", () => {
  const text = "# export 2026-10-12 06:00\nORDER 1001\n  OLIVE-500 x3\n  PASTA-1KG x1\nORDER 1002 !\n  OLIVE-500 x2\n";
  const stock = [
    lot("B-01-1", "OLIVE-500", 2, "2027-01-01"),
    lot("A-02-1", "OLIVE-500", 1, "2026-11-01"),
    lot("A-05-1", "OLIVE-500", 10, null),
  ];
  const snapshot = JSON.parse(JSON.stringify(stock));
  const result = buildPickList(text, stock);
  expect(stock).toEqual(snapshot);
  expect(result.shortages).toEqual([{ orderId: "1001", sku: "PASTA-1KG", missing: 1 }]);
  expect(result.picks).toEqual([
    { bin: "A-02-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    { bin: "A-05-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "B-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    { bin: "B-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
  ]);
});

test("duplicate SKUs are summed; partial shortage", () => {
  const r = buildPickList("ORDER a\nX x2\nY x1\nX   x3", [lot("A-01-1", "X", 4), lot("A-01-2", "Y", 1)]);
  expect(r.shortages).toEqual([{ orderId: "a", sku: "X", missing: 1 }]);
  expect(r.picks.map((p) => [p.bin, p.qty])).toEqual([["A-01-1", 4], ["A-01-2", 1]]);
});

test("serpentine walk over aisles with picks", () => {
  const stock = ["A-01-2", "A-03-1", "C-01-1", "C-04-1", "C-04-2", "D-02-1", "D-01-1"].map((b, i) => lot(b, `S${i}`, 1));
  const text = "ORDER o\n" + stock.map((l) => `${l.sku} x1`).join("\n");
  const bins = buildPickList(text, stock).picks.map((p) => p.bin);
  expect(bins).toEqual(["A-01-2", "A-03-1", "C-04-1", "C-04-2", "C-01-1", "D-01-1", "D-02-1"]);
});

test("format errors report the first problem from the top", () => {
  expect(lineOf("\nX x1\nORDER 1\nX x1")).toBe(2);
  expect(lineOf("ORDER 1\nX x1\nORDER 1\nX x1")).toBe(3);
  expect(lineOf("ORDER 1\n# c\nORDER 2\nX x1")).toBe(1);
  expect(lineOf("ORDER 1\nX x1\nORDER 2")).toBe(3);
  expect(lineOf("ORDER 1\nORDER 1\nX x1")).toBe(1);
  expect(lineOf("ORDER 1\nX x0")).toBe(2);
  expect(lineOf("ORDER 1\nX x03")).toBe(2);
  expect(lineOf("ORDER 1\nx-a x3")).toBe(2);
  expect(lineOf("ORDER 1\nX 3")).toBe(2);
  expect(lineOf("ORDER 1!\nX 3")).toBe(1);
  expect(buildPickList("ORDER 1   !\nX x1", []).shortages).toEqual([{ orderId: "1", sku: "X", missing: 1 }]);
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});
