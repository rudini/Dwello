import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

function errorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (e) {
    expect(e).toBeInstanceOf(OrderFormatError);
    return (e as OrderFormatError).line;
  }
  return undefined;
}

test("example export: priority first, earliest expiry first", () => {
  const stock: StockLot[] = [
    { bin: "B-02-1", sku: "OLIVE-500", qty: 2, expires: null },
    { bin: "A-05-1", sku: "OLIVE-500", qty: 2, expires: "2026-11-01" },
    { bin: "A-01-3", sku: "OLIVE-500", qty: 2, expires: "2026-10-20" },
    { bin: "C-04-2", sku: "PASTA-1KG", qty: 5, expires: "2027-01-01" },
  ];
  const before = JSON.stringify(stock);
  const text = "# export\nORDER 1001\n  OLIVE-500 x3\n  PASTA-1KG x1\nORDER 1002 !\n  OLIVE-500 x2\n";
  const result = buildPickList(text, stock);
  expect(JSON.stringify(stock)).toBe(before);
  expect(result.picks).toEqual([
    { bin: "A-01-3", sku: "OLIVE-500", qty: 2, orderId: "1002" },
    { bin: "A-05-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    { bin: "C-04-2", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
  ]);
  expect(result.shortages).toEqual([]);
});

test("shortages, merged items and serpentine walk", () => {
  const stock: StockLot[] = [
    { bin: "B-01-1", sku: "X", qty: 1, expires: null },
    { bin: "B-09-2", sku: "Y", qty: 10, expires: null },
    { bin: "B-09-1", sku: "Z", qty: 10, expires: null },
    { bin: "D-01-1", sku: "W", qty: 10, expires: null },
    { bin: "D-03-1", sku: "V", qty: 10, expires: null },
  ];
  const text = "ORDER a\nX x2\nY x1\nX   x1\nZ x1\nW x1\nV x1\nQ x4";
  const result = buildPickList(text, stock);
  expect(result.picks.map((p) => p.bin)).toEqual(["B-01-1", "B-09-1", "B-09-2", "D-03-1", "D-01-1"]);
  expect(result.shortages).toEqual([
    { orderId: "a", sku: "X", missing: 2 },
    { orderId: "a", sku: "Q", missing: 4 },
  ]);
});

test("format errors report the topmost problem", () => {
  expect(errorLine("\nX x1\nORDER 1\nX x1")).toBe(2);
  expect(errorLine("ORDER 1\nX x1\nORDER 1\nX x1")).toBe(3);
  expect(errorLine("ORDER 1\n# c\nORDER 2\nbad")).toBe(1);
  expect(errorLine("ORDER 1\nX x0")).toBe(2);
  expect(errorLine("ORDER 1\nX x03")).toBe(2);
  expect(errorLine("ORDER 1\nx x3")).toBe(2);
  expect(errorLine("ORDER 1\nX 3")).toBe(2);
  expect(errorLine("ORDER 1!\nX x3")).toBe(1);
  expect(errorLine("ORDER 1   !\nX x3")).toBeUndefined();
});
