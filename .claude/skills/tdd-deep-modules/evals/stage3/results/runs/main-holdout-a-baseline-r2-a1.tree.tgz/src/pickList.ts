export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface ParsedOrder {
  id: string;
  line: number;
  priority: boolean;
  items: { sku: string; qty: number }[];
}

const ORDER_LINE = /^ORDER +([A-Za-z0-9-]+)( +!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/;

function parseOrders(text: string): ParsedOrder[] {
  const orders: ParsedOrder[] = [];
  const seen = new Set<string>();
  let current: ParsedOrder | null = null;

  // An empty order is only detectable once the next ORDER line (or the end)
  // is reached; its line still precedes anything found from there on.
  const finishOrder = () => {
    if (current && current.items.length === 0) {
      throw new OrderFormatError(current.line, `order "${current.id}" has no items`);
    }
  };

  const lines = text.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const lineNo = index + 1;
    const line = lines[index]!.trim();
    if (line === "" || line.startsWith("#")) continue;

    const order = ORDER_LINE.exec(line);
    if (order) {
      finishOrder();
      const id = order[1]!;
      if (seen.has(id)) throw new OrderFormatError(lineNo, `duplicate order id "${id}"`);
      seen.add(id);
      current = { id, line: lineNo, priority: order[2] !== undefined, items: [] };
      orders.push(current);
      continue;
    }

    const item = ITEM_LINE.exec(line);
    if (!item) throw new OrderFormatError(lineNo, `unrecognized line "${line}"`);
    if (!current) throw new OrderFormatError(lineNo, "item line before the first ORDER line");
    const sku = item[1]!;
    const qty = Number(item[2]);
    const existing = current.items.find((it) => it.sku === sku);
    if (existing) existing.qty += qty;
    else current.items.push({ sku, qty });
  }
  finishOrder();
  return orders;
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Earliest best-before first, undated lots last, then by bin code. */
function compareLots(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "", level = ""] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);
  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];

  // Track remaining quantities separately so the caller's stock is never touched.
  const lotsBySku = new Map<string, { lot: StockLot; left: number }[]>();
  for (const lot of stock) {
    let list = lotsBySku.get(lot.sku);
    if (!list) lotsBySku.set(lot.sku, (list = []));
    list.push({ lot, left: lot.qty });
  }
  for (const list of lotsBySku.values()) list.sort((a, b) => compareLots(a.lot, b.lot));

  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  for (const order of served) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const entry of lotsBySku.get(item.sku) ?? []) {
        if (needed === 0) break;
        if (entry.left <= 0) continue;
        const take = Math.min(needed, entry.left);
        entry.left -= take;
        needed -= take;
        picks.push({ bin: entry.lot.bin, sku: item.sku, qty: take, orderId: order.id });
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
    }
  }

  // Serpentine walk: every second visited aisle is walked with racks descending.
  const aisles = [...new Set(picks.map((p) => parseBin(p.bin).aisle))].sort(compareStrings);
  const descending = new Set(aisles.filter((_, i) => i % 2 === 1));
  const keyed = picks.map((pick, index) => ({ pick, index, ...parseBin(pick.bin) }));
  keyed.sort((a, b) => {
    if (a.aisle !== b.aisle) return compareStrings(a.aisle, b.aisle);
    if (a.rack !== b.rack) return descending.has(a.aisle) ? b.rack - a.rack : a.rack - b.rack;
    if (a.level !== b.level) return a.level - b.level;
    return a.index - b.index;
  });

  return { picks: keyed.map((k) => k.pick), shortages };
}
