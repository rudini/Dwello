export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

const REQUIRED_COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof REQUIRED_COLUMNS)[number];

/** Splits one CSV line into trimmed fields; quoted fields may contain commas and "" for a quote. */
function parseFields(line: string): string[] {
  const fields: string[] = [];
  let i = 0;
  for (;;) {
    let value = "";
    while (line[i] === " " || line[i] === "\t") i++;
    if (line[i] === '"') {
      i++;
      while (i < line.length) {
        if (line[i] !== '"') {
          value += line[i++];
        } else if (line[i + 1] === '"') {
          value += '"';
          i += 2;
        } else {
          i++;
          break;
        }
      }
    }
    // Unquoted text, or anything between a closing quote and the next comma, belongs to the value.
    while (i < line.length && line[i] !== ",") value += line[i++];
    fields.push(value.trim());
    if (i >= line.length) return fields;
    i++; // skip the comma
  }
}

function isValidDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1) return false;
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]!;
  return day <= daysInMonth;
}

/** Parses an amount like "12", "12.5" or "12.50" into cents, or null if it is not a valid positive amount. */
function parseAmountCents(text: string): bigint | null {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(text);
  if (!match) return null;
  const cents = BigInt(match[1]!) * 100n + BigInt((match[2] ?? "").padEnd(2, "0"));
  return cents > 0n ? cents : null;
}

/** Represents a finite number exactly as numerator / 10^scale, based on its shortest decimal form. */
function toDecimal(rate: number): { numerator: bigint; scale: number } {
  const match = /^(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/i.exec(String(rate));
  if (!match) throw new ExpenseFileError(`Invalid exchange rate: ${rate}`);
  const fraction = match[2] ?? "";
  let numerator = BigInt(match[1]! + fraction);
  let scale = fraction.length - Number(match[3] ?? 0);
  if (scale < 0) {
    numerator *= 10n ** BigInt(-scale);
    scale = 0;
  }
  return { numerator, scale };
}

/** amountCents * rate, rounded to the nearest cent with halves rounded up (exact, no float error). */
function convertCents(amountCents: bigint, rate: number): number {
  const { numerator, scale } = toDecimal(rate);
  const divisor = 10n ** BigInt(scale);
  return Number((2n * amountCents * numerator + divisor) / (2n * divisor));
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const withoutBom = csv.charCodeAt(0) === 0xfeff ? csv.slice(1) : csv;
  const physicalLines = withoutBom.split(/\r?\n/);

  const headerIndex = physicalLines.findIndex((line) => line.trim() !== "");
  if (headerIndex < 0) throw new ExpenseFileError("Missing header");
  const header = parseFields(physicalLines[headerIndex]!).map((name) => name.toLowerCase());
  const columnIndex = {} as Record<Column, number>;
  for (const column of REQUIRED_COLUMNS) {
    const index = header.indexOf(column);
    if (index < 0) throw new ExpenseFileError(`Missing column: ${column}`);
    columnIndex[column] = index;
  }

  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const seen = new Set<string>();
  const dailyTotals = new Map<string, number>();
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();

  for (let index = headerIndex + 1; index < physicalLines.length; index++) {
    const text = physicalLines[index]!;
    if (text.trim() === "") continue;
    const line = index + 1;
    const reject = (reason: string) => rejected.push({ line, reason });

    const fields = parseFields(text);
    if (fields.length !== header.length) {
      reject("wrong number of fields");
      continue;
    }
    const field = (column: Column) => fields[columnIndex[column]]!;
    const date = field("date");
    const employee = field("employee");
    const category = field("category");
    const currency = field("currency");
    const receipt = field("receipt").toLowerCase();

    if (!isValidDate(date)) {
      reject("invalid date");
      continue;
    }
    if (employee === "") {
      reject("missing employee");
      continue;
    }
    if (!Object.hasOwn(policy.categories, category)) {
      reject("unknown category");
      continue;
    }
    const amountCents = parseAmountCents(field("amount"));
    if (amountCents === null) {
      reject("invalid amount");
      continue;
    }
    if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) {
      reject("unknown currency");
      continue;
    }
    if (receipt !== "yes" && receipt !== "no") {
      reject("invalid receipt flag");
      continue;
    }

    const amountChfCents = currency === "CHF" ? Number(amountCents) : convertCents(amountCents, fxRates[currency]!);
    const categoryPolicy = policy.categories[category]!;
    const violations: Violation[] = [];

    const duplicateKey = JSON.stringify([employee, date, category, amountCents.toString(), currency]);
    if (seen.has(duplicateKey)) violations.push("DUPLICATE");
    seen.add(duplicateKey);

    if (categoryPolicy.perItemLimitCents !== undefined && amountChfCents > categoryPolicy.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }

    const dailyKey = JSON.stringify([employee, date, category]);
    const dailyTotal = (dailyTotals.get(dailyKey) ?? 0) + amountChfCents;
    dailyTotals.set(dailyKey, dailyTotal);
    if (categoryPolicy.dailyLimitCents !== undefined && dailyTotal > categoryPolicy.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }

    if (receipt === "no" && amountChfCents > policy.receiptRequiredAboveCents) violations.push("NO_RECEIPT");

    lines.push({ line, date, employee, category, amountChfCents, violations });
    const employeeTotals = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    if (violations.length === 0) employeeTotals.approvedCents += amountChfCents;
    else employeeTotals.flaggedCents += amountChfCents;
    totals.set(employee, employeeTotals);
  }

  // fromEntries creates own properties, so names like "__proto__" are safe keys.
  return { lines, rejected, totals: Object.fromEntries(totals) };
}
