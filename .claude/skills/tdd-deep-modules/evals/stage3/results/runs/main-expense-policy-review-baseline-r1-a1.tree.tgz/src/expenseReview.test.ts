import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type Policy } from "./expenseReview";

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

const policy: Policy = {
  categories: { meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 }, hotel: { perItemLimitCents: 25000 }, taxi: {} },
  receiptRequiredAboveCents: 2000,
};
const fx = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";

test("missing header and columns", () => {
  expect(() => reviewExpenses("", policy, fx)).toThrow(new ExpenseFileError("Missing header"));
  expect(() => reviewExpenses(" \r\n\n", policy, fx)).toThrow("Missing header");
  expect(() => reviewExpenses("date,amount,category\n", policy, fx)).toThrow("Missing column: employee");
});

test("header in any order, case-insensitive, extra columns, blank lines count", () => {
  const csv =
    '\n  Receipt , AMOUNT,note,currency,category,employee,date\r\n\r\n yes ,12.5,"a, ""b""",EUR,meals, Anna ,2026-02-28\r\n';
  const report = reviewExpenses(csv, policy, fx);
  expect(report.rejected).toEqual([]);
  expect(report.lines).toEqual([
    { line: 4, date: "2026-02-28", employee: "Anna", category: "meals", amountChfCents: 1177, violations: [] },
  ]);
  expect(report.totals).toEqual({ Anna: { approvedCents: 1177, flaggedCents: 0 } });
});

test("rejections in order", () => {
  const rows = [
    "2026-01-01,Anna,meals,10,CHF",
    "2026-02-29,Anna,meals,10,CHF,yes",
    "2024-02-29,,meals,10,CHF,yes",
    "2024-02-29,Anna,Meals,10,CHF,yes",
    "2024-02-29,Anna,meals,0.00,CHF,yes",
    "2024-02-29,Anna,meals,1.,CHF,yes",
    "2024-02-29,Anna,meals,1.5,GBP,yes",
    "2024-02-29,Anna,meals,1.5,chf,yes",
    "2024-02-29,Anna,toString,1.5,CHF,yes",
    "2024-02-29,Anna,meals,1.5,CHF,y",
  ];
  const report = reviewExpenses([HEADER, ...rows].join("\n"), policy, fx);
  expect(report.lines).toEqual([]);
  expect(report.totals).toEqual({});
  expect(report.rejected.map((r) => r.reason)).toEqual([
    "wrong number of fields",
    "invalid date",
    "missing employee",
    "unknown category",
    "invalid amount",
    "invalid amount",
    "unknown currency",
    "unknown currency",
    "unknown category",
    "invalid receipt flag",
  ]);
  expect(report.rejected[0]!.line).toBe(2);
});

test("rounding halves up exactly", () => {
  // 0.05 * 0.9 = 0.045 CHF = 4.5 cents, rounded up to 5
  const report = reviewExpenses(`${HEADER}\n2026-01-01,A,taxi,0.05,X,yes`, policy, { X: 0.9 });
  expect(report.lines[0]!.amountChfCents).toBe(5);
});

test("violations and totals", () => {
  const rows = [
    "2026-03-01,Anna,meals,30,CHF,yes",
    "2026-03-01,Anna,meals,30.00,CHF,no",
    "2026-03-01,Anna,meals,60,CHF,yes",
    "2026-03-01,Ben,meals,30,CHF,yes",
    "2026-03-01,Ben,meals,30,EUR,yes",
    "2026-03-01,Ben,hotel,10,CHF,no",
  ];
  const report = reviewExpenses([HEADER, ...rows].join("\n"), policy, fx);
  expect(report.lines.map((l) => l.violations)).toEqual([
    [],
    ["DUPLICATE", "NO_RECEIPT"],
    ["OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT"],
    [],
    [],
    [],
  ]);
  expect(report.totals).toEqual({
    Anna: { approvedCents: 3000, flaggedCents: 9000 },
    Ben: { approvedCents: 3000 + 2824 + 1000, flaggedCents: 0 },
  });
});
