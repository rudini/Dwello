export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface OrderItem {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  items: OrderItem[];
  line: number;
}

/**
 * Parses the orders text. Problems are collected rather than thrown right away: an empty
 * order is only noticed after the lines following it, but is reported at its earlier ORDER line.
 */
function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  const lines = ordersText.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const lineNumber = index + 1;
    const line = lines[index].trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = /^ORDER +([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (orderMatch) {
      const [, id, priorityMark] = orderMatch;
      if (orders.some((o) => o.id === id)) problems.push(new OrderFormatError(lineNumber, `duplicate order id ${id}`));
      orders.push({ id, priority: priorityMark !== undefined, items: [], line: lineNumber });
      continue;
    }
    const itemMatch = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNumber, `cannot read "${line}"`));
      continue;
    }
    const [, sku, qty] = itemMatch;
    if (orders.length === 0) {
      problems.push(new OrderFormatError(lineNumber, "item before the first ORDER"));
      continue;
    }
    const items = orders[orders.length - 1].items;
    const existing = items.find((i) => i.sku === sku);
    if (existing) existing.qty += Number(qty);
    else items.push({ sku, qty: Number(qty) });
  }
  for (const order of orders) {
    if (order.items.length === 0) problems.push(new OrderFormatError(order.line, `order ${order.id} has no items`));
  }
  if (problems.length > 0) throw problems.reduce((first, p) => (p.line < first.line ? p : first));
  return orders;
}

interface Lot {
  bin: string;
  sku: string;
  remaining: number;
  expires: string | null;
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Earliest best-before first, undated lots last, ties by bin code. */
function byExpiry(a: Lot, b: Lot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle, rack, level] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/** Sorts picks into the serpentine walk; picks at the same bin keep their order (stable sort). */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((p) => parseBin(p.bin).aisle))].sort(compareStrings);
  const rackDirection = new Map(aisles.map((aisle, i) => [aisle, i % 2 === 0 ? 1 : -1]));
  return [...picks].sort((a, b) => {
    const binA = parseBin(a.bin);
    const binB = parseBin(b.bin);
    if (binA.aisle !== binB.aisle) return compareStrings(binA.aisle, binB.aisle);
    if (binA.rack !== binB.rack) return (binA.rack - binB.rack) * rackDirection.get(binA.aisle)!;
    return binA.level - binB.level;
  });
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);
  // Working copies, so the caller's stock stays untouched.
  const lots: Lot[] = stock.map((l) => ({ bin: l.bin, sku: l.sku, remaining: l.qty, expires: l.expires }));
  lots.sort(byExpiry);
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let open = item.qty;
      for (const source of lots) {
        if (open === 0) break;
        if (source.sku !== item.sku || source.remaining <= 0) continue;
        const taken = Math.min(open, source.remaining);
        source.remaining -= taken;
        open -= taken;
        picks.push({ bin: source.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (open > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: open });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}
