import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

/*
 * Test list
 * [x] single order, single item, one lot covers it
 * [x] item taken from several lots, earliest expiry first
 * [x] null expiry lots come after dated lots; ties broken by bin
 * [x] stock consumed by earlier items/orders is not available later
 * [x] shortage when lots don't cover the item (partial pick + shortage)
 * [x] shortage when no lot exists for the sku
 * [x] priority orders are served first, in text order
 * [x] repeated sku in an order is summed, keeps first position
 * [x] comments, blank lines, surrounding whitespace ignored
 * [x] picks sorted in serpentine walking order
 * [x] picks at the same bin keep allocation order
 * [x] stock array and objects are not modified
 * [x] error: item line before first ORDER
 * [x] error: duplicate order id
 * [x] error: ORDER without items (at its ORDER line, also at end of text)
 * [x] error: malformed lines (x0, x03, lowercase sku, missing x, bad id)
 * [x] error: first problem from the top is reported (empty order detected late)
 * [x] ORDER ids with letters and dashes, priority mark after several spaces
 * [x] end to end: the example export from the spec
 */

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("single item is picked from the one lot that covers it", () => {
  const result = buildPickList("ORDER 1001\nOLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("an item takes from several lots, earliest best-before first", () => {
  const result = buildPickList("ORDER 1001\nOLIVE-500 x5", [
    lot("A-02-1", "OLIVE-500", 10, "2027-03-01"),
    lot("A-01-1", "OLIVE-500", 3, "2026-11-01"),
    lot("A-03-1", "PASTA-1KG", 9, "2026-10-13"),
  ]);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    { bin: "A-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("lots without best-before come last; equal dates are broken by bin code", () => {
  const result = buildPickList("ORDER 1001\nSALT x4", [
    lot("A-03-1", "SALT", 5, null),
    lot("A-02-1", "SALT", 2, "2027-01-01"),
    lot("A-01-1", "SALT", 1, "2027-01-01"),
  ]);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "1001" },
    { bin: "A-02-1", sku: "SALT", qty: 2, orderId: "1001" },
    { bin: "A-03-1", sku: "SALT", qty: 1, orderId: "1001" },
  ]);
});

test("stock taken by an earlier order is not available to a later one", () => {
  const result = buildPickList("ORDER 1001\nSALT x2\nORDER 1002\nSALT x2", [
    lot("A-01-1", "SALT", 3, "2027-01-01"),
    lot("A-02-1", "SALT", 5, "2027-06-01"),
  ]);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "1001" },
    { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "1002" },
    { bin: "A-02-1", sku: "SALT", qty: 1, orderId: "1002" },
  ]);
});

test("a shortage reports what is missing after picking everything available", () => {
  const result = buildPickList("ORDER 1001\nSALT x5\nPASTA-1KG x2", [
    lot("A-01-1", "SALT", 3),
    lot("A-02-1", "OLIVE-500", 3),
  ]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "SALT", qty: 3, orderId: "1001" }],
    shortages: [
      { orderId: "1001", sku: "SALT", missing: 2 },
      { orderId: "1001", sku: "PASTA-1KG", missing: 2 },
    ],
  });
});

test("priority orders are served first, in text order, then the others", () => {
  const text = ["ORDER 1001", "SALT x1", "ORDER 1002 !", "SALT x1", "ORDER 1003", "SALT x1", "ORDER 1004   !", "SALT x1"].join(
    "\n",
  );
  const result = buildPickList(text, [lot("A-01-1", "SALT", 1)]);
  expect(result.picks).toEqual([{ bin: "A-01-1", sku: "SALT", qty: 1, orderId: "1002" }]);
  expect(result.shortages.map((s) => s.orderId)).toEqual(["1004", "1001", "1003"]);
});

test("a repeated sku within an order is summed and keeps its first position", () => {
  const result = buildPickList("ORDER 1001\nSALT x2\nPASTA-1KG x1\nSALT x3", []);
  expect(result.shortages).toEqual([
    { orderId: "1001", sku: "SALT", missing: 5 },
    { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
  ]);
});

test("comments, blank lines and surrounding whitespace are ignored", () => {
  const text = "# export 2026-10-12 06:00\r\n\r\n  ORDER A-17  \r\n\t  # note\r\n  OLIVE-500   x3\r\n\n";
  expect(buildPickList(text, []).shortages).toEqual([{ orderId: "A-17", sku: "OLIVE-500", missing: 3 }]);
});

test("picks follow the serpentine walk: visited aisles alternate rack direction, levels ascend", () => {
  const bins = ["D-01-1", "B-02-1", "A-10-1", "D-07-1", "B-11-1", "A-02-2", "A-02-1", "B-02-3", "D-07-3"];
  const text = ["ORDER 1", ...bins.map((_, i) => `SKU-${i} x1`)].join("\n");
  const stock = bins.map((bin, i) => lot(bin, `SKU-${i}`, 1));
  // Aisle C has no picks, so D is the 3rd visited aisle and walks racks ascending again.
  expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual([
    "A-02-1",
    "A-02-2",
    "A-10-1",
    "B-11-1",
    "B-02-1",
    "B-02-3",
    "D-01-1",
    "D-07-1",
    "D-07-3",
  ]);
});

test("several picks at the same bin keep their allocation order", () => {
  const text = "ORDER 1001\nSALT x1\nORDER 1002 !\nSALT x3";
  const stock = [lot("A-02-1", "SALT", 10, "2027-06-01"), lot("A-01-1", "SALT", 1, "2027-01-01")];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "1002" },
    { bin: "A-02-1", sku: "SALT", qty: 2, orderId: "1002" },
    { bin: "A-02-1", sku: "SALT", qty: 1, orderId: "1001" },
  ]);
});

test("the stock array and its lots are not modified", () => {
  const stock = [lot("A-02-1", "SALT", 10, "2027-06-01"), lot("A-01-1", "SALT", 1, "2027-01-01")];
  const snapshot = structuredClone(stock);
  const firstLot = stock[0];
  buildPickList("ORDER 1001\nSALT x5", stock);
  expect(stock).toEqual(snapshot);
  expect(stock[0]).toBe(firstLot);
});

function formatErrorLine(text: string): number {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  throw new Error("expected an OrderFormatError");
}

test("an item line before the first ORDER is an error", () => {
  expect(formatErrorLine("# header\n\nSALT x1\nORDER 1001\nSALT x1")).toBe(3);
});

test("an ORDER whose id was already used is an error", () => {
  expect(formatErrorLine("ORDER 1001\nSALT x1\nORDER 1002\nSALT x1\nORDER 1001 !\nSALT x1")).toBe(5);
});

test("an ORDER without items is reported at its ORDER line", () => {
  expect(formatErrorLine("ORDER 1001\nSALT x1\nORDER 1002\n# nothing\n\nORDER 1003\nSALT x1")).toBe(3);
  expect(formatErrorLine("ORDER 1001\nSALT x1\nORDER 1002\n\n# trailing\n")).toBe(3);
});

test.each([
  "SALT x0",
  "SALT x03",
  "SALT x-1",
  "SALT x1.5",
  "salt x1",
  "SALT 1",
  "SALT X1",
  "SALTx1",
  "SALT x",
  "SALT x1 x2",
  "ORDER",
  "ORDER 10 01",
  "ORDER 10_01",
  "ORDER 1003!",
  "ORDER 1003 ! !",
  "order 1003",
])("a malformed line is an error: %p", (badLine) => {
  expect(formatErrorLine(`ORDER 1001\nSALT x1\n${badLine}\nPASTA x1`)).toBe(3);
});

test("the first problem from the top is reported, even if it is detected later", () => {
  expect(formatErrorLine("ORDER 1001\nsalt x1")).toBe(1);
  expect(formatErrorLine("ORDER 1001\nsalt x1\nSALT x1")).toBe(2);
  expect(formatErrorLine("ORDER 1001\nORDER 1001\nSALT x1")).toBe(1);
  expect(formatErrorLine("ORDER 1001\nSALT x1\nORDER 1002\nbad line\nORDER 1001\nSALT x1")).toBe(3);
  expect(formatErrorLine("SALT x1\nORDER 1001")).toBe(1);
});

test("the example export becomes a pick list", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const stock = [
    lot("B-04-1", "OLIVE-500", 2, "2027-02-01"),
    lot("A-07-2", "OLIVE-500", 1, "2026-12-01"),
    lot("B-09-3", "OLIVE-500", 10, null),
    lot("C-01-1", "PASTA-1KG", 0, "2026-11-01"),
  ];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-07-2", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-09-3", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "B-04-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-04-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "PASTA-1KG", missing: 1 }],
  });
});

test("ORDER ids may contain letters, digits and dashes", () => {
  expect(buildPickList("ORDER ab-12-Z !\nSALT x1", []).shortages).toEqual([
    { orderId: "ab-12-Z", sku: "SALT", missing: 1 },
  ]);
});
