import { beforeEach, describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOffice, type BoxOfficeErrorCode } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

const MINUTE = 60_000;

function expectCode(fn: () => unknown, code: BoxOfficeErrorCode) {
  try {
    fn();
  } catch (error) {
    expect(error).toBeInstanceOf(BoxOfficeError);
    expect((error as BoxOfficeError).code).toBe(code);
    return;
  }
  throw new Error(`expected ${code} to be thrown`);
}

describe("createBoxOffice", () => {
  let time: number;
  let office: BoxOffice;

  beforeEach(() => {
    time = 1_000_000;
    office = createBoxOffice({
      sections: [
        { id: "PARKETT", capacity: 10, priceCents: 4990 },
        { id: "BALKON", capacity: 3, priceCents: 2500 },
        { id: "CHEAP", capacity: 10, priceCents: 150 },
      ],
      holdMinutes: 15,
      maxTicketsPerCustomer: 6,
      now: () => time,
    });
  });

  describe("available", () => {
    test("starts at capacity", () => {
      expect(office.available("PARKETT")).toBe(10);
    });

    test("unknown section", () => {
      expectCode(() => office.available("X"), "UNKNOWN_SECTION");
    });
  });

  describe("hold", () => {
    test("creates holds with sequential ids and expiry", () => {
      const h1 = office.hold("alice", "PARKETT", 2);
      expect(h1).toEqual({ holdId: "H1", customerId: "alice", sectionId: "PARKETT", quantity: 2, expiresAt: time + 15 * MINUTE });
      expect(office.available("PARKETT")).toBe(8);
      expectCode(() => office.hold("bob", "BALKON", 4), "SOLD_OUT");
      const h2 = office.hold("bob", "BALKON", 3);
      expect(h2.holdId).toBe("H2");
      expect(office.available("BALKON")).toBe(0);
    });

    test("validation order", () => {
      expectCode(() => office.hold("a", "X", 0), "UNKNOWN_SECTION");
      expectCode(() => office.hold("a", "PARKETT", 0), "INVALID_QUANTITY");
      expectCode(() => office.hold("a", "PARKETT", 1.5), "INVALID_QUANTITY");
      expectCode(() => office.hold("a", "PARKETT", Number.NaN), "INVALID_QUANTITY");
      expectCode(() => office.hold("a", "BALKON", 7), "CUSTOMER_LIMIT");
      expectCode(() => office.hold("a", "BALKON", 4), "SOLD_OUT");
    });

    test("customer limit spans sections and orders", () => {
      office.hold("alice", "BALKON", 2);
      const h = office.hold("alice", "PARKETT", 3);
      office.confirm(h.holdId);
      expectCode(() => office.hold("alice", "PARKETT", 2), "CUSTOMER_LIMIT");
      expect(office.hold("alice", "PARKETT", 1).holdId).toBe("H3");
      expect(office.hold("bob", "PARKETT", 6).holdId).toBe("H4");
    });

    test("expired holds stop counting", () => {
      office.hold("alice", "BALKON", 3);
      time += 15 * MINUTE - 1;
      expect(office.available("BALKON")).toBe(0);
      time += 1;
      expect(office.available("BALKON")).toBe(3);
      expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
    });
  });

  describe("confirm", () => {
    test("creates an order and keeps tickets taken", () => {
      const h = office.hold("alice", "PARKETT", 2);
      const o = office.confirm(h.holdId);
      expect(o).toEqual({ orderId: "O1", customerId: "alice", sectionId: "PARKETT", quantity: 2, totalCents: 9980 });
      expect(office.available("PARKETT")).toBe(8);
      time += 60 * MINUTE;
      expect(office.available("PARKETT")).toBe(8);
      expectCode(() => office.confirm(h.holdId), "UNKNOWN_HOLD");
    });

    test("unknown, released and expired holds", () => {
      expectCode(() => office.confirm("H1"), "UNKNOWN_HOLD");
      const h1 = office.hold("alice", "PARKETT", 1);
      office.release(h1.holdId);
      expectCode(() => office.confirm(h1.holdId), "UNKNOWN_HOLD");
      const h2 = office.hold("alice", "PARKETT", 1);
      time += 15 * MINUTE;
      expectCode(() => office.confirm(h2.holdId), "HOLD_EXPIRED");
      expect(office.available("PARKETT")).toBe(10);
    });

    test("group discount and Rappen rounding", () => {
      // 4 * 4990 = 19960, -10% = 17964 -> 17965
      expect(office.confirm(office.hold("a", "PARKETT", 4).holdId).totalCents).toBe(17965);
      // 3 * 4990 = 14970, no discount
      expect(office.confirm(office.hold("b", "PARKETT", 3).holdId).totalCents).toBe(14970);
      // 5 * 150 = 750, -10% = 675
      expect(office.confirm(office.hold("c", "CHEAP", 5).holdId).totalCents).toBe(675);
    });

    test("rounding of exact halves goes up, also without discount", () => {
      const office2 = createBoxOffice({
        sections: [
          { id: "A", capacity: 100, priceCents: 1233 },
          { id: "B", capacity: 100, priceCents: 25 },
        ],
        holdMinutes: 15,
        maxTicketsPerCustomer: 100,
        now: () => time,
      });
      expect(office2.confirm(office2.hold("a", "A", 1).holdId).totalCents).toBe(1235);
      // 5 * 25 = 125, -10% = 112.5 -> 115 (112.5 is exactly halfway between 110 and 115)
      expect(office2.confirm(office2.hold("a", "B", 5).holdId).totalCents).toBe(115);
      // 4 * 1233 = 4932, -10% = 4438.8 -> 4440
      expect(office2.confirm(office2.hold("a", "A", 4).holdId).totalCents).toBe(4440);
    });
  });

  describe("release", () => {
    test("frees tickets", () => {
      const h = office.hold("alice", "BALKON", 3);
      office.release(h.holdId);
      expect(office.available("BALKON")).toBe(3);
      expectCode(() => office.release(h.holdId), "UNKNOWN_HOLD");
      expectCode(() => office.release("H99"), "UNKNOWN_HOLD");
    });

    test("confirmed hold cannot be released", () => {
      const h = office.hold("alice", "BALKON", 3);
      office.confirm(h.holdId);
      expectCode(() => office.release(h.holdId), "UNKNOWN_HOLD");
      expect(office.available("BALKON")).toBe(0);
    });

    test("expired hold release succeeds without effect", () => {
      const h = office.hold("alice", "BALKON", 3);
      time += 15 * MINUTE;
      office.release(h.holdId);
      expect(office.available("BALKON")).toBe(3);
    });
  });

  describe("cancelOrder", () => {
    test("refunds minus fee and frees tickets", () => {
      const o = office.confirm(office.hold("alice", "PARKETT", 6).holdId);
      expect(office.cancelOrder(o.orderId)).toBe(o.totalCents - 1200);
      expect(office.available("PARKETT")).toBe(10);
      expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
      expectCode(() => office.cancelOrder(o.orderId), "UNKNOWN_ORDER");
      expectCode(() => office.cancelOrder("O99"), "UNKNOWN_ORDER");
    });

    test("refund never negative", () => {
      const o = office.confirm(office.hold("alice", "CHEAP", 2).holdId);
      expect(o.totalCents).toBe(300);
      expect(office.cancelOrder(o.orderId)).toBe(0);
    });
  });
});
