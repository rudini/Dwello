export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const GROUP_DISCOUNT_MIN_TICKETS = 4;
const CANCELLATION_FEE_CENTS_PER_TICKET = 200;

type HoldState = "active" | "confirmed" | "released";

interface HoldRecord extends Hold {
  state: HoldState;
}

interface OrderRecord extends Order {
  cancelled: boolean;
}

/**
 * Applies the group discount and rounds to the nearest multiple of 5 cents
 * (exact halves round up). Works in tenths of a cent to stay in integers.
 */
function orderTotalCents(quantity: number, priceCents: number): number {
  const percent = quantity >= GROUP_DISCOUNT_MIN_TICKETS ? 90 : 100;
  const tenths = (quantity * priceCents * percent) / 10;
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const { holdMinutes, maxTicketsPerCustomer, now } = options;
  const sections = new Map<string, SectionConfig>();
  for (const section of options.sections) sections.set(section.id, { ...section });

  const holds = new Map<string, HoldRecord>();
  const orders = new Map<string, OrderRecord>();
  let holdCounter = 0;
  let orderCounter = 0;

  const isActive = (hold: HoldRecord, time: number) =>
    hold.state === "active" && time < hold.expiresAt;

  const requireSection = (sectionId: string): SectionConfig => {
    const section = sections.get(sectionId);
    if (!section) throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    return section;
  };

  /** Tickets in active holds plus non-cancelled orders matching the predicate. */
  const ticketsTaken = (
    matches: (entry: { customerId: string; sectionId: string }) => boolean,
    time: number,
  ): number => {
    let total = 0;
    for (const hold of holds.values()) if (isActive(hold, time) && matches(hold)) total += hold.quantity;
    for (const order of orders.values()) if (!order.cancelled && matches(order)) total += order.quantity;
    return total;
  };

  const availableAt = (section: SectionConfig, time: number) =>
    section.capacity - ticketsTaken((e) => e.sectionId === section.id, time);

  const toHold = ({ holdId, customerId, sectionId, quantity, expiresAt }: HoldRecord): Hold => ({
    holdId,
    customerId,
    sectionId,
    quantity,
    expiresAt,
  });

  const toOrder = ({ orderId, customerId, sectionId, quantity, totalCents }: OrderRecord): Order => ({
    orderId,
    customerId,
    sectionId,
    quantity,
    totalCents,
  });

  /** A hold that was neither confirmed nor released (it may still be expired). */
  const requireOpenHold = (holdId: string): HoldRecord => {
    const hold = holds.get(holdId);
    if (!hold || hold.state !== "active") throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    return hold;
  };

  return {
    hold(customerId, sectionId, quantity) {
      const section = requireSection(sectionId);
      if (typeof quantity !== "number" || !Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const time = now();
      const customerTickets = ticketsTaken((e) => e.customerId === customerId, time);
      if (customerTickets + quantity > maxTicketsPerCustomer) {
        throw new BoxOfficeError(
          "CUSTOMER_LIMIT",
          `Customer ${customerId} would exceed ${maxTicketsPerCustomer} tickets`,
        );
      }
      if (quantity > availableAt(section, time)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in section ${sectionId}`);
      }
      holdCounter += 1;
      const record: HoldRecord = {
        holdId: `H${holdCounter}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: time + holdMinutes * 60_000,
        state: "active",
      };
      holds.set(record.holdId, record);
      return toHold(record);
    },

    confirm(holdId) {
      const hold = requireOpenHold(holdId);
      if (now() >= hold.expiresAt) throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      const section = requireSection(hold.sectionId);
      orderCounter += 1;
      const order: OrderRecord = {
        orderId: `O${orderCounter}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: orderTotalCents(hold.quantity, section.priceCents),
        cancelled: false,
      };
      hold.state = "confirmed";
      orders.set(order.orderId, order);
      return toOrder(order);
    },

    release(holdId) {
      const hold = requireOpenHold(holdId);
      // Releasing an expired hold succeeds without effect.
      if (now() >= hold.expiresAt) return;
      hold.state = "released";
    },

    cancelOrder(orderId) {
      const order = orders.get(orderId);
      if (!order || order.cancelled) throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      order.cancelled = true;
      return Math.max(0, order.totalCents - CANCELLATION_FEE_CENTS_PER_TICKET * order.quantity);
    },

    available(sectionId) {
      return availableAt(requireSection(sectionId), now());
    },
  };
}
