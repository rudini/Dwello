export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const MS_PER_MINUTE = 60_000;
const GROUP_DISCOUNT_MIN_TICKETS = 4;
const CANCELLATION_FEE_CENTS_PER_TICKET = 200;

interface HoldRecord extends Hold {
  ended: boolean;
}

interface OrderRecord extends Order {
  cancelled: boolean;
}

/**
 * Computes quantity * price, minus 10 % for groups, rounded to the nearest
 * multiple of 5 cents (halves round up). Works in tenths of a cent so the
 * discount stays exact for integer prices.
 */
function orderTotalCents(quantity: number, priceCents: number): number {
  const amount = quantity * priceCents;
  const tenths = quantity >= GROUP_DISCOUNT_MIN_TICKETS ? amount * 9 : amount * 10;
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const sections = new Map(options.sections.map((s) => [s.id, s]));
  const holds = new Map<string, HoldRecord>();
  const orders = new Map<string, OrderRecord>();
  let nextHoldNumber = 1;
  let nextOrderNumber = 1;

  const isActive = (h: HoldRecord, now: number) => !h.ended && now < h.expiresAt;

  function getSection(sectionId: string): SectionConfig {
    const section = sections.get(sectionId);
    if (!section) {
      throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    }
    return section;
  }

  /** Tickets in active holds plus non-cancelled orders that match the filter. */
  function taken(matches: (r: Hold | Order) => boolean, now: number): number {
    let total = 0;
    for (const h of holds.values()) {
      if (isActive(h, now) && matches(h)) total += h.quantity;
    }
    for (const o of orders.values()) {
      if (!o.cancelled && matches(o)) total += o.quantity;
    }
    return total;
  }

  function availableAt(section: SectionConfig, now: number): number {
    return section.capacity - taken((r) => r.sectionId === section.id, now);
  }

  function getOpenHold(holdId: string): HoldRecord {
    const h = holds.get(holdId);
    if (!h || h.ended) {
      throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    }
    return h;
  }

  return {
    hold(customerId, sectionId, quantity) {
      const section = getSection(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const now = options.now();
      const customerTickets = taken((r) => r.customerId === customerId, now);
      if (customerTickets + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError(
          "CUSTOMER_LIMIT",
          `Customer ${customerId} may have at most ${options.maxTicketsPerCustomer} tickets`,
        );
      }
      if (quantity > availableAt(section, now)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in section ${sectionId}`);
      }
      const hold: Hold = {
        holdId: `H${nextHoldNumber++}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: now + options.holdMinutes * MS_PER_MINUTE,
      };
      holds.set(hold.holdId, { ...hold, ended: false });
      return hold;
    },

    confirm(holdId) {
      const h = getOpenHold(holdId);
      if (options.now() >= h.expiresAt) {
        throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      }
      h.ended = true;
      const order: Order = {
        orderId: `O${nextOrderNumber++}`,
        customerId: h.customerId,
        sectionId: h.sectionId,
        quantity: h.quantity,
        totalCents: orderTotalCents(h.quantity, getSection(h.sectionId).priceCents),
      };
      orders.set(order.orderId, { ...order, cancelled: false });
      return order;
    },

    release(holdId) {
      const h = getOpenHold(holdId);
      if (options.now() >= h.expiresAt) return;
      h.ended = true;
    },

    cancelOrder(orderId) {
      const o = orders.get(orderId);
      if (!o || o.cancelled) {
        throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      }
      o.cancelled = true;
      return Math.max(0, o.totalCents - o.quantity * CANCELLATION_FEE_CENTS_PER_TICKET);
    },

    available(sectionId) {
      return availableAt(getSection(sectionId), options.now());
    },
  };
}
