import { describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOfficeErrorCode } from "./boxOffice";

function setup() {
  let time = 1_000_000;
  const office = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 4990 },
      { id: "BALKON", capacity: 3, priceCents: 2500 },
      { id: "CHEAP", capacity: 10, priceCents: 150 },
    ],
    holdMinutes: 10,
    maxTicketsPerCustomer: 6,
    now: () => time,
  });
  return { office, advance: (ms: number) => (time += ms), now: () => time };
}

function expectCode(fn: () => unknown, code: BoxOfficeErrorCode) {
  let caught: unknown;
  try {
    fn();
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(BoxOfficeError);
  expect((caught as BoxOfficeError).code).toBe(code);
}

describe("hold", () => {
  test("creates sequential holds and reduces availability", () => {
    const { office, now } = setup();
    const h = office.hold("alice", "PARKETT", 2);
    expect(h).toEqual({
      holdId: "H1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 2,
      expiresAt: now() + 600_000,
    });
    expectCode(() => office.hold("bob", "BALKON", 4), "SOLD_OUT");
    expect(office.hold("bob", "BALKON", 3).holdId).toBe("H2");
    expect(office.available("PARKETT")).toBe(8);
    expect(office.available("BALKON")).toBe(0);
  });

  test("validates in the specified order", () => {
    const { office } = setup();
    expectCode(() => office.hold("a", "NOPE", 0), "UNKNOWN_SECTION");
    expectCode(() => office.hold("a", "PARKETT", 0), "INVALID_QUANTITY");
    expectCode(() => office.hold("a", "PARKETT", 1.5), "INVALID_QUANTITY");
    expectCode(() => office.hold("a", "BALKON", 7), "CUSTOMER_LIMIT");
    expectCode(() => office.available("NOPE"), "UNKNOWN_SECTION");
  });

  test("customer limit spans sections and orders", () => {
    const { office } = setup();
    office.confirm(office.hold("a", "PARKETT", 3).holdId);
    office.hold("a", "BALKON", 2);
    expectCode(() => office.hold("a", "PARKETT", 2), "CUSTOMER_LIMIT");
    expect(office.hold("a", "PARKETT", 1).holdId).toBe("H3");
  });

  test("expired holds stop counting at expiresAt", () => {
    const { office, advance } = setup();
    office.hold("a", "BALKON", 3);
    advance(600_000 - 1);
    expect(office.available("BALKON")).toBe(0);
    advance(1);
    expect(office.available("BALKON")).toBe(3);
    expect(office.hold("a", "BALKON", 3).holdId).toBe("H2");
  });
});

describe("confirm / release", () => {
  test("confirm creates an order and keeps tickets taken", () => {
    const { office } = setup();
    const h = office.hold("a", "BALKON", 2);
    const o = office.confirm(h.holdId);
    expect(o).toEqual({ orderId: "O1", customerId: "a", sectionId: "BALKON", quantity: 2, totalCents: 5000 });
    expect(office.available("BALKON")).toBe(1);
    expectCode(() => office.confirm(h.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.release(h.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.confirm("H99"), "UNKNOWN_HOLD");
  });

  test("expired hold cannot be confirmed; releasing it is a no-op", () => {
    const { office, advance } = setup();
    const h = office.hold("a", "BALKON", 2);
    advance(600_000);
    expectCode(() => office.confirm(h.holdId), "HOLD_EXPIRED");
    office.release(h.holdId);
    expect(office.available("BALKON")).toBe(3);
  });

  test("release frees tickets", () => {
    const { office } = setup();
    const h = office.hold("a", "BALKON", 3);
    office.release(h.holdId);
    expect(office.available("BALKON")).toBe(3);
    expectCode(() => office.release(h.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.confirm(h.holdId), "UNKNOWN_HOLD");
  });
});

describe("pricing and cancellation", () => {
  test("group discount and Rappen rounding", () => {
    const { office } = setup();
    // 4 * 4990 = 19960, -10 % = 17964 -> 17965
    expect(office.confirm(office.hold("a", "PARKETT", 4).holdId).totalCents).toBe(17965);
    // 3 * 4990 = 14970, no discount
    expect(office.confirm(office.hold("b", "PARKETT", 3).holdId).totalCents).toBe(14970);
  });

  test("rounds without discount and rounds exact halves up", () => {
    const office = createBoxOffice({
      sections: [
        { id: "S", capacity: 100, priceCents: 1001 },
        { id: "T", capacity: 100, priceCents: 5 },
      ],
      holdMinutes: 5,
      maxTicketsPerCustomer: 100,
      now: () => 0,
    });
    expect(office.confirm(office.hold("a", "S", 1).holdId).totalCents).toBe(1000);
    expect(office.confirm(office.hold("a", "S", 3).holdId).totalCents).toBe(3005);
    // 5 * 5 = 25, -10 % = 22.5 -> 25
    expect(office.confirm(office.hold("a", "T", 5).holdId).totalCents).toBe(25);
  });

  test("cancel refunds total minus fee and frees tickets", () => {
    const { office } = setup();
    const o = office.confirm(office.hold("a", "BALKON", 2).holdId);
    expect(office.cancelOrder(o.orderId)).toBe(4600);
    expect(office.available("BALKON")).toBe(3);
    expectCode(() => office.cancelOrder(o.orderId), "UNKNOWN_ORDER");
    expectCode(() => office.cancelOrder("O9"), "UNKNOWN_ORDER");
    const cheap = office.confirm(office.hold("a", "CHEAP", 6).holdId);
    expect(office.cancelOrder(cheap.orderId)).toBe(0);
  });
});
