export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Card {
  /** Index of the card's column in board order. */
  position: number;
  /** When the card first left the first column. */
  started?: number;
  /** When the card most recently arrived in the last column. */
  finished?: number;
  /** When the current block began; undefined while unblocked. */
  blockedSince?: number;
  /** Closed blocked periods as [from, to]. */
  blockedPeriods: [number, number][];
}

export function createBoard(options: BoardOptions): Board {
  // Column contents by board position, in arrival order.
  const lists: string[][] = options.columns.map(() => []);
  const last = lists.length - 1;
  const cards = new Map<string, Card>();

  function cardOf(cardId: string): Card {
    const card = cards.get(cardId);
    if (card === undefined) throw new BoardError("UNKNOWN_CARD", `No card ${cardId}`);
    return card;
  }

  function positionOfColumn(column: string): number {
    const position = options.columns.findIndex((c) => c.name === column);
    if (position < 0) throw new BoardError("UNKNOWN_COLUMN", `No column ${column}`);
    return position;
  }

  function setBlocked(cardId: string, blocked: boolean): void {
    const card = cardOf(cardId);
    if (blocked === (card.blockedSince !== undefined)) {
      throw blocked
        ? new BoardError("ALREADY_BLOCKED", `${cardId} is already blocked`)
        : new BoardError("NOT_BLOCKED", `${cardId} is not blocked`);
    }
    if (blocked) {
      card.blockedSince = options.now();
    } else {
      card.blockedPeriods.push([card.blockedSince!, options.now()]);
      card.blockedSince = undefined;
    }
  }

  function isFull(position: number): boolean {
    const limit = options.columns[position].wipLimit;
    return limit !== undefined && lists[position].length >= limit;
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Title is empty");
      if (isFull(0)) throw new BoardError("WIP_LIMIT", "First column is full");
      const id = `C${cards.size + 1}`;
      cards.set(id, { position: 0, blockedPeriods: [] });
      lists[0].push(id);
      return id;
    },
    move(cardId, toColumn) {
      const card = cardOf(cardId);
      const from = card.position;
      const to = positionOfColumn(toColumn);
      if (to === from) throw new BoardError("SAME_COLUMN", `${cardId} is already in ${toColumn}`);
      if (card.blockedSince !== undefined) throw new BoardError("BLOCKED", `${cardId} is blocked`);
      if (to > from + 1) throw new BoardError("SKIP_NOT_ALLOWED", `${cardId} cannot skip columns`);
      if (isFull(to)) throw new BoardError("WIP_LIMIT", `${toColumn} is full`);
      lists[from].splice(lists[from].indexOf(cardId), 1);
      lists[to].push(cardId);
      card.position = to;
      if (from === 0) card.started ??= options.now();
      if (to === last) card.finished = options.now();
    },
    block(cardId) {
      setBlocked(cardId, true);
    },
    unblock(cardId) {
      setBlocked(cardId, false);
    },
    cardsIn(column) {
      return [...lists[positionOfColumn(column)]];
    },
    cycleTime(cardId) {
      const card = cardOf(cardId);
      if (card.position !== last) return null;
      // A card in the last column has left the first one, so both moments are set.
      const start = card.started!;
      const finish = card.finished!;
      const periods = [...card.blockedPeriods];
      if (card.blockedSince !== undefined) periods.push([card.blockedSince, finish]);
      let blockedMs = 0;
      for (const [from, to] of periods) blockedMs += Math.max(0, Math.min(to, finish) - Math.max(from, start));
      return { totalMs: finish - start, blockedMs };
    },
  };
}
