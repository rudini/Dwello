import { expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode, type ColumnConfig } from "./board";

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

const FOUR_COLUMNS: ColumnConfig[] = [{ name: "Backlog" }, { name: "Doing" }, { name: "Review" }, { name: "Done" }];

function setup(columns: ColumnConfig[] = FOUR_COLUMNS) {
  const clock = { t: 1_000 };
  const board = createBoard({ columns, now: () => clock.t });
  return { board, clock };
}

function codeOf(action: () => unknown): BoardErrorCode | "no error" | "other error" {
  try {
    action();
  } catch (error) {
    return error instanceof BoardError ? error.code : "other error";
  }
  return "no error";
}

test("addCard returns C1 and the card is listed in the first column", () => {
  expect(() => setup()).not.toThrow();
  const { board } = setup();
  expect(board.addCard("Fix login")).toBe("C1");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("a blank title is rejected with EMPTY_TITLE and does not use up an id", () => {
  const { board } = setup();
  expect(codeOf(() => board.addCard("   "))).toBe("EMPTY_TITLE");
  expect(board.addCard("Fix login")).toBe("C1");
  expect(board.addCard("Write docs")).toBe("C2");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("adding to a full first column is rejected with WIP_LIMIT", () => {
  const { board } = setup([{ name: "Backlog", wipLimit: 2 }, { name: "Done" }]);
  board.addCard("a");
  board.addCard("b");
  expect(codeOf(() => board.addCard("c"))).toBe("WIP_LIMIT");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("move puts the card at the end of the next column", () => {
  const { board } = setup();
  board.addCard("a");
  board.addCard("b");
  board.addCard("c");
  board.move("C2", "Doing");
  board.move("C1", "Doing");
  expect(board.cardsIn("Backlog")).toEqual(["C3"]);
  expect(board.cardsIn("Doing")).toEqual(["C2", "C1"]);
});

test("move of an unknown card is rejected with UNKNOWN_CARD", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.move("C9", "Doing"))).toBe("UNKNOWN_CARD");
  expect(codeOf(() => board.move("C9", "Nowhere"))).toBe("UNKNOWN_CARD");
  expect(board.cardsIn("Doing")).toEqual([]);
});

test("move to an unknown column is rejected with UNKNOWN_COLUMN", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.move("C1", "Nowhere"))).toBe("UNKNOWN_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("move to the card's own column is rejected with SAME_COLUMN", () => {
  const { board } = setup();
  board.addCard("a");
  board.addCard("b");
  expect(codeOf(() => board.move("C1", "Backlog"))).toBe("SAME_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("move of a blocked card is rejected with BLOCKED until it is unblocked", () => {
  const { board } = setup();
  board.addCard("a");
  board.block("C1", "waiting for customer");
  expect(codeOf(() => board.move("C1", "Doing"))).toBe("BLOCKED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  board.unblock("C1");
  board.move("C1", "Doing");
  expect(board.cardsIn("Doing")).toEqual(["C1"]);
});

test("move forward by two columns is rejected with SKIP_NOT_ALLOWED", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.move("C1", "Review"))).toBe("SKIP_NOT_ALLOWED");
  expect(codeOf(() => board.move("C1", "Done"))).toBe("SKIP_NOT_ALLOWED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  expect(board.cardsIn("Review")).toEqual([]);
});

test("move backwards by several columns is allowed", () => {
  const { board } = setup();
  board.addCard("a");
  board.addCard("b");
  board.move("C1", "Doing");
  board.move("C1", "Review");
  expect(codeOf(() => board.move("C1", "Backlog"))).toBe("no error");
  expect(board.cardsIn("Backlog")).toEqual(["C2", "C1"]);
  expect(board.cardsIn("Review")).toEqual([]);
});

test("move into a full column is rejected with WIP_LIMIT, counting blocked cards", () => {
  const { board } = setup([{ name: "Backlog" }, { name: "Doing", wipLimit: 1 }, { name: "Review", wipLimit: 1 }, { name: "Done" }]);
  board.addCard("a");
  board.addCard("b");
  board.move("C1", "Doing");
  board.move("C1", "Review");
  board.block("C1", "needs a second reviewer");
  board.move("C2", "Doing");
  expect(codeOf(() => board.move("C2", "Review"))).toBe("WIP_LIMIT");
  expect(board.cardsIn("Doing")).toEqual(["C2"]);
  expect(board.cardsIn("Review")).toEqual(["C1"]);
});

test("unknown cards and columns are rejected by block, unblock and cardsIn", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.block("C9", "why"))).toBe("UNKNOWN_CARD");
  expect(codeOf(() => board.unblock("C9"))).toBe("UNKNOWN_CARD");
  expect(codeOf(() => board.cardsIn("Nowhere"))).toBe("UNKNOWN_COLUMN");
  expect(codeOf(() => board.move("C9", "Doing"))).toBe("UNKNOWN_CARD");
});

test("blocking twice is ALREADY_BLOCKED and unblocking an unblocked card is NOT_BLOCKED", () => {
  const { board } = setup();
  board.addCard("a");
  expect(codeOf(() => board.unblock("C1"))).toBe("NOT_BLOCKED");
  board.block("C1", "waiting");
  expect(codeOf(() => board.block("C1", "still waiting"))).toBe("ALREADY_BLOCKED");
  board.unblock("C1");
  expect(codeOf(() => board.unblock("C1"))).toBe("NOT_BLOCKED");
});

test("cycleTime of an unknown card is rejected with UNKNOWN_CARD", () => {
  const { board } = setup();
  expect(codeOf(() => board.cycleTime("C1"))).toBe("UNKNOWN_CARD");
});

test("cycleTime runs from first leaving the first column to arriving in the last, null before that", () => {
  const { board, clock } = setup();
  board.addCard("a");
  expect(board.cycleTime("C1")).toBeNull();
  clock.t = 2_000;
  board.move("C1", "Doing");
  clock.t = 5_000;
  board.move("C1", "Review");
  expect(board.cycleTime("C1")).toBeNull();
  clock.t = 9_000;
  board.move("C1", "Done");
  clock.t = 20_000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 0 });
});

test("cycleTime keeps the first start and uses the most recent arrival in the last column", () => {
  const { board, clock } = setup();
  board.addCard("a");
  const at = (t: number, column: string) => {
    clock.t = t;
    board.move("C1", column);
  };
  at(2_000, "Doing");
  at(3_000, "Backlog");
  at(4_000, "Doing");
  at(5_000, "Review");
  at(6_000, "Done");
  at(7_000, "Review");
  expect(board.cycleTime("C1")).toBeNull();
  at(8_000, "Done");
  expect(board.cycleTime("C1")).toEqual({ totalMs: 6_000, blockedMs: 0 });
});

test("blockedMs adds up the blocked periods between start and finish", () => {
  const { board, clock } = setup();
  board.addCard("a");
  const at = (t: number, action: () => void) => {
    clock.t = t;
    action();
  };
  at(2_000, () => board.move("C1", "Doing"));
  at(3_000, () => board.block("C1", "waiting for customer"));
  at(4_500, () => board.unblock("C1"));
  at(5_000, () => board.move("C1", "Review"));
  at(6_000, () => board.block("C1", "reviewer away"));
  at(6_500, () => board.unblock("C1"));
  at(9_000, () => board.move("C1", "Done"));
  expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 2_000 });
});

test("blockedMs leaves out blocked time before start and after finish", () => {
  const { board, clock } = setup();
  board.addCard("a");
  const at = (t: number, action: () => void) => {
    clock.t = t;
    action();
  };
  at(1_500, () => board.block("C1", "unclear request"));
  at(1_800, () => board.unblock("C1"));
  at(2_000, () => board.move("C1", "Doing"));
  at(3_000, () => board.move("C1", "Review"));
  at(4_000, () => board.move("C1", "Done"));
  at(5_000, () => board.block("C1", "customer reopened"));
  clock.t = 6_000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 2_000, blockedMs: 0 });
  at(7_000, () => board.unblock("C1"));
  expect(board.cycleTime("C1")).toEqual({ totalMs: 2_000, blockedMs: 0 });
});
