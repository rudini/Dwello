# Board: design note

**Hidden decision:** how card positions and the history of moves and blocks are stored, and how start, finish and blocked time come out of that history. Callers only see card ids, column names and `CycleTime`.

## Both designs

- **A: stateful board object** (the given interface): `const board = createBoard({ columns, now }); board.move(id, "Doing"); board.cycleTime(id)`.
- **B: event log plus pure projections**: `log = apply(log, columns, { type: "move", cardId, to, at })`, `cycleTime(log, columns, cardId)`.

Chosen: A, because callers never learn how history is stored or when the clock is read. B would make every caller pass around the log, the column config and the time.

## Interface

- `createBoard({ columns, now })`: columns in board order; `now()` is read at every add, move, block and unblock.
- `addCard(title)`: returns `C1`, `C2`, ... in success order; `EMPTY_TITLE`, `WIP_LIMIT`.
- `move(cardId, toColumn)`: checks in this order: `UNKNOWN_CARD`, `UNKNOWN_COLUMN`, `SAME_COLUMN`, `BLOCKED`, `SKIP_NOT_ALLOWED`, `WIP_LIMIT`. The card goes to the end of the target column.
- `block` / `unblock`: `UNKNOWN_CARD`, `ALREADY_BLOCKED` / `NOT_BLOCKED`.
- `cardsIn(column)`: a copy of the ids in arrival order; `UNKNOWN_COLUMN`.
- `cycleTime(cardId)`: `null` unless the card is in the last column. Otherwise `totalMs` = most recent arrival in the last column minus first departure from the first column, and `blockedMs` = blocked time clipped to that interval (a block still open counts up to the finish).

Every failure throws before any state changes, so a failed call leaves the board unchanged.

## Depth

`depth_report src/board.ts`: `surface 10, size 122, ratio 12.2, classitis no, pass-through 0, tests 1, unused 0, duplicate 2 -> deep`.

Refactors: (1) column lists by index plus `cardOf` / `positionOfColumn` lookups that throw the unknown-id errors, so every method checks the same way; (2) per-card state (position, started, finished, open block, closed blocked periods) moved into one private `Card` record, and block/unblock share one `setBlocked` toggle. That fixed the duplicate lines `depth_report` flagged.

## Open points

- The check order of `move` follows the order of the guards in the code. Each check has its own test, but not every pair of checks is tested together (for example a skip into a full column).
- Blocking a card in the last column, moving it back and finishing again counts that blocked time, because it falls between start and the new finish. This follows from the clipping rule and has no test of its own.
- The block `reason` is accepted but not stored; the interface has no way to read it.

## Proof

`scripts/tdd_replay 3095eaf..HEAD` printed `REPLAY: ACCEPT`. It proves the phase order, test counts and exit codes, not how strong the assertions are.
