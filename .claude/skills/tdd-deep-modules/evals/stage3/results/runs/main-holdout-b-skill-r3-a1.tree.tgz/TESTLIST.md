# Team board: test list

**Hidden decision:** how card positions and the timeline of moves and blocks are recorded, and how start, finish and blocked time are derived from that timeline. Callers only see ids, column names and `CycleTime`.

**Sketch A: stateful board object** (the given interface)

```ts
const board = createBoard({ columns, now });
const id = board.addCard("Fix login");
board.move(id, "Doing");
board.cycleTime(id); // { totalMs, blockedMs } | null
```

**Sketch B: event log plus pure projections**

```ts
let log: BoardEvent[] = [];
log = apply(log, columns, { type: "move", cardId, to: "Doing", at: Date.now() }); // throws BoardError
cycleTime(log, columns, cardId);
```

Comparison: B leaks the event format and makes every caller thread the log, the column config and the time through every call. A hides both the log and the clock (`now` given once).

Chosen: Sketch A, because callers never learn how history is recorded or when the clock is read; one object, six calls.

All tests go through `createBoard` in `src/board.test.ts`.

## Behaviours

- [x] addCard returns "C1" and the card is listed in the first column
- [x] a blank title is rejected with EMPTY_TITLE and does not use up an id (also: ids count up, arrival order)
- [x] adding to a full first column is rejected with WIP_LIMIT
- [x] move puts the card at the end of the next column
- [x] move of an unknown card: UNKNOWN_CARD
- [x] move to an unknown column: UNKNOWN_COLUMN
- [x] move to the card's own column: SAME_COLUMN
- [x] move of a blocked card: BLOCKED; after unblock it moves
- [x] move forward by two columns: SKIP_NOT_ALLOWED, board unchanged
- [x] move backwards by several columns is allowed
- [x] move into a full column: WIP_LIMIT; blocked cards count
- [x] block / unblock / cardsIn reject unknown cards and columns
- [x] blocking twice: ALREADY_BLOCKED; unblocking an unblocked card: NOT_BLOCKED
- [x] cycleTime of an unknown card: UNKNOWN_CARD
- [x] totalMs runs from first leaving the first column to arriving in the last; null before that
- [x] going back to the first column does not change the start; finish is the most recent arrival
- [x] blockedMs counts blocked time between start and finish
- [x] blocked time before start and after finish is not counted

Folded into the tests above because they would have passed without a red of their
own: ids counting up, cardsIn of an unknown column, null outside the last column,
finish at the most recent arrival. Dropped: one test per pair of move checks
(for example skip into a full column); the order is the order of the checks in
`move` and is listed as an open point in DESIGN.md.
