import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours, type OpeningHoursErrorCode } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

const closed = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };

function expectError(text: string, code: OpeningHoursErrorCode, column: number) {
  let caught: unknown;
  try {
    parseOpeningHours(text);
  } catch (error) {
    caught = error;
  }
  expect(caught).toBeInstanceOf(OpeningHoursError);
  const error = caught as OpeningHoursError;
  expect({ code: error.code, column: error.column }).toEqual({ code, column });
}

test("parses the example", () => {
  const am = { from: "08:00", to: "12:00" };
  const pm = { from: "13:30", to: "18:30" };
  expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
    Mo: [am, pm],
    Tu: [am, pm],
    We: [am, pm],
    Th: [am, pm],
    Fr: [am, pm],
    Sa: [{ from: "09:00", to: "16:00" }],
    Su: [],
  });
});

test("day ranges wrap around and single-day ranges work", () => {
  const r = [{ from: "10:00", to: "11:00" }];
  expect(parseOpeningHours("Fr-Mo 10:00-11:00")).toEqual({ ...closed, Fr: r, Sa: r, Su: r, Mo: r });
  expect(parseOpeningHours("Mo-Mo 10:00-11:00")).toEqual({ ...closed, Mo: r });
});

test("spaces are insignificant, ranges are sorted, touching is allowed, 24:00 ends a range", () => {
  const r = [
    { from: "08:00", to: "12:00" },
    { from: "12:00", to: "24:00" },
  ];
  expect(parseOpeningHours("  Mo , We 12:00 - 24:00 ,08:00-12:00  ")).toEqual({ ...closed, Mo: r, We: r });
});

test("later rules replace earlier ones", () => {
  expect(parseOpeningHours("Mo-Su 08:00-20:00; Su off").Su).toEqual([]);
  const result = parseOpeningHours("Mo-Fr 08:00-12:00; We 14:00-18:00");
  expect(result.We).toEqual([{ from: "14:00", to: "18:00" }]);
  expect(result.Tu).toEqual([{ from: "08:00", to: "12:00" }]);
  expect(result.Sa).toEqual([]);
});

test("each day gets its own array", () => {
  const result = parseOpeningHours("Mo,Tu 08:00-12:00");
  expect(result.Mo).not.toBe(result.Tu);
  expect(result.Mo[0]).not.toBe(result.Tu[0]);
});

test.each<[string, OpeningHoursErrorCode, number]>([
  ["", "EMPTY", 1],
  ["   ", "EMPTY", 1],
  ["Mo-Fx 08:00-12:00", "UNKNOWN_DAY", 4],
  ["mo off", "UNKNOWN_DAY", 1],
  ["off", "UNKNOWN_DAY", 1],
  ["Mo off; Mon 08:00-09:00", "UNKNOWN_DAY", 9],
  ["Mo 8:00-12:00", "INVALID_TIME", 4],
  ["Mo 08:00-12:60", "INVALID_TIME", 10],
  ["Mo 24:00-24:00", "INVALID_TIME", 4],
  ["Mo 08:00-24:01", "INVALID_TIME", 10],
  ["Mo 08:00:00-12:00", "INVALID_TIME", 4],
  ["Mo 12:00-08:00", "END_BEFORE_START", 4],
  ["Mo 12:00-12:00", "END_BEFORE_START", 4],
  ["Mo 12:00-08:00 #", "END_BEFORE_START", 4],
  ["Mo 08:00-12:00,11:00-13:00", "OVERLAP", 16],
  ["Mo 11:00-13:00, 08:00-12:00", "OVERLAP", 17],
  ["Mo,Tu,Mo off", "DUPLICATE_DAY", 7],
  ["Mo-We,Su-Tu off", "DUPLICATE_DAY", 7],
  ["Mo 08:00-", "UNEXPECTED", 10],
  ["Mo off;", "UNEXPECTED", 8],
  ["Mo", "UNEXPECTED", 3],
  ["Mo Tu off", "UNEXPECTED", 4],
  ["Mo Off", "UNEXPECTED", 4],
  ["Mo 08:00-12:00 off", "UNEXPECTED", 16],
  ["Mo off 08:00-12:00", "UNEXPECTED", 8],
  ["Mo 08:00 12:00", "UNEXPECTED", 10],
  ["Mo 08:00-12:00 # x", "UNEXPECTED", 16],
  ["Mo 08:00-12:00;; Tu off", "UNEXPECTED", 16],
  ["08:00-12:00", "UNEXPECTED", 1],
])("%p -> %s at %d", (text, code, column) => {
  expectError(text, code, column);
});
