export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: readonly Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "other" | "end";

interface Token {
  kind: TokenKind;
  text: string;
  column: number; // 1-based
}

function isLetter(ch: string): boolean {
  return /^\p{L}$/u.test(ch);
}

function isTimeChar(ch: string): boolean {
  return (ch >= "0" && ch <= "9") || ch === ":";
}

function charAt(text: string, index: number): string {
  return String.fromCodePoint(text.codePointAt(index)!);
}

/**
 * Splits the text into tokens. Characters that belong to no token become
 * "other" tokens so that the parser reports them only when it reaches them.
 */
function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = charAt(text, i);
    const column = i + 1;
    if (ch === " ") {
      i++;
    } else if (ch === "-" || ch === "," || ch === ";") {
      tokens.push({ kind: ch, text: ch, column });
      i++;
    } else if (isLetter(ch) || isTimeChar(ch)) {
      const inToken = isLetter(ch) ? isLetter : isTimeChar;
      let j = i;
      while (j < text.length && inToken(charAt(text, j))) j += charAt(text, j).length;
      tokens.push({ kind: inToken === isLetter ? "word" : "time", text: text.slice(i, j), column });
      i = j;
    } else {
      tokens.push({ kind: "other", text: ch, column });
      i += ch.length;
    }
  }
  tokens.push({ kind: "end", text: "", column: text.length + 1 });
  return tokens;
}

/** Minutes since midnight, or null if the text is not a valid TIME. */
function timeToMinutes(text: string, isEnd: boolean): number | null {
  const match = /^(\d\d):(\d\d)$/.exec(text);
  if (!match) return null;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours === 24 && minutes === 0) return isEnd ? 24 * 60 : null;
  if (hours > 23 || minutes > 59) return null;
  return hours * 60 + minutes;
}

class Parser {
  private readonly tokens: Token[];
  private pos = 0;

  constructor(text: string) {
    this.tokens = tokenize(text);
  }

  private peek(): Token {
    return this.tokens[this.pos];
  }

  private next(): Token {
    const token = this.tokens[this.pos];
    if (token.kind !== "end") this.pos++;
    return token;
  }

  private unexpected(token: Token, expected: string): never {
    const found = token.kind === "end" ? "end of text" : `"${token.text}"`;
    throw new OpeningHoursError("UNEXPECTED", token.column, `Expected ${expected} but found ${found}`);
  }

  parse(): WeeklyHours {
    const result = Object.fromEntries(DAYS.map((day) => [day, []])) as unknown as WeeklyHours;
    for (;;) {
      const { days, ranges } = this.parseRule();
      for (const day of days) result[day] = ranges.map((range) => ({ ...range }));
      const token = this.next();
      if (token.kind === "end") return result;
      if (token.kind !== ";") this.unexpected(token, '";" or end of text');
    }
  }

  private parseRule(): { days: Day[]; ranges: TimeRange[] } {
    const days = this.parseDays();
    const token = this.peek();
    if (token.kind === "word" && token.text === "off") {
      this.next();
      return { days, ranges: [] };
    }
    if (token.kind === "time") return { days, ranges: this.parseRanges() };
    return this.unexpected(token, 'a time range, "off", "," or "-"');
  }

  private parseDay(): { day: Day; token: Token } {
    const token = this.next();
    if (token.kind !== "word") this.unexpected(token, "a day");
    if (!(DAYS as readonly string[]).includes(token.text)) {
      throw new OpeningHoursError(
        "UNKNOWN_DAY",
        token.column,
        `Unknown day "${token.text}", expected one of ${DAYS.join(", ")}`,
      );
    }
    return { day: token.text as Day, token };
  }

  private parseDays(): Day[] {
    const days: Day[] = [];
    for (;;) {
      const first = this.parseDay();
      let last = first;
      if (this.peek().kind === "-") {
        this.next();
        last = this.parseDay();
      }
      // Day ranges run forward through the week and may wrap around.
      const item: Day[] = [];
      let index = DAYS.indexOf(first.day);
      for (;;) {
        item.push(DAYS[index]);
        if (DAYS[index] === last.day) break;
        index = (index + 1) % DAYS.length;
      }
      const repeated = item.find((day) => days.includes(day));
      if (repeated) {
        throw new OpeningHoursError("DUPLICATE_DAY", first.token.column, `Day "${repeated}" is named more than once`);
      }
      days.push(...item);
      if (this.peek().kind !== ",") return days;
      this.next();
    }
  }

  private parseTime(isEnd: boolean): { minutes: number; token: Token } {
    const token = this.next();
    if (token.kind !== "time") this.unexpected(token, "a time (HH:MM)");
    const minutes = timeToMinutes(token.text, isEnd);
    if (minutes === null) {
      const hint = token.text === "24:00" ? "24:00 is only allowed as the end of a range" : "expected HH:MM";
      throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}" (${hint})`);
    }
    return { minutes, token };
  }

  private parseRanges(): TimeRange[] {
    const parsed: { from: number; to: number; range: TimeRange }[] = [];
    for (;;) {
      const start = this.parseTime(false);
      const dash = this.next();
      if (dash.kind !== "-") this.unexpected(dash, '"-"');
      const end = this.parseTime(true);
      const range = { from: start.token.text, to: end.token.text };
      if (end.minutes <= start.minutes) {
        throw new OpeningHoursError(
          "END_BEFORE_START",
          start.token.column,
          `Range ${range.from}-${range.to} must end after it starts`,
        );
      }
      const clash = parsed.find((p) => start.minutes < p.to && p.from < end.minutes);
      if (clash) {
        throw new OpeningHoursError(
          "OVERLAP",
          start.token.column,
          `Range ${range.from}-${range.to} overlaps ${clash.range.from}-${clash.range.to}`,
        );
      }
      parsed.push({ from: start.minutes, to: end.minutes, range });
      if (this.peek().kind !== ",") break;
      this.next();
    }
    return parsed.sort((a, b) => a.from - b.from).map((p) => p.range);
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  return new Parser(text).parse();
}
