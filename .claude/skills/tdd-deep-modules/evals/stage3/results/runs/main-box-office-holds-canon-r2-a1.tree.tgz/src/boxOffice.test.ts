import { describe, expect, test } from "bun:test";
import {
  BoxOfficeError,
  createBoxOffice,
  type BoxOfficeErrorCode,
  type BoxOfficeOptions,
} from "./boxOffice";

// Test list (all covered below):
// [x] available returns capacity for a fresh section
// [x] available: unknown section -> UNKNOWN_SECTION
// [x] hold returns H1 with expiresAt and reduces availability
// [x] hold ids increment; failed attempts don't use up a number
// [x] hold validation: unknown section, invalid quantity, check order
// [x] SOLD_OUT, no partial holds; taking exactly the rest works
// [x] CUSTOMER_LIMIT across sections, counting holds and orders
// [x] expired holds stop counting as soon as now >= expiresAt
// [x] confirm creates O1, tickets stay taken
// [x] confirm: unknown/confirmed/released -> UNKNOWN_HOLD, expired -> HOLD_EXPIRED
// [x] pricing: Rappen rounding, group discount from 4 tickets, halves round up
// [x] release frees tickets; errors; releasing an expired hold is a no-op
// [x] cancelOrder refund (fee 200/ticket, min 0), frees tickets and limit; errors
// [x] failed calls change nothing
// [x] returned holds and orders are copies (found while implementing)

function setup(overrides: Partial<BoxOfficeOptions> = {}) {
  const clock = { time: 1_000_000 };
  const office = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 5000 },
      { id: "BALKON", capacity: 5, priceCents: 3000 },
    ],
    holdMinutes: 10,
    maxTicketsPerCustomer: 6,
    now: () => clock.time,
    ...overrides,
  });
  return { office, clock };
}

function expectCode(fn: () => unknown, code: BoxOfficeErrorCode) {
  let caught: unknown;
  try {
    fn();
  } catch (error) {
    caught = error;
  }
  expect(caught).toBeInstanceOf(BoxOfficeError);
  expect((caught as BoxOfficeError).code).toBe(code);
}

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

describe("available", () => {
  test("returns the capacity of a fresh section", () => {
    const { office } = setup();
    expect(office.available("PARKETT")).toBe(10);
    expect(office.available("BALKON")).toBe(5);
  });

  test("rejects an unknown section", () => {
    const { office } = setup();
    expectCode(() => office.available("LOGE"), "UNKNOWN_SECTION");
  });
});

describe("hold", () => {
  test("returns the hold and takes its tickets", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 3);
    expect(hold).toEqual({
      holdId: "H1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 3,
      expiresAt: clock.time + 10 * 60_000,
    });
    expect(office.available("PARKETT")).toBe(7);
    expect(office.available("BALKON")).toBe(5);
  });

  test("rejects an unknown section", () => {
    const { office } = setup();
    expectCode(() => office.hold("alice", "LOGE", 1), "UNKNOWN_SECTION");
  });

  test.each([0, -1, 1.5, NaN, Infinity])("rejects quantity %p", (quantity) => {
    const { office } = setup();
    expectCode(() => office.hold("alice", "PARKETT", quantity), "INVALID_QUANTITY");
    expect(office.available("PARKETT")).toBe(10);
  });

  test("checks the section before the quantity", () => {
    const { office } = setup();
    expectCode(() => office.hold("alice", "LOGE", 0), "UNKNOWN_SECTION");
  });

  test("rejects more tickets than available, without a partial hold", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 3);
    expectCode(() => office.hold("bob", "BALKON", 3), "SOLD_OUT");
    expect(office.available("BALKON")).toBe(2);
  });

  test("numbers holds in creation order, skipping failed attempts", () => {
    const { office } = setup();
    expect(office.hold("alice", "PARKETT", 1).holdId).toBe("H1");
    expectCode(() => office.hold("bob", "BALKON", 6), "SOLD_OUT");
    expectCode(() => office.hold("bob", "LOGE", 1), "UNKNOWN_SECTION");
    expect(office.hold("bob", "BALKON", 1).holdId).toBe("H2");
    expect(office.hold("carol", "PARKETT", 2).holdId).toBe("H3");
  });

  test("limits the tickets per customer across all sections", () => {
    const { office } = setup();
    office.hold("alice", "PARKETT", 4);
    expectCode(() => office.hold("alice", "BALKON", 3), "CUSTOMER_LIMIT");
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "BALKON", 2).quantity).toBe(2);
    expect(office.hold("bob", "BALKON", 3).quantity).toBe(3);
  });

  test("checks the quantity before the customer limit", () => {
    const { office } = setup();
    office.hold("alice", "PARKETT", 6);
    expectCode(() => office.hold("alice", "PARKETT", 0), "INVALID_QUANTITY");
  });

  test("checks the customer limit before availability", () => {
    const { office } = setup();
    office.hold("bob", "BALKON", 5);
    expectCode(() => office.hold("alice", "BALKON", 7), "CUSTOMER_LIMIT");
  });

  test("expired holds stop counting as soon as now reaches expiresAt", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "BALKON", 5);
    clock.time = hold.expiresAt - 1;
    expect(office.available("BALKON")).toBe(0);
    expectCode(() => office.hold("alice", "PARKETT", 2), "CUSTOMER_LIMIT");
    clock.time = hold.expiresAt;
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "BALKON", 5).expiresAt).toBe(clock.time + 10 * 60_000);
  });

  test("allows taking exactly the remaining tickets", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 3);
    office.hold("bob", "BALKON", 2);
    expect(office.available("BALKON")).toBe(0);
  });
});

describe("confirm", () => {
  test("turns the hold into an order that keeps the tickets", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 3);
    expect(office.confirm(hold.holdId)).toEqual({
      orderId: "O1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 3,
      totalCents: 15000,
    });
    clock.time = hold.expiresAt + 1;
    expect(office.available("PARKETT")).toBe(7);
    expectCode(() => office.hold("alice", "BALKON", 4), "CUSTOMER_LIMIT");
  });

  test("numbers orders in creation order", () => {
    const { office } = setup();
    const first = office.hold("alice", "PARKETT", 1);
    const second = office.hold("bob", "PARKETT", 1);
    expect(office.confirm(second.holdId).orderId).toBe("O1");
    expect(office.confirm(first.holdId).orderId).toBe("O2");
  });

  test("rejects an unknown hold", () => {
    const { office } = setup();
    expectCode(() => office.confirm("H1"), "UNKNOWN_HOLD");
  });

  test("rejects a hold that was already confirmed", () => {
    const { office } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    office.confirm(hold.holdId);
    expectCode(() => office.confirm(hold.holdId), "UNKNOWN_HOLD");
    expect(office.available("PARKETT")).toBe(8);
    expect(office.confirm(office.hold("bob", "PARKETT", 1).holdId).orderId).toBe("O2");
  });

  test("rejects an expired hold and leaves its tickets free", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    clock.time = hold.expiresAt;
    expectCode(() => office.confirm(hold.holdId), "HOLD_EXPIRED");
    expect(office.available("PARKETT")).toBe(10);
    expect(office.confirm(office.hold("bob", "PARKETT", 1).holdId).orderId).toBe("O1");
  });

  test.each([
    { quantity: 3, priceCents: 5000, totalCents: 15000, why: "no discount below 4" },
    { quantity: 4, priceCents: 5000, totalCents: 18000, why: "10 % from 4 tickets" },
    { quantity: 1, priceCents: 1002, totalCents: 1000, why: "rounds down to 5 cents" },
    { quantity: 1, priceCents: 1003, totalCents: 1005, why: "rounds up to 5 cents" },
    { quantity: 3, priceCents: 333, totalCents: 1000, why: "rounds the total, not the price" },
    { quantity: 4, priceCents: 1234, totalCents: 4440, why: "rounds a discounted fraction" },
    { quantity: 5, priceCents: 5, totalCents: 25, why: "rounds exact halves up (22.5)" },
  ])("charges $totalCents for $quantity x $priceCents ($why)", (c) => {
    const { office } = setup({
      sections: [{ id: "PARKETT", capacity: 10, priceCents: c.priceCents }],
    });
    const hold = office.hold("alice", "PARKETT", c.quantity);
    expect(office.confirm(hold.holdId).totalCents).toBe(c.totalCents);
  });
});

describe("release", () => {
  test("frees the tickets and the customer's allowance", () => {
    const { office } = setup();
    const hold = office.hold("alice", "BALKON", 5);
    office.release(hold.holdId);
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
  });

  test("rejects an unknown hold", () => {
    const { office } = setup();
    expectCode(() => office.release("H1"), "UNKNOWN_HOLD");
  });

  test("rejects a hold that was already released", () => {
    const { office } = setup();
    const hold = office.hold("alice", "BALKON", 2);
    office.release(hold.holdId);
    office.hold("bob", "BALKON", 4);
    expectCode(() => office.release(hold.holdId), "UNKNOWN_HOLD");
    expect(office.available("BALKON")).toBe(1);
  });

  test("rejects a hold that was confirmed and keeps the order", () => {
    const { office } = setup();
    const hold = office.hold("alice", "BALKON", 2);
    office.confirm(hold.holdId);
    expectCode(() => office.release(hold.holdId), "UNKNOWN_HOLD");
    expect(office.available("BALKON")).toBe(3);
  });

  test("a released hold can no longer be confirmed", () => {
    const { office } = setup();
    const hold = office.hold("alice", "BALKON", 2);
    office.release(hold.holdId);
    expectCode(() => office.confirm(hold.holdId), "UNKNOWN_HOLD");
    expect(office.available("BALKON")).toBe(5);
  });

  test("releasing an expired hold succeeds without effect", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "BALKON", 2);
    clock.time = hold.expiresAt;
    office.release(hold.holdId);
    office.release(hold.holdId);
    expect(office.available("BALKON")).toBe(5);
    expectCode(() => office.confirm(hold.holdId), "HOLD_EXPIRED");
  });
});

describe("cancelOrder", () => {
  function order(
    office: ReturnType<typeof setup>["office"],
    customerId: string,
    sectionId: string,
    quantity: number,
  ) {
    return office.confirm(office.hold(customerId, sectionId, quantity).holdId);
  }

  test("refunds the total minus 200 cents per ticket", () => {
    const { office } = setup();
    expect(office.cancelOrder(order(office, "alice", "PARKETT", 3).orderId)).toBe(14400);
    expect(office.cancelOrder(order(office, "bob", "PARKETT", 4).orderId)).toBe(17200);
  });

  test("never refunds less than 0", () => {
    const { office } = setup({
      sections: [{ id: "PARKETT", capacity: 10, priceCents: 150 }],
    });
    expect(office.cancelOrder(order(office, "alice", "PARKETT", 2).orderId)).toBe(0);
  });

  test("frees the tickets and the customer's allowance", () => {
    const { office } = setup();
    const placed = order(office, "alice", "BALKON", 5);
    office.cancelOrder(placed.orderId);
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).quantity).toBe(6);
  });

  test("rejects an unknown order", () => {
    const { office } = setup();
    expectCode(() => office.cancelOrder("O1"), "UNKNOWN_ORDER");
    expectCode(() => office.cancelOrder("H1"), "UNKNOWN_ORDER");
  });

  test("rejects an order that was already cancelled", () => {
    const { office } = setup();
    const placed = order(office, "alice", "BALKON", 2);
    office.cancelOrder(placed.orderId);
    order(office, "bob", "BALKON", 4);
    expectCode(() => office.cancelOrder(placed.orderId), "UNKNOWN_ORDER");
    expect(office.available("BALKON")).toBe(1);
    expect(order(office, "carol", "BALKON", 1).orderId).toBe("O3");
  });
});

describe("returned objects", () => {
  test("changing a returned hold or order does not affect the box office", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    hold.quantity = 10;
    hold.expiresAt = 0;
    expect(office.available("PARKETT")).toBe(8);

    const placed = office.confirm(hold.holdId);
    placed.quantity = 0;
    placed.totalCents = 0;
    clock.time += 60 * 60_000;
    expect(office.available("PARKETT")).toBe(8);
    expect(office.cancelOrder(placed.orderId)).toBe(9600);
  });
});
