export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const GROUP_DISCOUNT_MIN_TICKETS = 4;
const CANCELLATION_FEE_CENTS = 200;

/** Group discount of 10 %, then rounded to 5 Rappen with halves up. */
function orderTotal(quantity: number, priceCents: number): number {
  // Work in tenths of a cent so the discount stays an exact integer.
  const factor = quantity >= GROUP_DISCOUNT_MIN_TICKETS ? 9 : 10;
  const tenths = quantity * priceCents * factor;
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const sections = new Map(options.sections.map((s) => [s.id, s]));
  const holds: (Hold & { ended: boolean })[] = [];
  const orders: (Order & { cancelled: boolean })[] = [];

  function section(sectionId: string): SectionConfig {
    const found = sections.get(sectionId);
    if (!found) {
      throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    }
    return found;
  }

  function isExpired(hold: Hold): boolean {
    return options.now() >= hold.expiresAt;
  }

  /** A hold that was neither confirmed nor released (it may have expired). */
  function openHold(holdId: string) {
    const hold = holds.find((h) => h.holdId === holdId);
    if (!hold || hold.ended) {
      throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    }
    return hold;
  }

  /** Active holds and orders: everything that currently takes tickets. */
  function takenTickets(matches: (item: Hold | Order) => boolean): number {
    const taken = [
      ...holds.filter((h) => !h.ended && !isExpired(h)),
      ...orders.filter((o) => !o.cancelled),
    ];
    return taken.filter(matches).reduce((sum, item) => sum + item.quantity, 0);
  }

  function available(sectionId: string): number {
    const { capacity } = section(sectionId);
    return capacity - takenTickets((item) => item.sectionId === sectionId);
  }

  return {
    hold(customerId, sectionId, quantity) {
      section(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const customerTickets = takenTickets((item) => item.customerId === customerId);
      if (customerTickets + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError("CUSTOMER_LIMIT", `Too many tickets for ${customerId}`);
      }
      if (quantity > available(sectionId)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in ${sectionId}`);
      }
      const hold: Hold = {
        holdId: `H${holds.length + 1}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: options.now() + options.holdMinutes * 60_000,
      };
      holds.push({ ...hold, ended: false });
      return hold;
    },
    confirm(holdId) {
      const hold = openHold(holdId);
      if (isExpired(hold)) {
        throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      }
      hold.ended = true;
      const order: Order = {
        orderId: `O${orders.length + 1}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: orderTotal(hold.quantity, section(hold.sectionId).priceCents),
      };
      orders.push({ ...order, cancelled: false });
      return order;
    },
    release(holdId) {
      const hold = openHold(holdId);
      if (!isExpired(hold)) {
        hold.ended = true;
      }
    },
    cancelOrder(orderId) {
      const order = orders.find((o) => o.orderId === orderId);
      if (!order || order.cancelled) {
        throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      }
      order.cancelled = true;
      return Math.max(0, order.totalCents - CANCELLATION_FEE_CENTS * order.quantity);
    },
    available,
  };
}
