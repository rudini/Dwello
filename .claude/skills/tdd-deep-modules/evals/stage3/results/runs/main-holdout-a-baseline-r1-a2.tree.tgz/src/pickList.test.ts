import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

function formatError(text: string): OrderFormatError {
  try {
    buildPickList(text, []);
  } catch (error) {
    if (error instanceof OrderFormatError) return error;
    throw error;
  }
  throw new Error("expected an OrderFormatError");
}

test("example batch: priority first, earliest expiry first, serpentine walk", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const stock: StockLot[] = [
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, expires: null },
    { bin: "B-02-1", sku: "OLIVE-500", qty: 2, expires: "2026-12-01" },
    { bin: "B-05-3", sku: "OLIVE-500", qty: 1, expires: "2026-11-01" },
    { bin: "C-04-1", sku: "PASTA-1KG", qty: 5, expires: "2027-01-01" },
  ];
  const snapshot = structuredClone(stock);
  const result = buildPickList(text, stock);
  expect(stock).toEqual(snapshot);
  expect(result.shortages).toEqual([]);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "B-05-3", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    { bin: "C-04-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
  ]);
});

test("shortages, merged duplicates and bin tie-break", () => {
  const text = "ORDER A-1\nX x2\nY x4\nX x3\nORDER b2\nY x1";
  const stock: StockLot[] = [
    { bin: "A-02-1", sku: "X", qty: 3, expires: "2026-11-01" },
    { bin: "A-01-1", sku: "X", qty: 1, expires: "2026-11-01" },
    { bin: "A-03-1", sku: "Y", qty: 0, expires: null },
  ];
  const result = buildPickList(text, stock);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "X", qty: 1, orderId: "A-1" },
    { bin: "A-02-1", sku: "X", qty: 3, orderId: "A-1" },
  ]);
  expect(result.shortages).toEqual([
    { orderId: "A-1", sku: "X", missing: 1 },
    { orderId: "A-1", sku: "Y", missing: 4 },
    { orderId: "b2", sku: "Y", missing: 1 },
  ]);
});

test("serpentine counts only visited aisles", () => {
  const bins = ["A-01-2", "A-02-1", "C-01-1", "C-03-2", "C-03-1", "D-01-1", "D-05-1"];
  const stock: StockLot[] = bins.map((bin, i) => ({ bin, sku: `S${i}`, qty: 1, expires: null }));
  const text = "ORDER 1\n" + stock.map((lot) => lot.sku + " x1").reverse().join("\n");
  expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual([
    "A-01-2",
    "A-02-1",
    "C-03-1",
    "C-03-2",
    "C-01-1",
    "D-01-1",
    "D-05-1",
  ]);
});

test("format errors report the first problem from the top", () => {
  expect(formatError("\nX x1\nORDER 1\nX x1").line).toBe(2);
  expect(formatError("ORDER 1\nX x1\nORDER 1\nX x1").line).toBe(3);
  expect(formatError("ORDER 1\nORDER 2\nX x1").line).toBe(1);
  expect(formatError("ORDER 1\nX x1\nORDER 2\n# c\n").line).toBe(3);
  expect(formatError("ORDER 1\nX x0").line).toBe(2);
  expect(formatError("ORDER 1\nX x03").line).toBe(2);
  expect(formatError("ORDER 1\nx x1").line).toBe(2);
  expect(formatError("ORDER 1\nX 1").line).toBe(2);
  expect(formatError("ORDER 1!\nX x1").line).toBe(1);
  expect(formatError("ORDER 1\nbad\nX x1\nORDER 1\n").line).toBe(2);
  expect(formatError("ORDER 1\nbad\nORDER 2\nX x1").line).toBe(2);
});

test("priority marker and item spacing are flexible", () => {
  expect(buildPickList("ORDER 1   !\nX   x1", []).shortages).toEqual([
    { orderId: "1", sku: "X", missing: 1 },
  ]);
});
