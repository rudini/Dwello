export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface OrderItem {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  items: OrderItem[];
}

const ORDER_LINE = /^ORDER +([A-Za-z0-9-]+)( +!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/;

function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const seenIds = new Set<string>();
  // An order is empty only if no content line at all follows it before the
  // next ORDER line; a malformed item line is reported as such instead.
  let current: { order: Order; line: number; hasContent: boolean } | null = null;
  const closeCurrent = () => {
    if (current !== null && !current.hasContent) {
      throw new OrderFormatError(current.line, `order ${current.order.id} has no items`);
    }
  };

  const lines = ordersText.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const lineNo = i + 1;
    const line = lines[i].trim();
    if (line === "" || line.startsWith("#")) continue;

    const orderMatch = ORDER_LINE.exec(line);
    if (orderMatch) {
      closeCurrent();
      const id = orderMatch[1];
      if (seenIds.has(id)) throw new OrderFormatError(lineNo, `duplicate order id ${id}`);
      seenIds.add(id);
      const order: Order = { id, priority: orderMatch[2] !== undefined, items: [] };
      orders.push(order);
      current = { order, line: lineNo, hasContent: false };
      continue;
    }

    const itemMatch = ITEM_LINE.exec(line);
    if (current === null && itemMatch) {
      throw new OrderFormatError(lineNo, "item line before the first ORDER line");
    }
    if (current === null || !itemMatch) {
      throw new OrderFormatError(lineNo, `unrecognized line "${line}"`);
    }
    current.hasContent = true;
    const sku = itemMatch[1];
    const qty = Number(itemMatch[2]);
    const existing = current.order.items.find((item) => item.sku === sku);
    if (existing) existing.qty += qty;
    else current.order.items.push({ sku, qty });
  }
  closeCurrent();

  return orders;
}

interface Lot {
  bin: string;
  remaining: number;
  expires: string | null;
  index: number;
}

function compareLots(a: Lot, b: Lot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return a.expires < b.expires ? -1 : 1;
  }
  if (a.bin !== b.bin) return a.bin < b.bin ? -1 : 1;
  return a.index - b.index;
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "", level = ""] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

function inWalkingOrder(picks: Pick[]): Pick[] {
  const entries = picks.map((pick, index) => ({ pick, index, ...parseBin(pick.bin) }));
  const aisles = [...new Set(entries.map((e) => e.aisle))].sort();
  const aisleRank = new Map(aisles.map((aisle, i) => [aisle, i]));
  entries.sort((a, b) => {
    const rankA = aisleRank.get(a.aisle)!;
    const rankB = aisleRank.get(b.aisle)!;
    if (rankA !== rankB) return rankA - rankB;
    // 1st, 3rd, ... visited aisle ascending; 2nd, 4th, ... descending.
    if (a.rack !== b.rack) return rankA % 2 === 0 ? a.rack - b.rack : b.rack - a.rack;
    if (a.level !== b.level) return a.level - b.level;
    return a.index - b.index;
  });
  return entries.map((e) => e.pick);
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);

  const lotsBySku = new Map<string, Lot[]>();
  stock.forEach((lot, index) => {
    let lots = lotsBySku.get(lot.sku);
    if (!lots) lotsBySku.set(lot.sku, (lots = []));
    lots.push({ bin: lot.bin, remaining: lot.qty, expires: lot.expires, index });
  });
  for (const lots of lotsBySku.values()) lots.sort(compareLots);

  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  for (const order of served) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const lot of lotsBySku.get(item.sku) ?? []) {
        if (needed === 0) break;
        if (lot.remaining <= 0) continue;
        const taken = Math.min(needed, lot.remaining);
        lot.remaining -= taken;
        needed -= taken;
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
    }
  }

  return { picks: inWalkingOrder(picks), shortages };
}
