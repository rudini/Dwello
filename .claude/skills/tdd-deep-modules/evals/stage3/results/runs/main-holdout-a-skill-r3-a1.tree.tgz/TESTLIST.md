# pickList — behaviour test list

**Hidden decision:** how the morning orders text is parsed and validated, how stock is
allocated (priority, FEFO by best-before date, bin tie-break) and how picks are ordered along
the serpentine walk — callers hand over text and stock and get a finished pick list.

**Design A (chosen):** one pure function
`buildPickList(ordersText, stock): { picks, shortages }`, throwing `OrderFormatError`.
Call site: `const { picks, shortages } = buildPickList(fs.readFileSync(f, "utf8"), stock);`

**Design B:** a stateful `Warehouse` object: `const w = new Warehouse(stock); w.load(text);
w.allocate(); w.walk()` with separate `parseOrders`, `allocate`, `sortByWalk` steps.

**Chosen: A**, because a single call hides parsing, allocation and walking order completely,
whereas B leaks the step order and intermediate structures (parsed orders, remaining stock)
into the interface.

## Behaviours (through `buildPickList`)

- [x] one order, one item, one lot: one pick with the ordered quantity
- [x] does not modify the stock array or its objects
- [x] an item takes the lot with the earliest best-before date first and splits across lots
- [x] undated lots come after dated lots; ties are broken by bin code
- [x] missing stock: picks what is available and reports a shortage
- [x] stock taken by an earlier order is not available to a later one (covered by the undated-lots test)
- [x] priority orders (`!`) are served before others, in text order
- [x] repeated SKU in an order is summed and keeps its first position
- [x] comment and empty lines are ignored, lines are trimmed
- [x] picks follow the serpentine walk (aisles alphabetical, racks alternating, levels ascending)
- [x] several picks at the same bin keep allocation order (covered by the priority test; stable sort)
- [x] error: item line before the first ORDER, with its line number
- [x] error: duplicate order id at the second ORDER line
- [x] error: ORDER without items, reported at the ORDER line
- [x] error: malformed item lines (x0, x03, lowercase SKU, missing x) and other junk
- [x] the first problem from the top is reported
