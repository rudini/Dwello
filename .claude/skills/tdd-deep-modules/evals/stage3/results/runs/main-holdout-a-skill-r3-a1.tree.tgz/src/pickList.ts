export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: { sku: string; qty: number }[];
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const { picks, shortages } = allocate(parseOrders(ordersText), stock);
  return { picks: inWalkingOrder(picks), shortages };
}

/**
 * Serpentine: aisles alphabetically (only those with picks), racks ascending in the
 * 1st, 3rd, ... aisle and descending in the others, levels ascending. Stable for equal bins.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const parse = (bin: string) => {
    const [aisle, rack, level] = bin.split("-");
    return { aisle, rack: Number(rack), level: Number(level) };
  };
  const aisles = [...new Set(picks.map((pick) => parse(pick.bin).aisle))].sort(compareText);
  return [...picks].sort((a, b) => {
    const pa = parse(a.bin);
    const pb = parse(b.bin);
    if (pa.aisle !== pb.aisle) return compareText(pa.aisle, pb.aisle);
    const descending = aisles.indexOf(pa.aisle) % 2 === 1;
    if (pa.rack !== pb.rack) return descending ? pb.rack - pa.rack : pa.rack - pb.rack;
    return pa.level - pb.level;
  });
}

function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const rejectEmptyLastOrder = () => {
    const last = orders[orders.length - 1];
    if (last && last.items.length === 0) throw new OrderFormatError(last.line, `order ${last.id} has no items`);
  };
  for (const [index, rawLine] of ordersText.split("\n").entries()) {
    const lineNo = index + 1;
    const line = rawLine.trim();
    if (line === "" || line.startsWith("#")) continue;

    const order = /^ORDER ([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (order) {
      const [, id, priorityMark] = order;
      rejectEmptyLastOrder();
      if (orders.some((o) => o.id === id)) throw new OrderFormatError(lineNo, `order id ${id} already used`);
      orders.push({ id, priority: priorityMark !== undefined, line: lineNo, items: [] });
      continue;
    }

    const item = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/.exec(line);
    if (!item) {
      // An order followed only by an unreadable line has no items; its ORDER line comes first.
      rejectEmptyLastOrder();
      throw new OrderFormatError(lineNo, `cannot read line "${line}"`);
    }
    const current = orders[orders.length - 1];
    if (!current) throw new OrderFormatError(lineNo, "item line before the first ORDER");
    const [, sku, qtyText] = item;
    const existing = current.items.find((i) => i.sku === sku);
    if (existing) existing.qty += Number(qtyText);
    else current.items.push({ sku, qty: Number(qtyText) });
  }
  rejectEmptyLastOrder();
  return orders;
}

/** Serves priority orders first, then the rest; each item takes the earliest-expiring lots first. */
function allocate(orders: Order[], stock: StockLot[]): PickList {
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const remaining = stock.map((lot) => ({ ...lot }));
  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const { id: orderId, items } of served) {
    for (const { sku, qty } of items) {
      let open = qty;
      const lots = remaining
        .filter((lot) => lot.sku === sku && lot.qty > 0)
        .sort((a, b) => compareExpiry(a.expires, b.expires) || compareText(a.bin, b.bin));
      for (const lot of lots) {
        if (open === 0) break;
        const taken = Math.min(open, lot.qty);
        lot.qty -= taken;
        open -= taken;
        picks.push({ bin: lot.bin, sku, qty: taken, orderId });
      }
      if (open > 0) shortages.push({ orderId, sku, missing: open });
    }
  }
  return { picks, shortages };
}

/** Dated lots first, earliest date first; undated lots last. */
function compareExpiry(a: string | null, b: string | null): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return compareText(a, b);
}

function compareText(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}
