# pickList design note

**Hidden decision:** how the orders text is parsed and validated, how stock is allocated
(priority first, earliest best-before first, undated last, bin tie-break) and how picks are
ordered along the serpentine walk.

**Both designs**

- A (chosen): `buildPickList(ordersText, stock): { picks, shortages }`, throws `OrderFormatError`.
- B: stateful `Warehouse` with `load(text)`, `allocate()`, `walk()`.

Chosen: A, because one call hides parsing, allocation and walking order, while B leaks the
step order and intermediate state (parsed orders, remaining stock) into the interface.

**Interface**

- `buildPickList(ordersText, stock)` returns picks in walking order and shortages in serving
  order; never modifies `stock`.
- `OrderFormatError.line` is the 1-based line of the first problem from the top.

**Depth:** `src/pickList.ts: surface 10, size 119, ratio 11.9, classitis no, pass-through 0,
tests 1, unused 0, duplicate 7`. The duplicates are the field declarations of the given
exported types (kept unchanged as required) and three `rejectEmptyLastOrder()` calls.
Refactors split the single loop into private `parseOrders`, `allocate` and `inWalkingOrder`,
replaced a concatenated sort key with explicit expiry/bin comparators, and tidied the parser.

**Open points**

- An `ORDER` followed only by an unreadable line is reported as an order without items at its
  `ORDER` line (that line is higher up, and the unreadable line is not an item line).
- `ORDER` and its id must be separated by exactly one space; bin codes are assumed well formed.

**Proof:** `scripts/tdd_replay 8a6fd67..HEAD` printed `REPLAY: ACCEPT`.
