import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("one order, one item, one lot: one pick with the ordered quantity", () => {
  const result = buildPickList("ORDER 1001\nOLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("an item takes the earliest best-before date first and splits across lots", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 5, "2026-12-01"), lot("A-01-2", "OLIVE-500", 2, "2026-11-01")];
  expect(buildPickList("ORDER 1001\nOLIVE-500 x4", stock).picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "A-01-2", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("undated lots come after dated lots and ties are broken by bin code", () => {
  const stock = [
    lot("A-01-1", "PASTA-1KG", 10, null),
    lot("A-02-1", "PASTA-1KG", 1, "2026-12-01"),
    lot("A-01-3", "PASTA-1KG", 1, "2026-12-01"),
  ];
  expect(buildPickList("ORDER 1\nPASTA-1KG x1\nORDER 2\nPASTA-1KG x2", stock).picks).toEqual([
    { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "2" },
    { bin: "A-01-3", sku: "PASTA-1KG", qty: 1, orderId: "1" },
    { bin: "A-02-1", sku: "PASTA-1KG", qty: 1, orderId: "2" },
  ]);
});

test("missing stock: picks what is available and reports a shortage", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 2)];
  expect(buildPickList("ORDER 1001\nOLIVE-500 x5\nPASTA-1KG x1", stock)).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
    shortages: [
      { orderId: "1001", sku: "OLIVE-500", missing: 3 },
      { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
    ],
  });
});

test("priority orders are served before the others, in text order", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 3)];
  const text = "ORDER 1\nOLIVE-500 x1\nORDER 2 !\nOLIVE-500 x2\nORDER 3  !\nOLIVE-500 x1";
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "2" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "3" },
    ],
    shortages: [{ orderId: "1", sku: "OLIVE-500", missing: 1 }],
  });
});

test("a repeated SKU in an order is summed and keeps its first position", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 2)];
  expect(buildPickList("ORDER 1\nOLIVE-500 x1\nPASTA-1KG x3\nOLIVE-500 x2", stock)).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1" }],
    shortages: [
      { orderId: "1", sku: "OLIVE-500", missing: 1 },
      { orderId: "1", sku: "PASTA-1KG", missing: 3 },
    ],
  });
});

test("comment and empty lines are ignored and lines are trimmed", () => {
  const text = "# export 2026-10-12 06:00\n\nORDER 1001  \n  OLIVE-500   x3\r\n\t\n  # note\n";
  expect(() => buildPickList(text, [])).not.toThrow();
  expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 10)]).picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
  ]);
});

test("picks follow the serpentine walk through the aisles that have picks", () => {
  const stock = [
    lot("C-01-1", "S-1", 1),
    lot("A-02-1", "S-2", 1),
    lot("A-01-2", "S-3", 1),
    lot("A-01-1", "S-4", 1),
    lot("C-03-2", "S-5", 1),
    lot("C-03-1", "S-6", 1),
    lot("D-02-1", "S-7", 1),
    lot("D-01-1", "S-8", 1),
    lot("B-01-1", "S-9", 1),
  ];
  const text = "ORDER 1\nS-1 x1\nS-2 x1\nS-3 x1\nS-4 x1\nS-5 x1\nS-6 x1\nS-7 x1\nS-8 x1";
  expect(buildPickList(text, stock).picks.map((pick) => pick.bin)).toEqual([
    "A-01-1",
    "A-01-2",
    "A-02-1",
    "C-03-1",
    "C-03-2",
    "C-01-1",
    "D-01-1",
    "D-02-1",
  ]);
});

function formatErrorLine(text: string): number | string {
  try {
    buildPickList(text, []);
  } catch (error) {
    return error instanceof OrderFormatError ? error.line : String(error);
  }
  return "no error";
}

test("error: an item line before the first ORDER", () => {
  expect(formatErrorLine("# export\n\nOLIVE-500 x1\nORDER 1\nOLIVE-500 x1")).toBe(3);
});

test("error: an ORDER whose id was already used", () => {
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\nORDER 2\nOLIVE-500 x1\nORDER 1 !\nOLIVE-500 x1")).toBe(5);
});

test("error: an ORDER without item lines, reported at the ORDER line", () => {
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\nORDER 2\n# nothing\n\nORDER 3\nOLIVE-500 x1")).toBe(3);
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\nORDER 2 !\n")).toBe(3);
});

test("error: a line that is neither an ORDER nor an item line", () => {
  const badLines = [
    "OLIVE-500 x0",
    "OLIVE-500 x03",
    "olive-500 x1",
    "OLIVE-500 1",
    "OLIVE-500x1",
    "OLIVE-500 x",
    "OLIVE-500 x-1",
    "OLIVE-500 x1.5",
    "OLIVE 500 x1",
    "OLIVE_500 x1",
    "ORDER",
    "ORDER 2!",
    "ORDER a_b",
    "ORDER 2 ! x",
    "order 2",
  ];
  for (const bad of badLines) {
    expect({ bad, line: formatErrorLine(`ORDER 1\nOLIVE-500 x1\n${bad}\nPASTA-1KG x1`) }).toEqual({ bad, line: 3 });
  }
});

test("the first problem from the top is reported", () => {
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\nORDER 2\nOLIVE-500 x0\nORDER 1\nOLIVE-500 x1")).toBe(3);
  expect(formatErrorLine("ORDER 1\nORDER 1\nOLIVE-500 x1")).toBe(1);
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\nOLIVE-500 x0\nORDER 1\nOLIVE-500 x1")).toBe(3);
});

test("does not modify the stock array or its objects", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 2, "2026-11-01"), lot("A-01-2", "OLIVE-500", 5)];
  buildPickList("ORDER 1001\nOLIVE-500 x4", stock);
  expect(stock).toEqual([lot("A-01-1", "OLIVE-500", 2, "2026-11-01"), lot("A-01-2", "OLIVE-500", 5)]);
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});
