export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface OrderItem {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  items: OrderItem[];
}

const ORDER_LINE = /^ORDER\s+([A-Za-z0-9-]+)(\s+!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+)\s+x([1-9][0-9]*)$/;

/**
 * Parses the whole text before reporting anything: an order without items is
 * only noticed later, but must still win over problems further down.
 */
function parseOrders(ordersText: string): Order[] {
  const orders: (Order & { line: number })[] = [];
  const problems: OrderFormatError[] = [];
  const lines = ordersText.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const lineNumber = index + 1;
    const line = lines[index]!.trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = ORDER_LINE.exec(line);
    if (orderMatch) {
      const id = orderMatch[1]!;
      if (orders.some((o) => o.id === id)) {
        problems.push(new OrderFormatError(lineNumber, `order id "${id}" is already used`));
      }
      orders.push({ id, priority: orderMatch[2] !== undefined, items: [], line: lineNumber });
      continue;
    }
    const itemMatch = ITEM_LINE.exec(line);
    if (itemMatch) {
      const current = orders[orders.length - 1];
      if (!current) {
        problems.push(new OrderFormatError(lineNumber, "item line before the first ORDER line"));
        continue;
      }
      const sku = itemMatch[1]!;
      const qty = Number(itemMatch[2]);
      const existing = current.items.find((i) => i.sku === sku);
      if (existing) existing.qty += qty;
      else current.items.push({ sku, qty });
      continue;
    }
    problems.push(new OrderFormatError(lineNumber, `expected "ORDER <id>" or "<sku> x<qty>", got "${line}"`));
  }
  for (const order of orders) {
    if (order.items.length === 0) {
      problems.push(new OrderFormatError(order.line, `order "${order.id}" has no items`));
    }
  }
  const first = problems.reduce<OrderFormatError | undefined>((a, p) => (a && a.line <= p.line ? a : p), undefined);
  if (first) throw first;
  return orders;
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Earliest best-before first, undated lots last, then by bin code. */
function byAllocationPriority(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

/**
 * Serpentine walk: aisles alphabetically, racks ascending in every odd visited
 * aisle and descending in every even one, levels ascending. The sort is stable,
 * so picks at the same bin keep their allocation order.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const location = (bin: string) => {
    const [aisle = "", rack = "", level = ""] = bin.split("-");
    return { aisle, rack: Number(rack), level: Number(level) };
  };
  const aisles = [...new Set(picks.map((p) => location(p.bin).aisle))].sort(compareStrings);
  const descending = new Set(aisles.filter((_, i) => i % 2 === 1));
  return [...picks].sort((a, b) => {
    const la = location(a.bin);
    const lb = location(b.bin);
    if (la.aisle !== lb.aisle) return compareStrings(la.aisle, lb.aisle);
    if (la.rack !== lb.rack) return descending.has(la.aisle) ? lb.rack - la.rack : la.rack - lb.rack;
    return la.level - lb.level;
  });
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const remaining = stock.map((l) => ({ ...l })).sort(byAllocationPriority);
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let wanted = item.qty;
      for (const source of remaining) {
        if (source.sku !== item.sku) continue;
        const taken = Math.min(wanted, source.qty);
        if (taken === 0) continue;
        picks.push({ bin: source.bin, sku: item.sku, qty: taken, orderId: order.id });
        source.qty -= taken;
        wanted -= taken;
      }
      if (wanted > 0) {
        shortages.push({ orderId: order.id, sku: item.sku, missing: wanted });
      }
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}
