import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("empty orders text yields an empty pick list", () => {
  expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
});

test("single item is picked from the matching lot", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3";
  expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 10)])).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("item without any stock is reported as a shortage", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3";
  expect(buildPickList(text, [lot("A-01-1", "PASTA-1KG", 10)])).toEqual({
    picks: [],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
  });
});

test("lots with the earliest best-before date are used first", () => {
  const text = "ORDER 1001\n  OLIVE-500 x4";
  const stock = [lot("A-02-1", "OLIVE-500", 5, "2027-03-01"), lot("A-01-1", "OLIVE-500", 2, "2026-11-01")];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "A-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("undated lots come after dated ones; ties are broken by bin code", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3";
  const stock = [
    lot("A-01-1", "OLIVE-500", 1, null),
    lot("A-01-3", "OLIVE-500", 1, "2027-01-01"),
    lot("A-01-2", "OLIVE-500", 1, "2027-01-01"),
    lot("A-01-4", "OLIVE-500", 1, "2027-05-01"),
  ];
  expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual(["A-01-2", "A-01-3", "A-01-4"]);
});

test("among undated lots the bin code decides", () => {
  const text = "ORDER 1001\n  OLIVE-500 x1";
  const stock = [lot("A-01-2", "OLIVE-500", 1, null), lot("A-01-1", "OLIVE-500", 1, null)];
  expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual(["A-01-1"]);
});

test("stock taken by an earlier order is not available to later ones", () => {
  const text = "ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n  OLIVE-500 x3";
  expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 4)])).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
    ],
    shortages: [{ orderId: "1002", sku: "OLIVE-500", missing: 2 }],
  });
});

test("the stock array and its lots are left untouched", () => {
  const stock = [lot("B-01-1", "OLIVE-500", 2, null), lot("A-01-1", "OLIVE-500", 2, "2027-01-01")];
  const snapshot = structuredClone(stock);
  const originals = [...stock];
  buildPickList("ORDER 1001\n  OLIVE-500 x3", stock);
  expect(stock).toEqual(snapshot);
  expect(stock).toEqual(originals);
  stock.forEach((l, i) => expect(l).toBe(originals[i]!));
});

test("priority orders are served first, each group in text order", () => {
  const text = ["ORDER N1", "  OLIVE-500 x1", "ORDER P1 !", "  OLIVE-500 x1", "ORDER N2", "  OLIVE-500 x1", "ORDER P2   !", "  OLIVE-500 x1"].join("\n");
  const { shortages } = buildPickList(text, [lot("A-01-1", "OLIVE-500", 1)]);
  expect(shortages.map((s) => s.orderId)).toEqual(["P2", "N1", "N2"]);
});

test("repeated SKU in an order is summed at the position of its first appearance", () => {
  const text = "ORDER 1001\n  OLIVE-500 x1\n  PASTA-1KG x1\n  OLIVE-500 x2";
  const { shortages } = buildPickList(text, []);
  expect(shortages).toEqual([
    { orderId: "1001", sku: "OLIVE-500", missing: 3 },
    { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
  ]);
});

test("picks follow the serpentine walk through the visited aisles", () => {
  const bins = ["D-02-1", "C-01-2", "A-02-1", "D-01-1", "C-10-1", "A-01-3", "C-01-1", "A-01-1"];
  const stock = bins.map((bin) => lot(bin, `SKU-${bin}`, 1));
  const text = ["ORDER 1001", ...bins.map((bin) => `  SKU-${bin} x1`)].join("\n");
  expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual([
    "A-01-1",
    "A-01-3",
    "A-02-1",
    "C-10-1",
    "C-01-1",
    "C-01-2",
    "D-01-1",
    "D-02-1",
  ]);
});

test("picks at the same bin keep their allocation order", () => {
  const text = "ORDER 1001\n  OLIVE-500 x1\n  PASTA-1KG x1\nORDER 1002 !\n  PASTA-1KG x1\n  OLIVE-500 x1";
  const stock = [lot("A-01-1", "PASTA-1KG", 5), lot("A-01-1", "OLIVE-500", 5), lot("A-01-2", "OLIVE-500", 1, "2026-12-01")];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "1002" },
    { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
    { bin: "A-01-2", sku: "OLIVE-500", qty: 1, orderId: "1002" },
  ]);
});

test("morning batch from the export", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const stock = [
    lot("C-02-1", "OLIVE-500", 2, "2027-01-01"),
    lot("C-05-1", "OLIVE-500", 5, null),
    lot("A-03-2", "OLIVE-500", 2, "2026-11-01"),
    lot("A-01-1", "PASTA-1KG", 0, "2026-10-20"),
    lot("B-04-1", "RICE-1KG", 3, null),
  ];
  // Aisle B has stock but no picks, so C is the 2nd visited aisle and walked backwards.
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-03-2", sku: "OLIVE-500", qty: 2, orderId: "1002" },
      { bin: "C-05-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
      { bin: "C-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "PASTA-1KG", missing: 1 }],
  });
});

function errorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  return undefined;
}

test.each([
  ["zero quantity", "  OLIVE-500 x0"],
  ["leading zero", "  OLIVE-500 x03"],
  ["lowercase SKU", "  olive-500 x3"],
  ["missing x", "  OLIVE-500 3"],
  ["no space before quantity", "  OLIVE-500x3"],
  ["uppercase X", "  OLIVE-500 X3"],
  ["trailing garbage", "  OLIVE-500 x3 y"],
  ["priority mark glued to the id", "ORDER 1002!"],
  ["invalid order id", "ORDER 10_02"],
  ["order without id", "ORDER"],
])("unrecognised line is reported: %s", (_name, badLine) => {
  expect(errorLine(`ORDER 1001\n  PASTA-1KG x1\n${badLine}\n  PASTA-1KG x1`)).toBe(3);
});

test("item line before the first ORDER is reported", () => {
  expect(errorLine("# header\nOLIVE-500 x1\nORDER 1001\n  OLIVE-500 x1")).toBe(2);
});

test("reused order id is reported at the second ORDER line", () => {
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002\n  OLIVE-500 x1\nORDER 1001 !\n  OLIVE-500 x1")).toBe(5);
});

test("order without items is reported at its ORDER line", () => {
  expect(errorLine("ORDER 1001\n# nothing\nORDER 1002\n  OLIVE-500 x1")).toBe(1);
});

test("last order without items is reported too", () => {
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1002 !\n\n# end")).toBe(3);
});

test("the topmost problem wins, even if it is only noticed later", () => {
  expect(errorLine("ORDER 1001\n  olive x1\nORDER 1002\n  OLIVE-500 x1")).toBe(1);
  expect(errorLine("ORDER 1001\n  olive x1\n  OLIVE-500 x1\nORDER 1002")).toBe(2);
  expect(errorLine("ORDER 1001\n  OLIVE-500 x1\nORDER 1001\nORDER 1003\n  bad")).toBe(3);
});

test("comments, blank lines and indentation are ignored but counted", () => {
  const text = "# export 2026-10-12 06:00\n\n   \nORDER 1001\n  # a note\n\tOLIVE-500   x3  \n\n  bad line";
  expect(errorLine(text)).toBe(8);
  const { picks } = buildPickList(text.replace("  bad line", ""), [lot("A-01-1", "OLIVE-500", 9)]);
  expect(picks).toEqual([{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }]);
});

test("partially covered item picks what is there and reports the rest", () => {
  const text = "ORDER 1001\n  OLIVE-500 x5";
  expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 2)])).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
  });
});
