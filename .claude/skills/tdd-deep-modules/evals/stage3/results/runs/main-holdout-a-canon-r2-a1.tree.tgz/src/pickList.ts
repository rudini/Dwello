export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Item {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  items: Item[];
  line: number;
}

/**
 * Parses the whole text, collecting every problem on the way, so that the
 * topmost one can be reported (an empty ORDER is only noticed further down).
 */
function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  const lines = ordersText.split("\n");
  for (const [index, rawLine] of lines.entries()) {
    const lineNumber = index + 1;
    const line = rawLine.trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = /^ORDER +([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (orderMatch) {
      const id = orderMatch[1]!;
      if (orders.some((o) => o.id === id)) {
        problems.push(new OrderFormatError(lineNumber, `order id ${id} already used`));
      }
      orders.push({ id, priority: orderMatch[2] !== undefined, items: [], line: lineNumber });
      continue;
    }
    const itemMatch = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNumber, `neither an ORDER nor an item line: ${line}`));
      continue;
    }
    const order = orders[orders.length - 1];
    if (!order) {
      problems.push(new OrderFormatError(lineNumber, "item line before the first ORDER line"));
      continue;
    }
    const sku = itemMatch[1]!;
    const qty = Number(itemMatch[2]);
    const existing = order.items.find((i) => i.sku === sku);
    if (existing) existing.qty += qty;
    else order.items.push({ sku, qty });
  }
  for (const order of orders) {
    if (order.items.length === 0) {
      problems.push(new OrderFormatError(order.line, `order ${order.id} has no items`));
    }
  }
  const firstProblem = problems.sort((a, b) => a.line - b.line)[0];
  if (firstProblem) throw firstProblem;
  return orders;
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

function byExpiryThenBin(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const lots = stock.map((l) => ({ ...l })).sort(byExpiryThenBin);
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let wanted = item.qty;
      for (const source of lots) {
        if (wanted === 0) break;
        if (source.sku !== item.sku || source.qty === 0) continue;
        const taken = Math.min(wanted, source.qty);
        source.qty -= taken;
        wanted -= taken;
        picks.push({ bin: source.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (wanted > 0) {
        shortages.push({ orderId: order.id, sku: item.sku, missing: wanted });
      }
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "0", level = "0"] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/** Serpentine walk: aisles alphabetically, racks alternating up/down per visited aisle, levels up. */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const located = picks.map((pick) => ({ pick, ...parseBin(pick.bin) }));
  const aisles = [...new Set(located.map((p) => p.aisle))].sort(compareStrings);
  const descending = new Set(aisles.filter((_, index) => index % 2 === 1));
  return located
    .sort(
      (a, b) =>
        compareStrings(a.aisle, b.aisle) ||
        (descending.has(a.aisle) ? b.rack - a.rack : a.rack - b.rack) ||
        a.level - b.level,
    )
    .map((p) => p.pick);
}
