import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("empty text gives an empty pick list", () => {
  expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
});

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("one item covered by one lot gives one pick", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("item without any stock is reported as shortage", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", []);
  expect(result).toEqual({
    picks: [],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
  });
});

test("item takes from the lots with the earliest expiry first", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x5", [
    lot("A-01-1", "OLIVE-500", 10, "2027-03-01"),
    lot("A-01-2", "OLIVE-500", 2, "2026-11-01"),
    lot("A-01-3", "OLIVE-500", 2, "2026-12-01"),
  ]);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    { bin: "A-01-2", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "A-01-3", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
  expect(result.shortages).toEqual([]);
});

test("lots without expiry come after dated lots", () => {
  const result = buildPickList("ORDER 1001\n  SALT x3", [
    lot("A-01-1", "SALT", 10, null),
    lot("A-01-2", "SALT", 3, "2030-01-01"),
  ]);
  expect(result.picks).toEqual([{ bin: "A-01-2", sku: "SALT", qty: 3, orderId: "1001" }]);
});

test("lots with equal expiry are taken in bin code order", () => {
  const dated = buildPickList("ORDER 1001\n  SALT x3", [
    lot("B-01-1", "SALT", 10, "2027-01-01"),
    lot("A-02-1", "SALT", 10, "2027-01-01"),
  ]);
  expect(dated.picks).toEqual([{ bin: "A-02-1", sku: "SALT", qty: 3, orderId: "1001" }]);
  const undated = buildPickList("ORDER 1001\n  SALT x3", [
    lot("B-01-1", "SALT", 10, null),
    lot("A-02-1", "SALT", 10, null),
  ]);
  expect(undated.picks).toEqual([{ bin: "A-02-1", sku: "SALT", qty: 3, orderId: "1001" }]);
});

test("partially covered item picks what is there and reports the rest", () => {
  const result = buildPickList("ORDER 1001\n  SALT x10", [
    lot("A-01-1", "SALT", 3, "2027-01-01"),
    lot("A-01-2", "SALT", 4, null),
  ]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "SALT", qty: 3, orderId: "1001" },
      { bin: "A-01-2", sku: "SALT", qty: 4, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "SALT", missing: 3 }],
  });
});

test("stock taken by an earlier order is not available to later ones", () => {
  const result = buildPickList("ORDER 1\n  SALT x4\nORDER 2\n  SALT x4", [
    lot("A-01-1", "SALT", 3, "2027-01-01"),
    lot("A-01-2", "SALT", 2, "2028-01-01"),
  ]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "SALT", qty: 3, orderId: "1" },
      { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "1" },
      { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "2" },
    ],
    shortages: [{ orderId: "2", sku: "SALT", missing: 3 }],
  });
});

test("lots of other SKUs and empty lots yield no picks", () => {
  const result = buildPickList("ORDER 1\n  SALT x2", [
    lot("A-01-1", "PEPPER", 9, "2026-01-01"),
    lot("A-01-2", "SALT", 0, "2026-01-01"),
    lot("A-01-3", "SALT", 5, "2027-01-01"),
  ]);
  expect(result.picks).toEqual([{ bin: "A-01-3", sku: "SALT", qty: 2, orderId: "1" }]);
});

test("repeated SKU in an order is summed up at its first position", () => {
  const result = buildPickList("ORDER 1\n  SALT x2\n  PEPPER x1\n  SALT x3", [lot("A-01-1", "SALT", 4)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "SALT", qty: 4, orderId: "1" }],
    shortages: [
      { orderId: "1", sku: "SALT", missing: 1 },
      { orderId: "1", sku: "PEPPER", missing: 1 },
    ],
  });
});

test("priority orders are served first, then the others, each in text order", () => {
  const text = ["ORDER n1", "  SALT x1", "ORDER p1 !", "  SALT x1", "ORDER n2", "  SALT x1", "ORDER p2   !", "  SALT x1"].join(
    "\n",
  );
  const result = buildPickList(text, [lot("A-01-1", "SALT", 1, "2026-11-01"), lot("A-01-2", "SALT", 1, "2026-12-01")]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "p1" },
      { bin: "A-01-2", sku: "SALT", qty: 1, orderId: "p2" },
    ],
    shortages: [
      { orderId: "n1", sku: "SALT", missing: 1 },
      { orderId: "n2", sku: "SALT", missing: 1 },
    ],
  });
});

const bins = (result: { picks: { bin: string }[] }) => result.picks.map((p) => p.bin);

test("picks walk the serpentine: racks up in odd aisles, down in even, levels up", () => {
  const stock = [
    lot("C-01-1", "C1", 1),
    lot("A-10-1", "A10", 1),
    lot("A-02-3", "A2L3", 1),
    lot("B-03-1", "B3", 1),
    lot("A-02-1", "A2L1", 1),
    lot("B-11-2", "B11L2", 1),
    lot("B-11-1", "B11L1", 1),
    lot("C-09-1", "C9", 1),
  ];
  const text = "ORDER 1\n" + stock.map((l) => `  ${l.sku} x1`).join("\n");
  expect(bins(buildPickList(text, stock))).toEqual([
    "A-02-1",
    "A-02-3",
    "A-10-1",
    "B-11-1",
    "B-11-2",
    "B-03-1",
    "C-01-1",
    "C-09-1",
  ]);
});

test("aisles without picks do not count for the serpentine", () => {
  const stock = [lot("A-01-1", "A", 1), lot("B-01-1", "UNUSED", 1), lot("C-01-1", "C1", 1), lot("C-05-1", "C5", 1)];
  const result = buildPickList("ORDER 1\n  C1 x1\n  A x1\n  C5 x1", stock);
  expect(bins(result)).toEqual(["A-01-1", "C-05-1", "C-01-1"]);
});

test("picks at the same bin keep their allocation order", () => {
  const stock = [lot("A-01-1", "SALT", 5), lot("A-01-1", "PEPPER", 5)];
  const result = buildPickList("ORDER 2 \nPEPPER x1\nSALT x1\nORDER 1 !\nSALT x1\nPEPPER x1", stock);
  expect(result.picks.map((p) => `${p.orderId}:${p.sku}`)).toEqual(["1:SALT", "1:PEPPER", "2:PEPPER", "2:SALT"]);
});

test("stock array and its lots are left untouched", () => {
  const stock = [lot("B-01-1", "SALT", 2, null), lot("A-01-1", "SALT", 2, "2027-01-01")];
  const snapshot = structuredClone(stock);
  const firstLot = stock[0];
  buildPickList("ORDER 1\n  SALT x3", stock);
  expect(stock).toEqual(snapshot);
  expect(stock[0]).toBe(firstLot!);
});

function errorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  return undefined;
}

test("item line before the first ORDER is an error", () => {
  expect(errorLine("# header\n\n  SALT x1\nORDER 1\n  SALT x1")).toBe(3);
});

test("reusing an order id is an error at the repeated ORDER line", () => {
  expect(errorLine("ORDER 1\n  SALT x1\nORDER 2\n  SALT x1\nORDER 1 !\n  SALT x1")).toBe(5);
});

test("an ORDER without items is an error at its ORDER line", () => {
  expect(errorLine("ORDER 1\n  SALT x1\nORDER 2\n# nothing\n\nORDER 3\n  SALT x1")).toBe(3);
  expect(errorLine("ORDER 1\n  SALT x1\nORDER 2\n\n")).toBe(3);
});

test.each([
  ["zero quantity", "SALT x0"],
  ["leading zero", "SALT x03"],
  ["negative quantity", "SALT x-1"],
  ["lowercase SKU", "salt x1"],
  ["missing x", "SALT 1"],
  ["uppercase X", "SALT X1"],
  ["no space before quantity", "SALTx1"],
  ["missing quantity", "SALT x"],
  ["fractional quantity", "SALT x1.5"],
  ["trailing text", "SALT x1 pcs"],
  ["SKU only", "SALT"],
  ["bad order id", "ORDER 10_01"],
  ["order without id", "ORDER"],
  ["priority mark not separated", "ORDER 1003!"],
  ["lowercase order keyword", "order 1003"],
  ["something else", "hello"],
])("malformed line (%s) is an error at that line", (_, badLine) => {
  expect(errorLine(`ORDER 1001\n  SALT x1\n  ${badLine}\n  PEPPER x2`)).toBe(3);
});

test("the first problem from the top is reported", () => {
  expect(errorLine("ORDER 1\n  SALT x1\nORDER 2\n  SALT x0\n  SALT x1\nORDER 1\n  SALT x1")).toBe(4);
  expect(errorLine("ORDER 1\n  SALT x1\nORDER 2\n  bad line\nORDER 1")).toBe(3);
  expect(errorLine("ORDER 1\nSALT x0\nSALT x1")).toBe(2);
});

test("comments, blank lines, whitespace and repeated spaces are tolerated", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "",
    "   ORDER 1001   ",
    "\tOLIVE-500    x3\r",
    "   # a comment inside an order",
    "  PASTA-1KG x1",
    "ORDER   1002 !",
    "  OLIVE-500 x2",
    "",
  ].join("\n");
  const result = buildPickList(text, [
    lot("B-02-1", "OLIVE-500", 4, "2027-05-01"),
    lot("A-01-1", "OLIVE-500", 6, "2027-09-01"),
    lot("A-03-2", "PASTA-1KG", 1, null),
  ]);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
      { bin: "A-03-2", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 2, orderId: "1002" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    ],
    shortages: [],
  });
});
