import { formatChf } from "./money";

export type Promotion = { code: string; minSubtotalCents?: number } & (
  | { kind: "percent"; percent: number }
  | { kind: "fixed"; amountCents: number }
  | { kind: "multibuy"; sku: string; buy: number; pay: number }
);

export interface PricedLine {
  sku: string;
  qty: number;
  unitCents: number;
  lineCents: number;
}

export interface CouponResult {
  /** Exact to the cent and never more than the subtotal. */
  discountCents: number;
  /** Why the coupon gave no discount, if it was refused. */
  notice?: string;
}

/**
 * Applies the coupon with the given code to the lines. Throws for an unknown
 * code; refuses (with a notice) a coupon whose minimum order is not reached.
 */
export function applyCoupon(promotions: Promotion[], code: string, lines: PricedLine[]): CouponResult {
  const promotion = promotions.find((p) => p.code === code);
  if (!promotion) throw new Error(`Unknown coupon code: ${code}`);
  const subtotal = lines.reduce((sum, l) => sum + l.lineCents, 0);
  if (promotion.minSubtotalCents !== undefined && subtotal < promotion.minSubtotalCents) {
    return {
      discountCents: 0,
      notice: `Coupon ${code} requires a minimum order of ${formatChf(promotion.minSubtotalCents)}`,
    };
  }
  return { discountCents: Math.min(discountFor(promotion, lines, subtotal), subtotal) };
}

function discountFor(promotion: Promotion, lines: PricedLine[], subtotal: number): number {
  switch (promotion.kind) {
    case "percent":
      return Math.round((subtotal * promotion.percent) / 100);
    case "fixed":
      return promotion.amountCents;
    case "multibuy": {
      const line = lines.find((l) => l.sku === promotion.sku);
      if (!line) return 0;
      const groups = Math.floor(line.qty / promotion.buy);
      return groups * (promotion.buy - promotion.pay) * line.unitCents;
    }
  }
}
