# Design note: till receipt amounts and coupon minimum

**Hidden decision:** how a receipt's money is derived — which items a promotion
frees, which amounts are exact to the cent and which are cash-rounded, how a
discount is capped and split across VAT rates, and when a coupon is refused.

**Both designs**

- A: one general call, `checkout(cart, catalog, promotions?, couponCode?) -> Receipt`
  (receipt carries every amount plus an optional `notice`).
- B: special calls `priceLines`, `applyCoupon`, `splitVat`, `cashRound` composed by the till.

Chosen: A, because the till learns one function and one result type while all
rounding, capping, VAT split and coupon rules stay behind it.

**Interface**

- `checkout(...)`: lines, `subtotalCents` and `discountCents` exact to the cent;
  `totalCents` rounded to 5 Rappen and never negative (discount capped at the
  subtotal); `vat[rate]` is the VAT in that rate's gross after its share of the
  discount (reduced share rounded half up, standard gets the rest); `notice` set
  only when a coupon misses its `minSubtotalCents`. Unknown coupons throw.
- `renderReceipt(receipt)`: prints the notice as the last line.
- `Promotion` may carry an optional `minSubtotalCents`.

**Depth** (`depth_report`, after the refactor)

```
src/checkout.ts:   surface 8, size 63, ratio 7.9  -> deep
src/promotions.ts: surface 7, size 42, ratio 6.0  -> deep   (was 3.9, shallow)
src/receipt.ts:    surface 2, size 21, ratio 10.5 -> deep
```

Refactor: `findPromotion` and `discountFor` were two exported helpers that
`checkout` had to call in order and then cap. They are now private behind one
`applyCoupon(promotions, code, lines) -> { discountCents, notice? }`, which owns
lookup, the minimum-order rule and the cap.

**Open points**

- Three behaviours from the list have no test of their own (multibuy with 4
  cups, a mixed-rate discount split, coupon exactly at the minimum): each passed
  already after an earlier green, so it could not be written as a failing red.
- The VAT split assumes exactly two rates (standard and reduced), as the catalog does.

**Proof:** `scripts/tdd_replay 2222866..HEAD` printed `REPLAY: ACCEPT`.
