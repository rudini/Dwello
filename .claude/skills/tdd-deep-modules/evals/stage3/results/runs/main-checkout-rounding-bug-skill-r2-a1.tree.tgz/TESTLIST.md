# Test list: till receipt amounts and coupon minimum

**Hidden decision:** how a receipt's money is derived — which items a promotion
frees, which amounts are exact to the cent and which are cash-rounded, how a
discount is capped and split across VAT rates, and when a coupon is refused.
Callers (the till, `renderReceipt`) only ever see the finished `Receipt`.

**Sketch A — one general call (existing):**
`checkout(cart, catalog, promotions?, couponCode?) -> Receipt`, where the
receipt carries every amount plus an optional `notice`.
Call site: `renderReceipt(checkout(cart, catalog, promos, "ZEHN"))`.

**Sketch B — several special calls:**
`priceLines(cart, catalog)`, `applyCoupon(lines, promos, code) -> { discount, error? }`,
`splitVat(lines, discount)`, `cashRound(total)`; the till composes them.
Call site: four calls in the right order, each caller re-deriving the rounding rules.

**Chosen:** Sketch A, because the till learns one function and one result
type, while rounding, capping, VAT split and coupon validity stay behind it;
in B every rule leaks into the call order.

Tests go through `checkout` (`src/checkout.test.ts`) and `renderReceipt`
(`src/receipt.test.ts`).

## Behaviours

- [x] multibuy gives nothing for an incomplete group (2 cups with buy 3 pay 2)
- [x] multibuy frees only complete groups (4 cups -> one cup free) — no own cycle:
      the `ceil` -> `floor` fix of the line above already made it pass, so it
      could not fail as a red
- [x] line amounts and subtotal are exact to the cent, total is cash-rounded (3 x 0.99 -> 2.97 / 2.95)
- [x] a fixed voucher is capped at the subtotal (CHF 50 on 5.80 -> discount 580, total 0)
- [x] VAT on a single rate is computed on the discounted amount (10 % on 4 cups -> 4.05)
- [x] the discount is split across VAT rates by share of subtotal, reduced share rounded —
      implemented with the line above (accounting's rule as a whole); no small
      mixed cart was found where a simpler split gives different VAT, so no red
- [x] a coupon below its minimum order gives no discount and a notice
- [x] a coupon at its minimum order applies normally, without notice — passed
      as soon as the minimum check existed (comparison is `<`)
- [x] the notice is printed as the last receipt line
