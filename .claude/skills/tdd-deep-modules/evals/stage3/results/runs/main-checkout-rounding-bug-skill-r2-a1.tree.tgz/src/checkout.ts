import { findProduct, VAT_RATES, type Catalog, type VatCategory } from "./catalog";
import { roundToRappen, vatIncluded } from "./money";
import { applyCoupon, type Promotion } from "./promotions";

export interface CartLine {
  sku: string;
  qty: number;
}

export interface ReceiptLine {
  sku: string;
  name: string;
  qty: number;
  unitCents: number;
  lineCents: number;
  vat: VatCategory;
}

export interface Receipt {
  lines: ReceiptLine[];
  subtotalCents: number;
  couponCode?: string;
  discountCents: number;
  totalCents: number;
  vat: Record<VatCategory, number>;
  notice?: string;
}

export function checkout(
  cart: CartLine[],
  catalog: Catalog,
  promotions: Promotion[] = [],
  couponCode?: string,
): Receipt {
  const lines: ReceiptLine[] = cart.map(({ sku, qty }) => {
    const product = findProduct(catalog, sku);
    return {
      sku,
      name: product.name,
      qty,
      unitCents: product.priceCents,
      lineCents: product.priceCents * qty,
      vat: product.vat,
    };
  });

  const subtotalCents = lines.reduce((sum, l) => sum + l.lineCents, 0);

  const { discountCents, notice } =
    couponCode === undefined ? { discountCents: 0 } : applyCoupon(promotions, couponCode, lines);

  // The discount is split by each rate's share of the subtotal; VAT is taken
  // from the discounted gross, before the total is cash-rounded.
  const grossOf = (category: VatCategory) =>
    lines.filter((l) => l.vat === category).reduce((sum, l) => sum + l.lineCents, 0);
  const reducedGross = grossOf("reduced");
  const reducedShare =
    subtotalCents === 0 ? 0 : Math.round((discountCents * reducedGross) / subtotalCents);
  const vat: Record<VatCategory, number> = {
    standard: vatIncluded(grossOf("standard") - (discountCents - reducedShare), VAT_RATES.standard),
    reduced: vatIncluded(reducedGross - reducedShare, VAT_RATES.reduced),
  };

  return {
    lines,
    subtotalCents,
    couponCode,
    discountCents,
    totalCents: roundToRappen(subtotalCents - discountCents),
    vat,
    notice,
  };
}
