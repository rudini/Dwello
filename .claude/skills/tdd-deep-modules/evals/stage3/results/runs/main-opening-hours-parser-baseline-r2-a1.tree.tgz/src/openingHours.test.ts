import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours, type OpeningHoursErrorCode } from "./openingHours";

function expectError(text: string, code: OpeningHoursErrorCode, column: number) {
  let caught: unknown;
  try {
    parseOpeningHours(text);
  } catch (error) {
    caught = error;
  }
  expect(caught).toBeInstanceOf(OpeningHoursError);
  const error = caught as OpeningHoursError;
  expect({ code: error.code, column: error.column }).toEqual({ code, column });
}

const closed = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };

test("parses the example", () => {
  const morningAndAfternoon = [
    { from: "08:00", to: "12:00" },
    { from: "13:30", to: "18:30" },
  ];
  expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
    Mo: morningAndAfternoon,
    Tu: morningAndAfternoon,
    We: morningAndAfternoon,
    Th: morningAndAfternoon,
    Fr: morningAndAfternoon,
    Sa: [{ from: "09:00", to: "16:00" }],
    Su: [],
  });
});

test("day ranges wrap around and unnamed days are closed", () => {
  const hours = [{ from: "10:00", to: "24:00" }];
  expect(parseOpeningHours("Fr-Mo 10:00-24:00")).toEqual({ ...closed, Fr: hours, Sa: hours, Su: hours, Mo: hours });
  expect(parseOpeningHours("We-We 10:00-24:00")).toEqual({ ...closed, We: hours });
});

test("spaces are insignificant and ranges are sorted", () => {
  expect(parseOpeningHours("  Mo , We 14:00 - 18:00 , 08:00-12:00,12:00-14:00 ")).toEqual({
    ...closed,
    Mo: [
      { from: "08:00", to: "12:00" },
      { from: "12:00", to: "14:00" },
      { from: "14:00", to: "18:00" },
    ],
    We: [
      { from: "08:00", to: "12:00" },
      { from: "12:00", to: "14:00" },
      { from: "14:00", to: "18:00" },
    ],
  });
});

test("later rules replace earlier ones", () => {
  const all = parseOpeningHours("Mo-Su 08:00-20:00; Su off");
  expect(all.Su).toEqual([]);
  expect(all.Sa).toEqual([{ from: "08:00", to: "20:00" }]);
  const week = parseOpeningHours("Mo-Fr 08:00-12:00; We 14:00-18:00");
  expect(week.We).toEqual([{ from: "14:00", to: "18:00" }]);
  expect(week.Th).toEqual([{ from: "08:00", to: "12:00" }]);
});

test("days do not share range arrays", () => {
  const hours = parseOpeningHours("Mo,Tu 08:00-12:00");
  hours.Mo.push({ from: "13:00", to: "14:00" });
  expect(hours.Tu).toHaveLength(1);
});

test("reports errors with codes and columns", () => {
  expectError("", "EMPTY", 1);
  expectError("   ", "EMPTY", 1);
  expectError("Mo-Fx 08:00-12:00", "UNKNOWN_DAY", 4);
  expectError("mo 08:00-12:00", "UNKNOWN_DAY", 1);
  expectError("Mo 08:00-", "UNEXPECTED", 10);
  expectError("Mo off;", "UNEXPECTED", 8);
  expectError("Mo off; ", "UNEXPECTED", 9);
  expectError("Mo Off", "UNEXPECTED", 4);
  expectError("Mo", "UNEXPECTED", 3);
  expectError("; Mo off", "UNEXPECTED", 1);
  expectError("08:00-12:00", "UNEXPECTED", 1);
  expectError("Mo 08:00-12:00 Tu off", "UNEXPECTED", 16);
  expectError("Mo 08:00/12:00", "UNEXPECTED", 9);
  expectError("Mo 8:00-12:00", "INVALID_TIME", 4);
  expectError("Mo 08:00-12:60", "INVALID_TIME", 10);
  expectError("Mo 24:00-24:00", "INVALID_TIME", 4);
  expectError("Mo 08:00-24:01", "INVALID_TIME", 10);
  expectError("Mo 12:00-12:00", "END_BEFORE_START", 4);
  expectError("Mo 12:00-08:00", "END_BEFORE_START", 4);
  expectError("Mo 08:00-12:00,11:00-14:00", "OVERLAP", 16);
  expectError("Mo 10:00-12:00, 08:00-18:00", "OVERLAP", 17);
  expectError("Mo-Fr,We 08:00-12:00", "DUPLICATE_DAY", 7);
  expectError("We,Mo-Fr 08:00-12:00", "DUPLICATE_DAY", 4);
  expectError("Mo-Fr 08:00-12:00; Sa,Sa off", "DUPLICATE_DAY", 23);
});

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});
