export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: readonly Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "invalid" | "end";

interface Token {
  kind: TokenKind;
  text: string;
  column: number;
}

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    const start = i;
    if (ch === " ") {
      i++;
      continue;
    }
    if (/\p{L}/u.test(ch)) {
      while (i < text.length && /\p{L}/u.test(text[i])) i++;
      tokens.push({ kind: "word", text: text.slice(start, i), column: start + 1 });
    } else if (/[0-9:]/.test(ch)) {
      while (i < text.length && /[0-9:]/.test(text[i])) i++;
      tokens.push({ kind: "time", text: text.slice(start, i), column: start + 1 });
    } else if (ch === "-" || ch === "," || ch === ";") {
      i++;
      tokens.push({ kind: ch, text: ch, column: start + 1 });
    } else {
      i++;
      tokens.push({ kind: "invalid", text: ch, column: start + 1 });
    }
  }
  tokens.push({ kind: "end", text: "", column: text.length + 1 });
  return tokens;
}

function unexpected(token: Token): OpeningHoursError {
  if (token.kind === "end") {
    return new OpeningHoursError("UNEXPECTED", token.column, "Unexpected end of text");
  }
  return new OpeningHoursError("UNEXPECTED", token.column, `Unexpected "${token.text}"`);
}

/** Returns the time in minutes since midnight, or undefined if it is not a valid TIME. */
function parseTime(text: string, isEnd: boolean): number | undefined {
  const match = /^([0-9]{2}):([0-9]{2})$/.exec(text);
  if (!match) return undefined;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours === 24 && minutes === 0 && isEnd) return 24 * 60;
  if (hours > 23 || minutes > 59) return undefined;
  return hours * 60 + minutes;
}

interface ParsedRange {
  range: TimeRange;
  start: number;
  end: number;
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) {
    throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  }

  const tokens = tokenize(text);
  let pos = 0;
  const peek = (): Token => tokens[pos];
  const next = (): Token => tokens[pos++];

  const expectDay = (): number => {
    const token = next();
    if (token.kind !== "word") throw unexpected(token);
    const index = DAYS.indexOf(token.text as Day);
    if (index < 0) {
      throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    }
    return index;
  };

  const expectTime = (isEnd: boolean): { token: Token; minutes: number } => {
    const token = next();
    if (token.kind !== "time") throw unexpected(token);
    const minutes = parseTime(token.text, isEnd);
    if (minutes === undefined) {
      throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    }
    return { token, minutes };
  };

  const parseDays = (): Day[] => {
    const named: Day[] = [];
    for (;;) {
      const first = peek();
      const from = expectDay();
      let to = from;
      if (peek().kind === "-") {
        next();
        to = expectDay();
      }
      const days: Day[] = [];
      for (let d = from; ; d = (d + 1) % 7) {
        days.push(DAYS[d]);
        if (d === to) break;
      }
      const duplicate = days.find((day) => named.includes(day));
      if (duplicate) {
        throw new OpeningHoursError("DUPLICATE_DAY", first.column, `Day "${duplicate}" is named twice`);
      }
      named.push(...days);
      if (peek().kind !== ",") return named;
      next();
    }
  };

  const parseRanges = (): TimeRange[] => {
    const ranges: ParsedRange[] = [];
    for (;;) {
      const from = expectTime(false);
      const dash = next();
      if (dash.kind !== "-") throw unexpected(dash);
      const to = expectTime(true);
      if (to.minutes <= from.minutes) {
        throw new OpeningHoursError(
          "END_BEFORE_START",
          from.token.column,
          `End ${to.token.text} is not later than start ${from.token.text}`,
        );
      }
      const current: ParsedRange = {
        range: { from: from.token.text, to: to.token.text },
        start: from.minutes,
        end: to.minutes,
      };
      const other = ranges.find((r) => r.start < current.end && current.start < r.end);
      if (other) {
        throw new OpeningHoursError(
          "OVERLAP",
          from.token.column,
          `Range ${current.range.from}-${current.range.to} overlaps ${other.range.from}-${other.range.to}`,
        );
      }
      ranges.push(current);
      if (peek().kind !== ",") break;
      next();
    }
    return ranges.sort((a, b) => a.start - b.start).map((r) => r.range);
  };

  const result = Object.fromEntries(DAYS.map((day) => [day, []])) as unknown as WeeklyHours;

  for (;;) {
    const days = parseDays();
    let ranges: TimeRange[];
    const token = peek();
    if (token.kind === "word" && token.text === "off") {
      next();
      ranges = [];
    } else if (token.kind === "time") {
      ranges = parseRanges();
    } else {
      throw unexpected(token);
    }
    for (const day of days) {
      result[day] = ranges.map((r) => ({ ...r }));
    }

    const separator = next();
    if (separator.kind === "end") return result;
    if (separator.kind !== ";") throw unexpected(separator);
  }
}
