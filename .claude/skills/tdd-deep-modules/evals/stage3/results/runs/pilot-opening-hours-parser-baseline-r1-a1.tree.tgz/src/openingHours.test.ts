import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours, type OpeningHoursErrorCode } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

const closed = { Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] };
const r = (from: string, to: string) => ({ from, to });

test("parses the example", () => {
  const morningAfternoon = [r("08:00", "12:00"), r("13:30", "18:30")];
  expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
    Mo: morningAfternoon,
    Tu: morningAfternoon,
    We: morningAfternoon,
    Th: morningAfternoon,
    Fr: morningAfternoon,
    Sa: [r("09:00", "16:00")],
    Su: [],
  });
});

test("days not named are closed", () => {
  expect(parseOpeningHours("We 10:00-11:00")).toEqual({ ...closed, We: [r("10:00", "11:00")] });
});

test("day ranges wrap around and Mo-Mo is one day", () => {
  const h = [r("10:00", "11:00")];
  expect(parseOpeningHours("Fr-Mo 10:00-11:00")).toEqual({ ...closed, Fr: h, Sa: h, Su: h, Mo: h });
  expect(parseOpeningHours("Mo-Mo 10:00-11:00")).toEqual({ ...closed, Mo: h });
});

test("spaces are insignificant", () => {
  const h = [r("08:00", "12:00")];
  expect(parseOpeningHours("Mo,We 08:00 - 12:00")).toEqual({ ...closed, Mo: h, We: h });
  expect(parseOpeningHours("  Mo , We08:00-12:00 ;Tu off  ")).toEqual({ ...closed, Mo: h, We: h });
});

test("ranges are sorted, may touch, and 24:00 ends a range", () => {
  expect(parseOpeningHours("Mo 12:00-24:00,00:00-12:00")).toEqual({
    ...closed,
    Mo: [r("00:00", "12:00"), r("12:00", "24:00")],
  });
});

test("later rules replace earlier ones", () => {
  const all = [r("08:00", "20:00")];
  expect(parseOpeningHours("Mo-Su 08:00-20:00; Su off")).toEqual({
    Mo: all,
    Tu: all,
    We: all,
    Th: all,
    Fr: all,
    Sa: all,
    Su: [],
  });
  const m = [r("08:00", "12:00")];
  expect(parseOpeningHours("Mo-Fr 08:00-12:00; We 14:00-18:00")).toEqual({
    ...closed,
    Mo: m,
    Tu: m,
    We: [r("14:00", "18:00")],
    Th: m,
    Fr: m,
  });
});

test("days do not share range objects", () => {
  const result = parseOpeningHours("Mo,Tu 08:00-12:00");
  expect(result.Mo).not.toBe(result.Tu);
  expect(result.Mo[0]).not.toBe(result.Tu[0]);
});

test.each<[string, OpeningHoursErrorCode, number]>([
  ["", "EMPTY", 1],
  ["   ", "EMPTY", 1],
  ["Mo-Fx 08:00-12:00", "UNKNOWN_DAY", 4],
  ["mo 08:00-12:00", "UNKNOWN_DAY", 1],
  ["off", "UNKNOWN_DAY", 1],
  ["Mo, off", "UNKNOWN_DAY", 5],
  ["Mo 08:00-", "UNEXPECTED", 10],
  ["Mo off;", "UNEXPECTED", 8],
  ["Mo off;  ", "UNEXPECTED", 10],
  ["Mo", "UNEXPECTED", 3],
  ["; Mo off", "UNEXPECTED", 1],
  ["08:00-12:00", "UNEXPECTED", 1],
  ["Mo Tu off", "UNEXPECTED", 4],
  ["Mo Off", "UNEXPECTED", 4],
  ["Mo off 08:00-09:00", "UNEXPECTED", 8],
  ["Mo 08:00 12:00", "UNEXPECTED", 10],
  ["Mo 08:00-12:00, Tu 09:00-10:00", "UNEXPECTED", 17],
  ["Mo 08:00-12:00 Tu off", "UNEXPECTED", 16],
  ["Mo 08:00-12:00 / Tu off", "UNEXPECTED", 16],
  ["Mo\t08:00-12:00", "UNEXPECTED", 3],
  ["Mo 8:00-12:00", "INVALID_TIME", 4],
  ["Mo 08:60-12:00", "INVALID_TIME", 4],
  ["Mo 08:00-25:00", "INVALID_TIME", 10],
  ["Mo 24:00-24:00", "INVALID_TIME", 4],
  ["Mo 0800-1200", "INVALID_TIME", 4],
  ["Mo 08:00:00-12:00", "INVALID_TIME", 4],
  ["Mo 12:00-08:00", "END_BEFORE_START", 4],
  ["Mo 12:00-12:00", "END_BEFORE_START", 4],
  ["Mo 12:00-08:00 ?", "END_BEFORE_START", 4],
  ["Mo 08:00-12:00,11:00-13:00", "OVERLAP", 16],
  ["Mo 10:00-12:00,08:00-18:00", "OVERLAP", 16],
  ["Mo,Mo off", "DUPLICATE_DAY", 4],
  ["Mo-We,Tu off", "DUPLICATE_DAY", 7],
  ["Mo,Tu-Mo off", "DUPLICATE_DAY", 4],
  ["Mo,Mo-Fx off", "DUPLICATE_DAY", 4],
  ["Mo,Tu-Fx off", "UNKNOWN_DAY", 7],
])("%p fails with %s at column %d", (text, code, column) => {
  let error: unknown;
  try {
    parseOpeningHours(text);
  } catch (e) {
    error = e;
  }
  expect(error).toBeInstanceOf(OpeningHoursError);
  const { code: actualCode, column: actualColumn } = error as OpeningHoursError;
  expect([actualCode, actualColumn]).toEqual([code, column]);
});
