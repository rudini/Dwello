export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: readonly Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "invalid";

interface Token {
  kind: TokenKind;
  text: string;
  column: number; // 1-based
}

const isLetter = (ch: string) => /\p{L}/u.test(ch);
const isTimeChar = (ch: string) => /[0-9:]/.test(ch);

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    const start = i;
    if (ch === " ") {
      i++;
      continue;
    }
    let kind: TokenKind;
    if (isLetter(ch)) {
      kind = "word";
      while (i < text.length && isLetter(text[i])) i++;
    } else if (isTimeChar(ch)) {
      kind = "time";
      while (i < text.length && isTimeChar(text[i])) i++;
    } else if (ch === "-" || ch === "," || ch === ";") {
      kind = ch;
      i++;
    } else {
      // A character that belongs to no token; keep surrogate pairs together.
      kind = "invalid";
      i += String.fromCodePoint(text.codePointAt(i)!).length;
    }
    tokens.push({ kind, text: text.slice(start, i), column: start + 1 });
  }
  return tokens;
}

function isDay(word: string): word is Day {
  return (DAYS as readonly string[]).includes(word);
}

/** Days from `from` to `to` inclusive, running forward through the week. */
function dayRange(from: Day, to: Day): Day[] {
  const days: Day[] = [];
  let i = DAYS.indexOf(from);
  for (;;) {
    days.push(DAYS[i]);
    if (DAYS[i] === to) return days;
    i = (i + 1) % DAYS.length;
  }
}

class Parser {
  private pos = 0;

  constructor(
    private readonly tokens: Token[],
    private readonly textLength: number,
  ) {}

  private peek(): Token | undefined {
    return this.tokens[this.pos];
  }

  private next(): Token | undefined {
    return this.tokens[this.pos++];
  }

  private unexpected(token: Token | undefined, expected: string): never {
    if (!token) {
      throw new OpeningHoursError(
        "UNEXPECTED",
        this.textLength + 1,
        `Unexpected end of text, expected ${expected}`,
      );
    }
    throw new OpeningHoursError(
      "UNEXPECTED",
      token.column,
      `Unexpected "${token.text}", expected ${expected}`,
    );
  }

  parse(): WeeklyHours {
    const result = {} as WeeklyHours;
    for (const day of DAYS) result[day] = [];

    for (;;) {
      const { days, ranges } = this.parseRule();
      // A later rule replaces the hours of every day it names.
      for (const day of days) result[day] = ranges.map((r) => ({ ...r }));

      const token = this.next();
      if (!token) return result;
      if (token.kind !== ";") this.unexpected(token, '";" or end of text');
    }
  }

  private parseRule(): { days: Day[]; ranges: TimeRange[] } {
    const days = this.parseDays();
    const token = this.peek();
    if (token?.kind === "word" && token.text === "off") {
      this.pos++;
      return { days, ranges: [] };
    }
    if (token?.kind === "time") return { days, ranges: this.parseRanges() };
    return this.unexpected(token, 'a time range or "off"');
  }

  private parseDays(): Day[] {
    const seen = new Set<Day>();
    for (;;) {
      const first = this.parseDay();
      if (seen.has(first.day)) this.duplicate(first.token, first.day);

      let itemDays = [first.day];
      if (this.peek()?.kind === "-") {
        this.pos++;
        const last = this.parseDay();
        itemDays = dayRange(first.day, last.day);
        const dup = itemDays.find((d) => seen.has(d));
        if (dup) this.duplicate(first.token, dup);
      }
      for (const d of itemDays) seen.add(d);

      if (this.peek()?.kind !== ",") return [...seen];
      this.pos++;
    }
  }

  private duplicate(token: Token, day: Day): never {
    throw new OpeningHoursError("DUPLICATE_DAY", token.column, `Day ${day} is named more than once`);
  }

  private parseDay(): { day: Day; token: Token } {
    const token = this.next();
    if (token?.kind !== "word") return this.unexpected(token, "a day");
    if (!isDay(token.text)) {
      throw new OpeningHoursError(
        "UNKNOWN_DAY",
        token.column,
        `Unknown day "${token.text}", expected one of ${DAYS.join(", ")}`,
      );
    }
    return { day: token.text, token };
  }

  private parseRanges(): TimeRange[] {
    const ranges: TimeRange[] = [];
    for (;;) {
      const startToken = this.parseTime(false);
      const dash = this.next();
      if (dash?.kind !== "-") this.unexpected(dash, '"-"');
      const endToken = this.parseTime(true);

      // "HH:MM" strings compare correctly as plain strings.
      const range = { from: startToken.text, to: endToken.text };
      if (range.to <= range.from) {
        throw new OpeningHoursError(
          "END_BEFORE_START",
          startToken.column,
          `Range ${range.from}-${range.to} does not end after it starts`,
        );
      }
      const other = ranges.find((r) => range.from < r.to && r.from < range.to);
      if (other) {
        throw new OpeningHoursError(
          "OVERLAP",
          startToken.column,
          `Range ${range.from}-${range.to} overlaps ${other.from}-${other.to}`,
        );
      }
      ranges.push(range);

      if (this.peek()?.kind !== ",") break;
      this.pos++;
    }
    return ranges.sort((a, b) => (a.from < b.from ? -1 : 1));
  }

  private parseTime(isEnd: boolean): Token {
    const token = this.next();
    if (token?.kind !== "time") return this.unexpected(token, "a time");
    const match = /^(\d\d):(\d\d)$/.exec(token.text);
    const valid =
      match !== null &&
      ((Number(match[1]) <= 23 && Number(match[2]) <= 59) || (isEnd && token.text === "24:00"));
    if (!valid) {
      const hint = token.text === "24:00" ? "24:00 is only allowed as an end time" : "expected HH:MM";
      throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}", ${hint}`);
    }
    return token;
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) {
    throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  }
  return new Parser(tokenize(text), text.length).parse();
}
