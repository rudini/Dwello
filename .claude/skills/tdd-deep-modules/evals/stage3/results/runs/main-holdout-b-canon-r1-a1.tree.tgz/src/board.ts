export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Column {
  name: string;
  wipLimit?: number;
  cards: string[];
}

interface BlockedPeriod {
  from: number;
  /** Absent while the card is still blocked. */
  to?: number;
}

interface Card {
  column: Column;
  blockedPeriods: BlockedPeriod[];
  startedAt?: number;
  finishedAt?: number;
}

function currentBlock(card: Card): BlockedPeriod | undefined {
  const latest = card.blockedPeriods[card.blockedPeriods.length - 1];
  return latest && latest.to === undefined ? latest : undefined;
}

function blockedWithin(card: Card, start: number, end: number): number {
  let total = 0;
  for (const period of card.blockedPeriods) {
    const from = Math.max(period.from, start);
    const to = Math.min(period.to ?? end, end);
    if (to > from) total += to - from;
  }
  return total;
}

export function createBoard(options: BoardOptions): Board {
  const columnList: Column[] = options.columns.map((c) => ({ name: c.name, wipLimit: c.wipLimit, cards: [] }));
  const columns = new Map(columnList.map((c) => [c.name, c]));
  const first = columnList[0]!;
  const last = columnList[columnList.length - 1]!;
  const cards = new Map<string, Card>();
  let lastId = 0;

  function getCard(id: string): Card {
    const card = cards.get(id);
    if (!card) throw new BoardError("UNKNOWN_CARD", `Unknown card ${id}`);
    return card;
  }

  function getColumn(name: string): Column {
    const column = columns.get(name);
    if (!column) throw new BoardError("UNKNOWN_COLUMN", `Unknown column ${name}`);
    return column;
  }

  function assertRoom(column: Column) {
    if (column.wipLimit !== undefined && column.cards.length >= column.wipLimit) {
      throw new BoardError("WIP_LIMIT", `Column ${column.name} is at its WIP limit`);
    }
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Card title must not be empty");
      assertRoom(first);
      const id = `C${++lastId}`;
      cards.set(id, { column: first, blockedPeriods: [] });
      first.cards.push(id);
      return id;
    },
    move(cardId, toColumn) {
      const card = getCard(cardId);
      const target = getColumn(toColumn);
      const source = card.column;
      if (target === source) throw new BoardError("SAME_COLUMN", `${cardId} is already in ${toColumn}`);
      if (currentBlock(card)) throw new BoardError("BLOCKED", `${cardId} is blocked`);
      if (columnList.indexOf(target) > columnList.indexOf(source) + 1) {
        throw new BoardError("SKIP_NOT_ALLOWED", `${cardId} cannot skip columns`);
      }
      assertRoom(target);
      const now = options.now();
      source.cards.splice(source.cards.indexOf(cardId), 1);
      target.cards.push(cardId);
      card.column = target;
      if (source === first && card.startedAt === undefined) card.startedAt = now;
      if (target === last) card.finishedAt = now;
    },
    block(cardId, _reason) {
      const card = getCard(cardId);
      if (currentBlock(card)) throw new BoardError("ALREADY_BLOCKED", `${cardId} is already blocked`);
      card.blockedPeriods.push({ from: options.now() });
    },
    unblock(cardId) {
      const block = currentBlock(getCard(cardId));
      if (!block) throw new BoardError("NOT_BLOCKED", `${cardId} is not blocked`);
      block.to = options.now();
    },
    cardsIn(column) {
      return [...getColumn(column).cards];
    },
    cycleTime(cardId) {
      const card = getCard(cardId);
      if (card.column !== last) return null;
      const started = card.startedAt!;
      const finished = card.finishedAt!;
      return { totalMs: finished - started, blockedMs: blockedWithin(card, started, finished) };
    },
  };
}
