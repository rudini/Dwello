import { describe, expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode, type ColumnConfig } from "./board";

const defaultColumns: ColumnConfig[] = [
  { name: "Backlog" },
  { name: "Doing" },
  { name: "Review" },
  { name: "Done" },
];

function makeBoard(columns: ColumnConfig[] = defaultColumns) {
  let time = 1_000;
  const clock = {
    set(t: number) {
      time = t;
    },
  };
  const board = createBoard({ columns, now: () => time });
  return { board, clock };
}

function expectCode(fn: () => unknown, code: BoardErrorCode) {
  let thrown: unknown;
  try {
    fn();
  } catch (e) {
    thrown = e;
  }
  expect(thrown).toBeInstanceOf(BoardError);
  expect((thrown as BoardError).code).toBe(code);
}

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

describe("adding", () => {
  test("addCard puts C1 into the first column", () => {
    const { board } = makeBoard();
    expect(board.addCard("Fix login")).toBe("C1");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
    expect(board.cardsIn("Doing")).toEqual([]);
  });

  test("ids count up and new cards go to the end of the first column", () => {
    const { board } = makeBoard();
    expect(board.addCard("a")).toBe("C1");
    expect(board.addCard("b")).toBe("C2");
    expect(board.addCard("c")).toBe("C3");
    expect(board.cardsIn("Backlog")).toEqual(["C1", "C2", "C3"]);
  });

  test("empty or whitespace-only titles are rejected and consume no id", () => {
    const { board } = makeBoard();
    expectCode(() => board.addCard(""), "EMPTY_TITLE");
    expectCode(() => board.addCard("  \t\n "), "EMPTY_TITLE");
    expect(board.cardsIn("Backlog")).toEqual([]);
    expect(board.addCard(" ok ")).toBe("C1");
  });

  test("addCard respects the first column's WIP limit", () => {
    const { board } = makeBoard([{ name: "Backlog", wipLimit: 2 }, { name: "Done" }]);
    board.addCard("a");
    board.addCard("b");
    expectCode(() => board.addCard("c"), "WIP_LIMIT");
    expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
    board.move("C1", "Done");
    expect(board.addCard("d")).toBe("C3");
  });

  test("an empty title is reported before a full first column", () => {
    const { board } = makeBoard([{ name: "Backlog", wipLimit: 0 }, { name: "Done" }]);
    expectCode(() => board.addCard(" "), "EMPTY_TITLE");
    expectCode(() => board.addCard("x"), "WIP_LIMIT");
  });
});

describe("listing", () => {
  test("cardsIn an unknown column throws UNKNOWN_COLUMN", () => {
    const { board } = makeBoard();
    expectCode(() => board.cardsIn("Archive"), "UNKNOWN_COLUMN");
  });

  test("cardsIn returns a copy", () => {
    const { board } = makeBoard();
    board.addCard("a");
    board.cardsIn("Backlog").push("C99");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  });
});

describe("moving", () => {
  test("a moved card goes to the end of the target column", () => {
    const { board } = makeBoard();
    board.addCard("a");
    board.addCard("b");
    board.addCard("c");
    board.move("C2", "Doing");
    board.move("C1", "Doing");
    expect(board.cardsIn("Backlog")).toEqual(["C3"]);
    expect(board.cardsIn("Doing")).toEqual(["C2", "C1"]);
  });

  test("unknown card", () => {
    const { board } = makeBoard();
    expectCode(() => board.move("C1", "Doing"), "UNKNOWN_CARD");
    expectCode(() => board.move("C1", "Nowhere"), "UNKNOWN_CARD");
  });

  test("unknown column", () => {
    const { board } = makeBoard();
    board.addCard("a");
    expectCode(() => board.move("C1", "Nowhere"), "UNKNOWN_COLUMN");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  });

  test("moving into the column the card is already in", () => {
    const { board } = makeBoard();
    board.addCard("a");
    board.addCard("b");
    expectCode(() => board.move("C1", "Backlog"), "SAME_COLUMN");
    expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
  });

  test("a blocked card cannot move until unblocked", () => {
    const { board } = makeBoard();
    board.addCard("a");
    board.block("C1", "waiting for customer");
    expectCode(() => board.move("C1", "Doing"), "BLOCKED");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
    board.unblock("C1");
    board.move("C1", "Doing");
    expect(board.cardsIn("Doing")).toEqual(["C1"]);
  });

  test("moving forward by more than one column is not allowed", () => {
    const { board } = makeBoard();
    board.addCard("a");
    expectCode(() => board.move("C1", "Review"), "SKIP_NOT_ALLOWED");
    expectCode(() => board.move("C1", "Done"), "SKIP_NOT_ALLOWED");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  });

  test("moving backwards by any number of columns is allowed", () => {
    const { board } = makeBoard();
    board.addCard("a");
    board.move("C1", "Doing");
    board.move("C1", "Review");
    board.move("C1", "Done");
    board.move("C1", "Backlog");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
    expect(board.cardsIn("Done")).toEqual([]);
  });

  test("the target column's WIP limit is respected, blocked cards included", () => {
    const { board } = makeBoard([{ name: "Backlog" }, { name: "Doing", wipLimit: 2 }, { name: "Done" }]);
    board.addCard("a");
    board.addCard("b");
    board.addCard("c");
    board.move("C1", "Doing");
    board.move("C2", "Doing");
    board.block("C1", "stuck");
    expectCode(() => board.move("C3", "Doing"), "WIP_LIMIT");
    expect(board.cardsIn("Backlog")).toEqual(["C3"]);
    expect(board.cardsIn("Doing")).toEqual(["C1", "C2"]);
    board.move("C2", "Done");
    board.move("C3", "Doing");
    expect(board.cardsIn("Doing")).toEqual(["C1", "C3"]);
  });

  test("backward moves respect WIP limits too", () => {
    const { board } = makeBoard([{ name: "Backlog", wipLimit: 1 }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    board.move("C1", "Doing");
    board.addCard("b");
    expectCode(() => board.move("C1", "Backlog"), "WIP_LIMIT");
  });

  test("errors are checked in the specified order", () => {
    const { board } = makeBoard([
      { name: "Backlog" },
      { name: "Doing", wipLimit: 0 },
      { name: "Review", wipLimit: 0 },
      { name: "Done" },
    ]);
    board.addCard("a");
    board.block("C1", "stuck");
    expectCode(() => board.move("C9", "Nowhere"), "UNKNOWN_CARD");
    expectCode(() => board.move("C1", "Nowhere"), "UNKNOWN_COLUMN");
    expectCode(() => board.move("C1", "Backlog"), "SAME_COLUMN");
    expectCode(() => board.move("C1", "Review"), "BLOCKED");
    board.unblock("C1");
    expectCode(() => board.move("C1", "Review"), "SKIP_NOT_ALLOWED");
    expectCode(() => board.move("C1", "Doing"), "WIP_LIMIT");
  });
});

describe("blocking", () => {
  test("unknown cards cannot be blocked or unblocked", () => {
    const { board } = makeBoard();
    expectCode(() => board.block("C1", "x"), "UNKNOWN_CARD");
    expectCode(() => board.unblock("C1"), "UNKNOWN_CARD");
  });

  test("a card cannot be blocked twice", () => {
    const { board } = makeBoard();
    board.addCard("a");
    board.block("C1", "x");
    expectCode(() => board.block("C1", "y"), "ALREADY_BLOCKED");
  });

  test("a card that is not blocked cannot be unblocked", () => {
    const { board } = makeBoard();
    board.addCard("a");
    expectCode(() => board.unblock("C1"), "NOT_BLOCKED");
    board.block("C1", "x");
    board.unblock("C1");
    expectCode(() => board.unblock("C1"), "NOT_BLOCKED");
  });

  test("cards can be blocked in any column", () => {
    const { board } = makeBoard();
    board.addCard("a");
    board.move("C1", "Doing");
    board.move("C1", "Review");
    board.move("C1", "Done");
    board.block("C1", "reopened by customer");
    expectCode(() => board.move("C1", "Backlog"), "BLOCKED");
  });
});

describe("cycle time", () => {
  test("unknown card", () => {
    const { board } = makeBoard();
    expectCode(() => board.cycleTime("C1"), "UNKNOWN_CARD");
  });

  test("null unless the card is in the last column", () => {
    const { board } = makeBoard();
    board.addCard("a");
    expect(board.cycleTime("C1")).toBeNull();
    board.move("C1", "Doing");
    expect(board.cycleTime("C1")).toBeNull();
  });

  test("total time runs from leaving the first column to arriving in the last", () => {
    const { board, clock } = makeBoard();
    clock.set(1_000);
    board.addCard("a");
    clock.set(5_000);
    board.move("C1", "Doing");
    clock.set(8_000);
    board.move("C1", "Review");
    clock.set(12_000);
    board.move("C1", "Done");
    clock.set(99_000);
    expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 0 });
  });

  test("going back to the first column does not change the start", () => {
    const { board, clock } = makeBoard([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.set(2_000);
    board.move("C1", "Doing");
    clock.set(3_000);
    board.move("C1", "Backlog");
    clock.set(4_000);
    board.move("C1", "Doing");
    clock.set(6_000);
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 4_000, blockedMs: 0 });
  });

  test("finish is the most recent arrival in the last column", () => {
    const { board, clock } = makeBoard([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.set(2_000);
    board.move("C1", "Doing");
    clock.set(3_000);
    board.move("C1", "Done");
    clock.set(5_000);
    board.move("C1", "Doing");
    expect(board.cycleTime("C1")).toBeNull();
    clock.set(9_000);
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 0 });
  });

  test("on a two-column board start and finish can coincide", () => {
    const { board, clock } = makeBoard([{ name: "Todo" }, { name: "Done" }]);
    board.addCard("a");
    clock.set(2_000);
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 0, blockedMs: 0 });
  });

  test("blocked time between start and finish is counted", () => {
    const { board, clock } = makeBoard();
    board.addCard("a");
    clock.set(2_000);
    board.move("C1", "Doing");
    clock.set(3_000);
    board.block("C1", "waiting");
    clock.set(4_500);
    board.unblock("C1");
    board.move("C1", "Review");
    clock.set(5_000);
    board.block("C1", "again");
    clock.set(5_200);
    board.unblock("C1");
    clock.set(6_000);
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 4_000, blockedMs: 1_700 });
  });

  test("blocked time before the start is not counted", () => {
    const { board, clock } = makeBoard([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.set(2_000);
    board.block("C1", "not refined");
    clock.set(5_000);
    board.unblock("C1");
    board.move("C1", "Doing");
    clock.set(7_000);
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 2_000, blockedMs: 0 });
  });

  test("blocked time after finishing is not counted, even while still blocked", () => {
    const { board, clock } = makeBoard([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.set(2_000);
    board.move("C1", "Doing");
    clock.set(3_000);
    board.block("C1", "x");
    clock.set(4_000);
    board.unblock("C1");
    board.move("C1", "Done");
    clock.set(5_000);
    board.block("C1", "reopened");
    clock.set(9_000);
    expect(board.cycleTime("C1")).toEqual({ totalMs: 2_000, blockedMs: 1_000 });
    board.unblock("C1");
    clock.set(20_000);
    expect(board.cycleTime("C1")).toEqual({ totalMs: 2_000, blockedMs: 1_000 });
  });

  test("blocked time in earlier visits to the last column counts once the card finishes later", () => {
    const { board, clock } = makeBoard([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.set(2_000);
    board.move("C1", "Doing");
    clock.set(3_000);
    board.move("C1", "Done");
    board.block("C1", "customer reopened");
    clock.set(4_000);
    board.unblock("C1");
    board.move("C1", "Doing");
    clock.set(8_000);
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 6_000, blockedMs: 1_000 });
  });
});
