import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

const pick = (bin: string, sku: string, qty: number, orderId: string) => ({ bin, sku, qty, orderId });

const formatErrorLine = (text: string): number | undefined => {
  try {
    buildPickList(text, []);
  } catch (error) {
    if (error instanceof OrderFormatError) return error.line;
    throw error;
  }
  return undefined;
};

test("rejects an item line before the first ORDER line", () => {
  expect(() => buildPickList("# head\n\nOLIVE-500 x3\nORDER 1\n  A x1", [])).toThrow(OrderFormatError);
});

test("a single order with one item from one lot yields one pick", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({ picks: [pick("A-01-1", "OLIVE-500", 3, "1001")], shortages: [] });
});

test("an item spanning two lots takes earliest expiry first, one pick per lot", () => {
  const stock = [lot("A-01-2", "OLIVE-500", 5, "2027-03-01"), lot("A-01-1", "OLIVE-500", 2, "2026-11-01")];
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x4", stock);
  expect(result.picks).toEqual([pick("A-01-1", "OLIVE-500", 2, "1001"), pick("A-01-2", "OLIVE-500", 2, "1001")]);
});

test("lots without expiry are used after all dated lots", () => {
  const stock = [lot("A-01-1", "SALT", 5, null), lot("A-01-2", "SALT", 5, "2030-01-01")];
  const result = buildPickList("ORDER 1\n  SALT x3", stock);
  expect(result.picks).toEqual([pick("A-01-2", "SALT", 3, "1")]);
});

test("lots with the same expiry are used in bin code order", () => {
  const stock = [
    lot("B-01-1", "SALT", 5, "2030-01-01"),
    lot("A-02-1", "SALT", 5, "2030-01-01"),
    lot("Z-01-1", "SALT", 5, null),
    lot("C-05-1", "SALT", 5, null),
  ];
  const result = buildPickList("ORDER 1\n  SALT x3\nORDER 2\n  SALT x13", stock);
  expect(result.picks).toEqual([
    pick("A-02-1", "SALT", 3, "1"),
    pick("A-02-1", "SALT", 2, "2"),
    pick("B-01-1", "SALT", 5, "2"),
    pick("C-05-1", "SALT", 5, "2"),
    pick("Z-01-1", "SALT", 1, "2"),
  ]);
});

test("missing stock is picked as far as possible and reported as shortage", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 4, "2026-12-01")];
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n  OLIVE-500 x2\n  PASTA-1KG x1", stock);
  expect(result).toEqual({
    picks: [pick("A-01-1", "OLIVE-500", 3, "1001"), pick("A-01-1", "OLIVE-500", 1, "1002")],
    shortages: [
      { orderId: "1002", sku: "OLIVE-500", missing: 1 },
      { orderId: "1002", sku: "PASTA-1KG", missing: 1 },
    ],
  });
});

test("priority orders are served first, in text order", () => {
  const text = "ORDER 1\n  SALT x2\nORDER 2   !\n  SALT x2\nORDER 3\n  SALT x2\nORDER 4 !\n  SALT x2";
  const result = buildPickList(text, [lot("A-01-1", "SALT", 5)]);
  expect(result).toEqual({
    picks: [pick("A-01-1", "SALT", 2, "2"), pick("A-01-1", "SALT", 2, "4"), pick("A-01-1", "SALT", 1, "1")],
    shortages: [
      { orderId: "1", sku: "SALT", missing: 1 },
      { orderId: "3", sku: "SALT", missing: 2 },
    ],
  });
});

test("repeated SKUs in one order are summed at their first position", () => {
  const result = buildPickList("ORDER 1\n  SALT x1\n  OIL x1\n  SALT x2\nORDER 2\n  SALT x1", []);
  expect(result.shortages).toEqual([
    { orderId: "1", sku: "SALT", missing: 3 },
    { orderId: "1", sku: "OIL", missing: 1 },
    { orderId: "2", sku: "SALT", missing: 1 },
  ]);
});

test("picks follow the serpentine walk through the warehouse", () => {
  const bins = ["C-01-1", "A-02-1", "B-01-1", "A-01-2", "B-03-1", "A-01-1", "C-02-1", "B-03-2"];
  const stock = bins.map((bin, i) => lot(bin, `SKU-${i}`, 1));
  const text = "ORDER 1\n" + bins.map((_, i) => `  SKU-${i} x1`).join("\n");
  const walked = buildPickList(text, stock).picks.map((p) => p.bin);
  expect(walked).toEqual(["A-01-1", "A-01-2", "A-02-1", "B-03-1", "B-03-2", "B-01-1", "C-01-1", "C-02-1"]);
});

test("rejects an ORDER line whose id was already used", () => {
  expect(formatErrorLine("ORDER 1\n  SALT x1\nORDER 2\n  SALT x1\n\nORDER 1 !\n  SALT x1")).toBe(6);
});

test("rejects an ORDER without items at its ORDER line", () => {
  expect(formatErrorLine("ORDER 1\n  SALT x1\n# c\nORDER 2\n\nORDER 3\n  SALT x1")).toBe(4);
});

test("rejects a last ORDER without items", () => {
  expect(formatErrorLine("ORDER 1\n  SALT x1\nORDER 2\n# nothing\n")).toBe(3);
});

test("rejects lines that are neither an ORDER nor an item line", () => {
  const bad = [
    "SALT x0",
    "SALT x03",
    "salt x1",
    "SALT 1",
    "SALT x",
    "SALT X1",
    "SALTx1",
    "SALT x-1",
    "SALT x1.5",
    "SALT x1 extra",
    "SALT_1 x1",
    "ORDER",
    "ORDER 9!",
    "ORDER a_b",
    "ORDER 9 ! x",
    "order 9",
  ];
  for (const line of bad) {
    expect({ line, at: formatErrorLine(`ORDER 1\n  SALT x1\n  ${line}\nORDER 2\n  SALT x1`) }).toEqual({ line, at: 3 });
  }
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});
