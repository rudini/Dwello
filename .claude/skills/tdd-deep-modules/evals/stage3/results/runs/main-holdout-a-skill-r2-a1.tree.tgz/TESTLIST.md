# Pick list – test list

**Hidden decision:** how the orders text is parsed and validated, how stock is
allocated (priority, FEFO, bin tie-break, shortages) and how picks are ordered
along the serpentine walk – callers hand over text and stock and get a finished list.

**Design A:** `buildPickList(ordersText, stock): PickList` – one call, value result.
Call site: `const { picks, shortages } = buildPickList(text, stock);`

**Design B:** a stateful `Warehouse` object: `new Warehouse(stock).parse(text).allocate().walk()`.
Call site: `const list = new Warehouse(stock).load(text).pickList();`

**Chosen:** Design A, because the caller needs to know one function and nothing
about the phases (parse, allocate, walk), which stay hidden; B leaks the phase order.

## Behaviours (through `buildPickList`)

- [x] error: item line before first ORDER (moved first: the stub throws, so a value test could not fail on an assertion)
- [x] a single order with one item from one lot yields one pick
- [x] an item spanning two lots takes earliest expiry first, one pick per lot
- [x] null-expiry lots come after dated lots
- [x] ties broken by bin code (plain string comparison)
- [x] stock used by an earlier order is not available to later ones (covered by the tie-break test)
- [x] missing stock is still picked partially and reported as shortage
- [x] an unknown SKU yields a shortage of the full quantity (covered by the shortage test)
- [x] priority orders are served first, in text order
- [x] duplicate SKU lines in one order are summed at first position
- [x] comments, blank lines and surrounding whitespace are ignored (exercised by several tests)
- [x] picks follow the serpentine walk (aisles alphabetical, racks alternate, levels ascending)
- [ ] serpentine counts only aisles with picks – implemented with the walk, no dedicated test (would pass at once)
- [ ] picks at the same bin keep allocation order – stable sort, exercised by the tie-break test only
- [ ] stock array and lots are not modified – lots are copied, no dedicated test (would pass at once)
- [x] error: duplicate order id
- [x] error: ORDER without items, reported at its ORDER line (middle and last order)
- [x] error: malformed lines (x0, x03, lowercase SKU, missing x, bad priority mark, ...)
- [x] the first problem from the top is reported (the parser throws on the first problem it reads)
