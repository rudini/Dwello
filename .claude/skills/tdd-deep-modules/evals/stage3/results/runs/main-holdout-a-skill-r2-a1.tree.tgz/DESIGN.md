# Design note: `src/pickList.ts`

**Hidden decision:** the orders text format and its validation, the allocation rules
(priority first, earliest expiry first, undated last, bin tie-break, shortages) and the
serpentine walk order. Callers pass text plus stock and get a finished `PickList`.

**Both designs**
- A: `buildPickList(ordersText, stock): PickList`: one call that returns a value.
- B: `new Warehouse(stock).load(text).pickList()`: a stateful object with separate phases.
- Chosen: A, because callers learn one function and the phase order stays hidden, where B would expose it.

**Interface**
- `buildPickList(ordersText, stock)` returns picks in walking order and shortages in serving order. It does not modify `stock`.
- `OrderFormatError` carries the 1-based `line` of the first problem from the top.
- The types `StockLot`, `Pick`, `Shortage` and `PickList` are kept as given.

**Depth** (`depth_report src/pickList.ts`)
`surface 10, size 112, ratio 11.2, classitis no, pass-through 0, tests 1, unused 0, duplicate 6 -> bloat: 6 duplicated lines`.
The duplicated lines are the repeated field declarations (`bin`, `sku`, `qty`, `orderId`) in the
given interfaces, which must stay as they are. The refactor broke the single function into the
private steps `parseOrders`, `allocate`, `compareExpiry` and `walkOrder`, none of them exported.
It also replaced the `"￿"` sentinel for undated lots with an explicit comparator.

**Open points**
- Three behaviours were already handled by earlier greens and have no test of their own:
  only aisles with picks count for the serpentine, picks at one bin keep allocation order, and `stock` is not mutated.
- `ORDER` needs exactly one space before the id. The spec does not say whether more are allowed.
- Bin codes are trusted to have the form `A-03-2`. Malformed bins are not validated.

**Proof:** `tdd_replay 08473fa..HEAD` printed `REPLAY: ACCEPT`.
