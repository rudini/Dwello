export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  line: number;
  priority: boolean;
  items: { sku: string; qty: number }[];
}

const ORDER_LINE = /^ORDER ([A-Za-z0-9-]+)( +!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9]\d*)$/;

const compare = (a: string, b: string): number => (a < b ? -1 : a > b ? 1 : 0);

/** Builds the pick list for a batch of orders; `stock` is left untouched. */
export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const { picks, shortages } = allocate(parseOrders(ordersText), stock);
  return { picks: walkOrder(picks), shortages };
}

function parseOrders(text: string): Order[] {
  const orders: Order[] = [];
  const rejectIfEmpty = (order: Order | undefined) => {
    if (order && order.items.length === 0) throw new OrderFormatError(order.line, `order ${order.id} has no items`);
  };
  text.split("\n").forEach((raw, index) => {
    const lineNo = index + 1;
    const line = raw.trim();
    if (line === "" || line.startsWith("#")) return;
    const order = ORDER_LINE.exec(line);
    if (order) {
      rejectIfEmpty(orders.at(-1));
      if (orders.some((o) => o.id === order[1])) throw new OrderFormatError(lineNo, `duplicate order id ${order[1]}`);
      orders.push({ id: order[1], line: lineNo, priority: order[2] !== undefined, items: [] });
      return;
    }
    const current = orders.at(-1);
    if (!current) throw new OrderFormatError(lineNo, "item line before the first ORDER line");
    const item = ITEM_LINE.exec(line);
    if (!item) throw new OrderFormatError(lineNo, `unrecognised line: ${line}`);
    const existing = current.items.find((i) => i.sku === item[1]);
    if (existing) existing.qty += Number(item[2]);
    else current.items.push({ sku: item[1], qty: Number(item[2]) });
  });
  rejectIfEmpty(orders.at(-1));
  return orders;
}

/** First-expiry-first allocation; priority orders before the rest, picks in allocation order. */
function allocate(orders: Order[], stock: StockLot[]): PickList {
  const lots = stock
    .map((lot) => ({ ...lot }))
    .sort((a, b) => compareExpiry(a.expires, b.expires) || compare(a.bin, b.bin));
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of served) {
    for (const item of order.items) {
      let wanted = item.qty;
      for (const lot of lots) {
        if (wanted === 0) break;
        if (lot.sku !== item.sku || lot.qty === 0) continue;
        const taken = Math.min(wanted, lot.qty);
        lot.qty -= taken;
        wanted -= taken;
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (wanted > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: wanted });
    }
  }
  return { picks, shortages };
}

/** Undated lots sort after all dated ones. */
function compareExpiry(a: string | null, b: string | null): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return compare(a, b);
}

/** Serpentine: aisles alphabetically, racks up/down alternating per visited aisle, levels up; stable per bin. */
function walkOrder(picks: Pick[]): Pick[] {
  const located = picks.map((pick) => {
    const [aisle, rack, level] = pick.bin.split("-");
    return { pick, aisle, rack: Number(rack), level: Number(level) };
  });
  const aisles = [...new Set(located.map((l) => l.aisle))].sort(compare);
  return located
    .sort((a, b) => {
      if (a.aisle !== b.aisle) return compare(a.aisle, b.aisle);
      const direction = aisles.indexOf(a.aisle) % 2 === 0 ? 1 : -1;
      return (a.rack - b.rack) * direction || a.level - b.level;
    })
    .map((l) => l.pick);
}
