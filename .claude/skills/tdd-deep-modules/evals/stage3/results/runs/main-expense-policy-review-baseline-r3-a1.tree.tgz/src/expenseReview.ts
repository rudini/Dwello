export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

const REQUIRED_COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof REQUIRED_COLUMNS)[number];

/** Splits one CSV line into trimmed fields; quoted fields may contain commas and "" for a quote. */
function parseFields(line: string): string[] {
  const fields: string[] = [];
  let i = 0;
  for (;;) {
    let value = "";
    while (line[i] === " " || line[i] === "\t") i++;
    if (line[i] === '"') {
      i++;
      while (i < line.length) {
        if (line[i] === '"') {
          if (line[i + 1] !== '"') {
            i++;
            break;
          }
          value += '"';
          i += 2;
        } else {
          value += line[i++];
        }
      }
    }
    // Unquoted value, or stray characters after a closing quote.
    while (i < line.length && line[i] !== ",") value += line[i++];
    fields.push(value.trim());
    if (i >= line.length) return fields;
    i++; // skip the comma
  }
}

function isValidDate(value: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1) return false;
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return day <= daysInMonth;
}

/** Parses an amount like "12", "12.5" or "12.50" into integer cents; null if invalid or not positive. */
function parseAmountCents(value: string): bigint | null {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(value);
  if (!match) return null;
  const cents = BigInt(match[1]) * 100n + BigInt((match[2] ?? "").padEnd(2, "0"));
  return cents > 0n ? cents : null;
}

/** Multiplies cents by the rate and rounds to the nearest cent, halves up, using exact decimal arithmetic. */
function convertCents(amountCents: bigint, rate: number): number {
  if (rate === 1) return Number(amountCents);
  // Take the rate exactly as its shortest decimal form: numerator / 10^scale.
  const match = /^(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/i.exec(String(rate));
  if (!match) return Math.floor(Number(amountCents) * rate + 0.5);
  const fraction = match[2] ?? "";
  let numerator = BigInt(match[1] + fraction);
  let scale = fraction.length - Number(match[3] ?? 0);
  if (scale < 0) {
    numerator *= 10n ** BigInt(-scale);
    scale = 0;
  }
  const denominator = 10n ** BigInt(scale);
  return Number((2n * amountCents * numerator + denominator) / (2n * denominator));
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const physicalLines = csv.split("\n").map((line) => (line.endsWith("\r") ? line.slice(0, -1) : line));

  let columns: Record<Column, number> | null = null;
  let headerLength = 0;
  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const seen = new Set<string>();
  const dailyTotals = new Map<string, number>();
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();

  for (let index = 0; index < physicalLines.length; index++) {
    const raw = physicalLines[index];
    if (raw.trim() === "") continue;
    const lineNumber = index + 1;

    if (columns === null) {
      const names = parseFields(raw).map((name) => name.toLowerCase());
      const found = {} as Record<Column, number>;
      for (const column of REQUIRED_COLUMNS) {
        const position = names.indexOf(column);
        if (position < 0) throw new ExpenseFileError(`Missing column: ${column}`);
        found[column] = position;
      }
      columns = found;
      headerLength = names.length;
      continue;
    }

    const fields = parseFields(raw);
    const reject = (reason: string) => rejected.push({ line: lineNumber, reason });

    if (fields.length !== headerLength) {
      reject("wrong number of fields");
      continue;
    }
    const date = fields[columns.date];
    const employee = fields[columns.employee];
    const category = fields[columns.category];
    const currency = fields[columns.currency];
    const receipt = fields[columns.receipt].toLowerCase();

    if (!isValidDate(date)) {
      reject("invalid date");
      continue;
    }
    if (employee === "") {
      reject("missing employee");
      continue;
    }
    if (!Object.hasOwn(policy.categories, category)) {
      reject("unknown category");
      continue;
    }
    const amountCents = parseAmountCents(fields[columns.amount]);
    if (amountCents === null) {
      reject("invalid amount");
      continue;
    }
    if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) {
      reject("unknown currency");
      continue;
    }
    if (receipt !== "yes" && receipt !== "no") {
      reject("invalid receipt flag");
      continue;
    }

    const amountChfCents = convertCents(amountCents, currency === "CHF" ? 1 : fxRates[currency]);
    const categoryPolicy = policy.categories[category];
    const violations: Violation[] = [];

    const duplicateKey = JSON.stringify([employee, date, category, amountCents.toString(), currency]);
    if (seen.has(duplicateKey)) violations.push("DUPLICATE");
    seen.add(duplicateKey);

    if (categoryPolicy.perItemLimitCents !== undefined && amountChfCents > categoryPolicy.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }

    const dailyKey = JSON.stringify([employee, date, category]);
    const dailyTotal = (dailyTotals.get(dailyKey) ?? 0) + amountChfCents;
    dailyTotals.set(dailyKey, dailyTotal);
    if (categoryPolicy.dailyLimitCents !== undefined && dailyTotal > categoryPolicy.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }

    if (receipt === "no" && amountChfCents > policy.receiptRequiredAboveCents) {
      violations.push("NO_RECEIPT");
    }

    lines.push({ line: lineNumber, date, employee, category, amountChfCents, violations });

    const employeeTotals = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    if (violations.length === 0) employeeTotals.approvedCents += amountChfCents;
    else employeeTotals.flaggedCents += amountChfCents;
    totals.set(employee, employeeTotals);
  }

  if (columns === null) throw new ExpenseFileError("Missing header");

  // fromEntries defines own properties, so names like "__proto__" are safe.
  return { lines, rejected, totals: Object.fromEntries(totals) };
}
