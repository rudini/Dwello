import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type Policy } from "./expenseReview";

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2500,
};
const fx = { EUR: 0.9412, USD: 0.8 };

test("missing header and columns", () => {
  expect(() => reviewExpenses(" \n\r\n", policy, fx)).toThrow(new ExpenseFileError("Missing header"));
  expect(() => reviewExpenses("date,employee,amount,receipt\n", policy, fx)).toThrow(
    new ExpenseFileError("Missing column: category"),
  );
});

test("full review", () => {
  const csv = [
    "",
    " Receipt , DATE,employee,category,amount,currency,note",
    'yes,2024-03-01,"Muster, Anna",meals,12.5,CHF,"say ""hi"""',
    'yes,2024-03-01,"Muster, Anna",meals,12.50,CHF,x',
    "no,2024-03-01,Bob,meals,60,EUR,",
    "   ",
    "yes,2024-02-30,Bob,meals,1,CHF,",
    "yes,2024-02-29,,meals,1,CHF,",
    "yes,2024-02-29,Bob,Meals,1,CHF,",
    "yes,2024-02-29,Bob,meals,1.234,CHF,",
    "yes,2024-02-29,Bob,meals,0.00,CHF,",
    "yes,2024-02-29,Bob,meals,1,GBP,",
    "maybe,2024-02-29,Bob,meals,1,CHF,",
    "yes,2024-02-29,Bob,meals,1,CHF",
    "YES,2024-02-29,Bob,taxi,10.05,USD,\r",
    "",
  ].join("\n");
  const report = reviewExpenses(csv, policy, fx);
  expect(report.lines).toEqual([
    { line: 3, date: "2024-03-01", employee: "Muster, Anna", category: "meals", amountChfCents: 1250, violations: [] },
    {
      line: 4,
      date: "2024-03-01",
      employee: "Muster, Anna",
      category: "meals",
      amountChfCents: 1250,
      violations: ["DUPLICATE"],
    },
    {
      line: 5,
      date: "2024-03-01",
      employee: "Bob",
      category: "meals",
      amountChfCents: 5647,
      violations: ["OVER_ITEM_LIMIT", "NO_RECEIPT"],
    },
    { line: 15, date: "2024-02-29", employee: "Bob", category: "taxi", amountChfCents: 804, violations: [] },
  ]);
  expect(report.rejected).toEqual([
    { line: 7, reason: "invalid date" },
    { line: 8, reason: "missing employee" },
    { line: 9, reason: "unknown category" },
    { line: 10, reason: "invalid amount" },
    { line: 11, reason: "invalid amount" },
    { line: 12, reason: "unknown currency" },
    { line: 13, reason: "invalid receipt flag" },
    { line: 14, reason: "wrong number of fields" },
  ]);
  expect(report.totals).toEqual({
    "Muster, Anna": { approvedCents: 1250, flaggedCents: 1250 },
    Bob: { approvedCents: 804, flaggedCents: 5647 },
  });
});

test("daily limit uses a running total and rounding is exact", () => {
  const csv =
    "date,employee,category,amount,currency,receipt\n" +
    "2024-01-01,A,meals,40,CHF,yes\n" +
    "2024-01-01,A,meals,40,CHF,yes\n" +
    "2024-01-01,A,meals,0.01,CHF,yes\n" +
    "2024-01-02,A,taxi,1.05,X,yes\n";
  const report = reviewExpenses(csv, policy, { X: 0.5 });
  expect(report.lines.map((l) => l.violations)).toEqual([[], ["DUPLICATE"], ["OVER_DAILY_LIMIT"], []]);
  expect(report.lines[3].amountChfCents).toBe(53); // 52.5 rounds up
});
