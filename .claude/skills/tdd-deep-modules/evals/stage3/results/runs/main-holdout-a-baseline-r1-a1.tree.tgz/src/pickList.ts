export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface OrderItem {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  items: OrderItem[];
}

const ORDER_LINE = /^ORDER +([A-Za-z0-9-]+)( +!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/;

function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const seenIds = new Set<string>();
  const problems: { line: number; description: string }[] = [];
  let current: Order | null = null;
  let currentLine = 0;

  const checkNotEmpty = (order: Order | null, line: number) => {
    if (order && order.items.length === 0) {
      problems.push({ line, description: `order ${order.id} has no items` });
    }
  };

  const lines = ordersText.split(/\r?\n/);
  for (let index = 0; index < lines.length; index++) {
    const lineNo = index + 1;
    const line = lines[index].trim();
    if (line === "" || line.startsWith("#")) continue;

    const orderMatch = ORDER_LINE.exec(line);
    if (orderMatch) {
      checkNotEmpty(current, currentLine);
      const id = orderMatch[1];
      const order: Order = { id, priority: orderMatch[2] !== undefined, items: [] };
      if (seenIds.has(id)) {
        problems.push({ line: lineNo, description: `duplicate order id ${id}` });
      } else {
        seenIds.add(id);
        orders.push(order);
      }
      current = order;
      currentLine = lineNo;
      continue;
    }

    const itemMatch = ITEM_LINE.exec(line);
    if (itemMatch) {
      if (!current) {
        problems.push({ line: lineNo, description: "item line before the first ORDER line" });
        continue;
      }
      const sku = itemMatch[1];
      const qty = Number(itemMatch[2]);
      const existing = current.items.find((item) => item.sku === sku);
      if (existing) existing.qty += qty;
      else current.items.push({ sku, qty });
      continue;
    }

    problems.push({ line: lineNo, description: `unrecognized line "${line}"` });
  }
  checkNotEmpty(current, currentLine);

  if (problems.length > 0) {
    const first = problems.reduce((a, b) => (b.line < a.line ? b : a));
    throw new OrderFormatError(first.line, first.description);
  }
  return orders;
}

function compareLots(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return a.expires < b.expires ? -1 : 1;
  }
  return a.bin < b.bin ? -1 : a.bin > b.bin ? 1 : 0;
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "", level = ""] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

function walkOrder(picks: Pick[]): Pick[] {
  const parsed = picks.map((pick, index) => ({ pick, index, ...parseBin(pick.bin) }));
  const aisles = [...new Set(parsed.map((p) => p.aisle))].sort();
  const aisleRank = new Map(aisles.map((aisle, i) => [aisle, i]));
  parsed.sort((a, b) => {
    const ra = aisleRank.get(a.aisle)!;
    const rb = aisleRank.get(b.aisle)!;
    if (ra !== rb) return ra - rb;
    // Serpentine: 1st, 3rd, ... visited aisle ascending, the others descending.
    if (a.rack !== b.rack) return ra % 2 === 0 ? a.rack - b.rack : b.rack - a.rack;
    if (a.level !== b.level) return a.level - b.level;
    return a.index - b.index;
  });
  return parsed.map((p) => p.pick);
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);
  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];

  // Remaining quantities are tracked separately so the caller's stock stays untouched.
  const lotsBySku = new Map<string, { lot: StockLot; left: number }[]>();
  for (const lot of stock) {
    let lots = lotsBySku.get(lot.sku);
    if (!lots) lotsBySku.set(lot.sku, (lots = []));
    lots.push({ lot, left: lot.qty });
  }
  for (const lots of lotsBySku.values()) lots.sort((a, b) => compareLots(a.lot, b.lot));

  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  for (const order of served) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const entry of lotsBySku.get(item.sku) ?? []) {
        if (needed === 0) break;
        if (entry.left <= 0) continue;
        const taken = Math.min(needed, entry.left);
        entry.left -= taken;
        needed -= taken;
        picks.push({ bin: entry.lot.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
    }
  }

  return { picks: walkOrder(picks), shortages };
}
