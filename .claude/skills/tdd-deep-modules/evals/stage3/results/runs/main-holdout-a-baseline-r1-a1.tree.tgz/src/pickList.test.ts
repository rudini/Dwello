import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

function errorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (e) {
    expect(e).toBeInstanceOf(OrderFormatError);
    return (e as OrderFormatError).line;
  }
  return undefined;
}

test("parses the example and allocates earliest expiry first, priority orders first", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
    "",
  ].join("\n");
  const stock: StockLot[] = [
    { bin: "B-01-1", sku: "OLIVE-500", qty: 2, expires: null },
    { bin: "A-02-1", sku: "OLIVE-500", qty: 2, expires: "2027-01-01" },
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, expires: "2027-01-01" },
  ];
  const snapshot = structuredClone(stock);
  const result = buildPickList(text, stock);
  expect(stock).toEqual(snapshot);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1002" },
    { bin: "A-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "B-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
  ]);
  expect(result.shortages).toEqual([{ orderId: "1001", sku: "PASTA-1KG", missing: 1 }]);
});

test("merges duplicate SKUs within an order at their first position", () => {
  const text = "ORDER A\nX x1\nY x1\nX   x2";
  const stock: StockLot[] = [{ bin: "A-01-1", sku: "X", qty: 1, expires: null }];
  expect(buildPickList(text, stock).shortages).toEqual([
    { orderId: "A", sku: "X", missing: 2 },
    { orderId: "A", sku: "Y", missing: 1 },
  ]);
});

test("picks follow the serpentine walk", () => {
  const bins = ["C-01-1", "A-02-1", "C-02-2", "A-01-2", "A-01-1", "C-02-1"];
  const stock = bins.map((bin) => ({ bin, sku: "S", qty: 1, expires: null }));
  expect(buildPickList("ORDER 1\nS x9", stock).picks.map((p) => p.bin)).toEqual([
    "A-01-1",
    "A-01-2",
    "A-02-1",
    "C-02-1",
    "C-02-2",
    "C-01-1",
  ]);
});

test("format errors report the first problem from the top", () => {
  expect(errorLine("X x1\nORDER 1\nX x1")).toBe(1);
  expect(errorLine("ORDER 1\nX x1\nORDER 1\nX x1")).toBe(3);
  expect(errorLine("ORDER 1\n\nORDER 2\nX x1")).toBe(1);
  expect(errorLine("ORDER 1\nX x1\nORDER 2")).toBe(3);
  expect(errorLine("ORDER 1\nX x0")).toBe(1); // order without items comes first
  expect(errorLine("ORDER 1\nY x1\nX x0")).toBe(3);
  expect(errorLine("ORDER 1\nY x1\nX x03")).toBe(3);
  expect(errorLine("ORDER 1\nY x1\nx x3")).toBe(3);
  expect(errorLine("ORDER 1\nY x1\nX 3")).toBe(3);
  expect(errorLine("ORDER 1!\nX x1")).toBe(1);
  expect(errorLine("# c\nORDER 1   !\n  X x1  ")).toBeUndefined();
});
