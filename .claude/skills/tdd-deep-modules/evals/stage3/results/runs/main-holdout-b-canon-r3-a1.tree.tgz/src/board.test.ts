import { describe, expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode, type ColumnConfig } from "./board";

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

const defaultColumns: ColumnConfig[] = [
  { name: "Backlog" },
  { name: "Doing" },
  { name: "Review" },
  { name: "Done" },
];

function setup(columns: ColumnConfig[] = defaultColumns) {
  const clock = { t: 1_000 };
  const board = createBoard({ columns, now: () => clock.t });
  return { board, clock };
}

function expectBoardError(fn: () => unknown, code: BoardErrorCode) {
  let caught: unknown;
  try {
    fn();
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(BoardError);
  expect((caught as BoardError).code).toBe(code);
}

describe("adding", () => {
  test("addCard returns sequential ids and appends to the first column", () => {
    const { board } = setup();
    expect(board.addCard("first")).toBe("C1");
    expect(board.addCard("second")).toBe("C2");
    expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
    expect(board.cardsIn("Doing")).toEqual([]);
  });

  test("empty or whitespace title throws EMPTY_TITLE and does not consume an id", () => {
    const { board } = setup();
    expectBoardError(() => board.addCard(""), "EMPTY_TITLE");
    expectBoardError(() => board.addCard("   \t\n"), "EMPTY_TITLE");
    expect(board.cardsIn("Backlog")).toEqual([]);
    expect(board.addCard("real")).toBe("C1");
  });

  test("adding to a full first column throws WIP_LIMIT and does not consume an id", () => {
    const { board } = setup([{ name: "Backlog", wipLimit: 2 }, { name: "Done" }]);
    board.addCard("a");
    board.addCard("b");
    expectBoardError(() => board.addCard("c"), "WIP_LIMIT");
    expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
    board.move("C1", "Done");
    expect(board.addCard("c")).toBe("C3");
  });
});

describe("moving", () => {
  test("moving forward by one puts the card at the end of the target column", () => {
    const { board } = setup();
    board.addCard("a");
    board.addCard("b");
    board.addCard("c");
    board.move("C2", "Doing");
    board.move("C1", "Doing");
    expect(board.cardsIn("Backlog")).toEqual(["C3"]);
    expect(board.cardsIn("Doing")).toEqual(["C2", "C1"]);
  });

  test("moving an unknown card throws UNKNOWN_CARD, even to an unknown column", () => {
    const { board } = setup();
    expectBoardError(() => board.move("C1", "Doing"), "UNKNOWN_CARD");
    expectBoardError(() => board.move("C1", "Nope"), "UNKNOWN_CARD");
  });

  test("moving to an unknown column throws UNKNOWN_COLUMN", () => {
    const { board } = setup();
    board.addCard("a");
    expectBoardError(() => board.move("C1", "Nope"), "UNKNOWN_COLUMN");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  });

  test("moving to the card's own column throws SAME_COLUMN, even when blocked or full", () => {
    const { board } = setup([{ name: "Backlog", wipLimit: 1 }, { name: "Done" }]);
    board.addCard("a");
    expectBoardError(() => board.move("C1", "Backlog"), "SAME_COLUMN");
    board.block("C1", "waiting");
    expectBoardError(() => board.move("C1", "Backlog"), "SAME_COLUMN");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  });

  test("moving a blocked card throws BLOCKED, before skip and WIP checks", () => {
    const { board } = setup([{ name: "Backlog" }, { name: "Doing", wipLimit: 0 }, { name: "Review" }, { name: "Done" }]);
    board.addCard("a");
    board.block("C1", "waiting");
    expectBoardError(() => board.move("C1", "Doing"), "BLOCKED");
    expectBoardError(() => board.move("C1", "Done"), "BLOCKED");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  });

  test("moving forward by more than one column throws SKIP_NOT_ALLOWED, before the WIP check", () => {
    const { board } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Review", wipLimit: 0 }, { name: "Done" }]);
    board.addCard("a");
    expectBoardError(() => board.move("C1", "Review"), "SKIP_NOT_ALLOWED");
    expectBoardError(() => board.move("C1", "Done"), "SKIP_NOT_ALLOWED");
    expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  });

  test("moving backwards by several columns is allowed", () => {
    const { board } = setup();
    board.addCard("a");
    board.addCard("b");
    board.move("C1", "Doing");
    board.move("C1", "Review");
    board.move("C1", "Done");
    board.move("C1", "Backlog");
    expect(board.cardsIn("Backlog")).toEqual(["C2", "C1"]);
    expect(board.cardsIn("Done")).toEqual([]);
  });

  test("moving into a full column throws WIP_LIMIT; blocked cards count", () => {
    const { board } = setup([{ name: "Backlog" }, { name: "Doing", wipLimit: 1 }, { name: "Done" }]);
    board.addCard("a");
    board.addCard("b");
    board.move("C1", "Doing");
    board.block("C1", "waiting");
    expectBoardError(() => board.move("C2", "Doing"), "WIP_LIMIT");
    expect(board.cardsIn("Backlog")).toEqual(["C2"]);
    expect(board.cardsIn("Doing")).toEqual(["C1"]);
  });
});

describe("blocking", () => {
  test("block and unblock reject unknown cards", () => {
    const { board } = setup();
    expectBoardError(() => board.block("C1", "x"), "UNKNOWN_CARD");
    expectBoardError(() => board.unblock("C1"), "UNKNOWN_CARD");
  });

  test("blocking twice throws ALREADY_BLOCKED; unblocking an unblocked card throws NOT_BLOCKED", () => {
    const { board } = setup();
    board.addCard("a");
    expectBoardError(() => board.unblock("C1"), "NOT_BLOCKED");
    board.block("C1", "waiting");
    expectBoardError(() => board.block("C1", "again"), "ALREADY_BLOCKED");
    board.unblock("C1");
    board.move("C1", "Doing");
    expect(board.cardsIn("Doing")).toEqual(["C1"]);
  });
});

describe("cycle time", () => {
  test("unknown card throws UNKNOWN_CARD", () => {
    const { board } = setup();
    expectBoardError(() => board.cycleTime("C1"), "UNKNOWN_CARD");
  });

  test("is null unless the card is in the last column", () => {
    const { board } = setup();
    board.addCard("a");
    expect(board.cycleTime("C1")).toBeNull();
    board.move("C1", "Doing");
    expect(board.cycleTime("C1")).toBeNull();
  });

  test("totalMs runs from leaving the first column to arriving in the last", () => {
    const { board, clock } = setup();
    board.addCard("a");
    clock.t = 5_000;
    board.move("C1", "Doing");
    clock.t = 8_000;
    board.move("C1", "Review");
    clock.t = 12_000;
    board.move("C1", "Done");
    clock.t = 20_000;
    expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 0 });
  });

  test("start is the first departure from the first column; finish is the latest arrival in the last", () => {
    const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.t = 2_000;
    board.move("C1", "Doing");
    clock.t = 3_000;
    board.move("C1", "Backlog");
    clock.t = 4_000;
    board.move("C1", "Doing");
    clock.t = 5_000;
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 3_000, blockedMs: 0 });
    clock.t = 6_000;
    board.move("C1", "Doing");
    expect(board.cycleTime("C1")).toBeNull();
    clock.t = 9_000;
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 0 });
  });

  test("a two-column board starts and finishes on the same move", () => {
    const { board, clock } = setup([{ name: "Todo" }, { name: "Done" }]);
    board.addCard("a");
    clock.t = 2_000;
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 0, blockedMs: 0 });
  });

  test("blockedMs sums blocked periods between start and finish", () => {
    const { board, clock } = setup();
    board.addCard("a");
    clock.t = 2_000;
    board.move("C1", "Doing");
    clock.t = 3_000;
    board.block("C1", "waiting for customer");
    clock.t = 4_500;
    board.unblock("C1");
    clock.t = 5_000;
    board.move("C1", "Review");
    clock.t = 6_000;
    board.block("C1", "reviewer away");
    clock.t = 6_250;
    board.unblock("C1");
    clock.t = 7_000;
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 5_000, blockedMs: 1_750 });
  });

  test("blocked time before start is not counted", () => {
    const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.t = 2_000;
    board.block("C1", "unclear");
    clock.t = 5_000;
    board.unblock("C1");
    clock.t = 6_000;
    board.move("C1", "Doing");
    clock.t = 7_000;
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 1_000, blockedMs: 0 });
  });

  test("blocked time after finish is not counted, including an ongoing block", () => {
    const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.t = 2_000;
    board.move("C1", "Doing");
    clock.t = 3_000;
    board.move("C1", "Done");
    clock.t = 4_000;
    board.block("C1", "follow-up");
    clock.t = 9_000;
    expect(board.cycleTime("C1")).toEqual({ totalMs: 1_000, blockedMs: 0 });
    board.unblock("C1");
    clock.t = 10_000;
    expect(board.cycleTime("C1")).toEqual({ totalMs: 1_000, blockedMs: 0 });
  });

  test("blocked periods from earlier trips through Done count once the card finishes again", () => {
    const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
    board.addCard("a");
    clock.t = 2_000;
    board.move("C1", "Doing");
    clock.t = 3_000;
    board.move("C1", "Done");
    clock.t = 4_000;
    board.block("C1", "reopened");
    clock.t = 6_000;
    board.unblock("C1");
    board.move("C1", "Doing");
    clock.t = 8_000;
    board.move("C1", "Done");
    expect(board.cycleTime("C1")).toEqual({ totalMs: 6_000, blockedMs: 2_000 });
  });
});

describe("failed operations", () => {
  test("a rejected move does not start the card's clock", () => {
    const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing", wipLimit: 1 }, { name: "Done" }]);
    board.addCard("a");
    board.addCard("b");
    board.move("C1", "Doing");
    clock.t = 2_000;
    expectBoardError(() => board.move("C2", "Doing"), "WIP_LIMIT");
    board.block("C2", "x");
    expectBoardError(() => board.block("C2", "y"), "ALREADY_BLOCKED");
    clock.t = 3_000;
    board.unblock("C2");
    board.move("C1", "Done");
    clock.t = 4_000;
    board.move("C2", "Doing");
    clock.t = 6_000;
    board.move("C2", "Done");
    expect(board.cardsIn("Done")).toEqual(["C1", "C2"]);
    expect(board.cycleTime("C2")).toEqual({ totalMs: 2_000, blockedMs: 0 });
  });
});

describe("listing", () => {
  test("cardsIn an unknown column throws UNKNOWN_COLUMN", () => {
    const { board } = setup();
    expectBoardError(() => board.cardsIn("Nope"), "UNKNOWN_COLUMN");
  });
});
