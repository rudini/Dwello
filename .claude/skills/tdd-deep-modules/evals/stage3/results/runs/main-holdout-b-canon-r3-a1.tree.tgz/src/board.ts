export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Card {
  column: number;
  /** The last period is still open (`to: Infinity`) while the card is blocked. */
  blockedPeriods: { from: number; to: number }[];
  startedAt?: number;
  finishedAt?: number;
}

function isBlocked(card: Card): boolean {
  return card.blockedPeriods.at(-1)?.to === Infinity;
}

export function createBoard(options: BoardOptions): Board {
  const columns = options.columns.map((config) => ({ config, cards: [] as string[] }));
  const lastColumn = columns.length - 1;
  const cards = new Map<string, Card>();
  let nextId = 1;

  function columnIndex(name: string): number {
    const index = columns.findIndex((c) => c.config.name === name);
    if (index < 0) throw new BoardError("UNKNOWN_COLUMN", `Unknown column ${name}`);
    return index;
  }

  function getCard(id: string): Card {
    const card = cards.get(id);
    if (!card) throw new BoardError("UNKNOWN_CARD", `Unknown card ${id}`);
    return card;
  }

  function ensureRoom(index: number): void {
    const { config, cards } = columns[index]!;
    if (config.wipLimit !== undefined && cards.length >= config.wipLimit) {
      throw new BoardError("WIP_LIMIT", `Column ${config.name} is full`);
    }
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Title must not be empty");
      ensureRoom(0);
      const id = `C${nextId++}`;
      cards.set(id, { column: 0, blockedPeriods: [] });
      columns[0]!.cards.push(id);
      return id;
    },
    move(cardId, toColumn) {
      const card = getCard(cardId);
      const to = columnIndex(toColumn);
      if (to === card.column) throw new BoardError("SAME_COLUMN", `${cardId} is already in ${toColumn}`);
      if (isBlocked(card)) throw new BoardError("BLOCKED", `${cardId} is blocked`);
      if (to > card.column + 1) throw new BoardError("SKIP_NOT_ALLOWED", `${cardId} cannot skip columns`);
      ensureRoom(to);
      const from = columns[card.column]!.cards;
      from.splice(from.indexOf(cardId), 1);
      columns[to]!.cards.push(cardId);
      const now = options.now();
      if (card.column === 0 && card.startedAt === undefined) card.startedAt = now;
      if (to === lastColumn) card.finishedAt = now;
      card.column = to;
    },
    block(cardId, _reason) {
      const card = getCard(cardId);
      if (isBlocked(card)) throw new BoardError("ALREADY_BLOCKED", `${cardId} is already blocked`);
      card.blockedPeriods.push({ from: options.now(), to: Infinity });
    },
    unblock(cardId) {
      const card = getCard(cardId);
      if (!isBlocked(card)) throw new BoardError("NOT_BLOCKED", `${cardId} is not blocked`);
      card.blockedPeriods.at(-1)!.to = options.now();
    },
    cardsIn(column) {
      return [...columns[columnIndex(column)]!.cards];
    },
    cycleTime(cardId) {
      const card = getCard(cardId);
      if (card.column !== lastColumn) return null;
      const started = card.startedAt!;
      const finished = card.finishedAt!;
      let blockedMs = 0;
      for (const { from, to } of card.blockedPeriods) {
        blockedMs += Math.max(0, Math.min(to, finished) - Math.max(from, started));
      }
      return { totalMs: finished - started, blockedMs };
    },
  };
}
