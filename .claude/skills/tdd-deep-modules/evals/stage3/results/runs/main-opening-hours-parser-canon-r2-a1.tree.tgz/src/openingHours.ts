export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "invalid" | "end";

interface Token {
  kind: TokenKind;
  text: string;
  column: number;
}

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const start = i;
    const ch = text[i];
    if (ch === " ") {
      i++;
      continue;
    }
    let kind: TokenKind;
    if (/[A-Za-z]/.test(ch)) {
      while (i < text.length && /[A-Za-z]/.test(text[i])) i++;
      kind = "word";
    } else if (/[0-9:]/.test(ch)) {
      while (i < text.length && /[0-9:]/.test(text[i])) i++;
      kind = "time";
    } else {
      i++;
      kind = ch === "-" || ch === "," || ch === ";" ? ch : "invalid";
    }
    tokens.push({ kind, text: text.slice(start, i), column: start + 1 });
  }
  tokens.push({ kind: "end", text: "", column: text.length + 1 });
  return tokens;
}

function unexpected(token: Token): OpeningHoursError {
  const description = token.kind === "end" ? "Unexpected end of text" : `Unexpected "${token.text}"`;
  return new OpeningHoursError("UNEXPECTED", token.column, description);
}

class Parser {
  private readonly tokens: Token[];
  private pos = 0;

  constructor(text: string) {
    this.tokens = tokenize(text);
  }

  // spec = rule { ";" rule }
  parseSpec(): WeeklyHours {
    if (this.peek().kind === "end") throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
    const week = Object.fromEntries(DAYS.map((day) => [day, []])) as unknown as WeeklyHours;
    do {
      const { days, ranges } = this.parseRule();
      for (const day of days) week[day] = ranges.map((range) => ({ ...range }));
    } while (this.accept(";"));
    this.expect("end");
    return week;
  }

  // rule = days ( ranges | "off" )
  private parseRule(): { days: Day[]; ranges: TimeRange[] } {
    const days = this.parseDays();
    if (this.peek().kind === "word" && this.peek().text === "off") {
      this.next();
      return { days, ranges: [] };
    }
    return { days, ranges: this.parseRanges() };
  }

  // days = dayItem { "," dayItem }
  private parseDays(): Day[] {
    const days: Day[] = [];
    do {
      const column = this.peek().column;
      const item = this.parseDayItem();
      const duplicate = item.find((day) => days.includes(day));
      if (duplicate) {
        throw new OpeningHoursError("DUPLICATE_DAY", column, `Day ${duplicate} is named more than once`);
      }
      days.push(...item);
    } while (this.accept(","));
    return days;
  }

  // dayItem = DAY [ "-" DAY ]
  private parseDayItem(): Day[] {
    const first = this.parseDay();
    let last = first;
    if (this.accept("-")) last = this.parseDay();
    const days: Day[] = [];
    for (let i = first; ; i = (i + 1) % DAYS.length) {
      days.push(DAYS[i]);
      if (i === last) return days;
    }
  }

  // DAY, returned as its index in DAYS
  private parseDay(): number {
    const token = this.expect("word");
    const index = DAYS.indexOf(token.text as Day);
    if (index < 0) throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    return index;
  }

  // ranges = range { "," range }
  private parseRanges(): TimeRange[] {
    const ranges: TimeRange[] = [];
    do {
      const column = this.peek().column;
      const range = this.parseRange();
      const earlier = ranges.find((other) => range.from < other.to && other.from < range.to);
      if (earlier) {
        throw new OpeningHoursError(
          "OVERLAP",
          column,
          `Range ${range.from}-${range.to} overlaps ${earlier.from}-${earlier.to}`,
        );
      }
      ranges.push(range);
    } while (this.accept(","));
    return ranges.sort((a, b) => a.from.localeCompare(b.from));
  }

  // range = TIME "-" TIME
  private parseRange(): TimeRange {
    const from = this.parseTime(false);
    this.expect("-");
    const to = this.parseTime(true);
    // Valid times are fixed-width "HH:MM", so string order is chronological order.
    if (to.text <= from.text) {
      throw new OpeningHoursError("END_BEFORE_START", from.column, `Range ${from.text}-${to.text} ends before it starts`);
    }
    return { from: from.text, to: to.text };
  }

  // TIME = HH:MM, 00:00-23:59, or 24:00 at the end of a range
  private parseTime(isEnd: boolean): Token {
    const token = this.expect("time");
    const match = /^(\d\d):(\d\d)$/.exec(token.text);
    const valid =
      match !== null &&
      ((Number(match[1]) <= 23 && Number(match[2]) <= 59) || (isEnd && token.text === "24:00"));
    if (!valid) throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    return token;
  }

  private peek(): Token {
    return this.tokens[this.pos];
  }

  private next(): Token {
    return this.tokens[this.pos++];
  }

  private expect(kind: TokenKind): Token {
    const token = this.next();
    if (token.kind !== kind) throw unexpected(token);
    return token;
  }

  private accept(kind: TokenKind): boolean {
    if (this.peek().kind !== kind) return false;
    this.pos++;
    return true;
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  return new Parser(text).parseSpec();
}
