import { describe, expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

const closedWeek = () => ({ Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] });

describe("parsing valid opening hours", () => {
  test("a single day with a single range", () => {
    expect(parseOpeningHours("Mo 08:00-12:00")).toEqual({
      ...closedWeek(),
      Mo: [{ from: "08:00", to: "12:00" }],
    });
  });

  test("a closed day", () => {
    expect(parseOpeningHours("Su off")).toEqual(closedWeek());
  });

  test("a day range", () => {
    const range = [{ from: "09:00", to: "17:00" }];
    expect(parseOpeningHours("Mo-Fr 09:00-17:00")).toEqual({
      ...closedWeek(),
      Mo: range, Tu: range, We: range, Th: range, Fr: range,
    });
  });

  test("a day range wraps around the end of the week", () => {
    const range = [{ from: "09:00", to: "17:00" }];
    expect(parseOpeningHours("Fr-Mo 09:00-17:00")).toEqual({
      ...closedWeek(),
      Fr: range, Sa: range, Su: range, Mo: range,
    });
  });

  test("a day range from a day to itself names only that day", () => {
    expect(parseOpeningHours("Mo-Mo 09:00-17:00")).toEqual({
      ...closedWeek(),
      Mo: [{ from: "09:00", to: "17:00" }],
    });
  });

  test("a list of day items", () => {
    const range = [{ from: "09:00", to: "17:00" }];
    expect(parseOpeningHours("Mo,We,Fr-Sa 09:00-17:00")).toEqual({
      ...closedWeek(),
      Mo: range, We: range, Fr: range, Sa: range,
    });
  });

  test("several ranges are returned sorted by start time and may touch", () => {
    expect(parseOpeningHours("Mo 14:00-18:00,08:00-12:00,12:00-14:00")).toEqual({
      ...closedWeek(),
      Mo: [
        { from: "08:00", to: "12:00" },
        { from: "12:00", to: "14:00" },
        { from: "14:00", to: "18:00" },
      ],
    });
  });

  test("a later rule replaces the hours of the days it names", () => {
    const morning = [{ from: "08:00", to: "12:00" }];
    expect(parseOpeningHours("Mo-Fr 08:00-12:00;We 14:00-18:00;Sa-Su 10:00-11:00;Su off")).toEqual({
      Mo: morning, Tu: morning, Th: morning, Fr: morning,
      We: [{ from: "14:00", to: "18:00" }],
      Sa: [{ from: "10:00", to: "11:00" }],
      Su: [],
    });
  });

  test("spaces between tokens and around the text carry no meaning", () => {
    const range = [{ from: "08:00", to: "12:00" }];
    expect(parseOpeningHours("  Mo , We - Th 08:00 - 12:00 ;  Fr  off  ")).toEqual({
      ...closedWeek(),
      Mo: range, We: range, Th: range,
    });
  });

  test("24:00 is allowed as the end of a range", () => {
    expect(parseOpeningHours("Sa 18:00-24:00")).toEqual({
      ...closedWeek(),
      Sa: [{ from: "18:00", to: "24:00" }],
    });
  });

  test("a range may last until midnight", () => {
    expect(parseOpeningHours("Fr 23:00-24:00").Fr).toEqual([{ from: "23:00", to: "24:00" }]);
  });

  test("each day gets its own array", () => {
    const week = parseOpeningHours("Mo-Tu 08:00-12:00");
    week.Mo.push({ from: "13:00", to: "14:00" });
    week.Mo[0].to = "11:00";
    expect(week.Tu).toEqual([{ from: "08:00", to: "12:00" }]);
  });

  test("the example from the specification", () => {
    const weekday = [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }];
    expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
      Mo: weekday, Tu: weekday, We: weekday, Th: weekday, Fr: weekday,
      Sa: [{ from: "09:00", to: "16:00" }],
      Su: [],
    });
  });
});

function errorOf(text: string): { code: string; column: number } {
  try {
    parseOpeningHours(text);
  } catch (error) {
    expect(error).toBeInstanceOf(OpeningHoursError);
    const { code, column } = error as OpeningHoursError;
    return { code, column };
  }
  throw new Error(`expected "${text}" to be rejected`);
}

describe("reporting errors", () => {
  test.each(["", "   "])("EMPTY for %p", (text) => {
    expect(errorOf(text)).toEqual({ code: "EMPTY", column: 1 });
  });

  test.each([
    ["Mo-Fx 08:00-12:00", 4],
    ["mo 08:00-12:00", 1],
    ["Mo,Tue 08:00-12:00", 4],
    ["Mo off; off", 9],
  ])("UNKNOWN_DAY for %p at column %p", (text, column) => {
    expect(errorOf(text)).toEqual({ code: "UNKNOWN_DAY", column });
  });

  test.each([
    ["Mo 8:00-12:00", 4],
    ["Mo 08:00-1200", 10],
    ["Mo 08:00-12:0", 10],
    ["Mo 08:00-12:000", 10],
    ["Mo 08:00-12:00:00", 10],
    ["Mo 25:00-26:00", 4],
    ["Mo 08:60-12:00", 4],
    ["Mo 24:00-24:00", 4],
    ["Mo 08:00-24:01", 10],
    ["Mo 08:00-:", 10],
  ])("INVALID_TIME for %p at column %p", (text, column) => {
    expect(errorOf(text)).toEqual({ code: "INVALID_TIME", column });
  });

  test.each([
    ["Mo 12:00-08:00", 4],
    ["Mo 08:00-12:00, 14:00 - 14:00", 17],
  ])("END_BEFORE_START for %p at column %p", (text, column) => {
    expect(errorOf(text)).toEqual({ code: "END_BEFORE_START", column });
  });

  test.each([
    ["Mo 08:00-12:00,11:00-13:00", 16],
    ["Mo 10:00-12:00,08:00-11:00", 16],
    ["Mo 08:00-18:00,12:00-13:00", 16],
    ["Mo 12:00-13:00,14:00-15:00,08:00-18:00", 28],
    ["Mo 08:00-12:00,08:00-12:00", 16],
    ["Mo 08:00-12:00,09:00-10:00,25:00-26:00", 16],
  ])("OVERLAP for %p at column %p", (text, column) => {
    expect(errorOf(text)).toEqual({ code: "OVERLAP", column });
  });

  test.each([
    ["Mo,Mo 08:00-12:00", 4],
    ["Mo-We,Tu 08:00-12:00", 7],
    ["Tu,Mo-We off", 4],
    ["Fr-Mo,Su-Tu off", 7],
    ["Mo,Mo @", 4],
  ])("DUPLICATE_DAY for %p at column %p", (text, column) => {
    expect(errorOf(text)).toEqual({ code: "DUPLICATE_DAY", column });
  });

  test("a day item is only checked for duplicates once it is complete", () => {
    expect(errorOf("Mo,Mo-Fx off")).toEqual({ code: "UNKNOWN_DAY", column: 7 });
  });

  test.each([
    // the text ends too early
    ["Mo 08:00-", 10],
    ["Mo off;", 8],
    ["Mo", 3],
    ["Mo-", 4],
    ["Mo,  ", 6],
    ["Mo 08:00-12:00,", 16],
    // a token that does not fit
    ["08:00-12:00", 1],
    ["Mo-08:00 off", 4],
    [";Mo off", 1],
    ["Mo off;;Tu off", 8],
    ["Mo Tu 08:00-09:00", 4],
    ["Mo Off", 4],
    ["Mo 08:00 12:00", 10],
    ["Mo 08:00-12:00-13:00", 15],
    ["Mo 08:00-12:00 off", 16],
    ["Mo 08:00-12:00 Tu off", 16],
    ["Mo 08:00-12:00,Tu off", 16],
    ["Mo off 08:00-09:00", 8],
    ["Mo off,Tu off", 7],
    // a character that belongs to no token
    ["@Mo off", 1],
    ["Mo @", 4],
    ["Mo\t08:00-12:00", 3],
    ["Mo 08:00@12:00", 9],
    ["Mo 08:00-12:00 @", 16],
  ])("UNEXPECTED for %p at column %p", (text, column) => {
    expect(errorOf(text)).toEqual({ code: "UNEXPECTED", column });
  });

  test.each([
    ["Mo 12:00-08:0", "INVALID_TIME", 10],
    ["Mo 08:0a-12:00", "INVALID_TIME", 4],
    ["Mo 12:00-08:00 @", "END_BEFORE_START", 4],
    ["Mo-Fx 25:00-26:00", "UNKNOWN_DAY", 4],
    ["Mo,Mo 25:00-26:00", "DUPLICATE_DAY", 4],
    ["Mo 08:00-12:00; Tu-Xx off", "UNKNOWN_DAY", 20],
  ])("the first problem from the left wins: %p", (text, code, column) => {
    expect(errorOf(text)).toEqual({ code, column });
  });

  test("the same day may appear in different rules", () => {
    expect(parseOpeningHours("Mo off; Mo 08:00-09:00").Mo).toEqual([{ from: "08:00", to: "09:00" }]);
  });
});
