# Checkout amounts: test list

**Hidden decision:** how the money on a receipt is computed from cart and coupon:
exact-cent lines, subtotal and discount, discount capped and gated by a minimum
order, the discount split across VAT rates, and 5-Rappen cash rounding only on the
amount to pay. Callers (till, `renderReceipt`) never learn any of these rules.

**Design A:** one general call, as today.
`checkout(cart, catalog, promotions?, couponCode?) -> Receipt`;
the receipt carries every amount plus an optional `notice`.
Call site: `renderReceipt(checkout(cart, catalog, promotions, code))`.

**Design B:** several special calls the till composes.
`priceLines(cart, catalog)`, `applyCoupon(lines, promotions, code) -> { discountCents, notice? }`,
`allocateVat(lines, discountCents)`, `cashTotal(subtotal, discount)`.
Call site: four calls in the right order, the till passing intermediate values along.

**Chosen:** Design A, because callers never learn the order of capping, VAT
allocation and cash rounding; in B every caller must know that order and the
rounding rules leak into four signatures.

Tests go through `checkout` (`src/checkout.test.ts`) and `renderReceipt`
(`src/receipt.test.ts`).

## Behaviours

- [x] multibuy gives no discount before a complete group (2 cups -> 0)
- [x] multibuy gives one free item per complete group only (4 cups -> one free):
  fixed by the same green (complete groups only); a red for it could not fail,
  so it was checked by hand (discount 1500, total 4500) instead of added as a test
- [x] line amounts and subtotal are exact to the cent (3 x 0.99 -> 297)
- [x] the amount to pay is rounded to 5 Rappen (3 x 0.99 -> 295)
- [x] a percent discount is exact to the cent (10 % of 2.90 -> 29, pay 2.60)
- [x] a fixed voucher is capped at the subtotal (5000 on 580 -> discount 580, pay 0)
- [x] VAT is computed on the discounted amount for a single rate (4 cups, 10 % -> 405)
- [x] the discount is split between VAT rates in proportion to their subtotals
- [x] a coupon below its minimum order gives no discount and a notice
- [x] a coupon at its minimum order works as usual, without a notice:
  already true after the previous green (the check is `subtotal < minimum`), so a
  red could not fail; checked by hand instead
- [x] the receipt prints the notice as its last line
