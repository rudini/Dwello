import { describe, expect, test } from "bun:test";
import { createCatalog } from "./catalog";
import { checkout, type Promotion } from "./checkout";

const catalog = createCatalog([
  { sku: "BROT", name: "Ruchbrot", priceCents: 290, vat: "reduced" },
  { sku: "KAFFEE", name: "Kaffeebohnen 500g", priceCents: 1250, vat: "reduced" },
  { sku: "TASSE", name: "Espressotasse", priceCents: 1500, vat: "standard" },
  { sku: "GUM", name: "Kaugummi", priceCents: 99, vat: "standard" },
]);

const promotions: Promotion[] = [
  { code: "ZEHN", kind: "percent", percent: 10 },
  { code: "TASSE3", kind: "multibuy", sku: "TASSE", buy: 3, pay: 2 },
];

describe("checkout", () => {
  test("sums the lines", () => {
    const receipt = checkout(
      [
        { sku: "BROT", qty: 2 },
        { sku: "KAFFEE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.lines.map((l) => l.lineCents)).toEqual([580, 1250]);
    expect(receipt.subtotalCents).toBe(1830);
    expect(receipt.totalCents).toBe(1830);
  });

  test("includes VAT per rate", () => {
    const receipt = checkout(
      [
        { sku: "KAFFEE", qty: 1 },
        { sku: "TASSE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.vat).toEqual({ reduced: 32, standard: 112 });
  });

  test("applies a percent coupon", () => {
    const receipt = checkout([{ sku: "KAFFEE", qty: 4 }], catalog, promotions, "ZEHN");
    expect(receipt.discountCents).toBe(500);
    expect(receipt.totalCents).toBe(4500);
  });

  test("buy three, pay two", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 3 }], catalog, promotions, "TASSE3");
    expect(receipt.discountCents).toBe(1500);
    expect(receipt.totalCents).toBe(3000);
  });

  test("multibuy gives no discount before a complete group", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 2 }], catalog, promotions, "TASSE3");
    expect(receipt.discountCents).toBe(0);
    expect(receipt.totalCents).toBe(3000);
  });

  test("line amounts and subtotal are exact to the cent", () => {
    const receipt = checkout([{ sku: "GUM", qty: 3 }], catalog);
    expect(receipt.lines[0].lineCents).toBe(297);
    expect(receipt.subtotalCents).toBe(297);
  });

  test("the amount to pay is rounded to 5 Rappen", () => {
    const receipt = checkout([{ sku: "GUM", qty: 3 }], catalog);
    expect(receipt.totalCents).toBe(295);
  });

  test("a percent discount is exact to the cent", () => {
    const receipt = checkout([{ sku: "BROT", qty: 1 }], catalog, promotions, "ZEHN");
    expect(receipt.discountCents).toBe(29);
    expect(receipt.totalCents).toBe(260);
  });

  test("a fixed voucher is capped at the subtotal", () => {
    const voucher: Promotion[] = [{ code: "FUENFZIG", kind: "fixed", amountCents: 5000 }];
    const receipt = checkout([{ sku: "BROT", qty: 2 }], catalog, voucher, "FUENFZIG");
    expect(receipt.discountCents).toBe(580);
    expect(receipt.totalCents).toBe(0);
  });

  test("VAT is computed on the discounted amount", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 4 }], catalog, promotions, "ZEHN");
    expect(receipt.totalCents).toBe(5400);
    expect(receipt.vat).toEqual({ standard: 405, reduced: 0 });
  });

  test("the discount is split between VAT rates in proportion to their subtotals", () => {
    const receipt = checkout(
      [
        { sku: "KAFFEE", qty: 4 },
        { sku: "TASSE", qty: 4 },
      ],
      catalog,
      promotions,
      "ZEHN",
    );
    expect(receipt.discountCents).toBe(1100);
    expect(receipt.vat).toEqual({ reduced: 114, standard: 405 });
  });

  test("a coupon below its minimum order gives no discount and a notice", () => {
    const minimum: Promotion[] = [
      { code: "ZEHN50", kind: "percent", percent: 10, minSubtotalCents: 5000 },
    ];
    const receipt = checkout([{ sku: "KAFFEE", qty: 1 }], catalog, minimum, "ZEHN50");
    expect(receipt.discountCents).toBe(0);
    expect(receipt.totalCents).toBe(1250);
    expect(receipt.couponCode).toBe("ZEHN50");
    expect(receipt.notice).toBe("Coupon ZEHN50 requires a minimum order of CHF 50.00");
  });

  test("rejects unknown products and coupons", () => {
    expect(() => checkout([{ sku: "TEE", qty: 1 }], catalog)).toThrow("Unknown product: TEE");
    expect(() => checkout([{ sku: "BROT", qty: 1 }], catalog, promotions, "GRATIS")).toThrow(
      "Unknown coupon code: GRATIS",
    );
  });
});
