# Checkout amounts: design note

**Hidden decision:** how the money on a receipt is computed from cart and coupon:
exact-cent lines, subtotal and discount, discount capped and gated by a minimum
order, the discount split across VAT rates, and 5-Rappen cash rounding only on the
amount to pay.

**Design A (chosen):** one general call, `checkout(cart, catalog, promotions?, couponCode?) -> Receipt`.
**Design B:** separate calls the till composes: `priceLines`, `applyCoupon`,
`allocateVat`, `cashTotal`.
Chosen: A, because callers never learn the order of capping, VAT allocation and
cash rounding; in B every caller must know that order, and the rounding rules leak
into four signatures.

## Interface

- `checkout(...)` (`src/checkout.ts`): returns a `Receipt`. `lines[].lineCents`,
  `subtotalCents` and `discountCents` are exact to the cent; `discountCents` is
  capped at the subtotal and is 0 when the subtotal is below the coupon's
  `minSubtotalCents`, in which case `notice` explains why. `totalCents` is
  `subtotal - discount` rounded to 5 Rappen. `vat[rate]` is the VAT in that rate's
  gross minus its share of the discount (reduced share proportional, rounded
  half up; standard takes the rest). Throws on unknown products and coupon codes.
- `Promotion` (`src/checkout.ts`): percent, fixed or multibuy, each with an optional
  `minSubtotalCents`. Multibuy gives `buy - pay` items free per complete group.
- `renderReceipt(receipt)` (`src/receipt.ts`): fixed-width text; prints `notice`
  as the last line when present.

## Depth

```
src/checkout.ts: surface 9, size 107, ratio 11.9 -> deep
src/receipt.ts:  surface 2, size 21,  ratio 10.5 -> deep
src/money.ts:    surface 2, size 5,   ratio 2.5  -> shallow
```

Refactor: `promotions.ts` (`findPromotion`, `discountFor`) and the rounding/VAT
helpers from `money.ts` (`roundToRappen`, `vatIncluded`) became private functions
of `checkout.ts`; only the `Promotion` type stays public. `money.ts` keeps only
`formatChf`, the one formatting rule shared by `checkout` (for the notice) and
`renderReceipt`. It is shallow, but merging it into either caller would
couple the two.

## Open points

- Two listed behaviours (4 cups with buy 3 pay 2; a coupon exactly at its minimum)
  were already true after an earlier green, so a red for them could not fail. They
  were checked by hand (discount 1500 / total 4500; discount applied, no notice)
  rather than added as tests.
- The half-up rounding of the reduced-rate share has no test of its own: a real
  .5 case needs an odd cart, and `Math.round` would pass it anyway. The integer
  formula rounds half up exactly.
- With only a reduced-rate subtotal, the standard rate takes 0 of the discount
  because the reduced share equals the whole discount.
- The unused part of a voucher above the subtotal is lost, as intended.

## Proof

`scripts/tdd_replay 07a1346..HEAD` printed `REPLAY: ACCEPT`.
