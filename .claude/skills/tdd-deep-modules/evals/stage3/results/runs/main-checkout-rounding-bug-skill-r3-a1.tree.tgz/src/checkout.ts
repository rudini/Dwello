import { findProduct, VAT_RATES, type Catalog, type VatCategory } from "./catalog";
import { formatChf } from "./money";

export type Promotion = { minSubtotalCents?: number } & (
  | { code: string; kind: "percent"; percent: number }
  | { code: string; kind: "fixed"; amountCents: number }
  | { code: string; kind: "multibuy"; sku: string; buy: number; pay: number }
);

export interface CartLine {
  sku: string;
  qty: number;
}

export interface ReceiptLine {
  sku: string;
  name: string;
  qty: number;
  unitCents: number;
  lineCents: number;
  vat: VatCategory;
}

export interface Receipt {
  lines: ReceiptLine[];
  subtotalCents: number;
  couponCode?: string;
  discountCents: number;
  totalCents: number;
  vat: Record<VatCategory, number>;
  notice?: string;
}

/**
 * Prices a cart. Lines, subtotal, discount and VAT are exact to the cent; only
 * the amount to pay is rounded to 5 Rappen.
 */
export function checkout(
  cart: CartLine[],
  catalog: Catalog,
  promotions: Promotion[] = [],
  couponCode?: string,
): Receipt {
  const lines: ReceiptLine[] = cart.map(({ sku, qty }) => {
    const product = findProduct(catalog, sku);
    return {
      sku,
      name: product.name,
      qty,
      unitCents: product.priceCents,
      lineCents: product.priceCents * qty,
      vat: product.vat,
    };
  });

  const subtotalCents = lines.reduce((sum, l) => sum + l.lineCents, 0);

  let discountCents = 0;
  let notice: string | undefined;
  if (couponCode !== undefined) {
    const promotion = findPromotion(promotions, couponCode);
    if (promotion.minSubtotalCents !== undefined && subtotalCents < promotion.minSubtotalCents) {
      notice = `Coupon ${couponCode} requires a minimum order of ${formatChf(promotion.minSubtotalCents)}`;
    } else {
      discountCents = Math.min(discountFor(promotion, lines, subtotalCents), subtotalCents);
    }
  }

  return {
    lines,
    subtotalCents,
    couponCode,
    discountCents,
    totalCents: roundToRappen(subtotalCents - discountCents),
    vat: vatAfterDiscount(lines, subtotalCents, discountCents),
    ...(notice !== undefined && { notice }),
  };
}

function findPromotion(promotions: Promotion[], code: string): Promotion {
  const promotion = promotions.find((p) => p.code === code);
  if (!promotion) throw new Error(`Unknown coupon code: ${code}`);
  return promotion;
}

/** Discount in cents that a promotion grants, before capping at the subtotal. */
function discountFor(promotion: Promotion, lines: ReceiptLine[], subtotalCents: number): number {
  switch (promotion.kind) {
    case "percent":
      return Math.round((subtotalCents * promotion.percent) / 100);
    case "fixed":
      return promotion.amountCents;
    case "multibuy": {
      const line = lines.find((l) => l.sku === promotion.sku);
      if (!line) return 0;
      const groups = Math.floor(line.qty / promotion.buy);
      return groups * (promotion.buy - promotion.pay) * line.unitCents;
    }
  }
}

/**
 * VAT per rate on what the customer pays: the discount is split in proportion
 * to each rate's gross, the reduced share rounded half up, the standard rate
 * taking the rest.
 */
function vatAfterDiscount(
  lines: ReceiptLine[],
  subtotalCents: number,
  discountCents: number,
): Record<VatCategory, number> {
  const gross: Record<VatCategory, number> = { standard: 0, reduced: 0 };
  for (const l of lines) gross[l.vat] += l.lineCents;
  const reducedShare =
    subtotalCents === 0
      ? 0
      : Math.floor((2 * discountCents * gross.reduced + subtotalCents) / (2 * subtotalCents));
  return {
    standard: vatIncluded(gross.standard - (discountCents - reducedShare), VAT_RATES.standard),
    reduced: vatIncluded(gross.reduced - reducedShare, VAT_RATES.reduced),
  };
}

/** VAT contained in a gross (VAT-inclusive) amount, rounded to the cent. */
function vatIncluded(grossCents: number, ratePercent: number): number {
  return Math.round((grossCents * ratePercent) / (100 + ratePercent));
}

/** Rounds an amount in cents to the nearest 5 Rappen (Swiss cash rounding). */
function roundToRappen(cents: number): number {
  return Math.round(cents / 5) * 5;
}
