/** Formats cents as "CHF 12.35" (negative amounts as "-CHF 0.50"). */
export function formatChf(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  return `${sign}CHF ${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, "0")}`;
}
