import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type PickList, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

const plan: (text: string, stock: StockLot[]) => PickList = buildPickList;

function lot(bin: string, sku: string, qty: number, expires: string | null = null): StockLot {
  return { bin, sku, qty, expires };
}

test("one order with one item covered by one lot yields one pick", () => {
  expect(plan("ORDER 1001\nOLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)])).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("comments, blank lines and surrounding whitespace are ignored", () => {
  const text = "# export 2026-10-12 06:00\n\n  ORDER 1001  \n   OLIVE-500   x3 \n\n# end\n";
  expect(plan(text, [lot("A-01-1", "OLIVE-500", 10)])).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("an item takes from the earliest expiring lots first, one pick per lot", () => {
  const stock = [
    lot("A-01-1", "OLIVE-500", 4, "2026-12-01"),
    lot("A-01-2", "OLIVE-500", 2, "2026-11-01"),
    lot("A-01-3", "PASTA-1KG", 9, "2026-10-20"),
    lot("A-01-4", "OLIVE-500", 5, "2027-01-01"),
  ];
  expect(plan("ORDER 1001\nOLIVE-500 x5", stock)?.picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    { bin: "A-01-2", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("undated lots come after dated ones and equal dates are broken by bin code", () => {
  const stock = [
    lot("A-01-1", "RICE", 5, null),
    lot("A-01-2", "RICE", 1, null),
    lot("A-01-5", "RICE", 2, "2027-03-01"),
    lot("A-01-4", "RICE", 2, "2027-03-01"),
  ];
  expect(plan("ORDER 7\nRICE x7", stock)?.picks).toEqual([
    { bin: "A-01-1", sku: "RICE", qty: 3, orderId: "7" },
    { bin: "A-01-4", sku: "RICE", qty: 2, orderId: "7" },
    { bin: "A-01-5", sku: "RICE", qty: 2, orderId: "7" },
  ]);
});

test("stock taken by an earlier order is not available to a later one", () => {
  const stock = [lot("A-01-1", "RICE", 3, "2026-11-01"), lot("A-01-2", "RICE", 10, "2026-12-01")];
  expect(plan("ORDER 1\nRICE x2\nORDER 2\nRICE x2", stock)?.picks).toEqual([
    { bin: "A-01-1", sku: "RICE", qty: 2, orderId: "1" },
    { bin: "A-01-1", sku: "RICE", qty: 1, orderId: "2" },
    { bin: "A-01-2", sku: "RICE", qty: 1, orderId: "2" },
  ]);
});

test("priority orders are served first, each group in text order", () => {
  const stock = [lot("A-01-1", "RICE", 3, null)];
  const text = "ORDER 1\nRICE x1\nORDER P-2   !\nRICE x1\nORDER 3\nRICE x1\nORDER P-4 !\nRICE x1";
  expect(plan(text, stock)?.picks.map((p) => p.orderId)).toEqual(["P-2", "P-4", "1"]);
});

test("a repeated sku within an order is added up at its first position", () => {
  const stock = [lot("A-01-1", "RICE", 4, null), lot("A-01-1", "PASTA", 4, null)];
  expect(plan("ORDER 1\nRICE x1\nPASTA x2\nRICE x2", stock)?.picks).toEqual([
    { bin: "A-01-1", sku: "RICE", qty: 3, orderId: "1" },
    { bin: "A-01-1", sku: "PASTA", qty: 2, orderId: "1" },
  ]);
});

test("missing stock is still picked as far as possible and reported in serving order", () => {
  const stock = [lot("A-01-1", "RICE", 3, null)];
  const text = "ORDER 1\nRICE x5\nBEANS x2\nORDER 2 !\nRICE x1\nBEANS x1\nORDER 3\nRICE x1";
  expect(plan(text, stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "RICE", qty: 1, orderId: "2" },
      { bin: "A-01-1", sku: "RICE", qty: 2, orderId: "1" },
    ],
    shortages: [
      { orderId: "2", sku: "BEANS", missing: 1 },
      { orderId: "1", sku: "RICE", missing: 3 },
      { orderId: "1", sku: "BEANS", missing: 2 },
      { orderId: "3", sku: "RICE", missing: 1 },
    ],
  });
});

test("picks follow the serpentine over the aisles that have picks", () => {
  const bins = ["C-02-1", "A-03-1", "D-05-1", "A-01-2", "C-10-1", "A-01-1", "D-01-1", "C-02-3"];
  const stock = [...bins.map((bin) => lot(bin, `S${bin}`, 1)), lot("B-01-1", "UNORDERED", 1)];
  const text = "ORDER 1\n" + bins.map((bin) => `S${bin} x1`).join("\n");
  expect(plan(text, stock)?.picks.map((p) => p.bin)).toEqual([
    "A-01-1", "A-01-2", "A-03-1",
    "C-10-1", "C-02-1", "C-02-3",
    "D-01-1", "D-05-1",
  ]);
});

function errorLine(text: string): number | string {
  try {
    buildPickList(text, []);
    return "no error";
  } catch (e) {
    return e instanceof OrderFormatError ? e.line : String(e);
  }
}

test("an item line before the first order is reported at its line", () => {
  expect(errorLine("# export\n\n  RICE x1\nORDER 1\nRICE x1")).toBe(3);
});

test("a reused order id is reported at the second ORDER line", () => {
  expect(errorLine("ORDER A-1\nRICE x1\nORDER 2\nRICE x1\nORDER A-1 !\nRICE x1")).toBe(5);
});

test("an order without items is reported at its ORDER line", () => {
  expect(errorLine("ORDER 1\n\nORDER 2\nRICE x1")).toBe(1);
  expect(errorLine("ORDER 1\nRICE x1\nORDER 2 !\n# nothing\n")).toBe(3);
});

test("lines matching neither form are reported at their line", () => {
  const bad = [
    "RICE x0", "RICE x03", "rice x1", "RICE 1", "RICEx1", "RICE x1.5", "RICE x-1", "RICE X1",
    "RICE_1 x1", "RICE x1 x2", "ORDER 1!", "ORDER", "ORDER 1_2", "ORDER 1 !!", "order 1",
  ];
  for (const line of bad) {
    expect([line, errorLine(`ORDER 1\nRICE x1\n${line}\nRICE x1`)]).toEqual([line, 3]);
  }
});

test("of several problems the topmost is reported", () => {
  expect(errorLine("ORDER 1\nORDER 2\nrice x1")).toBe(1);
  expect(errorLine("ORDER 1\nORDER 1\nRICE x1")).toBe(1);
  expect(errorLine("ORDER 1\nRICE x1\nORDER 2\nRICE x0\nORDER 1\nRICE x1")).toBe(4);
});
