export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: { sku: string; qty: number }[];
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const orders = parseOrders(ordersText);
  const served = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  const { picks, shortages } = allocate(served, stock);
  return { picks: walkOrder(picks), shortages };
}

function parseOrders(text: string): Order[] {
  const orders: Order[] = [];
  // An order is known to be empty only when its block ends: at the next ORDER line or the end.
  const closeLastOrder = () => {
    const last = orders[orders.length - 1];
    if (last && last.items.length === 0) {
      throw new OrderFormatError(last.line, `order ${last.id} has no items`);
    }
  };
  const lines = text.split("\n");
  for (let n = 1; n <= lines.length; n++) {
    const line = lines[n - 1].trim();
    if (line === "" || line.startsWith("#")) continue;
    const order = /^ORDER +([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (order) {
      closeLastOrder();
      if (orders.some((o) => o.id === order[1])) {
        throw new OrderFormatError(n, `order id ${order[1]} used twice`);
      }
      orders.push({ id: order[1], priority: order[2] !== undefined, line: n, items: [] });
      continue;
    }
    const item = /^([A-Z0-9-]+) +x([1-9]\d*)$/.exec(line);
    if (!item) throw new OrderFormatError(n, `cannot read "${line}"`);
    if (orders.length === 0) throw new OrderFormatError(n, "item before the first ORDER");
    const [, sku, qty] = item;
    const items = orders[orders.length - 1].items;
    const same = items.find((i) => i.sku === sku);
    if (same) same.qty += Number(qty);
    else items.push({ sku, qty: Number(qty) });
  }
  closeLastOrder();
  return orders;
}

/** Serves the orders in the given sequence, earliest best-before first; undated lots last. */
function allocate(orders: Order[], stock: StockLot[]): PickList {
  const fefo = [...stock].sort(
    (a, b) => compareExpiry(a.expires, b.expires) || compare(a.bin, b.bin),
  );
  const left = new Map(stock.map((l) => [l, l.qty]));
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  for (const order of orders) {
    for (const { sku, qty } of order.items) {
      let wanted = qty;
      for (const lot of fefo) {
        if (wanted === 0) break;
        const taken = lot.sku === sku ? Math.min(wanted, left.get(lot)!) : 0;
        if (taken === 0) continue;
        left.set(lot, left.get(lot)! - taken);
        picks.push({ bin: lot.bin, sku, qty: taken, orderId: order.id });
        wanted -= taken;
      }
      if (wanted > 0) shortages.push({ orderId: order.id, sku, missing: wanted });
    }
  }
  return { picks, shortages };
}

/**
 * Serpentine: aisles alphabetical, racks ascending in odd and descending in even visited aisles,
 * levels ascending. The sort is stable, so picks at one bin keep their allocation order.
 */
function walkOrder(picks: Pick[]): Pick[] {
  const place = (bin: string) => {
    const [aisle, rack, level] = bin.split("-");
    return { aisle, rack: Number(rack), level: Number(level) };
  };
  const aisles = [...new Set(picks.map((p) => place(p.bin).aisle))].sort(compare);
  return [...picks].sort((a, b) => {
    const pa = place(a.bin);
    const pb = place(b.bin);
    if (pa.aisle !== pb.aisle) return compare(pa.aisle, pb.aisle);
    const direction = aisles.indexOf(pa.aisle) % 2 === 0 ? 1 : -1;
    return (pa.rack - pb.rack) * direction || pa.level - pb.level;
  });
}

function compareExpiry(a: string | null, b: string | null): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return compare(a, b);
}

function compare(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}
