# Design note: `src/pickList.ts`

**Hidden decision:** how the morning orders text is parsed and validated, how
stock is allocated (priority first, earliest best-before first, undated last,
bin tie-break) and how picks are ordered along the serpentine walk. Callers hand
over text and stock and get picks and shortages back.

**Design A (chosen):** a single pure function
`buildPickList(ordersText, stock): PickList` that throws `OrderFormatError`.
**Design B:** a stateful `PickPlanner(stock)` with `addOrders(text)`, `picks()`
and `shortages()`.
Chosen: A, because one call hides parsing, allocation and the walk completely
and leaves the caller with no state or call order to manage. That also makes
"stock is not modified" easy to guarantee.

## Interface

- `buildPickList(ordersText, stock)` returns `{ picks, shortages }`. `picks` are
  in walking order and `shortages` are in serving order. The function never
  modifies `stock`: remaining quantities live in a private `Map`, and the FEFO
  order sorts a copy.
- `OrderFormatError.line` is the 1-based line of the first problem from the top.
- Types `StockLot`, `Pick`, `Shortage`, `PickList` are unchanged from the stub.

Inside the module, the private steps `parseOrders` → `allocate` → `walkOrder`
are not exported and are tested only through `buildPickList`.

## Depth

`depth_report src/pickList.ts`: surface 10, size 120, ratio 12.0, no classitis,
no pass-throughs. It flags 6 duplicated lines. These are the repeated fields of
the fixed public types plus the two intentional `closeLastOrder()` calls, so
nothing was changed. Refactors split the first single function into parse,
allocate and walk steps, gave FEFO its own comparator, ordered the helpers as a
pipeline, and simplified the test helper once the stub no longer threw.

## Open points and interpretations

- **Which problem comes first** is decided by reading top-down: a malformed
  line, an item line before the first order, or a duplicate id is reported as
  soon as it is reached. An empty order is noticed when its block closes (at the
  next `ORDER` line or at the end of the text) and is reported at its own
  `ORDER` line. So `ORDER 1\nRICE x0` reports line 2, not line 1.
- `ORDER` and the id may be separated by more than one space.
- Bin codes are assumed to be well formed (`A-03-2`). Racks and levels are
  compared as numbers.
- Two items on the test list hold by construction and have no test of their own,
  because a test cannot be written to fail first: picks at the same bin keep
  allocation order (the sort is stable; the priority and shortage tests cover
  it) and `stock` is not modified. A scratch check with frozen stock objects
  passed.

## Proof

`scripts/tdd_replay 08473fa..HEAD` → `REPLAY: ACCEPT`. This checks phase order,
test counts and exit codes, not how strong the assertions are.
