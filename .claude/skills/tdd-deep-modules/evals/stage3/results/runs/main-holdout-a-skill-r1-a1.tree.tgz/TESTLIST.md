# Pick list – test list

**Hidden decision:** how the orders text is parsed, how stock is allocated
(priority, FEFO, bin tie-break) and how bins are ordered along the serpentine
walk; callers only hand over text and stock and get picks and shortages back.

**Design A (chosen):** one pure function
`buildPickList(ordersText, stock): PickList`, throwing `OrderFormatError`.
Call site: `const { picks, shortages } = buildPickList(text, stock);`

**Design B:** a stateful planner,
`const p = new PickPlanner(stock); p.addOrders(text); p.picks(); p.shortages();`

**Chosen:** A, because one call hides parsing, allocation and walking order
entirely, the caller never sees intermediate state, and stock immutability is
trivially guaranteed; B exposes call ordering and mutable state for no gain.

## Behaviours (through `buildPickList`)

- [x] one order, one item, one lot covering it → one pick, no shortages
- [x] comments, blank lines and surrounding whitespace are ignored
- [x] an item spread over several lots takes earliest `expires` first, one pick per lot
- [x] undated lots come after dated lots; ties broken by bin code
- [x] stock taken by an earlier order is not available to a later one
- [x] priority orders (`!`) are served before others, each group in text order
- [x] repeated SKU within an order adds quantities, keeping first position
- [x] not enough stock → picks what exists and reports the missing quantity, in serving order
- [x] picks follow the serpentine: aisles alphabetical, racks asc/desc alternating over visited aisles, levels asc
- [x] picks at the same bin keep allocation order (covered by the priority and shortage tests;
      the walk sort is stable, so no separate failing test could be written first)
- [x] stock array and its objects are not modified (by construction: remaining quantities live
      in a private Map and the FEFO order sorts a copy; it never failed, so no red test exists)
- [x] item line before the first ORDER → OrderFormatError at that line
- [x] duplicate order id → OrderFormatError at the second ORDER line
- [x] ORDER without items → OrderFormatError at its ORDER line (also the last order)
- [x] malformed lines (`x0`, `x03`, lowercase sku, missing `x`, bad id) → OrderFormatError at that line
- [x] the first problem from the top is reported
