# Box office: design note

**Hidden decision:** how the ticket ledger (holds that expire with time, orders that can be
cancelled) turns into availability, per-customer counts and prices. Callers never learn that
expiry is checked lazily against `now()`, or how the group discount and 5-Rappen rounding
are applied.

## Both designs

- **A, stateful service object** (`createBoxOffice(options): BoxOffice`, five verbs).
- **B, pure reducer** (`holdTickets(state, customer, section, qty, now) -> [state, hold]`).

**Chosen: A**, because it hides both the state and the clock, so callers learn only the five
verbs. The stub also fixed this interface already.

## Interface

- `available(sectionId)`: capacity minus active holds minus non-cancelled orders.
- `hold(customer, section, qty)`: validates in this order: section, quantity, customer limit
  across sections, availability. Returns `H<n>`, which expires `holdMinutes` from now.
- `confirm(holdId)`: `UNKNOWN_HOLD` / `HOLD_EXPIRED`, otherwise order `O<n>` with the
  discounted and rounded total.
- `release(holdId)`: frees an active hold. Releasing an expired hold changes nothing (the
  hold stays expired, so releasing it again also succeeds and `confirm` still reports
  `HOLD_EXPIRED`).
- `cancelOrder(orderId)`: refund `max(0, total - 200 * qty)`, frees the tickets and the
  customer's limit.

Inside: one ledger of hold and order records with `ended` / `cancelled` flags.
`takenTickets(predicate)` is the only place that decides what counts, and `now()` is read
at each call. `totalCents` computes in tenths of a cent so the 10 % discount stays an
integer before rounding.

## Depth

`depth_report src/boxOffice.ts`:
`surface 11, size 131, ratio 11.9, classitis no, pass-through 0, tests 1, unused 0, duplicate 4 -> bloat: 4 duplicated lines`.
Three of the four duplicates are the `customerId`/`sectionId`/`quantity` fields shared by
the stub's `Hold` and `Order` interfaces, which must stay as given. The fourth is the
`openHold` destructuring that `confirm` and `release` share. Refactors merged the section
lookups, put pricing in one function, combined counting into `takenTickets`, added the
`openHold` lookup, and named the constants.

## Open points

- That CUSTOMER_LIMIT is checked before SOLD_OUT, and that releasing a confirmed hold
  throws UNKNOWN_HOLD, are implemented but have no test of their own: both already held
  when their cycle came up, so no failing red was possible.
- Records are kept forever, which is fine for a single event's volume.

## Proof

`scripts/tdd_replay 64691e8..HEAD` printed `REPLAY: ACCEPT`.
