import { describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOffice } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

const START = 1_000_000;
const MINUTE = 60_000;

function setup(): { box: BoxOffice; clock: { time: number } } {
  const clock = { time: START };
  const box = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 4990 },
      { id: "BALKON", capacity: 5, priceCents: 3000 },
      { id: "STEH", capacity: 20, priceCents: 4993 },
      { id: "GALERIE", capacity: 20, priceCents: 3005 },
      { id: "KIND", capacity: 20, priceCents: 150 },
    ],
    holdMinutes: 15,
    maxTicketsPerCustomer: 6,
    now: () => clock.time,
  });
  return { box, clock };
}

function codeOf(action: () => unknown): string | undefined {
  try {
    action();
  } catch (error) {
    if (error instanceof BoxOfficeError) return error.code;
    return `not a BoxOfficeError: ${error}`;
  }
  return undefined;
}

describe("box office", () => {
  test("available returns the full capacity of a fresh section", () => {
    const { box } = setup();
    expect(box.available("PARKETT")).toBe(10);
  });

  test("hold returns H1 with its details and an expiry holdMinutes from now", () => {
    const { box } = setup();
    expect(box.hold("anna", "PARKETT", 2)).toEqual({
      holdId: "H1",
      customerId: "anna",
      sectionId: "PARKETT",
      quantity: 2,
      expiresAt: START + 15 * MINUTE,
    });
  });

  test("an active hold reduces availability of its section only", () => {
    const { box } = setup();
    box.hold("anna", "PARKETT", 2);
    expect([box.available("PARKETT"), box.available("BALKON")]).toEqual([8, 5]);
  });

  test("hold ids count up in creation order", () => {
    const { box } = setup();
    const ids = [box.hold("anna", "PARKETT", 1), box.hold("ben", "BALKON", 1)].map((h) => h.holdId);
    expect(ids).toEqual(["H1", "H2"]);
  });

  test("available on an unknown section throws UNKNOWN_SECTION", () => {
    const { box } = setup();
    expect(codeOf(() => box.available("LOGE"))).toBe("UNKNOWN_SECTION");
  });

  test("hold on an unknown section throws UNKNOWN_SECTION and uses no hold id", () => {
    const { box } = setup();
    expect(codeOf(() => box.hold("anna", "LOGE", 1))).toBe("UNKNOWN_SECTION");
    expect(box.hold("anna", "PARKETT", 1).holdId).toBe("H1");
  });

  test("hold with a quantity that is not a whole number of at least 1 throws INVALID_QUANTITY", () => {
    const { box } = setup();
    const codes = [0, -1, 1.5, Number.NaN].map((q) => codeOf(() => box.hold("anna", "PARKETT", q)));
    expect(codes).toEqual(["INVALID_QUANTITY", "INVALID_QUANTITY", "INVALID_QUANTITY", "INVALID_QUANTITY"]);
    expect(box.available("PARKETT")).toBe(10);
  });

  test("hold beyond availability throws SOLD_OUT and holds nothing", () => {
    const { box } = setup();
    box.hold("anna", "BALKON", 3);
    expect(codeOf(() => box.hold("ben", "BALKON", 3))).toBe("SOLD_OUT");
    expect(box.available("BALKON")).toBe(2);
    expect(box.hold("ben", "BALKON", 2).holdId).toBe("H2");
  });

  test("hold beyond the per-customer limit across sections throws CUSTOMER_LIMIT", () => {
    const { box } = setup();
    box.hold("anna", "PARKETT", 4);
    box.hold("ben", "PARKETT", 4);
    expect(codeOf(() => box.hold("anna", "BALKON", 3))).toBe("CUSTOMER_LIMIT");
    expect(box.hold("anna", "BALKON", 2).quantity).toBe(2);
  });

  test("a hold stops counting for availability and the limit once now reaches expiresAt", () => {
    const { box, clock } = setup();
    box.hold("anna", "BALKON", 5);
    clock.time = START + 15 * MINUTE - 1;
    const before = box.available("BALKON");
    clock.time = START + 15 * MINUTE;
    expect([before, box.available("BALKON")]).toEqual([0, 5]);
    expect(box.hold("anna", "PARKETT", 6).quantity).toBe(6);
  });

  test("confirm turns a hold into order O1 and the tickets stay taken after the hold would expire", () => {
    const { box, clock } = setup();
    const hold = box.hold("anna", "BALKON", 2);
    expect(box.confirm(hold.holdId)).toEqual({
      orderId: "O1",
      customerId: "anna",
      sectionId: "BALKON",
      quantity: 2,
      totalCents: 6000,
    });
    clock.time = START + 60 * MINUTE;
    expect(box.available("BALKON")).toBe(3);
    expect(codeOf(() => box.hold("anna", "PARKETT", 5))).toBe("CUSTOMER_LIMIT");
  });

  test("an order of 4 or more tickets gets 10 % off, rounded to 5 cents", () => {
    const { box } = setup();
    const hold = box.hold("anna", "PARKETT", 4);
    // 4 * 4990 = 19960, minus 10 % = 17964, nearest 5 cents = 17965
    expect(box.confirm(hold.holdId).totalCents).toBe(17965);
  });

  test("totals are rounded to 5 cents also without discount, exact halves round up", () => {
    const { box } = setup();
    // 1 * 4993 = 4993, nearest 5 cents = 4995
    const single = box.confirm(box.hold("anna", "STEH", 1).holdId);
    // 5 * 3005 = 15025, minus 10 % = 13522.5, exactly halfway between 13520 and 13525
    const half = box.confirm(box.hold("ben", "GALERIE", 5).holdId);
    expect([single.totalCents, half.totalCents]).toEqual([4995, 13525]);
  });

  test("confirm of an unknown or already confirmed hold throws UNKNOWN_HOLD and creates no order", () => {
    const { box } = setup();
    const hold = box.hold("anna", "BALKON", 1);
    box.confirm(hold.holdId);
    expect(codeOf(() => box.confirm("H99"))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => box.confirm(hold.holdId))).toBe("UNKNOWN_HOLD");
    expect(box.available("BALKON")).toBe(4);
    expect(box.confirm(box.hold("ben", "BALKON", 1).holdId).orderId).toBe("O2");
  });

  test("confirm of an expired hold throws HOLD_EXPIRED and takes no tickets", () => {
    const { box, clock } = setup();
    const hold = box.hold("anna", "BALKON", 2);
    clock.time = hold.expiresAt;
    expect(codeOf(() => box.confirm(hold.holdId))).toBe("HOLD_EXPIRED");
    expect(box.available("BALKON")).toBe(5);
  });

  test("release frees the tickets and the hold cannot be released or confirmed again", () => {
    const { box } = setup();
    const hold = box.hold("anna", "BALKON", 5);
    box.release(hold.holdId);
    expect(box.available("BALKON")).toBe(5);
    expect(codeOf(() => box.release(hold.holdId))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => box.confirm(hold.holdId))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => box.release("H99"))).toBe("UNKNOWN_HOLD");
  });

  test("release of an expired hold succeeds without effect", () => {
    const { box, clock } = setup();
    const hold = box.hold("anna", "BALKON", 2);
    clock.time = hold.expiresAt + MINUTE;
    const codes = [codeOf(() => box.release(hold.holdId)), codeOf(() => box.release(hold.holdId))];
    expect(codes).toEqual([undefined, undefined]);
    expect(codeOf(() => box.confirm(hold.holdId))).toBe("HOLD_EXPIRED");
    expect(box.available("BALKON")).toBe(5);
  });

  test("cancelOrder refunds the total minus 200 cents per ticket and frees the tickets and the limit", () => {
    const { box } = setup();
    const order = box.confirm(box.hold("anna", "BALKON", 2).holdId);
    // 2 * 3000 = 6000, minus 2 * 200 fee = 5600
    expect(box.cancelOrder(order.orderId)).toBe(5600);
    expect(box.available("BALKON")).toBe(5);
    expect(box.hold("anna", "PARKETT", 6).quantity).toBe(6);
  });

  test("cancelOrder never refunds less than 0", () => {
    const { box } = setup();
    // 1 * 150 = 150, minus 200 fee would be -50
    const order = box.confirm(box.hold("anna", "KIND", 1).holdId);
    expect(box.cancelOrder(order.orderId)).toBe(0);
  });

  test("cancelOrder of an unknown or already cancelled order throws UNKNOWN_ORDER", () => {
    const { box } = setup();
    const order = box.confirm(box.hold("anna", "BALKON", 2).holdId);
    box.cancelOrder(order.orderId);
    box.hold("ben", "BALKON", 5);
    expect(codeOf(() => box.cancelOrder(order.orderId))).toBe("UNKNOWN_ORDER");
    expect(codeOf(() => box.cancelOrder("O99"))).toBe("UNKNOWN_ORDER");
    expect(box.available("BALKON")).toBe(0);
  });
});
