# Box office: test list

**Hidden decision:** how the ticket ledger (holds that expire with time, orders that can be
cancelled) turns into availability, per-customer counts and prices — callers never learn
that expiry is evaluated lazily against `now()`, nor how group discount and 5-Rappen
rounding are applied.

## Design it twice

- **A: stateful service object** (the stub's `createBoxOffice(options): BoxOffice`):
  `const box = createBoxOffice(opts); const h = box.hold("c1", "A", 2); box.confirm(h.holdId);`
  Callers know five verbs and the error codes; ledger, clock and pricing stay inside.
- **B: pure reducer over an immutable state**:
  `const [state2, hold] = holdTickets(state1, "c1", "A", 2, now);`
  Callers must thread state and time through every call; the clock and the state shape leak
  into every signature.

**Chosen: A**, because it hides the state and the clock entirely, so callers learn only the
five verbs, and the interface is already fixed by the stub.

## Behaviours

- [x] available returns the full capacity of a fresh section
- [x] hold returns H1 with customer, section, quantity and expiresAt = now + holdMinutes
- [x] an active hold reduces availability
- [x] hold ids count up H1, H2, ... and failed holds do not use a number
- [x] available on an unknown section throws UNKNOWN_SECTION
- [x] hold on an unknown section throws UNKNOWN_SECTION
- [x] hold with quantity 0, negative or fractional throws INVALID_QUANTITY
- [x] hold beyond availability throws SOLD_OUT (no partial holds)
- [x] hold beyond the per-customer limit across sections throws CUSTOMER_LIMIT
- [ ] CUSTOMER_LIMIT is checked before SOLD_OUT — not a separate cycle: it already held
      after the limit's green, so no failing test was possible (see DESIGN.md)
- [x] an expired hold (now >= expiresAt) no longer counts for availability or the limit
- [x] confirm turns a hold into order O1 with quantity * price, tickets stay taken
- [x] confirm of 4+ tickets gives 10 % discount, rounded to 5 cents
- [x] rounding to 5 cents applies without discount, exact halves round up
- [x] confirm of unknown or confirmed hold throws UNKNOWN_HOLD
- [x] confirm of an expired hold throws HOLD_EXPIRED
- [x] release frees the tickets; release/confirm again throws UNKNOWN_HOLD
- [x] release of an expired hold succeeds without effect
- [ ] release of a confirmed hold throws UNKNOWN_HOLD — same `ended` check as a released
      hold, already passing, so no red was possible
- [x] cancelOrder refunds total minus 200 per ticket and frees tickets and the limit
- [x] cancelOrder refund never below 0
- [x] cancelOrder of unknown or cancelled order throws UNKNOWN_ORDER
