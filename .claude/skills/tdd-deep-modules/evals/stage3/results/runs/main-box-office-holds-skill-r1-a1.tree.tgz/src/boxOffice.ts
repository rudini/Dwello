export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const MS_PER_MINUTE = 60_000;
const GROUP_SIZE = 4;
const CANCELLATION_FEE_CENTS = 200;

/** Price of an order: 10 % group discount from GROUP_SIZE tickets, rounded to 5 Rappen (halves up). */
function totalCents(quantity: number, priceCents: number): number {
  const amount = quantity * priceCents;
  // Work in tenths of a cent so the discount stays an integer; one 5-cent step is 50 tenths.
  const tenths = quantity >= GROUP_SIZE ? amount * 9 : amount * 10;
  return Math.round(tenths / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const holds: (Hold & { ended: boolean })[] = [];
  const orders: (Order & { cancelled: boolean })[] = [];

  function sectionById(sectionId: string): SectionConfig {
    const section = options.sections.find((s) => s.id === sectionId);
    if (!section) throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    return section;
  }

  /** Tickets in active holds and orders that match `belongs`. */
  function takenTickets(belongs: (entry: { customerId: string; sectionId: string }) => boolean): number {
    const now = options.now();
    const activeHolds = holds.filter((h) => !h.ended && now < h.expiresAt);
    const activeOrders = orders.filter((o) => !o.cancelled);
    return [...activeHolds, ...activeOrders].filter(belongs).reduce((sum, e) => sum + e.quantity, 0);
  }

  /** The hold that may still be confirmed or released; throws UNKNOWN_HOLD otherwise. */
  function openHold(holdId: string): { hold: Hold & { ended: boolean }; expired: boolean } {
    const hold = holds.find((h) => h.holdId === holdId);
    if (!hold || hold.ended) throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    return { hold, expired: options.now() >= hold.expiresAt };
  }

  function available(sectionId: string): number {
    const section = sectionById(sectionId);
    return section.capacity - takenTickets((e) => e.sectionId === sectionId);
  }

  return {
    available,
    hold(customerId, sectionId, quantity) {
      sectionById(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const owned = takenTickets((e) => e.customerId === customerId);
      if (owned + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError("CUSTOMER_LIMIT", `Customer ${customerId} would exceed the limit`);
      }
      if (quantity > available(sectionId)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in ${sectionId}`);
      }
      const hold = {
        holdId: `H${holds.length + 1}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: options.now() + options.holdMinutes * MS_PER_MINUTE,
      };
      holds.push({ ...hold, ended: false });
      return hold;
    },
    confirm(holdId) {
      const { hold, expired } = openHold(holdId);
      if (expired) throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      hold.ended = true;
      const order = {
        orderId: `O${orders.length + 1}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: totalCents(hold.quantity, sectionById(hold.sectionId).priceCents),
      };
      orders.push({ ...order, cancelled: false });
      return order;
    },
    release(holdId) {
      const { hold, expired } = openHold(holdId);
      // An expired hold already stopped counting; releasing it changes nothing.
      if (!expired) hold.ended = true;
    },
    cancelOrder(orderId) {
      const order = orders.find((o) => o.orderId === orderId);
      if (!order || order.cancelled) {
        throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      }
      order.cancelled = true;
      return Math.max(0, order.totalCents - CANCELLATION_FEE_CENTS * order.quantity);
    },
  };
}
