import { expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode, type ColumnConfig } from "./board";

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

const defaultColumns: ColumnConfig[] = [
  { name: "Backlog" },
  { name: "Doing" },
  { name: "Review" },
  { name: "Done" },
];

function setup(columns: ColumnConfig[] = defaultColumns) {
  const clock = { t: 1000 };
  const board = createBoard({ columns, now: () => clock.t });
  return { board, clock };
}

function expectCode(fn: () => unknown, code: BoardErrorCode) {
  let thrown: unknown;
  try {
    fn();
  } catch (e) {
    thrown = e;
  }
  expect(thrown).toBeInstanceOf(BoardError);
  expect((thrown as BoardError).code).toBe(code);
}

test("addCard returns sequential ids and appends to the first column", () => {
  const { board } = setup();
  expect(board.addCard("a")).toBe("C1");
  expect(board.addCard("b")).toBe("C2");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
  expect(board.cardsIn("Doing")).toEqual([]);
});

test("empty title is rejected and does not consume an id", () => {
  const { board } = setup();
  expectCode(() => board.addCard(""), "EMPTY_TITLE");
  expectCode(() => board.addCard("   "), "EMPTY_TITLE");
  expect(board.cardsIn("Backlog")).toEqual([]);
  expect(board.addCard("a")).toBe("C1");
});

test("addCard fails when the first column is at its WIP limit", () => {
  const { board } = setup([{ name: "Backlog", wipLimit: 2 }, { name: "Done" }]);
  board.addCard("a");
  board.addCard("b");
  expectCode(() => board.addCard("c"), "WIP_LIMIT");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
  board.move("C1", "Done");
  expect(board.addCard("c")).toBe("C3");
});

test("move forward one column puts the card at the end of the target", () => {
  const { board } = setup();
  board.addCard("a");
  board.addCard("b");
  board.move("C2", "Doing");
  board.move("C1", "Doing");
  expect(board.cardsIn("Backlog")).toEqual([]);
  expect(board.cardsIn("Doing")).toEqual(["C2", "C1"]);
});

test("move rejects unknown cards and columns", () => {
  const { board } = setup();
  board.addCard("a");
  expectCode(() => board.move("C9", "Doing"), "UNKNOWN_CARD");
  expectCode(() => board.move("C1", "Nowhere"), "UNKNOWN_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("move to the column the card is already in is rejected", () => {
  const { board } = setup();
  board.addCard("a");
  board.addCard("b");
  expectCode(() => board.move("C1", "Backlog"), "SAME_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("moving forward more than one column is rejected, backwards any distance is allowed", () => {
  const { board } = setup();
  board.addCard("a");
  expectCode(() => board.move("C1", "Review"), "SKIP_NOT_ALLOWED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  board.move("C1", "Doing");
  board.move("C1", "Review");
  board.move("C1", "Done");
  board.move("C1", "Backlog");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  expect(board.cardsIn("Done")).toEqual([]);
});

test("move fails when the target column is at its WIP limit", () => {
  const { board } = setup([{ name: "Backlog" }, { name: "Doing", wipLimit: 1 }, { name: "Done" }]);
  board.addCard("a");
  board.addCard("b");
  board.move("C1", "Doing");
  expectCode(() => board.move("C2", "Doing"), "WIP_LIMIT");
  expect(board.cardsIn("Backlog")).toEqual(["C2"]);
  expect(board.cardsIn("Doing")).toEqual(["C1"]);
});

test("blocked cards cannot move until unblocked", () => {
  const { board } = setup();
  board.addCard("a");
  expectCode(() => board.block("C9", "why"), "UNKNOWN_CARD");
  expectCode(() => board.unblock("C9"), "UNKNOWN_CARD");
  expectCode(() => board.unblock("C1"), "NOT_BLOCKED");
  board.block("C1", "waiting on customer");
  expectCode(() => board.block("C1", "again"), "ALREADY_BLOCKED");
  expectCode(() => board.move("C1", "Doing"), "BLOCKED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
  board.unblock("C1");
  expectCode(() => board.unblock("C1"), "NOT_BLOCKED");
  board.move("C1", "Doing");
  expect(board.cardsIn("Doing")).toEqual(["C1"]);
});

test("blocked cards count toward WIP limits", () => {
  const { board } = setup([{ name: "Backlog", wipLimit: 1 }, { name: "Doing", wipLimit: 1 }, { name: "Done" }]);
  board.addCard("a");
  board.block("C1", "why");
  expectCode(() => board.addCard("b"), "WIP_LIMIT");
  board.unblock("C1");
  board.move("C1", "Doing");
  board.block("C1", "why");
  board.addCard("b");
  expectCode(() => board.move("C2", "Doing"), "WIP_LIMIT");
});

test("move checks rules in the specified order", () => {
  const { board } = setup([
    { name: "Backlog" },
    { name: "Doing", wipLimit: 1 },
    { name: "Review", wipLimit: 0 },
    { name: "Done" },
  ]);
  board.addCard("a");
  board.addCard("b");
  board.move("C2", "Doing");
  board.block("C1", "why");
  expectCode(() => board.move("C9", "Nowhere"), "UNKNOWN_CARD");
  expectCode(() => board.move("C1", "Nowhere"), "UNKNOWN_COLUMN");
  expectCode(() => board.move("C1", "Backlog"), "SAME_COLUMN");
  expectCode(() => board.move("C1", "Review"), "BLOCKED");
  board.unblock("C1");
  expectCode(() => board.move("C1", "Review"), "SKIP_NOT_ALLOWED");
  expectCode(() => board.move("C1", "Doing"), "WIP_LIMIT");
});

test("cardsIn rejects unknown columns and returns a copy", () => {
  const { board } = setup();
  expectCode(() => board.cardsIn("Nowhere"), "UNKNOWN_COLUMN");
  board.addCard("a");
  board.cardsIn("Backlog").push("C42");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("cycleTime rejects unknown cards and is null until the card is done", () => {
  const { board } = setup();
  expectCode(() => board.cycleTime("C1"), "UNKNOWN_CARD");
  board.addCard("a");
  expect(board.cycleTime("C1")).toBeNull();
  board.move("C1", "Doing");
  expect(board.cycleTime("C1")).toBeNull();
});

test("cycleTime measures from leaving the first column to arriving in the last", () => {
  const { board, clock } = setup();
  board.addCard("a");
  clock.t = 2000;
  board.move("C1", "Doing");
  clock.t = 2500;
  board.move("C1", "Review");
  clock.t = 4000;
  board.move("C1", "Done");
  clock.t = 9000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 2000, blockedMs: 0 });
});

test("returning to the first column keeps the start; finish is the latest arrival in the last column", () => {
  const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
  board.addCard("a");
  clock.t = 2000;
  board.move("C1", "Doing");
  clock.t = 3000;
  board.move("C1", "Done");
  expect(board.cycleTime("C1")).toEqual({ totalMs: 1000, blockedMs: 0 });
  clock.t = 4000;
  board.move("C1", "Backlog");
  expect(board.cycleTime("C1")).toBeNull();
  clock.t = 5000;
  board.move("C1", "Doing");
  clock.t = 7000;
  board.move("C1", "Done");
  expect(board.cycleTime("C1")).toEqual({ totalMs: 5000, blockedMs: 0 });
});

test("blockedMs sums blocked periods between start and finish", () => {
  const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
  board.addCard("a");
  clock.t = 2000;
  board.move("C1", "Doing");
  clock.t = 2100;
  board.block("C1", "waiting");
  clock.t = 2400;
  board.unblock("C1");
  clock.t = 3000;
  board.block("C1", "again");
  clock.t = 3050;
  board.unblock("C1");
  clock.t = 4000;
  board.move("C1", "Done");
  expect(board.cycleTime("C1")).toEqual({ totalMs: 2000, blockedMs: 350 });
});

test("blocked time before start or after finish does not count", () => {
  const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
  board.addCard("a");
  board.block("C1", "not ready");
  clock.t = 1500;
  board.unblock("C1");
  clock.t = 2000;
  board.move("C1", "Doing");
  clock.t = 3000;
  board.move("C1", "Done");
  clock.t = 3100;
  board.block("C1", "reopened?");
  clock.t = 3300;
  board.unblock("C1");
  clock.t = 3500;
  board.block("C1", "still unsure");
  clock.t = 9000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 1000, blockedMs: 0 });
});

test("blocks during rework after starting count toward blockedMs", () => {
  const { board, clock } = setup([{ name: "Backlog" }, { name: "Doing" }, { name: "Done" }]);
  board.addCard("a");
  clock.t = 2000;
  board.move("C1", "Doing");
  clock.t = 3000;
  board.move("C1", "Done");
  board.block("C1", "customer complained");
  clock.t = 3200;
  board.unblock("C1");
  board.move("C1", "Backlog");
  clock.t = 3500;
  board.block("C1", "needs triage");
  clock.t = 4000;
  board.unblock("C1");
  board.move("C1", "Doing");
  clock.t = 5000;
  board.move("C1", "Done");
  expect(board.cycleTime("C1")).toEqual({ totalMs: 3000, blockedMs: 700 });
});
