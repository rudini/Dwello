export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Card {
  column: number;
  /** When the current block began; undefined while not blocked. */
  blockedSince?: number;
  /** Completed blocked periods. */
  blockedPeriods: { from: number; to: number }[];
  /** When the card first left the first column. */
  startedAt?: number;
  /** When the card most recently arrived in the last column. */
  finishedAt?: number;
}

export function createBoard(options: BoardOptions): Board {
  /** Card ids per column, indexed like `options.columns`, in arrival order. */
  const columns: string[][] = options.columns.map(() => []);
  const lastColumn = columns.length - 1;
  const cards = new Map<string, Card>();
  let nextId = 1;

  function assertRoom(column: number): void {
    const { name, wipLimit } = options.columns[column]!;
    if (wipLimit !== undefined && columns[column]!.length >= wipLimit) {
      throw new BoardError("WIP_LIMIT", `Column ${name} is at its WIP limit`);
    }
  }

  function getCard(cardId: string) {
    const card = cards.get(cardId);
    if (!card) throw new BoardError("UNKNOWN_CARD", `No card ${cardId}`);
    return card;
  }

  function columnIndex(name: string): number {
    const index = options.columns.findIndex((c) => c.name === name);
    if (index < 0) throw new BoardError("UNKNOWN_COLUMN", `No column ${name}`);
    return index;
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Card title must not be empty");
      assertRoom(0);
      const id = `C${nextId++}`;
      columns[0]!.push(id);
      cards.set(id, { column: 0, blockedPeriods: [] });
      return id;
    },
    move(cardId, toColumn) {
      const card = getCard(cardId);
      const to = columnIndex(toColumn);
      if (to === card.column) throw new BoardError("SAME_COLUMN", `${cardId} is already in ${toColumn}`);
      if (card.blockedSince !== undefined) throw new BoardError("BLOCKED", `${cardId} is blocked`);
      if (to > card.column + 1) throw new BoardError("SKIP_NOT_ALLOWED", `${cardId} cannot skip columns`);
      assertRoom(to);
      const from = columns[card.column]!;
      from.splice(from.indexOf(cardId), 1);
      columns[to]!.push(cardId);
      const now = options.now();
      if (card.column === 0) card.startedAt ??= now;
      if (to === lastColumn) card.finishedAt = now;
      card.column = to;
    },
    block(cardId, _reason) {
      const card = getCard(cardId);
      if (card.blockedSince !== undefined) {
        throw new BoardError("ALREADY_BLOCKED", `${cardId} is already blocked`);
      }
      card.blockedSince = options.now();
    },
    unblock(cardId) {
      const card = getCard(cardId);
      if (card.blockedSince === undefined) throw new BoardError("NOT_BLOCKED", `${cardId} is not blocked`);
      card.blockedPeriods.push({ from: card.blockedSince, to: options.now() });
      card.blockedSince = undefined;
    },
    cardsIn(column) {
      return [...columns[columnIndex(column)]!];
    },
    cycleTime(cardId) {
      const card = getCard(cardId);
      if (card.column !== lastColumn) return null;
      const started = card.startedAt!;
      const finished = card.finishedAt!;
      const blockedMs = card.blockedPeriods.reduce(
        (sum, { from, to }) => sum + Math.max(0, Math.min(to, finished) - Math.max(from, started)),
        0,
      );
      return { totalMs: finished - started, blockedMs };
    },
  };
}
