export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

/** Splits one CSV line into fields; quoted values are kept verbatim, unquoted ones trimmed. */
function parseFields(text: string): string[] {
  const fields: string[] = [];
  let pos = 0;
  while (true) {
    while (text[pos] === " " || text[pos] === "\t") pos++;
    let value = "";
    if (text[pos] === '"') {
      pos++;
      while (pos < text.length) {
        if (text[pos] === '"') {
          if (text[pos + 1] !== '"') {
            pos++;
            break;
          }
          pos++;
        }
        value += text[pos++];
      }
    }
    const comma = text.indexOf(",", pos);
    const end = comma === -1 ? text.length : comma;
    value += text.slice(pos, end).trim();
    pos = end;
    fields.push(value);
    if (pos >= text.length) return fields;
    pos++; // skip the comma
  }
}

function isCalendarDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number) as [number, number, number];
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== undefined && day >= 1 && day <= daysInMonth;
}

/** The amount in hundredths, or undefined unless it is written like `12`, `12.5` or `12.50` and positive. */
function parseAmountCents(text: string): bigint | undefined {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(text);
  if (!match) return undefined;
  const cents = BigInt(match[1]!) * 100n + BigInt((match[2] ?? "").padEnd(2, "0"));
  return cents > 0n ? cents : undefined;
}

/** `amountCents * rate`, rounded to the nearest cent (halves up), computed exactly on the rate's decimal digits. */
function convertCents(amountCents: bigint, rate: number): number {
  const match = /^(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/.exec(String(rate));
  if (!match) return Math.round(Number(amountCents) * rate);
  const fraction = match[2] ?? "";
  const exponent = Number(match[3] ?? 0) - fraction.length;
  let numerator = amountCents * BigInt(match[1]! + fraction);
  let denominator = 1n;
  if (exponent >= 0) numerator *= 10n ** BigInt(exponent);
  else denominator = 10n ** BigInt(-exponent);
  return Number((2n * numerator + denominator) / (2n * denominator));
}

const COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof COLUMNS)[number];

interface Expense {
  date: string;
  employee: string;
  category: string;
  /** The amount as written, in hundredths of `currency`. */
  amountCents: bigint;
  currency: string;
  hasReceipt: boolean;
  amountChfCents: number;
}

interface ReadContext {
  columnIndex: Record<Column, number>;
  columnCount: number;
  policy: Policy;
  fxRates: FxRates;
}

/** Parses and validates one data row; returns the rejection reason if a check fails. */
function readRow(fields: string[], { columnIndex, columnCount, policy, fxRates }: ReadContext): Expense | string {
  if (fields.length !== columnCount) return "wrong number of fields";
  const value = (name: Column) => fields[columnIndex[name]]!.trim();
  const date = value("date");
  if (!isCalendarDate(date)) return "invalid date";
  const employee = value("employee");
  if (employee === "") return "missing employee";
  const category = value("category");
  if (!Object.hasOwn(policy.categories, category)) return "unknown category";
  const amountCents = parseAmountCents(value("amount"));
  if (amountCents === undefined) return "invalid amount";
  const currency = value("currency");
  if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) return "unknown currency";
  const receipt = value("receipt").toLowerCase();
  if (receipt !== "yes" && receipt !== "no") return "invalid receipt flag";
  return {
    date,
    employee,
    category,
    amountCents,
    currency,
    hasReceipt: receipt === "yes",
    amountChfCents: currency === "CHF" ? Number(amountCents) : convertCents(amountCents, fxRates[currency]!),
  };
}

/** Returns a function that checks the accepted expenses in file order, remembering the earlier ones. */
function policyChecker(policy: Policy): (expense: Expense) => Violation[] {
  const seen = new Set<string>();
  const dayTotals = new Map<string, number>();
  return ({ date, employee, category, amountCents, currency, hasReceipt, amountChfCents }) => {
    const violations: Violation[] = [];
    const identity = JSON.stringify([employee, date, category, String(amountCents), currency]);
    if (seen.has(identity)) violations.push("DUPLICATE");
    seen.add(identity);

    const limits = policy.categories[category]!;
    if (limits.perItemLimitCents !== undefined && amountChfCents > limits.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }

    const day = JSON.stringify([employee, date, category]);
    const dayTotal = (dayTotals.get(day) ?? 0) + amountChfCents;
    dayTotals.set(day, dayTotal);
    if (limits.dailyLimitCents !== undefined && dayTotal > limits.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }

    if (!hasReceipt && amountChfCents > policy.receiptRequiredAboveCents) violations.push("NO_RECEIPT");
    return violations;
  };
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const rows = csv
    .split("\n")
    .map((text, i) => ({ line: i + 1, text: text.replace(/\r$/, "") }))
    .filter((row) => row.text.trim() !== "");
  if (rows.length === 0) throw new ExpenseFileError("Missing header");
  const header = parseFields(rows[0]!.text).map((name) => name.trim().toLowerCase());
  for (const name of COLUMNS) {
    if (!header.includes(name)) throw new ExpenseFileError(`Missing column: ${name}`);
  }
  const context: ReadContext = {
    columnIndex: Object.fromEntries(COLUMNS.map((name) => [name, header.indexOf(name)])) as Record<Column, number>,
    columnCount: header.length,
    policy,
    fxRates,
  };

  const checkPolicy = policyChecker(policy);
  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const totals = new Map<string, ExpenseReport["totals"][string]>();
  for (const { line, text } of rows.slice(1)) {
    const expense = readRow(parseFields(text), context);
    if (typeof expense === "string") {
      rejected.push({ line, reason: expense });
      continue;
    }
    const { date, employee, category, amountChfCents } = expense;
    const violations = checkPolicy(expense);
    lines.push({ line, date, employee, category, amountChfCents, violations });
    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
    totals.set(employee, total);
  }
  // Object.fromEntries defines own properties, so even an employee called "__proto__" gets an entry.
  return { lines, rejected, totals: Object.fromEntries(totals) };
}
