import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type Policy } from "./expenseReview";

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};
const fx = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";
const csv = (...rows: string[]) => [HEADER, ...rows].join("\n");
/** The rejection reason of a single data row, or "accepted". */
const verdict = (row: string) => {
  const report = reviewExpenses(csv(row), policy, fx);
  return report.rejected[0]?.reason ?? (report.lines.length === 1 ? "accepted" : "lost");
};

test("a single valid CHF row is approved", () => {
  const report = reviewExpenses(csv("2026-09-01,Anna,meals,12.50,CHF,yes"), policy, fx);
  expect(report).toEqual({
    lines: [
      { line: 2, date: "2026-09-01", employee: "Anna", category: "meals", amountChfCents: 1250, violations: [] },
    ],
    rejected: [],
    totals: { Anna: { approvedCents: 1250, flaggedCents: 0 } },
  });
});

test("a file without any non-blank line has no header", () => {
  for (const text of ["", "\n", "  \r\n\t\n   "]) {
    expect(() => reviewExpenses(text, policy, fx)).toThrow(new ExpenseFileError("Missing header"));
  }
});

test("a missing required column is named, the first one in spec order", () => {
  const check = (header: string, missing: string) =>
    expect(() => reviewExpenses(header + "\n", policy, fx)).toThrow(
      new ExpenseFileError(`Missing column: ${missing}`),
    );
  check("date,employee,category,amount,currency", "receipt");
  check("receipt,currency,amount,date", "employee");
  check("note", "date");
  check("dates,employee,category,amount,currency,receipt", "date");
});

test("header columns may come in any order, any case, padded, with extra columns", () => {
  const text = " Receipt ,NOTE,AMOUNT, Employee,currency,Category ,Date\nno,lunch,7.00,Ben,CHF,taxi,2026-09-02";
  const report = reviewExpenses(text, policy, fx);
  expect(report.lines).toEqual([
    { line: 2, date: "2026-09-02", employee: "Ben", category: "taxi", amountChfCents: 700, violations: [] },
  ]);
});

test("blank lines are skipped but counted, CRLF endings are accepted", () => {
  const text = `\r\n  \r\n${HEADER}\r\n\r\n2026-09-01,Anna,taxi,10,CHF,yes\r\n \t \r\n2026-09-02,Anna,taxi,5.5,CHF,yes\r\n`;
  const report = reviewExpenses(text, policy, fx);
  expect(report.lines.map((l) => [l.line, l.amountChfCents, l.date])).toEqual([
    [5, 1000, "2026-09-01"],
    [7, 550, "2026-09-02"],
  ]);
  expect(report.totals).toEqual({ Anna: { approvedCents: 1550, flaggedCents: 0 } });
});

test("quoted fields keep commas and unescape doubled quotes; unquoted values are trimmed", () => {
  const text = [
    `date,employee,category,amount,currency,receipt,note`,
    ` 2026-09-03 , "Muster, Hans ""Hansi""" ,"taxi", 3 ,CHF,"YES","a, b"`,
  ].join("\n");
  const report = reviewExpenses(text, policy, fx);
  expect(report.rejected).toEqual([]);
  expect(report.lines).toEqual([
    {
      line: 2,
      date: "2026-09-03",
      employee: `Muster, Hans "Hansi"`,
      category: "taxi",
      amountChfCents: 300,
      violations: [],
    },
  ]);
});

test("rows with a different number of fields than the header are rejected", () => {
  const report = reviewExpenses(
    csv("2026-09-01,Anna,taxi,10,CHF", "2026-09-01,Anna,taxi,10,CHF,yes", "2026-09-01,Anna,taxi,10,CHF,yes,extra"),
    policy,
    fx,
  );
  expect(report.rejected).toEqual([
    { line: 2, reason: "wrong number of fields" },
    { line: 4, reason: "wrong number of fields" },
  ]);
  expect(report.lines.map((l) => l.line)).toEqual([3]);
  expect(report.totals).toEqual({ Anna: { approvedCents: 1000, flaggedCents: 0 } });
  expect(verdict(`2026-09-01,"Anna, B",taxi,10,CHF,yes`)).toBe("accepted");
});

test("dates must be real calendar dates written YYYY-MM-DD", () => {
  for (const date of ["2026-09-30", "2024-02-29", "2000-02-29", "2026-12-31", "2026-01-01"]) {
    expect(verdict(`${date},Anna,taxi,10,CHF,yes`)).toBe("accepted");
  }
  for (const date of [
    "", "2026-9-01", "2026-09-1", "26-09-01", "2026/09/01", "01.09.2026", "2026-09-01T10:00",
    "2026-02-29", "1900-02-29", "2026-04-31", "2026-13-01", "2026-00-10", "2026-09-00", "2026-09-32",
    "２０２６-09-01",
  ]) {
    expect(verdict(`${date},Anna,taxi,10,CHF,yes`)).toBe("invalid date");
  }
});

test("rows without an employee are rejected", () => {
  expect(verdict("2026-09-01,,taxi,10,CHF,yes")).toBe("missing employee");
  expect(verdict("2026-09-01,   ,taxi,10,CHF,yes")).toBe("missing employee");
  expect(verdict(`2026-09-01,"",taxi,10,CHF,yes`)).toBe("missing employee");
  expect(verdict(`2026-09-01," ",taxi,10,CHF,yes`)).toBe("missing employee");
});

test("categories must be policy keys, matched exactly", () => {
  expect(verdict("2026-09-01,Anna, hotel ,10,CHF,yes")).toBe("accepted");
  for (const category of ["Taxi", "TAXI", "train", "", "toString", "__proto__", "constructor"]) {
    expect(verdict(`2026-09-01,Anna,${category},10,CHF,yes`)).toBe("unknown category");
  }
});

test("amounts are positive decimals with at most two decimals", () => {
  for (const amount of ["10", "0.01", "10.5", "10.50", "007.10", "123456"]) {
    expect(verdict(`2026-09-01,Anna,taxi,${amount},CHF,yes`)).toBe("accepted");
  }
  for (const amount of [
    "", "0", "0.00", "00.0", "-5", "+5", "10.", ".5", "10.123", "1e3", "1'000", "10,50", "abc", "Infinity", "0x10",
    "１０", "1 0",
  ]) {
    expect(verdict(`2026-09-01,Anna,taxi,"${amount}",CHF,yes`)).toBe("invalid amount");
  }
});

test("currencies must be CHF or have an exchange rate", () => {
  for (const currency of ["CHF", "EUR", " USD "]) {
    expect(verdict(`2026-09-01,Anna,taxi,10,${currency},yes`)).toBe("accepted");
  }
  for (const currency of ["chf", "eur", "GBP", "", "toString", "__proto__"]) {
    expect(verdict(`2026-09-01,Anna,taxi,10,${currency},yes`)).toBe("unknown currency");
  }
});

test("the receipt flag is yes or no, in any case", () => {
  for (const receipt of ["yes", "no", "YES", "No", " nO "]) {
    expect(verdict(`2026-09-01,Anna,taxi,10,CHF,${receipt}`)).toBe("accepted");
  }
  for (const receipt of ["", "y", "n", "true", "1", "yess", "ja"]) {
    expect(verdict(`2026-09-01,Anna,taxi,10,CHF,${receipt}`)).toBe("invalid receipt flag");
  }
});

test("foreign amounts are converted to CHF cents, halves rounded up", () => {
  const rates = { EUR: 0.9412, USD: 1.005, JPY: 0.0061, XAU: 2500, TINY: 1e-7, HALF: 0.5 };
  const chf = (amount: string, currency: string) =>
    reviewExpenses(csv(`2026-09-01,Anna,taxi,${amount},${currency},yes`), policy, rates).lines[0]!.amountChfCents;
  expect(chf("10", "EUR")).toBe(941); // 941.2
  expect(chf("12.34", "EUR")).toBe(1161); // 1161.4408
  expect(chf("1.00", "USD")).toBe(101); // 100.5 exactly, a float product gives 100.4999…
  expect(chf("0.01", "HALF")).toBe(1); // 0.5
  expect(chf("0.03", "HALF")).toBe(2); // 1.5
  expect(chf("1000", "JPY")).toBe(610);
  expect(chf("0.5", "XAU")).toBe(125000);
  expect(chf("50000", "TINY")).toBe(1); // 0.5
  expect(chf("49999", "TINY")).toBe(0);
  expect(chf("10.05", "CHF")).toBe(1005);
});

const violations = (...rows: string[]) =>
  reviewExpenses(csv(...rows), policy, fx).lines.map((l) => [l.line, ...l.violations]);

test("a row equal to an earlier accepted row is a duplicate", () => {
  expect(
    violations(
      "2026-09-01,Anna,taxi,12.5,EUR,yes",
      "2026-09-01,Anna,taxi,12.50,EUR,no", // same value, receipt flag does not matter
      "2026-09-01, Anna ,taxi,012.5,EUR,yes", // and again
      "2026-09-01,Anna,taxi,12.5,CHF,yes", // other currency
      "2026-09-01,Ben,taxi,12.5,EUR,yes", // other employee
      "2026-09-02,Anna,taxi,12.5,EUR,yes", // other date
      "2026-09-01,Anna,hotel,12.5,EUR,yes", // other category
      "2026-09-01,Anna,taxi,12.51,EUR,yes", // other amount
    ),
  ).toEqual([[2], [3, "DUPLICATE"], [4, "DUPLICATE"], [5], [6], [7], [8], [9]]);
});

test("rejected rows do not make later rows duplicates", () => {
  expect(violations("2026-09-01,Anna,taxi,12.5,EUR,maybe", "2026-09-01,Anna,taxi,12.5,EUR,yes")).toEqual([[3]]);
});

test("an item above the category's per-item limit in CHF is flagged", () => {
  expect(
    violations(
      "2026-09-01,Anna,hotel,250.00,CHF,yes", // at the limit
      "2026-09-02,Anna,hotel,250.01,CHF,yes",
      "2026-09-03,Anna,hotel,265.00,EUR,yes", // 249.42 CHF
      "2026-09-04,Anna,hotel,266.00,EUR,yes", // 250.36 CHF
      "2026-09-05,Anna,taxi,9999,CHF,yes", // no limit for taxis
    ),
  ).toEqual([[2], [3, "OVER_ITEM_LIMIT"], [4], [5, "OVER_ITEM_LIMIT"], [6]]);
});

test("rows are flagged once the running daily total per employee, date and category exceeds the limit", () => {
  expect(
    violations(
      "2026-09-01,Anna,meals,30,CHF,yes", // 30
      "2026-09-01,Ben,meals,50,CHF,yes", // other employee
      "2026-09-02,Anna,meals,50,CHF,yes", // other date
      "2026-09-01,Anna,taxi,60,CHF,yes", // other category, no daily limit
      "2026-09-01,Anna,meals,50,CHF,yes", // 80, at the limit
      "2026-09-01,Anna,meals,0.01,CHF,yes", // 80.01
      "2026-09-01,Anna,meals,5,XXX,yes", // rejected, does not count
      "2026-09-01,Anna,meals,5,CHF,yes", // 85.01
    ),
  ).toEqual([[2], [3], [4], [5], [6], [7, "OVER_DAILY_LIMIT"], [9, "OVER_DAILY_LIMIT"]]);
});

test("duplicates count towards the daily running total", () => {
  expect(
    violations("2026-09-01,Anna,meals,45,CHF,yes", "2026-09-01,Anna,meals,45,CHF,yes"),
  ).toEqual([[2], [3, "DUPLICATE", "OVER_DAILY_LIMIT"]]);
});

test("rows without receipt above the receipt threshold in CHF are flagged", () => {
  expect(
    violations(
      "2026-09-01,Anna,taxi,20.00,CHF,no", // at the threshold
      "2026-09-02,Anna,taxi,20.01,CHF,NO",
      "2026-09-03,Anna,taxi,21.00,EUR,no", // 19.77 CHF
      "2026-09-04,Anna,taxi,21.30,EUR,no", // 20.05 CHF
      "2026-09-05,Anna,taxi,500,CHF,yes",
    ),
  ).toEqual([[2], [3, "NO_RECEIPT"], [4], [5, "NO_RECEIPT"], [6]]);
});

test("violations are listed in a fixed order", () => {
  expect(
    violations("2026-09-01,Anna,meals,60,CHF,yes", "2026-09-01,Anna,meals,60.00,CHF,no"),
  ).toEqual([
    [2, "OVER_ITEM_LIMIT"],
    [3, "DUPLICATE", "OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
  ]);
});

test("totals split each employee's CHF amounts into approved and flagged", () => {
  const report = reviewExpenses(
    csv(
      "2026-09-01,Anna,taxi,10,CHF,yes",
      "2026-09-01,Anna,taxi,10,CHF,yes", // duplicate
      "2026-09-01,Anna,meals,10,EUR,yes", // 9.41
      "2026-09-01,Ben,hotel,300,CHF,yes", // over item limit
      "2026-09-01,Cleo,taxi,abc,CHF,yes", // rejected: no entry for Cleo
      "2026-09-01,__proto__,taxi,1,CHF,yes",
    ),
    policy,
    fx,
  );
  expect(report.totals).toEqual({
    Anna: { approvedCents: 1941, flaggedCents: 1000 },
    Ben: { approvedCents: 0, flaggedCents: 30000 },
    ["__proto__"]: { approvedCents: 100, flaggedCents: 0 },
  });
  expect(Object.keys(report.totals)).toEqual(["Anna", "Ben", "__proto__"]);
  expect(report.rejected).toEqual([{ line: 6, reason: "invalid amount" }]);
});

test("the first failing check gives the reason", () => {
  expect(verdict("2026-02-30,,bus,0,GBP,maybe")).toBe("invalid date");
  expect(verdict("2026-02-28,,bus,0,GBP,maybe")).toBe("missing employee");
  expect(verdict("2026-02-28,Anna,bus,0,GBP,maybe")).toBe("unknown category");
  expect(verdict("2026-02-28,Anna,taxi,0,GBP,maybe")).toBe("invalid amount");
  expect(verdict("2026-02-28,Anna,taxi,1,GBP,maybe")).toBe("unknown currency");
  expect(verdict("2026-02-28,Anna,taxi,1,EUR,maybe")).toBe("invalid receipt flag");
  expect(verdict("2026-02-30,,bus,0,GBP")).toBe("wrong number of fields");
});

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});
