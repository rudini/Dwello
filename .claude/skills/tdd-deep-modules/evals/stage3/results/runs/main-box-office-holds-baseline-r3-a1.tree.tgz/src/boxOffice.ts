export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const GROUP_DISCOUNT_MIN_TICKETS = 4;
const CANCELLATION_FEE_PER_TICKET_CENTS = 200;

interface HoldRecord extends Hold {
  ended: boolean;
}

interface OrderRecord extends Order {
  cancelled: boolean;
}

/** Order total in cents: 10 % off from 4 tickets, rounded to 5 cents (halves up). */
function orderTotalCents(quantity: number, priceCents: number): number {
  // Work in tenths of a cent so the discount stays in integer arithmetic.
  const tenths = quantity * priceCents * (quantity >= GROUP_DISCOUNT_MIN_TICKETS ? 9 : 10);
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const sections = new Map(options.sections.map((s) => [s.id, { ...s }]));
  const holds = new Map<string, HoldRecord>();
  const orders = new Map<string, OrderRecord>();
  let nextHoldNumber = 1;
  let nextOrderNumber = 1;

  const isActive = (hold: HoldRecord, now: number) => !hold.ended && now < hold.expiresAt;

  function requireSection(sectionId: string): SectionConfig {
    const section = sections.get(sectionId);
    if (!section) {
      throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    }
    return section;
  }

  function requireOpenHold(holdId: string): HoldRecord {
    const hold = holds.get(holdId);
    if (!hold || hold.ended) {
      throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    }
    return hold;
  }

  /** Tickets in active holds plus non-cancelled orders matching the predicate. */
  function taken(matches: (entry: Hold | Order) => boolean, now: number): number {
    let total = 0;
    for (const hold of holds.values()) {
      if (isActive(hold, now) && matches(hold)) total += hold.quantity;
    }
    for (const order of orders.values()) {
      if (!order.cancelled && matches(order)) total += order.quantity;
    }
    return total;
  }

  function availableAt(section: SectionConfig, now: number): number {
    return section.capacity - taken((e) => e.sectionId === section.id, now);
  }

  return {
    hold(customerId, sectionId, quantity) {
      const section = requireSection(sectionId);
      if (typeof quantity !== "number" || !Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const now = options.now();
      const customerTickets = taken((e) => e.customerId === customerId, now);
      if (customerTickets + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError(
          "CUSTOMER_LIMIT",
          `Customer ${customerId} may have at most ${options.maxTicketsPerCustomer} tickets`,
        );
      }
      if (quantity > availableAt(section, now)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in section ${sectionId}`);
      }
      const record: HoldRecord = {
        holdId: `H${nextHoldNumber++}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: now + options.holdMinutes * 60_000,
        ended: false,
      };
      holds.set(record.holdId, record);
      const { ended: _ended, ...hold } = record;
      return hold;
    },

    confirm(holdId) {
      const hold = requireOpenHold(holdId);
      if (!isActive(hold, options.now())) {
        throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      }
      const section = requireSection(hold.sectionId);
      hold.ended = true;
      const record: OrderRecord = {
        orderId: `O${nextOrderNumber++}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: orderTotalCents(hold.quantity, section.priceCents),
        cancelled: false,
      };
      orders.set(record.orderId, record);
      const { cancelled: _cancelled, ...order } = record;
      return order;
    },

    release(holdId) {
      const hold = requireOpenHold(holdId);
      // Releasing an expired hold succeeds without effect.
      if (isActive(hold, options.now())) {
        hold.ended = true;
      }
    },

    cancelOrder(orderId) {
      const order = orders.get(orderId);
      if (!order || order.cancelled) {
        throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      }
      order.cancelled = true;
      return Math.max(0, order.totalCents - CANCELLATION_FEE_PER_TICKET_CENTS * order.quantity);
    },

    available(sectionId) {
      return availableAt(requireSection(sectionId), options.now());
    },
  };
}
