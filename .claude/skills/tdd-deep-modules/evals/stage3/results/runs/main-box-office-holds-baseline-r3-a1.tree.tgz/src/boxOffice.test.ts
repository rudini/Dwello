import { describe, expect, test } from "bun:test";
import { BoxOfficeError, type BoxOfficeErrorCode, createBoxOffice } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

const MINUTE = 60_000;

function setup(overrides: { maxTicketsPerCustomer?: number } = {}) {
  const clock = { time: 1_000_000 };
  const office = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 4990 },
      { id: "BALKON", capacity: 5, priceCents: 3333 },
      { id: "LOGE", capacity: 8, priceCents: 150 },
    ],
    holdMinutes: 15,
    maxTicketsPerCustomer: overrides.maxTicketsPerCustomer ?? 6,
    now: () => clock.time,
  });
  return { office, clock };
}

function expectCode(fn: () => unknown, code: BoxOfficeErrorCode) {
  try {
    fn();
  } catch (error) {
    expect(error).toBeInstanceOf(BoxOfficeError);
    expect((error as BoxOfficeError).code).toBe(code);
    return;
  }
  throw new Error(`expected ${code}`);
}

describe("hold", () => {
  test("creates holds with sequential ids and expiry", () => {
    const { office, clock } = setup();
    expect(office.hold("alice", "PARKETT", 2)).toEqual({
      holdId: "H1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 2,
      expiresAt: clock.time + 15 * MINUTE,
    });
    expect(office.available("PARKETT")).toBe(8);
    expectCode(() => office.hold("bob", "PARKETT", 0), "INVALID_QUANTITY");
    expect(office.hold("bob", "PARKETT", 1).holdId).toBe("H2");
  });

  test("validates in the documented order", () => {
    const { office } = setup({ maxTicketsPerCustomer: 20 });
    expectCode(() => office.hold("a", "NOPE", 0), "UNKNOWN_SECTION");
    expectCode(() => office.hold("a", "PARKETT", 1.5), "INVALID_QUANTITY");
    expectCode(() => office.hold("a", "PARKETT", -1), "INVALID_QUANTITY");
    expectCode(() => office.hold("a", "PARKETT", NaN), "INVALID_QUANTITY");
    expectCode(() => office.hold("a", "PARKETT", 21), "CUSTOMER_LIMIT");
    expectCode(() => office.hold("a", "PARKETT", 11), "SOLD_OUT");
    expect(office.available("PARKETT")).toBe(10);
  });

  test("customer limit spans sections and orders, ignores cancelled orders", () => {
    const { office } = setup();
    office.confirm(office.hold("alice", "PARKETT", 3).holdId);
    office.hold("alice", "BALKON", 2);
    expectCode(() => office.hold("alice", "LOGE", 2), "CUSTOMER_LIMIT");
    office.hold("alice", "LOGE", 1);
    office.cancelOrder("O1");
    office.hold("alice", "LOGE", 3);
  });

  test("no partial holds when sold out", () => {
    const { office } = setup();
    office.hold("a", "BALKON", 4);
    expectCode(() => office.hold("b", "BALKON", 2), "SOLD_OUT");
    expect(office.hold("b", "BALKON", 1).holdId).toBe("H2");
    expect(office.available("BALKON")).toBe(0);
  });
});

describe("expiry", () => {
  test("expired holds stop counting at expiresAt", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "BALKON", 5);
    clock.time = hold.expiresAt - 1;
    expect(office.available("BALKON")).toBe(0);
    clock.time = hold.expiresAt;
    expect(office.available("BALKON")).toBe(5);
    expectCode(() => office.confirm(hold.holdId), "HOLD_EXPIRED");
    office.hold("alice", "BALKON", 5);
  });

  test("releasing an expired hold succeeds without effect", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "BALKON", 2);
    clock.time = hold.expiresAt;
    office.release(hold.holdId);
    expect(office.available("BALKON")).toBe(5);
  });
});

describe("confirm and release", () => {
  test("confirm creates an order and keeps the tickets taken", () => {
    const { office } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    expect(office.confirm(hold.holdId)).toEqual({
      orderId: "O1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 2,
      totalCents: 9980,
    });
    expect(office.available("PARKETT")).toBe(8);
    expectCode(() => office.confirm(hold.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.release(hold.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.confirm("H99"), "UNKNOWN_HOLD");
  });

  test("release frees tickets once", () => {
    const { office } = setup();
    const hold = office.hold("alice", "PARKETT", 3);
    office.release(hold.holdId);
    expect(office.available("PARKETT")).toBe(10);
    expectCode(() => office.release(hold.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.confirm(hold.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.release("H42"), "UNKNOWN_HOLD");
  });

  test("pricing: group discount and 5-cent rounding", () => {
    const { office } = setup();
    // 3 * 3333 = 9999 -> 10000
    expect(office.confirm(office.hold("a", "BALKON", 3).holdId).totalCents).toBe(10000);
    // 4 * 4990 * 0.9 = 17964 -> 17965
    expect(office.confirm(office.hold("b", "PARKETT", 4).holdId).totalCents).toBe(17965);
    // 5 * 150 * 0.9 = 675 (exact)
    expect(office.confirm(office.hold("c", "LOGE", 5).holdId).totalCents).toBe(675);
  });

  test("pricing: exact halves round up", () => {
    const office = createBoxOffice({
      sections: [
        { id: "A", capacity: 10, priceCents: 5 },
        { id: "B", capacity: 10, priceCents: 1003 },
      ],
      holdMinutes: 10,
      maxTicketsPerCustomer: 10,
      now: () => 0,
    });
    // 5 * 5 * 0.9 = 22.5 -> 25 (exact half rounds up)
    expect(office.confirm(office.hold("a", "A", 5).holdId).totalCents).toBe(25);
    // 4 * 1003 * 0.9 = 3610.8 -> 3610
    expect(office.confirm(office.hold("b", "B", 4).holdId).totalCents).toBe(3610);
    // 1 * 1003 = 1003 -> 1005 (rounding without discount)
    expect(office.confirm(office.hold("c", "B", 1).holdId).totalCents).toBe(1005);
    // 2 * 1003 = 2006 -> 2005
    expect(office.confirm(office.hold("d", "B", 2).holdId).totalCents).toBe(2005);
  });
});

describe("cancelOrder", () => {
  test("refunds total minus fee, frees tickets, never negative", () => {
    const { office } = setup();
    const order = office.confirm(office.hold("alice", "PARKETT", 2).holdId);
    expect(office.cancelOrder(order.orderId)).toBe(9980 - 400);
    expect(office.available("PARKETT")).toBe(10);
    expectCode(() => office.cancelOrder(order.orderId), "UNKNOWN_ORDER");
    expectCode(() => office.cancelOrder("O9"), "UNKNOWN_ORDER");
    const cheap = office.confirm(office.hold("bob", "LOGE", 2).holdId);
    expect(office.cancelOrder(cheap.orderId)).toBe(0);
  });
});
