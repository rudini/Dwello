export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const WEEK: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

interface Token {
  kind: "word" | "time" | "symbol";
  text: string;
  column: number;
}

/** Words, times and "-,;" symbols; any other character but a space is a symbol of its own. */
function tokenize(text: string): Token[] {
  return [...text.matchAll(/(\p{L}+)|([0-9:]+)|[^ ]/gu)].map((m) => ({
    kind: m[1] ? "word" : m[2] ? "time" : "symbol",
    text: m[0],
    column: m.index + 1,
  }));
}

function unexpected(token: Token): OpeningHoursError {
  return new OpeningHoursError("UNEXPECTED", token.column, `Unexpected "${token.text}"`);
}

/** Reads the tokens of one text from left to right. */
class Cursor {
  private pos = 0;

  constructor(
    private readonly tokens: Token[],
    private readonly endColumn: number,
  ) {}

  peekColumn(): number {
    return this.tokens[this.pos]?.column ?? this.endColumn;
  }

  /** Consumes the next token, which must exist and fit. */
  next(fits: (token: Token) => boolean): Token {
    const token = this.tokens[this.pos++];
    if (!token) throw new OpeningHoursError("UNEXPECTED", this.endColumn, "Unexpected end of text");
    if (!fits(token)) throw unexpected(token);
    return token;
  }

  /** Throws unless all tokens are consumed. */
  expectEnd(): void {
    const token = this.tokens[this.pos];
    if (token) throw unexpected(token);
  }

  /** Consumes the next token if it is `text`. */
  accept(text: string): boolean {
    if (this.tokens[this.pos]?.text !== text) return false;
    this.pos++;
    return true;
  }
}

function readDay(cursor: Cursor): number {
  const token = cursor.next((t) => t.kind === "word");
  const index = WEEK.indexOf(token.text as Day);
  if (index < 0) throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
  return index;
}

function readDays(cursor: Cursor): Day[] {
  const days: Day[] = [];
  do {
    const column = cursor.peekColumn();
    const name = (day: Day) => {
      if (days.includes(day)) {
        throw new OpeningHoursError("DUPLICATE_DAY", column, `${day} is named twice in the same rule`);
      }
      days.push(day);
    };
    // The first day is checked before the rest of the item is read: it is the first problem.
    const first = readDay(cursor);
    name(WEEK[first]);
    const last = cursor.accept("-") ? readDay(cursor) : first;
    for (let i = 1; i <= (last - first + 7) % 7; i++) name(WEEK[(first + i) % 7]);
  } while (cursor.accept(","));
  return days;
}

/** Reads a time and returns its text; "24:00" is only valid as the end of a range. */
function readTime(cursor: Cursor, isEnd: boolean): string {
  const token = cursor.next((t) => t.kind === "time");
  const match = /^(\d\d):([0-5]\d)$/.exec(token.text);
  const valid = match !== null && (Number(match[1]) < 24 || (isEnd && token.text === "24:00"));
  if (!valid) throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
  return token.text;
}

function readRanges(cursor: Cursor): TimeRange[] {
  const ranges: TimeRange[] = [];
  if (cursor.accept("off")) return ranges;
  do {
    const start = cursor.peekColumn();
    const from = readTime(cursor, false);
    cursor.next((t) => t.text === "-");
    const to = readTime(cursor, true);
    if (to <= from) {
      throw new OpeningHoursError("END_BEFORE_START", start, `Range ${from}-${to} ends before it starts`);
    }
    if (ranges.some((earlier) => from < earlier.to && earlier.from < to)) {
      throw new OpeningHoursError("OVERLAP", start, `Range ${from}-${to} overlaps an earlier range`);
    }
    ranges.push({ from, to });
  } while (cursor.accept(","));
  // "HH:MM" texts sort like the times they denote.
  return ranges.sort((a, b) => a.from.localeCompare(b.from));
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  const hours = Object.fromEntries(WEEK.map((day) => [day, []])) as unknown as WeeklyHours;
  const cursor = new Cursor(tokenize(text), text.length + 1);
  do {
    const days = readDays(cursor);
    const ranges = readRanges(cursor);
    // A later rule replaces the hours of every day it names.
    for (const day of days) hours[day] = ranges.map((r) => ({ ...r }));
  } while (cursor.accept(";"));
  cursor.expectEnd();
  return hours;
}
