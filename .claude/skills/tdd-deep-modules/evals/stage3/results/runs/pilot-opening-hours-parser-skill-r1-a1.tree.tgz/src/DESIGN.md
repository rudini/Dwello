# Design note: `parseOpeningHours`

**Hidden decision:** how the opening-hours text is split into tokens and parsed, how
rules override each other, and which error (code and column) comes first when reading
left to right. Callers see only a weekly schedule or one `OpeningHoursError`.

**Two designs**

- A: `parseOpeningHours(text): WeeklyHours`, which throws `OpeningHoursError`.
- B: `tryParseOpeningHours(text): { ok: true; hours } | { ok: false; code; column; description }`.

Chosen: A, because the caller learns one name and one error type, and the tokenizer,
the grammar and the rule merging all sit behind it. It is also the required API.

**Interface**

- `parseOpeningHours(text)` returns all seven days. A closed day is `[]`. Each day's
  ranges are fresh objects, sorted by start time.
- `OpeningHoursError` has `code` and a 1-based `column`, and its message ends with
  `(column N)`.
- `Day`, `TimeRange`, `WeeklyHours` and `OpeningHoursErrorCode` are unchanged from the stub.

**Inside:** a tokenizer and a recursive-descent parser. The tokenizer produces words
(`\p{L}+`), times (`[0-9:]+`) and single-character symbols; any character other than a
space becomes a symbol of its own. The parser uses a private `Cursor` with
`readDays`/`readRanges`/`readTime`. Every check runs as soon as its token is read, so
the first problem from the left wins. End of text is reported at `text.length + 1`.

**Depth:** `depth_report src/openingHours.ts` gives
`surface 10, size 125, ratio 12.5, classitis no, pass-through 0, duplicate 1 -> deep`.
The refactors made these changes:
- The index-juggling loop became a cursor-based parser.
- `nextOf`/`expect` were merged into a single `next(fits)` (this removed the duplicate lines).
- The `24:00` check became simpler.
- Ranges are copied per day, so days don't share range objects.

**Interpretations and limits**

- A word counts as `UNKNOWN_DAY` only where a day is expected (at the start of a rule,
  after `,` in the day list, or after `-` in a day range). A word anywhere else (`Mo Tu`,
  `Mo Off`) is `UNEXPECTED`. `off` in a day position is `UNKNOWN_DAY`.
- A time token is validated only where a time is expected. A time in a day position is
  `UNEXPECTED`. `Mo 08.00-…` gives `INVALID_TIME` on `08`, at column 4.
- `DUPLICATE_DAY` checks the first day of an item as soon as it is read. So `Mo,Mo-Fx`
  reports `DUPLICATE_DAY` at column 4, not `UNKNOWN_DAY` at `Fx`.
- Only the space character counts as whitespace. A tab is `UNEXPECTED`, and a tab-only
  text is `UNEXPECTED`, not `EMPTY`.
- Columns count UTF-16 code units.
- "The first problem from the left is reported" has no test of its own. Each check
  already ran eagerly when its error test went green, so a test for it could not fail
  first. Each error test includes left-to-right cases.

**Proof:** `scripts/tdd_replay d083a1a..HEAD` printed `REPLAY: ACCEPT` before this note was added.
