# Opening hours parser: test list

**Hidden decision:** how the opening-hours text is tokenised and parsed, how rules
override each other, and which error (code and column) is the first one met when
reading left to right. Callers only see a weekly schedule or one `OpeningHoursError`.

**Sketch A (chosen):** one function that returns the schedule or throws.

```ts
parseOpeningHours(text: string): WeeklyHours // throws OpeningHoursError
const hours = parseOpeningHours(input.value);
```

**Sketch B:** a result object, no exceptions.

```ts
tryParseOpeningHours(text: string): { ok: true; hours: WeeklyHours } | { ok: false; code; column; description }
const result = tryParseOpeningHours(input.value); if (!result.ok) highlight(result.column);
```

Chosen: Sketch A, because the caller learns one name and one error type, and the
tokenizer, grammar and rule merging all sit behind it (it is also the required API).

## Behaviours (through `parseOpeningHours`)

- [x] a single day with one range yields that range, all seven days present, the others closed
- [x] a day list with commas opens each listed day
- [x] a day range opens every day from first to last
- [x] a day range wraps around the week (`Fr-Mo`), `Mo-Mo` is Mo only
- [x] several ranges are returned sorted by start time; touching ranges are allowed
- [x] `off` closes the named days
- [x] a later rule replaces the hours of the days it names
- [x] spaces between tokens and at start and end carry no meaning
- [x] `24:00` is accepted as the end of a range
- [x] EMPTY for empty or blank text, column 1
- [x] UNKNOWN_DAY for a word where a day is expected
- [x] INVALID_TIME for malformed or out-of-range times, and `24:00` as a start
- [x] END_BEFORE_START at the range's start when the end is not later
- [x] OVERLAP at the later-written range's start
- [x] DUPLICATE_DAY at the day item naming an already named day
- [x] UNEXPECTED when the text ends too early (length + 1), including an empty last rule
- [x] UNEXPECTED for a token that does not fit or a character that belongs to no token
- [x] the first problem from the left is reported when there are several
