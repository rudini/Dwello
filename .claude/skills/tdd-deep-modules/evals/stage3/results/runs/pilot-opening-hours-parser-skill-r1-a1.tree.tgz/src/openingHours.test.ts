import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

const closedWeek = () => ({ Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] });
const range = (from: string, to: string) => ({ from, to });

/** The schedule, or `{ code, column }` of the thrown OpeningHoursError (any other error as is). */
function outcome(text: string): unknown {
  try {
    return parseOpeningHours(text);
  } catch (error) {
    if (error instanceof OpeningHoursError) return { code: error.code, column: error.column };
    return error;
  }
}

test("a single day with one range opens only that day", () => {
  expect(outcome("Mo 08:00-12:00")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00")],
  });
});

test("a day list with commas opens each listed day", () => {
  expect(outcome("Mo,We,Su 08:00-12:00")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00")],
    We: [range("08:00", "12:00")],
    Su: [range("08:00", "12:00")],
  });
});

test("a day range opens every day from first to last", () => {
  const morning = [range("08:00", "12:00")];
  expect(outcome("Tu-Fr 08:00-12:00")).toEqual({
    ...closedWeek(),
    Tu: morning,
    We: morning,
    Th: morning,
    Fr: morning,
  });
});

test("a day range wraps around the week, and a range from a day to itself is that day", () => {
  const morning = [range("08:00", "12:00")];
  expect(outcome("Fr-Mo 08:00-12:00")).toEqual({
    ...closedWeek(),
    Fr: morning,
    Sa: morning,
    Su: morning,
    Mo: morning,
  });
  expect(outcome("We-We 08:00-12:00")).toEqual({ ...closedWeek(), We: morning });
});

test("several ranges are returned sorted by start time, and touching ranges are allowed", () => {
  expect(outcome("Mo 13:30-18:30,08:00-12:00,12:00-13:00")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00"), range("12:00", "13:00"), range("13:30", "18:30")],
  });
});

test("off closes the named days", () => {
  expect(outcome("Mo-Su off")).toEqual(closedWeek());
});

test("a later rule replaces the hours of the days it names", () => {
  const day = [range("08:00", "20:00")];
  expect(outcome("Mo-Su 08:00-20:00;Su off;We 14:00-18:00")).toEqual({
    Mo: day,
    Tu: day,
    We: [range("14:00", "18:00")],
    Th: day,
    Fr: day,
    Sa: day,
    Su: [],
  });
});

test("spaces between tokens and at the start and end carry no meaning", () => {
  expect(outcome("  Mo , We - Th 08:00 - 12:00 ,13:00-14:00 ; Su   off  ")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00"), range("13:00", "14:00")],
    We: [range("08:00", "12:00"), range("13:00", "14:00")],
    Th: [range("08:00", "12:00"), range("13:00", "14:00")],
  });
  expect(outcome("Mo-Fr08:00-12:00")).toEqual(outcome("Mo-Fr 08:00-12:00"));
});

test("empty or blank text is EMPTY at column 1", () => {
  expect(outcome("")).toEqual({ code: "EMPTY", column: 1 });
  expect(outcome("   ")).toEqual({ code: "EMPTY", column: 1 });
});

test("a word where a day is expected that is no day is UNKNOWN_DAY at the word", () => {
  expect(outcome("Mo-Fx 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 4 });
  expect(outcome("  mo 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 3 });
  expect(outcome("Mo off; Sa,Sun 09:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 12 });
  expect(outcome("off")).toEqual({ code: "UNKNOWN_DAY", column: 1 });
});

test("a malformed or out-of-range time is INVALID_TIME at the time, and 24:00 ends a range only", () => {
  expect(outcome("Mo 8:00-12:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(outcome("Mo 08:00-12:0")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(outcome("Mo 08:00-1200")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(outcome("Mo 08:00-12:00:00")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(outcome("Mo 08:60-12:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(outcome("Mo 08:00-25:00")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(outcome("Mo 08:00-24:01")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(outcome("Mo 24:00-24:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(outcome("Mo 18:00-24:00")).toEqual({ ...closedWeek(), Mo: [range("18:00", "24:00")] });
});

test("a range whose end is not later than its start is END_BEFORE_START at its start", () => {
  expect(outcome("Mo 12:00-08:00")).toEqual({ code: "END_BEFORE_START", column: 4 });
  expect(outcome("Mo 08:00-12:00, 10:00 - 10:00")).toEqual({ code: "END_BEFORE_START", column: 17 });
  expect(outcome("Mo 00:00-00:00")).toEqual({ code: "END_BEFORE_START", column: 4 });
});

test("a range overlapping an earlier range of the same rule is OVERLAP at the later range", () => {
  expect(outcome("Mo 13:00-18:00,08:00-12:00,11:00-14:00")).toEqual({ code: "OVERLAP", column: 28 });
  expect(outcome("Mo 08:00-18:00, 10:00-11:00")).toEqual({ code: "OVERLAP", column: 17 });
  expect(outcome("Mo 10:00-11:00,08:00-18:00")).toEqual({ code: "OVERLAP", column: 16 });
  expect(outcome("Mo 08:00-12:00;Mo 10:00-14:00")).toEqual({
    ...closedWeek(),
    Mo: [range("10:00", "14:00")],
  });
});

test("a day item naming a day already named in the same rule is DUPLICATE_DAY at the item", () => {
  expect(outcome("Mo-We,Tu 08:00-12:00")).toEqual({ code: "DUPLICATE_DAY", column: 7 });
  expect(outcome("Mo, Sa-Tu 08:00-12:00")).toEqual({ code: "DUPLICATE_DAY", column: 5 });
  expect(outcome("Fr-Mo,Mo off")).toEqual({ code: "DUPLICATE_DAY", column: 7 });
  expect(outcome("Mo,Mo-Fx off")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
  expect(outcome("Tu-Mo off;Mo 08:00-12:00")).toEqual({
    ...closedWeek(),
    Mo: [range("08:00", "12:00")],
  });
});

test("text that ends too early is UNEXPECTED at its length + 1", () => {
  expect(outcome("Mo 08:00-")).toEqual({ code: "UNEXPECTED", column: 10 });
  expect(outcome("Mo off;")).toEqual({ code: "UNEXPECTED", column: 8 });
  expect(outcome("Mo off; ")).toEqual({ code: "UNEXPECTED", column: 9 });
  expect(outcome("Mo")).toEqual({ code: "UNEXPECTED", column: 3 });
  expect(outcome("Mo-")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(outcome("Mo, ")).toEqual({ code: "UNEXPECTED", column: 5 });
  expect(outcome("Mo 08:00")).toEqual({ code: "UNEXPECTED", column: 9 });
  expect(outcome("Mo 08:00-12:00,")).toEqual({ code: "UNEXPECTED", column: 16 });
});

test("a token that does not fit, or a character that belongs to no token, is UNEXPECTED at it", () => {
  expect(outcome(";Mo off")).toEqual({ code: "UNEXPECTED", column: 1 });
  expect(outcome("Mo off;;Tu off")).toEqual({ code: "UNEXPECTED", column: 8 });
  expect(outcome("Mo Tu 08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(outcome("Mo Off")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(outcome("Mo off Tu off")).toEqual({ code: "UNEXPECTED", column: 8 });
  expect(outcome("Mo off,08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 7 });
  expect(outcome("Mo 08:00-12:00 13:00-14:00")).toEqual({ code: "UNEXPECTED", column: 16 });
  expect(outcome("Mo 08:00-12:00,Tu 13:00-14:00")).toEqual({ code: "UNEXPECTED", column: 16 });
  expect(outcome("Mo 08:00 12:00")).toEqual({ code: "UNEXPECTED", column: 10 });
  expect(outcome("Mo-08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(outcome("Mo-Fr-Sa off")).toEqual({ code: "UNEXPECTED", column: 6 });
  expect(outcome("Mo 08:00-12:00!")).toEqual({ code: "UNEXPECTED", column: 15 });
  expect(outcome("Mo\t08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 3 });
  expect(outcome("\t")).toEqual({ code: "UNEXPECTED", column: 1 });
});
