export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Card {
  column: number;
  blocked: boolean;
  /** Blocked intervals; the current one is open (`end === null`) while the card is blocked. */
  blockedIntervals: { start: number; end: number | null }[];
  /** When the card first left the first column. */
  startedAt: number | null;
  /** When the card most recently arrived in the last column. */
  finishedAt: number | null;
}

export function createBoard(options: BoardOptions): Board {
  const columns = options.columns.map((c) => ({ ...c }));
  const now = options.now;
  const lastIndex = columns.length - 1;
  const cards = new Map<string, Card>();
  const lanes: string[][] = columns.map(() => []);
  let nextId = 1;

  function getCard(cardId: string): Card {
    const card = cards.get(cardId);
    if (!card) throw new BoardError("UNKNOWN_CARD", `Unknown card ${cardId}`);
    return card;
  }

  function columnIndex(name: string): number {
    const index = columns.findIndex((c) => c.name === name);
    if (index < 0) throw new BoardError("UNKNOWN_COLUMN", `Unknown column ${name}`);
    return index;
  }

  function isFull(index: number): boolean {
    const limit = columns[index].wipLimit;
    return limit !== undefined && lanes[index].length >= limit;
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Title must not be empty");
      if (isFull(0)) throw new BoardError("WIP_LIMIT", `Column ${columns[0].name} is full`);
      const id = `C${nextId++}`;
      cards.set(id, { column: 0, blocked: false, blockedIntervals: [], startedAt: null, finishedAt: null });
      lanes[0].push(id);
      return id;
    },

    move(cardId, toColumn) {
      const card = getCard(cardId);
      const target = columnIndex(toColumn);
      if (target === card.column) throw new BoardError("SAME_COLUMN", `Card ${cardId} is already in ${toColumn}`);
      if (card.blocked) throw new BoardError("BLOCKED", `Card ${cardId} is blocked`);
      if (target > card.column + 1) throw new BoardError("SKIP_NOT_ALLOWED", `Card ${cardId} cannot skip columns`);
      if (isFull(target)) throw new BoardError("WIP_LIMIT", `Column ${toColumn} is full`);

      const t = now();
      const from = lanes[card.column];
      from.splice(from.indexOf(cardId), 1);
      lanes[target].push(cardId);
      if (card.column === 0 && card.startedAt === null) card.startedAt = t;
      if (target === lastIndex) card.finishedAt = t;
      card.column = target;
    },

    block(cardId, _reason) {
      const card = getCard(cardId);
      if (card.blocked) throw new BoardError("ALREADY_BLOCKED", `Card ${cardId} is already blocked`);
      card.blocked = true;
      card.blockedIntervals.push({ start: now(), end: null });
    },

    unblock(cardId) {
      const card = getCard(cardId);
      if (!card.blocked) throw new BoardError("NOT_BLOCKED", `Card ${cardId} is not blocked`);
      card.blocked = false;
      card.blockedIntervals[card.blockedIntervals.length - 1].end = now();
    },

    cardsIn(column) {
      return [...lanes[columnIndex(column)]];
    },

    cycleTime(cardId) {
      const card = getCard(cardId);
      if (card.column !== lastIndex || card.startedAt === null || card.finishedAt === null) return null;
      const started = card.startedAt;
      const finished = card.finishedAt;
      let blockedMs = 0;
      for (const { start, end } of card.blockedIntervals) {
        // Clip each interval to [started, finished]; an open interval runs at least until finished.
        const from = Math.max(start, started);
        const to = Math.min(end ?? finished, finished);
        if (to > from) blockedMs += to - from;
      }
      return { totalMs: finished - started, blockedMs };
    },
  };
}
