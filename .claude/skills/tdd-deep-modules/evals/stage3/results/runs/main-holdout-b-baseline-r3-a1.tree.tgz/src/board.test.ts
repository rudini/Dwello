import { expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode, type ColumnConfig } from "./board";

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

function setup(columns: ColumnConfig[] = [{ name: "Backlog" }, { name: "Doing" }, { name: "Review" }, { name: "Done" }]) {
  const clock = { t: 1000 };
  const board = createBoard({ columns, now: () => clock.t });
  return { board, clock };
}

function expectCode(fn: () => unknown, code: BoardErrorCode) {
  try {
    fn();
  } catch (e) {
    expect(e).toBeInstanceOf(BoardError);
    expect((e as BoardError).code).toBe(code);
    return;
  }
  throw new Error(`expected ${code}`);
}

test("adds cards with sequential ids to the first column", () => {
  const { board } = setup();
  expect(board.addCard("a")).toBe("C1");
  expectCode(() => board.addCard("   "), "EMPTY_TITLE");
  expect(board.addCard("b")).toBe("C2");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
  expectCode(() => board.cardsIn("Nope"), "UNKNOWN_COLUMN");
});

test("WIP limit on first column blocks adding and does not consume ids", () => {
  const { board } = setup([{ name: "A", wipLimit: 1 }, { name: "B" }]);
  board.addCard("a");
  expectCode(() => board.addCard("b"), "WIP_LIMIT");
  board.move("C1", "B");
  expect(board.addCard("c")).toBe("C2");
});

test("move validation order and rules", () => {
  const { board } = setup([{ name: "Backlog" }, { name: "Doing", wipLimit: 1 }, { name: "Review" }, { name: "Done" }]);
  board.addCard("a");
  board.addCard("b");
  expectCode(() => board.move("C9", "Nope"), "UNKNOWN_CARD");
  expectCode(() => board.move("C1", "Nope"), "UNKNOWN_COLUMN");
  expectCode(() => board.move("C1", "Backlog"), "SAME_COLUMN");
  board.block("C1", "waiting");
  expectCode(() => board.move("C1", "Review"), "BLOCKED");
  board.unblock("C1");
  expectCode(() => board.move("C1", "Review"), "SKIP_NOT_ALLOWED");
  board.move("C1", "Doing");
  expectCode(() => board.move("C2", "Doing"), "WIP_LIMIT");
  board.move("C1", "Review");
  board.move("C1", "Done");
  board.move("C1", "Backlog"); // backwards any distance
  expect(board.cardsIn("Backlog")).toEqual(["C2", "C1"]);
});

test("blocked cards count toward WIP", () => {
  const { board } = setup([{ name: "A" }, { name: "B", wipLimit: 1 }, { name: "C" }]);
  board.addCard("a");
  board.addCard("b");
  board.move("C1", "B");
  board.block("C1", "x");
  expectCode(() => board.move("C2", "B"), "WIP_LIMIT");
});

test("block/unblock errors", () => {
  const { board } = setup();
  board.addCard("a");
  expectCode(() => board.block("C2", "x"), "UNKNOWN_CARD");
  expectCode(() => board.unblock("C2"), "UNKNOWN_CARD");
  expectCode(() => board.unblock("C1"), "NOT_BLOCKED");
  board.block("C1", "x");
  expectCode(() => board.block("C1", "y"), "ALREADY_BLOCKED");
});

test("cycle time", () => {
  const { board, clock } = setup([{ name: "A" }, { name: "B" }, { name: "C" }]);
  board.addCard("a");
  expectCode(() => board.cycleTime("C9"), "UNKNOWN_CARD");
  expect(board.cycleTime("C1")).toBeNull();
  board.block("C1", "pre-start"); // t=1000
  clock.t = 2000;
  board.unblock("C1");
  clock.t = 3000;
  board.move("C1", "B"); // started 3000
  clock.t = 4000;
  board.block("C1", "x");
  clock.t = 4500;
  board.unblock("C1");
  board.move("C1", "A"); // back to first: start unchanged
  clock.t = 5000;
  board.move("C1", "B");
  clock.t = 6000;
  board.move("C1", "C"); // finished 6000
  expect(board.cycleTime("C1")).toEqual({ totalMs: 3000, blockedMs: 500 });
  clock.t = 7000;
  board.block("C1", "after"); // blocked after finishing doesn't count
  clock.t = 9000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 3000, blockedMs: 500 });
  board.unblock("C1");
  board.move("C1", "B");
  expect(board.cycleTime("C1")).toBeNull();
  clock.t = 10000;
  board.move("C1", "C"); // refinished at 10000, blocked 7000-9000 now inside
  expect(board.cycleTime("C1")).toEqual({ totalMs: 7000, blockedMs: 2500 });
});

test("blocked time is clipped to the started-finished interval", () => {
  const { board, clock } = setup([{ name: "A" }, { name: "B" }, { name: "C" }]);
  board.addCard("a");
  board.block("C1", "x"); // 1000
  clock.t = 2000;
  board.unblock("C1");
  board.move("C1", "B"); // started 2000
  clock.t = 2500;
  board.block("C1", "y");
  clock.t = 3000;
  board.unblock("C1");
  board.move("C1", "C"); // finished 3000
  board.block("C1", "z"); // still open
  clock.t = 5000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 1000, blockedMs: 500 });
});
