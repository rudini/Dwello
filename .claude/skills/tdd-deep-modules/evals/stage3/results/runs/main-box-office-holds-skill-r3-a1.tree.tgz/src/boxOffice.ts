export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const MS_PER_MINUTE = 60_000;
const CANCELLATION_FEE_CENTS = 200;

/**
 * Price of an order: 10 % group discount from 4 tickets, rounded to the nearest
 * 5 cents (halves up). Computed in tenths of a cent to stay exact.
 */
function totalCents(quantity: number, priceCents: number): number {
  const tenths = quantity * priceCents * (quantity >= 4 ? 9 : 10);
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  /** `ended` once confirmed or released; expiry is derived from the clock. */
  const holds: (Hold & { ended: boolean })[] = [];
  const orders: (Order & { cancelled: boolean })[] = [];

  function section(sectionId: string): SectionConfig {
    const found = options.sections.find((s) => s.id === sectionId);
    if (!found) throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    return found;
  }

  /** Tickets currently taken by active holds and orders matching the filter. */
  function takenTickets(matches: (entry: { customerId: string; sectionId: string }) => boolean): number {
    const taken = [...holds.filter((h) => !h.ended && !expired(h)), ...orders.filter((o) => !o.cancelled)];
    return taken.filter(matches).reduce((sum, t) => sum + t.quantity, 0);
  }

  function expired(hold: Hold): boolean {
    return options.now() >= hold.expiresAt;
  }

  /** A hold that was neither confirmed nor released (it may have expired). */
  function unendedHold(holdId: string) {
    const hold = holds.find((h) => h.holdId === holdId);
    if (!hold || hold.ended) throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    return hold;
  }

  function available(sectionId: string): number {
    return section(sectionId).capacity - takenTickets((t) => t.sectionId === sectionId);
  }

  return {
    hold(customerId, sectionId, quantity) {
      section(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const customerTickets = takenTickets((t) => t.customerId === customerId);
      if (customerTickets + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError("CUSTOMER_LIMIT", `Customer ${customerId} would exceed the limit`);
      }
      if (quantity > available(sectionId)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in ${sectionId}`);
      }
      const hold: Hold = {
        holdId: `H${holds.length + 1}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: options.now() + options.holdMinutes * MS_PER_MINUTE,
      };
      holds.push({ ...hold, ended: false });
      return hold;
    },
    confirm(holdId) {
      const hold = unendedHold(holdId);
      if (expired(hold)) throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} expired`);
      hold.ended = true;
      const order: Order = {
        orderId: `O${orders.length + 1}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: totalCents(hold.quantity, section(hold.sectionId).priceCents),
      };
      orders.push({ ...order, cancelled: false });
      return { ...order };
    },
    release(holdId) {
      const hold = unendedHold(holdId);
      if (!expired(hold)) hold.ended = true;
    },
    cancelOrder(orderId) {
      const order = orders.find((o) => o.orderId === orderId);
      if (!order || order.cancelled) throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      order.cancelled = true;
      return Math.max(0, order.totalCents - order.quantity * CANCELLATION_FEE_CENTS);
    },
    available,
  };
}
