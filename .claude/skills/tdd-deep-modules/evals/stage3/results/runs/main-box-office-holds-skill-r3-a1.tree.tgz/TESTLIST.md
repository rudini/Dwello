# Box office: test list

**Hidden decision:** how tickets are accounted over time — which holds still count
(expiry read from `now()` lazily, no clean-up), how the per-customer limit sums holds
and orders across sections, and how prices are discounted and rounded to 5 Rappen.
Callers only ask "hold / confirm / release / cancel / how many are left".

**Sketch A — stateful object (given interface):**
`const office = createBoxOffice(opts); office.hold("c1", "PARKETT", 2); office.available("PARKETT")`

**Sketch B — pure reducer:** `const [state2, hold] = holdTickets(state, "c1", "PARKETT", 2, now)`;
callers thread state and time through every call.

**Chosen: A**, because the caller never sees the ledger, the id counters or the clock
handling; B leaks state shape and time into every call site.

## Behaviours (through `createBoxOffice`)

- [x] available returns the capacity of a fresh section
- [x] hold returns H1 with customer, section, quantity and expiresAt = now + holdMinutes
- [x] an active hold reduces availability; hold ids count up H1, H2
- [x] hold on an unknown section throws UNKNOWN_SECTION; available on unknown section too
- [x] hold rejects quantity 0, negative and fractional with INVALID_QUANTITY
- [x] hold exceeding availability throws SOLD_OUT, no partial hold, no id used up
- [x] hold exceeding customer limit across sections throws CUSTOMER_LIMIT (checked before SOLD_OUT)
- [x] an expired hold (now >= expiresAt) no longer counts toward availability or customer limit
- [x] confirm creates O1 with total = quantity * price, tickets stay taken
- [x] confirm of 4+ tickets applies 10 % discount, rounded to 5 Rappen (halves up)
- [x] confirm rounds to 5 Rappen without discount too
- [x] confirm of unknown / already confirmed / released hold throws UNKNOWN_HOLD
- [x] confirm of an expired hold throws HOLD_EXPIRED
- [x] release frees the tickets; releasing again throws UNKNOWN_HOLD; unknown throws UNKNOWN_HOLD
- [x] release of an expired hold succeeds; release of confirmed hold throws UNKNOWN_HOLD
- [x] cancelOrder refunds total minus 200 per ticket and frees tickets and customer limit
- [x] cancelOrder refund never below 0
- [x] cancelOrder of unknown or already cancelled order throws UNKNOWN_ORDER
