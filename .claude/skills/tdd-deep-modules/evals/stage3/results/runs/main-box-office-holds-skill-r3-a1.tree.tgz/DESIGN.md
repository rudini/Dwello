# Box office: design note

**Hidden decision:** how tickets are accounted over time. That covers which holds still
count (expiry is read lazily from `now()`, with no clean-up), how the per-customer limit
sums holds and orders across sections, and how prices are discounted and rounded to
5 Rappen.

**Both designs**
- A, a stateful object (the given interface): `createBoxOffice(opts).hold("anna", "PARKETT", 2)`.
- B, a pure reducer: `holdTickets(state, "anna", "PARKETT", 2, now) -> [state, hold]`.
- **Chosen: A**, because callers never see the ledger, the id counters or the clock. B
  leaks the state shape and the time into every call site.

**Interface** (`src/boxOffice.ts`, the only exports besides the given types):
- `createBoxOffice(options)` builds an independent box office.
- `hold` validates in this order: section, quantity, customer limit, availability. It
  returns `H<n>` and expires at `now + holdMinutes`.
- `confirm` ends an active hold and returns order `O<n>`. The order gets 10 % off from
  4 tickets and is rounded to 5 cents with halves up.
- `release` ends an active hold. On an expired hold it does nothing.
- `cancelOrder` refunds `max(0, total - 200 * quantity)` and frees the tickets.
- `available` returns capacity minus active holds minus non-cancelled orders.
- Every failure is a `BoxOfficeError` with a `code` and leaves the state unchanged.

**Depth:** `depth_report`: `surface 11, size 127, ratio 11.5, classitis no, pass-through 0`.
All helpers are private: `totalCents`, `takenTickets`, `expired`, `unendedHold` and `section`.
The reported "5 duplicated lines" are the given `Hold`/`Order` field declarations. Changes
made during refactoring:
- One `takenTickets` filter now serves both availability and the customer limit.
- The `confirmed` flag became a single `ended` flag shared by confirm and release, with
  one lookup (`unendedHold`).
- The expiry rule moved into one place (`expired`), and the minute length and the fee
  became named constants.

**Open points**
- Prices are computed in tenths of a cent, so they stay exact in integers. For example,
  24975 × 0.9 = 22477.5 rounds up to 22480.
- Releasing an expired hold is a true no-op: the hold is not marked as released, and a
  later `confirm` still reports `HOLD_EXPIRED`.
- Section ids in the options are assumed to be unique. The options are not validated.

**Proof:** `scripts/tdd_replay 64d3c61..HEAD` (see the commit that adds this note).
