import { describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOfficeOptions } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

const MINUTE = 60_000;
const START = 1_000_000;

function setup(overrides: Partial<BoxOfficeOptions> = {}) {
  const clock = { time: START };
  const office = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 4990 },
      { id: "BALKON", capacity: 5, priceCents: 3000 },
    ],
    holdMinutes: 15,
    maxTicketsPerCustomer: 6,
    now: () => clock.time,
    ...overrides,
  });
  return { office, clock };
}

function codeOf(fn: () => unknown): string | undefined {
  try {
    fn();
  } catch (error) {
    if (error instanceof BoxOfficeError) return error.code;
    return `non-BoxOfficeError: ${String(error)}`;
  }
  return undefined;
}

describe("box office", () => {
  test("available returns the capacity of a fresh section", () => {
    let available: number | undefined;
    expect(codeOf(() => (available = setup().office.available("PARKETT")))).toBeUndefined();
    expect(available).toBe(10);
  });

  test("hold returns H1 with expiresAt = now + holdMinutes", () => {
    const { office } = setup();
    let hold: unknown;
    expect(codeOf(() => (hold = office.hold("anna", "PARKETT", 2)))).toBeUndefined();
    expect(hold).toEqual({
      holdId: "H1",
      customerId: "anna",
      sectionId: "PARKETT",
      quantity: 2,
      expiresAt: START + 15 * MINUTE,
    });
  });

  test("active holds reduce availability and hold ids count up", () => {
    const { office } = setup();
    expect(office.hold("anna", "PARKETT", 2).holdId).toBe("H1");
    expect(office.hold("ben", "PARKETT", 3).holdId).toBe("H2");
    expect(office.available("PARKETT")).toBe(5);
    expect(office.available("BALKON")).toBe(5);
  });

  test("unknown section throws UNKNOWN_SECTION for hold and available", () => {
    const { office } = setup();
    expect(codeOf(() => office.hold("anna", "LOGE", 1))).toBe("UNKNOWN_SECTION");
    expect(codeOf(() => office.hold("anna", "LOGE", 0))).toBe("UNKNOWN_SECTION");
    expect(codeOf(() => office.available("LOGE"))).toBe("UNKNOWN_SECTION");
    expect(office.hold("anna", "PARKETT", 1).holdId).toBe("H1");
  });

  test("hold rejects quantities that are not whole numbers of at least 1", () => {
    const { office } = setup();
    for (const quantity of [0, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY]) {
      expect(codeOf(() => office.hold("anna", "PARKETT", quantity))).toBe("INVALID_QUANTITY");
    }
    expect(office.available("PARKETT")).toBe(10);
    expect(office.hold("anna", "PARKETT", 1).holdId).toBe("H1");
  });

  test("hold beyond availability throws SOLD_OUT without a partial hold", () => {
    const { office } = setup();
    office.hold("anna", "BALKON", 3);
    expect(codeOf(() => office.hold("ben", "BALKON", 3))).toBe("SOLD_OUT");
    expect(office.available("BALKON")).toBe(2);
    expect(office.hold("ben", "BALKON", 2).holdId).toBe("H2");
    expect(office.available("BALKON")).toBe(0);
  });

  test("hold beyond the customer limit across sections throws CUSTOMER_LIMIT before SOLD_OUT", () => {
    const { office } = setup();
    office.hold("anna", "PARKETT", 4);
    office.hold("ben", "BALKON", 4);
    expect(codeOf(() => office.hold("anna", "BALKON", 3))).toBe("CUSTOMER_LIMIT");
    expect(codeOf(() => office.hold("ben", "BALKON", 3))).toBe("CUSTOMER_LIMIT");
    expect(codeOf(() => office.hold("anna", "BALKON", 2))).toBe("SOLD_OUT");
    expect(office.hold("anna", "PARKETT", 2).holdId).toBe("H3");
    expect(codeOf(() => office.hold("anna", "PARKETT", 1))).toBe("CUSTOMER_LIMIT");
  });

  test("an expired hold stops counting toward availability and the customer limit", () => {
    const { office, clock } = setup();
    office.hold("anna", "PARKETT", 6);
    clock.time = START + 15 * MINUTE - 1;
    expect(office.available("PARKETT")).toBe(4);
    expect(codeOf(() => office.hold("anna", "BALKON", 1))).toBe("CUSTOMER_LIMIT");
    clock.time = START + 15 * MINUTE;
    expect(office.available("PARKETT")).toBe(10);
    const second = office.hold("anna", "BALKON", 1);
    expect(second.holdId).toBe("H2");
    expect(second.expiresAt).toBe(START + 30 * MINUTE);
  });

  test("confirm turns the hold into order O1 and the tickets stay taken past the expiry", () => {
    const { office, clock } = setup();
    const hold = office.hold("anna", "BALKON", 2);
    clock.time = START + 5 * MINUTE;
    let order: unknown;
    expect(codeOf(() => (order = office.confirm(hold.holdId)))).toBeUndefined();
    expect(order).toEqual({
      orderId: "O1",
      customerId: "anna",
      sectionId: "BALKON",
      quantity: 2,
      totalCents: 6000,
    });
    clock.time = START + 60 * MINUTE;
    expect(office.available("BALKON")).toBe(3);
    expect(codeOf(() => office.hold("anna", "PARKETT", 5))).toBe("CUSTOMER_LIMIT");
    expect(office.confirm(office.hold("ben", "BALKON", 1).holdId).orderId).toBe("O2");
  });

  test("orders of 4 or more tickets get 10 % off, rounded to 5 Rappen with halves up", () => {
    const { office } = setup({
      sections: [
        { id: "PARKETT", capacity: 10, priceCents: 4990 },
        { id: "LOGE", capacity: 10, priceCents: 4995 },
        { id: "RANG", capacity: 10, priceCents: 1233 },
      ],
    });
    expect(office.confirm(office.hold("dora", "RANG", 1).holdId).totalCents).toBe(1235);
    expect(office.confirm(office.hold("emil", "RANG", 2).holdId).totalCents).toBe(2465);
    expect(office.confirm(office.hold("anna", "PARKETT", 4).holdId).totalCents).toBe(17965);
    expect(office.confirm(office.hold("ben", "LOGE", 5).holdId).totalCents).toBe(22480);
    expect(office.confirm(office.hold("cleo", "PARKETT", 3).holdId).totalCents).toBe(14970);
  });

  test("confirm of an unknown or already confirmed hold throws UNKNOWN_HOLD", () => {
    const { office } = setup();
    expect(codeOf(() => office.confirm("H1"))).toBe("UNKNOWN_HOLD");
    const hold = office.hold("anna", "BALKON", 2);
    office.confirm(hold.holdId);
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("UNKNOWN_HOLD");
    expect(office.available("BALKON")).toBe(3);
    expect(office.confirm(office.hold("ben", "BALKON", 1).holdId).orderId).toBe("O2");
  });

  test("confirm of an expired hold throws HOLD_EXPIRED and creates no order", () => {
    const { office, clock } = setup();
    const hold = office.hold("anna", "BALKON", 2);
    clock.time = hold.expiresAt;
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("HOLD_EXPIRED");
    expect(office.available("BALKON")).toBe(5);
    expect(office.confirm(office.hold("anna", "BALKON", 1).holdId).orderId).toBe("O1");
  });

  test("release frees the tickets and a released hold is unknown afterwards", () => {
    const { office } = setup();
    const hold = office.hold("anna", "BALKON", 5);
    expect(codeOf(() => office.release(hold.holdId))).toBeUndefined();
    expect(office.available("BALKON")).toBe(5);
    expect(codeOf(() => office.release(hold.holdId))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => office.release("H99"))).toBe("UNKNOWN_HOLD");
    expect(office.hold("anna", "BALKON", 5).holdId).toBe("H2");
  });

  test("releasing an expired hold succeeds without effect; a confirmed hold cannot be released", () => {
    const { office, clock } = setup();
    const expiring = office.hold("anna", "BALKON", 2);
    const confirmed = office.hold("ben", "BALKON", 1);
    office.confirm(confirmed.holdId);
    expect(codeOf(() => office.release(confirmed.holdId))).toBe("UNKNOWN_HOLD");
    clock.time = expiring.expiresAt;
    expect(codeOf(() => office.release(expiring.holdId))).toBeUndefined();
    expect(codeOf(() => office.confirm(expiring.holdId))).toBe("HOLD_EXPIRED");
    expect(office.available("BALKON")).toBe(4);
  });

  test("cancelOrder refunds the total minus 200 per ticket and frees the tickets and the limit", () => {
    const { office } = setup();
    const order = office.confirm(office.hold("anna", "BALKON", 3).holdId);
    office.hold("anna", "PARKETT", 3);
    expect(codeOf(() => office.hold("anna", "BALKON", 1))).toBe("CUSTOMER_LIMIT");
    let refund: number | undefined;
    expect(codeOf(() => (refund = office.cancelOrder(order.orderId)))).toBeUndefined();
    expect(refund).toBe(8400);
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("anna", "BALKON", 3).holdId).toBe("H3");
  });

  test("the refund is never below 0", () => {
    const { office } = setup({ sections: [{ id: "STEH", capacity: 10, priceCents: 150 }] });
    const order = office.confirm(office.hold("anna", "STEH", 1).holdId);
    expect(office.cancelOrder(order.orderId)).toBe(0);
  });

  test("cancelOrder of an unknown or already cancelled order throws UNKNOWN_ORDER", () => {
    const { office } = setup();
    expect(codeOf(() => office.cancelOrder("O1"))).toBe("UNKNOWN_ORDER");
    const order = office.confirm(office.hold("anna", "BALKON", 2).holdId);
    office.cancelOrder(order.orderId);
    office.hold("ben", "BALKON", 5);
    expect(codeOf(() => office.cancelOrder(order.orderId))).toBe("UNKNOWN_ORDER");
    expect(office.available("BALKON")).toBe(0);
  });
});
