# Box office: design note

**Hidden decision:** how ticket state (active, expired or ended holds; live or cancelled orders) is derived from the clock on every call, and how order prices are discounted and rounded to 5 Rappen. Callers only ask to hold, confirm, release or cancel, and how many tickets are left.

## Both designs

- **A (chosen):** a stateful object from `createBoxOffice(options)` with five calls.
  `office.hold("alice", "PARKETT", 2)`
- **B:** a pure reducer `apply(state, command, now) -> { state, result }`.
  `apply(s1, { type: "hold", customerId: "alice", sectionId: "PARKETT", quantity: 2 }, Date.now())`

Chosen: A, because callers never see the state shape, the clock or expiry bookkeeping. B would leak the state representation and time handling into every call site.

## Interface

- `hold(customerId, sectionId, quantity)` checks, in order: the section exists, the quantity is valid, the customer limit across all sections, then availability. It returns `H<n>`, which expires `holdMinutes` from `now()`.
- `confirm(holdId)` turns an open, unexpired hold into `O<n>`. The total gets 10 % off from 4 tickets and is rounded to 5 Rappen, with exact halves rounded up.
- `release(holdId)` ends an open hold. On an expired hold it succeeds and does nothing.
- `cancelOrder(orderId)` returns `max(0, total − 200 × quantity)` and frees the tickets.
- `available(sectionId)` returns capacity minus active holds minus live orders.

## Depth

`depth_report`: `surface 11, size 126, ratio 11.5, classitis no, pass-through 0`. The 5 duplicated lines it reports come from the "find or throw" guard pattern that the hold and order lookups share.

Refactors during the work:
- one section lookup (`sectionOf`);
- one counting function (`takenTickets`) for both availability and the customer limit, so expiry and cancellation are decided in one place;
- a shared open-hold lookup for `confirm` and `release`;
- named constants.

The pricing helper stays private and is tested through `confirm`.

## Open points

- Records are kept in memory and holds are never deleted. Expired holds are filtered on every read, which costs O(n) per call. That is fine for a single event.
- Once a hold has expired, both `release` and `confirm` keep treating it as expired (`release` succeeds, `confirm` throws `HOLD_EXPIRED`). It never becomes `UNKNOWN_HOLD`.
- Returned `Hold` and `Order` objects are copies. Changing them does not affect the office's state.

## Proof

`scripts/tdd_replay 6d17a63..HEAD` printed `REPLAY: ACCEPT`.
