# Box office: test list

**Hidden decision:** how ticket state (active vs. expired vs. ended holds, cancelled vs. live orders) is derived from the clock on every call, and how prices are discounted and Rappen-rounded — callers only ask "hold / confirm / release / cancel / how many left".

**Design A (chosen, given by the stub):** one stateful object from `createBoxOffice(options)` with five intention-level calls.
`const office = createBoxOffice({ sections, holdMinutes: 15, maxTicketsPerCustomer: 6, now }); office.hold("alice", "PARKETT", 2);`

**Design B:** a pure reducer `apply(state, command, now) -> { state, result }` with commands as tagged values.
`const { state: s2, result } = apply(s1, { type: "hold", customerId: "alice", sectionId: "PARKETT", quantity: 2 }, Date.now());`

**Chosen:** Design A, because callers never see the state shape, the clock or expiry bookkeeping, whereas B leaks the state representation and time handling into every call site.

## Behaviours

- [x] available returns the capacity of a fresh section
- [x] available rejects an unknown section with UNKNOWN_SECTION
- [x] hold returns H1 with customer, section, quantity and expiresAt = now + holdMinutes
- [x] hold reduces availability of its section only
- [x] hold ids count up H1, H2 and failed attempts do not use a number
- [x] hold rejects unknown section with UNKNOWN_SECTION (before quantity check)
- [x] hold rejects quantity 0, negative or fractional with INVALID_QUANTITY
- [x] hold rejects more than available with SOLD_OUT (no partial hold)
- [x] hold rejects exceeding the per-customer limit across sections with CUSTOMER_LIMIT (checked before SOLD_OUT)
- [x] expired hold (now >= expiresAt) no longer counts for availability or customer limit
- [x] confirm creates O1 with total = quantity * price, tickets stay taken
- [x] confirm applies 10 % group discount from 4 tickets
- [x] confirm rounds to 5 Rappen, halves up
- [x] confirm rejects unknown / already confirmed hold with UNKNOWN_HOLD
- [x] confirm rejects expired hold with HOLD_EXPIRED
- [x] confirmed tickets count towards the customer limit
- [x] release frees the tickets; releasing again or after confirm is UNKNOWN_HOLD; unknown id is UNKNOWN_HOLD
- [x] release of an expired hold succeeds without effect
- [x] cancelOrder returns total minus 200 per ticket, frees tickets and customer limit
- [x] cancelOrder never refunds less than 0
- [x] cancelOrder rejects unknown / already cancelled order with UNKNOWN_ORDER
