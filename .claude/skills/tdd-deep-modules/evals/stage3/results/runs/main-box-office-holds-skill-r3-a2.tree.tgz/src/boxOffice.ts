export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const MINUTE_MS = 60_000;
const GROUP_MIN_TICKETS = 4;
const CANCELLATION_FEE_CENTS_PER_TICKET = 200;

/**
 * Price of an order: 10 % group discount from 4 tickets, rounded to 5 Rappen (halves up).
 * Works in tenths of a cent so the discount stays exact.
 */
function totalCents(quantity: number, priceCents: number): number {
  const tenths = quantity * priceCents * (quantity >= GROUP_MIN_TICKETS ? 9 : 10);
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const holds: Array<Hold & { ended: boolean }> = [];
  const orders: Array<Order & { cancelled: boolean }> = [];

  function sectionOf(sectionId: string): SectionConfig {
    const section = options.sections.find((s) => s.id === sectionId);
    if (!section) throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    return section;
  }

  /** Tickets taken by active holds and orders matching `belongs`. */
  function takenTickets(belongs: (taken: { customerId: string; sectionId: string }) => boolean): number {
    const now = options.now();
    const activeHolds = holds.filter((h) => !h.ended && now < h.expiresAt);
    const liveOrders = orders.filter((o) => !o.cancelled);
    return [...activeHolds, ...liveOrders].filter(belongs).reduce((sum, t) => sum + t.quantity, 0);
  }

  function available(sectionId: string): number {
    return sectionOf(sectionId).capacity - takenTickets((t) => t.sectionId === sectionId);
  }

  /** A hold that was neither confirmed nor released; it may have expired. */
  function openHold(holdId: string): Hold & { ended: boolean } {
    const hold = holds.find((h) => h.holdId === holdId);
    if (!hold || hold.ended) throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    return hold;
  }

  return {
    hold(customerId, sectionId, quantity) {
      sectionOf(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      if (takenTickets((t) => t.customerId === customerId) + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError("CUSTOMER_LIMIT", `Customer ${customerId} would exceed the ticket limit`);
      }
      if (quantity > available(sectionId)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in ${sectionId}`);
      }
      const hold = {
        holdId: `H${holds.length + 1}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: options.now() + options.holdMinutes * MINUTE_MS,
      };
      holds.push({ ...hold, ended: false });
      return hold;
    },
    confirm(holdId) {
      const hold = openHold(holdId);
      if (options.now() >= hold.expiresAt) throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      hold.ended = true;
      const order = {
        orderId: `O${orders.length + 1}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: totalCents(hold.quantity, sectionOf(hold.sectionId).priceCents),
      };
      orders.push({ ...order, cancelled: false });
      return order;
    },
    release(holdId) {
      const hold = openHold(holdId);
      if (options.now() < hold.expiresAt) hold.ended = true;
    },
    cancelOrder(orderId) {
      const order = orders.find((o) => o.orderId === orderId);
      if (!order || order.cancelled) throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      order.cancelled = true;
      return Math.max(0, order.totalCents - CANCELLATION_FEE_CENTS_PER_TICKET * order.quantity);
    },
    available,
  };
}
