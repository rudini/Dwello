import { describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOfficeOptions } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

const MINUTE = 60_000;

function setup(overrides: Partial<BoxOfficeOptions> = {}) {
  const clock = { time: 1_000_000 };
  const office = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 4990 },
      { id: "BALKON", capacity: 5, priceCents: 3000 },
    ],
    holdMinutes: 15,
    maxTicketsPerCustomer: 6,
    now: () => clock.time,
    ...overrides,
  });
  return { office, clock };
}

function codeOf(fn: () => unknown): string | undefined {
  try {
    fn();
  } catch (error) {
    return error instanceof BoxOfficeError ? error.code : `not a BoxOfficeError: ${error}`;
  }
  return undefined;
}

/** The call's return value, or a description of what it threw. */
function outcome<T>(fn: () => T): T | string {
  try {
    return fn();
  } catch (error) {
    return error instanceof BoxOfficeError ? error.code : `not a BoxOfficeError: ${error}`;
  }
}

describe("hold", () => {
  test("returns the first hold with an expiry holdMinutes from now", () => {
    const { office } = setup();
    expect(outcome(() => office.hold("alice", "PARKETT", 2))).toEqual({
      holdId: "H1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 2,
      expiresAt: 1_000_000 + 15 * MINUTE,
    });
  });

  test("takes tickets from its own section only", () => {
    const { office } = setup();
    office.hold("alice", "PARKETT", 2);
    expect(office.available("PARKETT")).toBe(8);
    expect(office.available("BALKON")).toBe(5);
  });

  test("rejects an unknown section before looking at the quantity", () => {
    const { office } = setup();
    expect(codeOf(() => office.hold("alice", "LOGE", 0))).toBe("UNKNOWN_SECTION");
  });

  test("numbers holds in creation order, skipping failed attempts", () => {
    const { office } = setup();
    expect(office.hold("alice", "PARKETT", 1).holdId).toBe("H1");
    codeOf(() => office.hold("bob", "LOGE", 1));
    expect(office.hold("bob", "BALKON", 1).holdId).toBe("H2");
    expect(office.hold("carol", "PARKETT", 1).holdId).toBe("H3");
  });

  test("rejects quantities that are not whole numbers of at least 1", () => {
    const { office } = setup();
    expect(codeOf(() => office.hold("alice", "PARKETT", 0))).toBe("INVALID_QUANTITY");
    expect(codeOf(() => office.hold("alice", "PARKETT", -2))).toBe("INVALID_QUANTITY");
    expect(codeOf(() => office.hold("alice", "PARKETT", 1.5))).toBe("INVALID_QUANTITY");
    expect(codeOf(() => office.hold("alice", "PARKETT", Number.NaN))).toBe("INVALID_QUANTITY");
    expect(office.available("PARKETT")).toBe(10);
  });

  test("rejects more tickets than are available, without a partial hold", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 4);
    expect(codeOf(() => office.hold("bob", "BALKON", 2))).toBe("SOLD_OUT");
    expect(office.available("BALKON")).toBe(1);
    expect(office.hold("bob", "BALKON", 1).holdId).toBe("H2");
    expect(office.available("BALKON")).toBe(0);
  });

  test("limits a customer's held tickets across all sections, before checking availability", () => {
    const { office } = setup();
    office.hold("alice", "PARKETT", 4);
    expect(codeOf(() => office.hold("alice", "BALKON", 3))).toBe("CUSTOMER_LIMIT");
    expect(office.hold("alice", "BALKON", 2).holdId).toBe("H2");
    expect(codeOf(() => office.hold("bob", "PARKETT", 7))).toBe("CUSTOMER_LIMIT");
    expect(office.available("PARKETT")).toBe(6);
  });

  test("stops counting a hold as soon as it expires", () => {
    const { office, clock } = setup();
    office.hold("alice", "BALKON", 5);
    clock.time += 15 * MINUTE - 1;
    expect(office.available("BALKON")).toBe(5 - 5);
    clock.time += 1;
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
  });
});

describe("confirm", () => {
  test("turns a hold into an order that keeps the tickets taken", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 2);
    expect(outcome(() => office.confirm("H1"))).toEqual({
      orderId: "O1",
      customerId: "alice",
      sectionId: "BALKON",
      quantity: 2,
      totalCents: 6000,
    });
    expect(office.available("BALKON")).toBe(3);
  });

  test("keeps ordered tickets taken past the hold's expiry and counts them for the customer", () => {
    const { office, clock } = setup();
    office.hold("alice", "BALKON", 2);
    office.confirm("H1");
    clock.time += 60 * MINUTE;
    expect(office.available("BALKON")).toBe(3);
    expect(codeOf(() => office.hold("alice", "PARKETT", 5))).toBe("CUSTOMER_LIMIT");
  });

  test("numbers orders in creation order", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 1);
    office.hold("bob", "BALKON", 1);
    expect(office.confirm("H2").orderId).toBe("O1");
    expect(office.confirm("H1").orderId).toBe("O2");
  });

  test("gives a 10 % group discount from 4 tickets on", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 4);
    office.hold("bob", "PARKETT", 3);
    expect(office.confirm("H1").totalCents).toBe(10800);
    expect(office.confirm("H2").totalCents).toBe(14970);
  });

  test("rounds the total to 5 Rappen, exact halves up", () => {
    const { office } = setup({
      sections: [
        { id: "A", capacity: 10, priceCents: 1005 },
        { id: "B", capacity: 10, priceCents: 4993 },
        { id: "C", capacity: 10, priceCents: 4992 },
        { id: "D", capacity: 10, priceCents: 4990 },
      ],
    });
    office.hold("alice", "A", 5); // 5025 * 0.9 = 4522.5
    office.hold("bob", "B", 1);
    office.hold("carol", "C", 1);
    office.hold("dave", "D", 4); // 19960 * 0.9 = 17964
    expect(office.confirm("H1").totalCents).toBe(4525);
    expect(office.confirm("H2").totalCents).toBe(4995);
    expect(office.confirm("H3").totalCents).toBe(4990);
    expect(office.confirm("H4").totalCents).toBe(17965);
  });

  test("rejects an unknown or already confirmed hold", () => {
    const { office } = setup();
    expect(codeOf(() => office.confirm("H1"))).toBe("UNKNOWN_HOLD");
    office.hold("alice", "BALKON", 2);
    office.confirm("H1");
    expect(codeOf(() => office.confirm("H1"))).toBe("UNKNOWN_HOLD");
    expect(office.available("BALKON")).toBe(3);
    office.hold("bob", "BALKON", 1);
    expect(office.confirm("H2").orderId).toBe("O2");
  });

  test("rejects a hold that has expired, without creating an order", () => {
    const { office, clock } = setup();
    office.hold("alice", "BALKON", 2);
    office.hold("bob", "BALKON", 1);
    clock.time += 15 * MINUTE;
    expect(codeOf(() => office.confirm("H1"))).toBe("HOLD_EXPIRED");
    expect(office.available("BALKON")).toBe(5);
    office.hold("carol", "BALKON", 1);
    expect(office.confirm("H3").orderId).toBe("O1");
  });
});

describe("release", () => {
  test("gives the held tickets back to the section and the customer", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 5);
    expect(codeOf(() => office.release("H1"))).toBeUndefined();
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
  });

  test("rejects an unknown, released or confirmed hold", () => {
    const { office } = setup();
    expect(codeOf(() => office.release("H1"))).toBe("UNKNOWN_HOLD");
    office.hold("alice", "BALKON", 1);
    office.hold("bob", "BALKON", 2);
    office.release("H1");
    expect(codeOf(() => office.release("H1"))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => office.confirm("H1"))).toBe("UNKNOWN_HOLD");
    office.confirm("H2");
    expect(codeOf(() => office.release("H2"))).toBe("UNKNOWN_HOLD");
    expect(office.available("BALKON")).toBe(3);
  });

  test("accepts an expired hold without effect", () => {
    const { office, clock } = setup();
    office.hold("alice", "BALKON", 2);
    clock.time += 20 * MINUTE;
    expect(codeOf(() => office.release("H1"))).toBeUndefined();
    expect(codeOf(() => office.release("H1"))).toBeUndefined();
    expect(codeOf(() => office.confirm("H1"))).toBe("HOLD_EXPIRED");
    expect(office.available("BALKON")).toBe(5);
  });
});

describe("cancelOrder", () => {
  test("refunds the total minus 200 per ticket and frees the tickets", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 5);
    office.confirm("H1");
    expect(outcome(() => office.cancelOrder("O1"))).toBe(13500 - 1000);
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
  });

  test("never refunds less than nothing", () => {
    const { office } = setup({ sections: [{ id: "STEH", capacity: 10, priceCents: 150 }] });
    office.hold("alice", "STEH", 2);
    office.confirm("H1");
    expect(office.cancelOrder("O1")).toBe(0);
  });

  test("rejects an unknown or already cancelled order", () => {
    const { office } = setup();
    expect(codeOf(() => office.cancelOrder("O1"))).toBe("UNKNOWN_ORDER");
    office.hold("alice", "BALKON", 2);
    office.confirm("H1");
    office.cancelOrder("O1");
    office.hold("bob", "BALKON", 5);
    expect(codeOf(() => office.cancelOrder("O1"))).toBe("UNKNOWN_ORDER");
    expect(office.available("BALKON")).toBe(0);
  });
});

describe("availability", () => {
  test("a fresh section has its full capacity available", () => {
    expect(() => setup()).not.toThrow();
    const { office } = setup();
    expect(office.available("PARKETT")).toBe(10);
  });

  test("rejects an unknown section", () => {
    const { office } = setup();
    expect(codeOf(() => office.available("LOGE"))).toBe("UNKNOWN_SECTION");
  });
});
