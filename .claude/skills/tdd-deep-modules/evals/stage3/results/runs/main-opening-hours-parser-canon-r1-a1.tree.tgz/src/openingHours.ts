export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: readonly Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "invalid" | "end";

interface Token {
  kind: TokenKind;
  text: string;
  column: number;
}

/** Reads tokens one at a time, so that problems are found strictly left to right. */
class Lexer {
  private pos = 0;
  private current: Token;

  constructor(private readonly text: string) {
    this.current = this.read();
  }

  peek(): Token {
    return this.current;
  }

  next(): Token {
    const token = this.current;
    this.current = this.read();
    return token;
  }

  private read(): Token {
    const text = this.text;
    while (text[this.pos] === " ") this.pos++;
    const start = this.pos;
    const column = start + 1;
    if (start >= text.length) return { kind: "end", text: "", column };
    const ch = text[start]!;
    if (ch === "-" || ch === "," || ch === ";") {
      this.pos++;
      return { kind: ch, text: ch, column };
    }
    const run = (pattern: RegExp) => {
      while (this.pos < text.length && pattern.test(text[this.pos]!)) this.pos++;
      return text.slice(start, this.pos);
    };
    if (/\p{L}/u.test(ch)) return { kind: "word", text: run(/\p{L}/u), column };
    if (/[0-9:]/.test(ch)) return { kind: "time", text: run(/[0-9:]/), column };
    this.pos++;
    return { kind: "invalid", text: ch, column };
  }
}

interface ParsedTime {
  text: string;
  column: number;
  minutes: number; // since midnight
}

interface ParsedRange {
  from: ParsedTime;
  to: ParsedTime;
}

class Parser {
  private readonly lexer: Lexer;

  constructor(text: string) {
    this.lexer = new Lexer(text);
  }

  parse(): WeeklyHours {
    const week = Object.fromEntries(DAYS.map((day) => [day, []])) as unknown as WeeklyHours;
    this.parseRule(week);
    while (this.lexer.peek().kind === ";") {
      this.lexer.next();
      this.parseRule(week);
    }
    this.expect("end");
    return week;
  }

  private parseRule(week: WeeklyHours): void {
    const days: Day[] = [];
    this.addDayItem(days);
    while (this.lexer.peek().kind === ",") {
      this.lexer.next();
      this.addDayItem(days);
    }
    const ranges: ParsedRange[] = [];
    const next = this.lexer.peek();
    if (next.kind === "word" && next.text === "off") {
      this.lexer.next();
    } else if (next.kind !== "time") {
      throw unexpected(next);
    } else {
      this.addRange(ranges);
      while (this.lexer.peek().kind === ",") {
        this.lexer.next();
        this.addRange(ranges);
      }
      ranges.sort((a, b) => a.from.minutes - b.from.minutes);
    }
    for (const day of days) {
      week[day] = ranges.map(({ from, to }) => ({ from: from.text, to: to.text }));
    }
  }

  private addRange(ranges: ParsedRange[]): void {
    const range = this.parseRange();
    const { from, to } = range;
    const overlapped = ranges.find((r) => from.minutes < r.to.minutes && r.from.minutes < to.minutes);
    if (overlapped) {
      throw new OpeningHoursError(
        "OVERLAP",
        from.column,
        `Range ${from.text}-${to.text} overlaps ${overlapped.from.text}-${overlapped.to.text}`,
      );
    }
    ranges.push(range);
  }

  private addDayItem(days: Day[]): void {
    const column = this.lexer.peek().column;
    const item = this.parseDayItem();
    const duplicate = item.find((day) => days.includes(day));
    if (duplicate) {
      throw new OpeningHoursError("DUPLICATE_DAY", column, `Day ${duplicate} is named twice`);
    }
    days.push(...item);
  }

  private parseDayItem(): Day[] {
    const first = this.parseDay();
    if (this.lexer.peek().kind !== "-") return [first];
    this.lexer.next();
    const last = this.parseDay();
    const days: Day[] = [];
    for (let i = DAYS.indexOf(first); ; i = (i + 1) % DAYS.length) {
      days.push(DAYS[i]!);
      if (DAYS[i] === last) return days;
    }
  }

  private parseDay(): Day {
    const token = this.expect("word");
    if (!(DAYS as readonly string[]).includes(token.text)) {
      throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    }
    return token.text as Day;
  }

  private parseRange(): ParsedRange {
    const from = this.parseTime(false);
    this.expect("-");
    const to = this.parseTime(true);
    if (to.minutes <= from.minutes) {
      throw new OpeningHoursError(
        "END_BEFORE_START",
        from.column,
        `Range ${from.text}-${to.text} does not end after it starts`,
      );
    }
    return { from, to };
  }

  private parseTime(isEnd: boolean): ParsedTime {
    const token = this.expect("time");
    const match = /^(\d\d):(\d\d)$/.exec(token.text);
    const hours = match ? Number(match[1]) : NaN;
    const minutes = match ? Number(match[2]) : NaN;
    const valid = (hours <= 23 && minutes <= 59) || (isEnd && hours === 24 && minutes === 0);
    if (!valid) {
      throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid time "${token.text}"`);
    }
    return { text: token.text, column: token.column, minutes: hours * 60 + minutes };
  }

  private expect(kind: TokenKind): Token {
    const token = this.lexer.next();
    if (token.kind !== kind) throw unexpected(token);
    return token;
  }
}

function unexpected(token: Token): OpeningHoursError {
  const description = token.kind === "end" ? "Unexpected end of text" : `Unexpected "${token.text}"`;
  return new OpeningHoursError("UNEXPECTED", token.column, description);
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  return new Parser(text).parse();
}
