import { expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

function errorOf(text: string): { code: string; column: number } {
  try {
    parseOpeningHours(text);
  } catch (e) {
    if (e instanceof OpeningHoursError) return { code: e.code, column: e.column };
    throw e;
  }
  throw new Error(`expected "${text}" to fail`);
}

test("empty text is rejected", () => {
  expect(errorOf("")).toEqual({ code: "EMPTY", column: 1 });
  expect(errorOf("   ")).toEqual({ code: "EMPTY", column: 1 });
});

const closedWeek = () => ({ Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] });

test("a single day with a single range", () => {
  expect(parseOpeningHours("Mo 08:00-12:00")).toEqual({
    ...closedWeek(),
    Mo: [{ from: "08:00", to: "12:00" }],
  });
});

test("off closes a day", () => {
  expect(parseOpeningHours("Su off")).toEqual(closedWeek());
});

const morning = [{ from: "08:00", to: "12:00" }];

test("a day range covers every day from the first to the last", () => {
  expect(parseOpeningHours("Mo-We 08:00-12:00")).toEqual({
    ...closedWeek(),
    Mo: morning,
    Tu: morning,
    We: morning,
  });
});

test("a day range may wrap around the end of the week", () => {
  expect(parseOpeningHours("Fr-Mo 08:00-12:00")).toEqual({
    ...closedWeek(),
    Fr: morning,
    Sa: morning,
    Su: morning,
    Mo: morning,
  });
});

test("a day range from a day to itself is that day only", () => {
  expect(parseOpeningHours("Mo-Mo 08:00-12:00")).toEqual({ ...closedWeek(), Mo: morning });
});

test("days are separated by commas", () => {
  expect(parseOpeningHours("Mo,We-Th,Sa 08:00-12:00")).toEqual({
    ...closedWeek(),
    Mo: morning,
    We: morning,
    Th: morning,
    Sa: morning,
  });
});

test("several ranges are returned sorted by start time, and may touch", () => {
  expect(parseOpeningHours("Mo 14:00-18:00,08:00-12:00,12:00-14:00")).toEqual({
    ...closedWeek(),
    Mo: [
      { from: "08:00", to: "12:00" },
      { from: "12:00", to: "14:00" },
      { from: "14:00", to: "18:00" },
    ],
  });
});

test("a later rule replaces the hours of the days it names", () => {
  const afternoon = [{ from: "14:00", to: "18:00" }];
  expect(parseOpeningHours("Mo-Fr 08:00-12:00; We 14:00-18:00; Fr off")).toEqual({
    ...closedWeek(),
    Mo: morning,
    Tu: morning,
    We: afternoon,
    Th: morning,
  });
});

test("spaces between tokens and around the text carry no meaning", () => {
  expect(parseOpeningHours("  Mo , We - Th 08:00 - 12:00 ;Su   off  ")).toEqual({
    ...closedWeek(),
    Mo: morning,
    We: morning,
    Th: morning,
  });
  expect(parseOpeningHours("Mo,We-Th 08:00-12:00;Su off")).toEqual(
    parseOpeningHours("  Mo , We - Th 08:00 - 12:00 ;Su   off  "),
  );
});

test("a word where a day is expected must be a day", () => {
  expect(errorOf("Mo-Fx 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 4 });
  expect(errorOf("Monday 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 1 });
  expect(errorOf("mo 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 1 });
  expect(errorOf("Mo, Xy 08:00-12:00")).toEqual({ code: "UNKNOWN_DAY", column: 5 });
  expect(errorOf("Mo off; off")).toEqual({ code: "UNKNOWN_DAY", column: 9 });
});

test("times must be HH:MM within the day", () => {
  expect(errorOf("Mo 8:00-12:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(errorOf("Mo 08:00-1200")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(errorOf("Mo 08:00-12:00:00")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(errorOf("Mo 08:0-12:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(errorOf("Mo 25:00-26:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(errorOf("Mo 08:00-12:60")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(errorOf("Mo 08:00-24:01")).toEqual({ code: "INVALID_TIME", column: 10 });
  expect(errorOf("Mo 08:00-12:00,:")).toEqual({ code: "INVALID_TIME", column: 16 });
});

test("24:00 is allowed only as the end of a range", () => {
  expect(parseOpeningHours("Sa 20:00-24:00").Sa).toEqual([{ from: "20:00", to: "24:00" }]);
  expect(errorOf("Sa 24:00-24:00")).toEqual({ code: "INVALID_TIME", column: 4 });
});

test("a range must end later than it starts", () => {
  expect(errorOf("Mo 08:00-12:00, 18:00 - 13:00")).toEqual({ code: "END_BEFORE_START", column: 17 });
  expect(errorOf("Mo 08:00-08:00")).toEqual({ code: "END_BEFORE_START", column: 4 });
});

test("ranges of one rule must not overlap", () => {
  expect(errorOf("Mo 08:00-12:00,11:00-13:00")).toEqual({ code: "OVERLAP", column: 16 });
  expect(errorOf("Mo 14:00-18:00,08:00-12:00,07:00-20:00")).toEqual({ code: "OVERLAP", column: 28 });
  expect(errorOf("Mo 14:00-18:00,14:00-15:00")).toEqual({ code: "OVERLAP", column: 16 });
});

test("a rule must not name a day twice", () => {
  expect(errorOf("Mo,Tu,Mo 08:00-12:00")).toEqual({ code: "DUPLICATE_DAY", column: 7 });
  expect(errorOf("Mo-Fr, Sa-Mo 08:00-12:00")).toEqual({ code: "DUPLICATE_DAY", column: 8 });
  expect(errorOf("Tu, Mo-We off")).toEqual({ code: "DUPLICATE_DAY", column: 5 });
});

test("text ending too early is reported after its last character", () => {
  expect(errorOf("Mo 08:00-")).toEqual({ code: "UNEXPECTED", column: 10 });
  expect(errorOf("Mo 08:00-  ")).toEqual({ code: "UNEXPECTED", column: 12 });
  expect(errorOf("Mo")).toEqual({ code: "UNEXPECTED", column: 3 });
  expect(errorOf("Mo-")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(errorOf("Mo 08:00-12:00,")).toEqual({ code: "UNEXPECTED", column: 16 });
  expect(errorOf("Mo off;")).toEqual({ code: "UNEXPECTED", column: 8 });
});

test("a token that does not fit the format is reported", () => {
  expect(errorOf(";Mo off")).toEqual({ code: "UNEXPECTED", column: 1 });
  expect(errorOf("Mo off; ;Tu off")).toEqual({ code: "UNEXPECTED", column: 9 });
  expect(errorOf("08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 1 });
  expect(errorOf("Mo,08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(errorOf("Mo-08:00")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(errorOf("Mo Tu 08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(errorOf("Mo Off")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(errorOf("Mo 08:00 12:00")).toEqual({ code: "UNEXPECTED", column: 10 });
  expect(errorOf("Mo 08:00-12:00, Tu off")).toEqual({ code: "UNEXPECTED", column: 17 });
  expect(errorOf("Mo 08:00-12:00 Tu off")).toEqual({ code: "UNEXPECTED", column: 16 });
  expect(errorOf("Mo off 08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 8 });
  expect(errorOf("Mo off,Tu off")).toEqual({ code: "UNEXPECTED", column: 7 });
});

test("a character that belongs to no token is reported", () => {
  expect(errorOf("Mo # 08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 4 });
  expect(errorOf("Mo 08:00-12:00!")).toEqual({ code: "UNEXPECTED", column: 15 });
  expect(errorOf("Mo\t08:00-12:00")).toEqual({ code: "UNEXPECTED", column: 3 });
});

test("the first problem from the left is reported", () => {
  expect(errorOf("Mx #")).toEqual({ code: "UNKNOWN_DAY", column: 1 });
  expect(errorOf("Mo 25:00-12:00")).toEqual({ code: "INVALID_TIME", column: 4 });
  expect(errorOf("Mo 12:00-08:00 #")).toEqual({ code: "END_BEFORE_START", column: 4 });
  expect(errorOf("Mo 08:00-12:00,10:00-11:00;Xx")).toEqual({ code: "OVERLAP", column: 16 });
  expect(errorOf("Mo,Mo #")).toEqual({ code: "DUPLICATE_DAY", column: 4 });
  expect(errorOf("Mo,Mo-Fx")).toEqual({ code: "UNKNOWN_DAY", column: 7 });
  expect(errorOf("Mo 08:00-12:00; Mo-Fr 25:00")).toEqual({ code: "INVALID_TIME", column: 23 });
});

test("the example from the shop owner form", () => {
  expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
    Mo: [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }],
    Tu: [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }],
    We: [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }],
    Th: [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }],
    Fr: [{ from: "08:00", to: "12:00" }, { from: "13:30", to: "18:30" }],
    Sa: [{ from: "09:00", to: "16:00" }],
    Su: [],
  });
  expect(parseOpeningHours("Mo-Su 08:00-20:00; Su off").Su).toEqual([]);
});

test("each day gets its own list of ranges", () => {
  const week = parseOpeningHours("Mo-Tu 08:00-12:00");
  week.Mo.push({ from: "13:00", to: "14:00" });
  week.Mo[0]!.to = "11:00";
  expect(week.Tu).toEqual(morning);
});

test("ranges of different rules may overlap", () => {
  expect(parseOpeningHours("Mo 08:00-12:00; Mo 10:00-14:00").Mo).toEqual([{ from: "10:00", to: "14:00" }]);
});
