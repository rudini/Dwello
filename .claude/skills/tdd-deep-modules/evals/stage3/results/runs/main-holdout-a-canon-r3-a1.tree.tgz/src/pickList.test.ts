import { describe, expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

describe("buildPickList", () => {
  test("comments and empty lines only yield an empty pick list", () => {
    expect(buildPickList("# export 2026-10-12 06:00\n\n   \n", [])).toEqual({ picks: [], shortages: [] });
  });

  test("one order with one item picks from the lot of its SKU", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x3\n", [
      lot("B-01-1", "PASTA-1KG", 9),
      lot("A-02-1", "OLIVE-500", 10, "2026-12-01"),
    ]);
    expect(result).toEqual({
      picks: [{ bin: "A-02-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
      shortages: [],
    });
  });

  test("an item not covered by stock picks what is there and reports the shortage", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x5\n", [lot("A-02-1", "OLIVE-500", 3)]);
    expect(result).toEqual({
      picks: [{ bin: "A-02-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
      shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 2 }],
    });
  });

  test("an item without any stock is reported missing in full", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x4\n", [
      lot("A-02-1", "PASTA-1KG", 3),
      lot("A-02-2", "OLIVE-500", 0),
    ]);
    expect(result).toEqual({
      picks: [],
      shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 4 }],
    });
  });

  test("lots with the earliest best-before date are taken first, one pick per lot", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x7\n", [
      lot("A-01-1", "OLIVE-500", 5, "2027-01-15"),
      lot("A-01-2", "OLIVE-500", 4, "2026-11-30"),
      lot("A-01-3", "OLIVE-500", 5, "2026-12-01"),
    ]);
    expect(result.picks).toEqual([
      { bin: "A-01-2", sku: "OLIVE-500", qty: 4, orderId: "1001" },
      { bin: "A-01-3", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ]);
    expect(result.shortages).toEqual([]);
  });

  test("undated lots come after dated ones; equal dates are taken in bin order", () => {
    const result = buildPickList("ORDER 1001\n  SALT-1KG x6\n", [
      lot("A-01-2", "SALT-1KG", 9, null),
      lot("A-01-4", "SALT-1KG", 2, "2027-03-01"),
      lot("A-01-3", "SALT-1KG", 2, "2027-03-01"),
      lot("A-01-1", "SALT-1KG", 9, null),
    ]);
    // Taken: A-01-3, A-01-4 (dated, by bin), then 2 from A-01-1 (first undated bin); A-01-2 untouched.
    expect(result.picks.toSorted((a, b) => a.bin.localeCompare(b.bin))).toEqual([
      { bin: "A-01-1", sku: "SALT-1KG", qty: 2, orderId: "1001" },
      { bin: "A-01-3", sku: "SALT-1KG", qty: 2, orderId: "1001" },
      { bin: "A-01-4", sku: "SALT-1KG", qty: 2, orderId: "1001" },
    ]);
    expect(result.shortages).toEqual([]);
  });

  test("stock taken by an earlier order is not available to a later one", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n  OLIVE-500 x3\n", [
      lot("A-01-1", "OLIVE-500", 4),
    ]);
    expect(result).toEqual({
      picks: [
        { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
        { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      ],
      shortages: [{ orderId: "1002", sku: "OLIVE-500", missing: 2 }],
    });
  });

  test("the stock array and its lots are left untouched", () => {
    const stock = [lot("B-01-1", "OLIVE-500", 4, null), lot("A-01-1", "OLIVE-500", 2, "2026-11-01")];
    const snapshot = structuredClone(stock);
    const lots = [...stock];
    buildPickList("ORDER 1001\n  OLIVE-500 x5\n", stock);
    expect(stock).toEqual(snapshot);
    stock.forEach((l, i) => expect(l).toBe(lots[i]));
  });

  test("a SKU repeated within an order is summed at the position of its first appearance", () => {
    const result = buildPickList("ORDER 1001\n  OLIVE-500 x2\n  PASTA-1KG x1\n  OLIVE-500 x3\n", []);
    expect(result.shortages).toEqual([
      { orderId: "1001", sku: "OLIVE-500", missing: 5 },
      { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
    ]);
  });

  test("priority orders are served first, each group in text order", () => {
    const text = [
      "ORDER 1001",
      "  OLIVE-500 x1",
      "ORDER 1002 !",
      "  OLIVE-500 x1",
      "ORDER 1003",
      "  OLIVE-500 x1",
      "ORDER 1004   !",
      "  OLIVE-500 x1",
    ].join("\n");
    const result = buildPickList(text, [lot("A-01-1", "OLIVE-500", 2)]);
    expect(result.picks.map((p) => p.orderId)).toEqual(["1002", "1004"]);
    expect(result.shortages.map((s) => s.orderId)).toEqual(["1001", "1003"]);
  });

  test("lines are trimmed and SKU and quantity may be separated by several spaces", () => {
    const text = "  # comment\r\n\t ORDER Web-77 \r\n   OLIVE-500     x12  \r\n\tPASTA-1KG x1\r\n";
    expect(buildPickList(text, []).shortages).toEqual([
      { orderId: "Web-77", sku: "OLIVE-500", missing: 12 },
      { orderId: "Web-77", sku: "PASTA-1KG", missing: 1 },
    ]);
  });
});

test("the example export becomes a pick list", () => {
  const text = [
    "# export 2026-10-12 06:00",
    "ORDER 1001",
    "  OLIVE-500 x3",
    "  PASTA-1KG x1",
    "ORDER 1002 !",
    "  OLIVE-500 x2",
  ].join("\n");
  const result = buildPickList(text, [
    lot("A-03-2", "OLIVE-500", 2, "2026-11-01"),
    lot("B-01-1", "OLIVE-500", 6, "2027-02-01"),
    lot("A-05-1", "PASTA-1KG", 0, null),
  ]);
  expect(result).toEqual({
    picks: [
      { bin: "A-03-2", sku: "OLIVE-500", qty: 2, orderId: "1002" },
      { bin: "B-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "PASTA-1KG", missing: 1 }],
  });
});

describe("walking order", () => {
  test("aisles alphabetically, racks up in odd and down in even aisles, levels ascending", () => {
    const skus = ["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8"];
    const bins = ["C-01-1", "B-10-1", "A-02-1", "B-02-3", "A-01-2", "B-02-1", "A-01-1", "C-05-1"];
    const text = ["ORDER 1", ...skus.map((sku) => `${sku} x1`)].join("\n");
    const result = buildPickList(
      text,
      skus.map((sku, i) => lot(bins[i], sku, 1)),
    );
    expect(result.picks.map((p) => p.bin)).toEqual([
      "A-01-1",
      "A-01-2",
      "A-02-1",
      "B-10-1",
      "B-02-1",
      "B-02-3",
      "C-01-1",
      "C-05-1",
    ]);
  });

  test("only aisles with picks count for the serpentine", () => {
    const text = "ORDER 1\n  S1 x1\n  S2 x1\n  S3 x1\n  S4 x1\n";
    const result = buildPickList(text, [
      lot("B-01-1", "UNUSED", 5),
      lot("C-01-1", "S1", 1),
      lot("C-07-1", "S2", 1),
      lot("A-01-1", "S3", 1),
      lot("A-03-1", "S4", 1),
    ]);
    // Visited aisles are A (1st, ascending) and C (2nd, descending); B has no pick.
    expect(result.picks.map((p) => p.bin)).toEqual(["A-01-1", "A-03-1", "C-07-1", "C-01-1"]);
  });

  test("picks at the same bin keep the order in which they were allocated", () => {
    const text = "ORDER 1\n  OLIVE-500 x1\nORDER 2 !\n  OLIVE-500 x1\nORDER 3\n  OLIVE-500 x1\n  PASTA-1KG x1\n";
    const result = buildPickList(text, [
      lot("B-02-1", "PASTA-1KG", 5),
      lot("B-02-1", "OLIVE-500", 5),
      lot("A-01-1", "PASTA-1KG", 5),
    ]);
    expect(result.picks).toEqual([
      { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "3" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "2" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "1" },
      { bin: "B-02-1", sku: "OLIVE-500", qty: 1, orderId: "3" },
    ]);
  });
});

function errorLine(ordersText: string): number {
  try {
    buildPickList(ordersText, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  throw new Error("expected an OrderFormatError");
}

describe("format errors", () => {
  test("an item line before the first ORDER", () => {
    expect(errorLine("# export\n\n  OLIVE-500 x3\nORDER 1001\n  OLIVE-500 x1\n")).toBe(3);
  });

  test("an ORDER id that was already used", () => {
    expect(errorLine("ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n  OLIVE-500 x1\nORDER 1001 !\n  OLIVE-500 x1\n")).toBe(5);
  });

  test("an ORDER without items is reported at its ORDER line", () => {
    expect(errorLine("ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n# nothing here\n\nORDER 1003\n  OLIVE-500 x1\n")).toBe(3);
    expect(errorLine("ORDER 1001\n  OLIVE-500 x3\nORDER 1002\n\n# trailing comment\n")).toBe(3);
  });

  test.each([
    "OLIVE-500 x0",
    "OLIVE-500 x03",
    "OLIVE-500 x-1",
    "OLIVE-500 x1.5",
    "olive-500 x1",
    "OLIVE-500 3",
    "OLIVE-500x3",
    "OLIVE_500 x3",
    "OLIVE-500 X3",
    "OLIVE-500 x3 extra",
    "ORDER",
    "ORDER 10!",
    "ORDER 10 ! !",
    "ORDER 10_1",
    "order 1003",
    "hello",
  ])("a malformed line %p", (badLine) => {
    expect(errorLine(`ORDER 1001\n  OLIVE-500 x3\n  ${badLine}\n  PASTA-1KG x1\n`)).toBe(3);
  });

  test("the first problem from the top is reported", () => {
    // A malformed line is no item line: the order above it stays empty, and that problem sits higher up.
    expect(errorLine("ORDER 1001\n  OLIVE-500 x0\nORDER 1002\n  OLIVE-500 x1\n")).toBe(1);
    expect(errorLine("ORDER 1001\n  OLIVE-500 x0\n")).toBe(1);
    // ...but a valid item line after the malformed one means the order is not empty.
    expect(errorLine("ORDER 1001\n  OLIVE-500 x0\n  OLIVE-500 x1\n")).toBe(2);
    // Empty order directly followed by a duplicate of its own id.
    expect(errorLine("ORDER 1001\nORDER 1001\n  OLIVE-500 x1\n")).toBe(1);
    expect(errorLine("ORDER 1001\n  OLIVE-500 x1\n  bad\nORDER 1001\nORDER 1002\n")).toBe(3);
    expect(errorLine("bad\n  OLIVE-500 x1\nORDER 1001\n")).toBe(1);
  });
});
