export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface OrderItem {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: OrderItem[];
}

const ORDER_LINE = /^ORDER +([A-Za-z0-9-]+)( +!)?$/;
const ITEM_LINE = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/;

/**
 * Parses the whole text, collecting every problem; the topmost one is thrown.
 * (An order's emptiness is only known once its block ends, but is reported at its ORDER line.)
 */
function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  ordersText.split("\n").forEach((rawLine, index) => {
    const lineNumber = index + 1;
    const line = rawLine.trim();
    if (line === "" || line.startsWith("#")) return;
    const orderMatch = ORDER_LINE.exec(line);
    if (orderMatch) {
      const [, id, priority] = orderMatch;
      if (orders.some((o) => o.id === id)) {
        problems.push(new OrderFormatError(lineNumber, `duplicate order id ${id}`));
      }
      orders.push({ id, priority: priority !== undefined, line: lineNumber, items: [] });
      return;
    }
    const itemMatch = ITEM_LINE.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNumber, `unrecognised line "${line}"`));
      return;
    }
    const current = orders.at(-1);
    if (!current) {
      problems.push(new OrderFormatError(lineNumber, "item line before the first ORDER"));
      return;
    }
    const [, sku, qty] = itemMatch;
    const existing = current.items.find((item) => item.sku === sku);
    if (existing) existing.qty += Number(qty);
    else current.items.push({ sku, qty: Number(qty) });
  });
  for (const order of orders) {
    if (order.items.length === 0) problems.push(new OrderFormatError(order.line, `order ${order.id} has no items`));
  }
  if (problems.length > 0) {
    throw problems.reduce((first, problem) => (problem.line < first.line ? problem : first));
  }
  return orders;
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Earliest best-before first, undated lots last, ties by bin code. */
function compareLots(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return compareStrings(a.expires, b.expires);
  }
  return compareStrings(a.bin, b.bin);
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle, rack, level] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/**
 * Serpentine walk: aisles alphabetically, racks ascending in the 1st, 3rd, ... visited aisle and
 * descending in the others, levels ascending. The sort is stable, so picks at one bin keep their order.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const aisles = [...new Set(picks.map((p) => parseBin(p.bin).aisle))].sort();
  const keyed = picks.map((pick) => {
    const { aisle, rack, level } = parseBin(pick.bin);
    const aisleIndex = aisles.indexOf(aisle);
    return { pick, aisleIndex, rack: aisleIndex % 2 === 0 ? rack : -rack, level };
  });
  keyed.sort((a, b) => a.aisleIndex - b.aisleIndex || a.rack - b.rack || a.level - b.level);
  return keyed.map((k) => k.pick);
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const remaining = stock.map((l) => l.qty);
  const lotOrder = stock.map((_, i) => i).sort((a, b) => compareLots(stock[a], stock[b]));
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const orders = parseOrders(ordersText);
  const serviceOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of serviceOrder) {
    for (const item of order.items) {
      let open = item.qty;
      for (const i of lotOrder) {
        if (open === 0) break;
        if (stock[i].sku !== item.sku || remaining[i] === 0) continue;
        const qty = Math.min(open, remaining[i]);
        remaining[i] -= qty;
        open -= qty;
        picks.push({ bin: stock[i].bin, sku: item.sku, qty, orderId: order.id });
      }
      if (open > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: open });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}
