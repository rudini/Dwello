export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

/** A decimal string as exact integer units and a power-of-ten scale, so rounding never meets float error. */
function decimal(value: string): { units: bigint; scale: number } {
  const [mantissa, exponent = "0"] = value.toLowerCase().split("e");
  const [whole, fraction = ""] = mantissa.split(".");
  const scale = fraction.length - Number(exponent);
  const units = BigInt(whole + fraction);
  return scale >= 0 ? { units, scale } : { units: units * 10n ** BigInt(-scale), scale: 0 };
}

/** `amount * rate` in cents, rounded to the nearest cent, halves up. */
function toChfCents(amount: string, rate: number): number {
  const a = decimal(amount);
  const r = decimal(String(rate));
  const product = a.units * r.units * 100n;
  const divisor = 10n ** BigInt(a.scale + r.scale);
  return Number((product * 2n + divisor) / (divisor * 2n));
}

function splitFields(row: string): string[] {
  const fields: string[] = [];
  let i = 0;
  while (true) {
    while (row[i] === " " || row[i] === "\t") i++;
    let value = "";
    if (row[i] === '"') {
      i++;
      while (i < row.length) {
        if (row[i] === '"' && row[i + 1] === '"') {
          value += '"';
          i += 2;
        } else if (row[i] === '"') {
          i++;
          break;
        } else {
          value += row[i++];
        }
      }
      while (i < row.length && row[i] !== ",") i++;
    } else {
      const end = row.indexOf(",", i);
      value = row.slice(i, end === -1 ? row.length : end).trim();
      i = end === -1 ? row.length : end;
    }
    fields.push(value);
    if (i >= row.length) return fields;
    i++;
  }
}

const COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Row = Record<(typeof COLUMNS)[number], string>;

/** Data rows of the file with their 1-based line numbers, keyed by column name. */
function readRows(csv: string): { line: number; complete: boolean; row: Row }[] {
  const lines = csv.split(/\r?\n/);
  const headerIndex = lines.findIndex((line) => line.trim() !== "");
  if (headerIndex === -1) throw new ExpenseFileError("Missing header");
  const names = splitFields(lines[headerIndex]).map((name) => name.trim().toLowerCase());
  for (const name of COLUMNS) {
    if (!names.includes(name)) throw new ExpenseFileError(`Missing column: ${name}`);
  }
  const rows = [];
  for (let i = headerIndex + 1; i < lines.length; i++) {
    if (lines[i].trim() === "") continue;
    const fields = splitFields(lines[i]);
    const row = Object.fromEntries(COLUMNS.map((name) => [name, fields[names.indexOf(name)] ?? ""])) as Row;
    rows.push({ line: i + 1, complete: fields.length === names.length, row });
  }
  return rows;
}

function isCalendarDate(value: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== undefined && day >= 1 && day <= daysInMonth;
}

/** The reason of the first failing check of a row, in the order the checks apply. */
function rejection(complete: boolean, row: Row, policy: Policy, fxRates: FxRates): string | undefined {
  if (!complete) return "wrong number of fields";
  if (!isCalendarDate(row.date)) return "invalid date";
  if (row.employee.trim() === "") return "missing employee";
  if (!Object.hasOwn(policy.categories, row.category)) return "unknown category";
  if (!/^\d+(\.\d{1,2})?$/.test(row.amount) || !/[1-9]/.test(row.amount)) return "invalid amount";
  if (row.currency !== "CHF" && !Object.hasOwn(fxRates, row.currency)) return "unknown currency";
  if (!/^(yes|no)$/i.test(row.receipt)) return "invalid receipt flag";
  return undefined;
}

/** Checks accepted rows against the policy in file order, remembering earlier rows and day totals. */
function policyChecker(policy: Policy): (row: Row, cents: number) => Violation[] {
  const seen = new Set<string>();
  const dayTotals = new Map<string, number>();
  return (row, cents) => {
    const { date, employee, category, amount, currency } = row;
    const limit = policy.categories[category];
    const violations: Violation[] = [];

    const expense = JSON.stringify([employee, date, category, toChfCents(amount, 1), currency]);
    if (seen.has(expense)) violations.push("DUPLICATE");
    seen.add(expense);

    if (limit.perItemLimitCents !== undefined && cents > limit.perItemLimitCents) violations.push("OVER_ITEM_LIMIT");

    const day = JSON.stringify([employee, date, category]);
    const dayTotal = (dayTotals.get(day) ?? 0) + cents;
    dayTotals.set(day, dayTotal);
    if (limit.dailyLimitCents !== undefined && dayTotal > limit.dailyLimitCents) violations.push("OVER_DAILY_LIMIT");

    if (row.receipt.toLowerCase() === "no" && cents > policy.receiptRequiredAboveCents) violations.push("NO_RECEIPT");
    return violations;
  };
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const report: ExpenseReport = { lines: [], rejected: [], totals: {} };
  const check = policyChecker(policy);
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();
  for (const { line, complete, row } of readRows(csv)) {
    const reason = rejection(complete, row, policy, fxRates);
    if (reason) {
      report.rejected.push({ line, reason });
      continue;
    }
    const { date, employee, category, amount, currency } = row;
    const cents = toChfCents(amount, currency === "CHF" ? 1 : fxRates[currency]);
    const violations = check(row, cents);
    report.lines.push({ line, date, employee, category, amountChfCents: cents, violations });
    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    total[violations.length ? "flaggedCents" : "approvedCents"] += cents;
    totals.set(employee, total);
  }
  report.totals = Object.fromEntries(totals);
  return report;
}
