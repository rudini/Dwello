import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type ExpenseReport, type Policy } from "./expenseReview";

const HEADER = "date,employee,category,amount,currency,receipt";
const policy: Policy = {
  categories: { meals: {}, hotel: {}, taxi: {} },
  receiptRequiredAboveCents: 1_000_000,
};

function reviewCsv(csv: string, p: Policy = policy, rates = {}) {
  let report: ExpenseReport | undefined;
  expect(() => (report = reviewExpenses(csv, p, rates))).not.toThrow();
  return report!;
}

function review(rows: string[], p: Policy = policy, rates = { EUR: 0.9412 }) {
  return reviewExpenses([HEADER, ...rows].join("\n"), p, rates);
}

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

test("reviews a single CHF row into a line with CHF cents, no violations, approved total", () => {
  const run = () => review(["2026-09-01,Anna,meals,12.50,CHF,yes"]);
  expect(run).not.toThrow();
  expect(run()).toEqual({
    lines: [
      { line: 2, date: "2026-09-01", employee: "Anna", category: "meals", amountChfCents: 1250, violations: [] },
    ],
    rejected: [],
    totals: { Anna: { approvedCents: 1250, flaggedCents: 0 } },
  });
});

test("converts a foreign amount with the rate, rounding to the nearest cent, halves up", () => {
  const report = review(
    ["2026-09-01,Anna,meals,12.50,EUR,yes", "2026-09-02,Anna,meals,0.10,USD,yes", "2026-09-03,Anna,meals,10.00,EUR,yes"],
    policy,
    { EUR: 0.9412, USD: 0.95 },
  );
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([1177, 10, 941]);
});

test("finds header columns in any order, case-insensitively, trimmed, ignoring extra columns", () => {
  const csv = " Receipt , NOTE,Currency,AMOUNT,Category, employee ,Date\nyes,lunch,CHF,8.40,meals,Ben,2026-09-04";
  expect(() => reviewExpenses(csv, policy, {})).not.toThrow();
  expect(reviewExpenses(csv, policy, {}).lines).toEqual([
    { line: 2, date: "2026-09-04", employee: "Ben", category: "meals", amountChfCents: 840, violations: [] },
  ]);
});

test("skips blank lines but counts every physical line, with \\n and \\r\\n", () => {
  const csv = `\r\n  \n${HEADER}\r\n\r\n2026-09-01,Anna,meals,5,CHF,yes\r\n \t \n2026-09-02,Ben,hotel,7,CHF,no\n\n`;
  const report = reviewCsv(csv);
  expect(report.lines.map((l) => [l.line, l.employee, l.amountChfCents])).toEqual([
    [5, "Anna", 500],
    [7, "Ben", 700],
  ]);
  expect(report.rejected).toEqual([]);
});

test("reads quoted fields with commas and doubled quotes, and trims unquoted values", () => {
  const csv = [
    "date,employee,category,amount,currency,receipt,note",
    ` 2026-09-01 ,"Müller, Hans", hotel ,"120.00", CHF ,yes,"dinner, ""late"""`,
    `2026-09-02,"Anna ""Ace"" Bell","meals",3,CHF,no,`,
  ].join("\n");
  expect(reviewCsv(csv).lines).toEqual([
    { line: 2, date: "2026-09-01", employee: "Müller, Hans", category: "hotel", amountChfCents: 12000, violations: [] },
    { line: 3, date: "2026-09-02", employee: 'Anna "Ace" Bell', category: "meals", amountChfCents: 300, violations: [] },
  ]);
});

test("throws Missing header when the file has no non-blank line", () => {
  for (const csv of ["", "\n \r\n\t\n"]) {
    expect(() => reviewExpenses(csv, policy, {})).toThrow(new ExpenseFileError("Missing header"));
    expect(() => reviewExpenses(csv, policy, {})).toThrow(ExpenseFileError);
  }
});

test("throws Missing column naming the first missing column in spec order", () => {
  const cases: [string, string][] = [
    ["receipt,currency,amount,category,employee", "Missing column: date"],
    ["receipt,date,amount,employees,dates", "Missing column: employee"],
    ["date,employee,category,amount,currency", "Missing column: receipt"],
  ];
  for (const [header, message] of cases) {
    expect(() => reviewExpenses(`${header}\n`, policy, {})).toThrow(new ExpenseFileError(message));
  }
});

test("rejects a row with the wrong number of fields", () => {
  const report = reviewCsv(
    [HEADER, "2026-09-01,Anna,meals,5,CHF", "2026-09-01,Anna,meals,5,CHF,yes,extra", `2026-09-01,"Anna, B",meals,5,CHF,yes`].join("\n"),
  );
  expect(report.rejected).toEqual([
    { line: 2, reason: "wrong number of fields" },
    { line: 3, reason: "wrong number of fields" },
  ]);
  expect(report.lines.map((l) => l.line)).toEqual([4]);
  expect(Object.keys(report.totals)).toEqual(["Anna, B"]);
});

/** The rejection reason of one data row, or "accepted". */
function verdict(row: string) {
  const report = reviewCsv(`${HEADER}\n${row}`, policy, { EUR: 0.9412 });
  return report.rejected[0]?.reason ?? (report.lines.length === 1 ? "accepted" : "lost");
}

test("rejects an invalid date (format and calendar)", () => {
  const dates = ["2026-9-01", "2026/09/01", "26-09-01", "2026-09-01x", "2025-02-29", "2026-13-01", "2026-04-31", "2026-00-10", "2026-01-00", ""];
  for (const date of dates) expect([date, verdict(`${date},Anna,meals,5,CHF,yes`)]).toEqual([date, "invalid date"]);
  for (const date of ["2024-02-29", "2026-12-31", "2026-01-01"]) {
    expect([date, verdict(`${date},Anna,meals,5,CHF,yes`)]).toEqual([date, "accepted"]);
  }
});

test("rejects a missing employee", () => {
  expect(verdict("2026-09-01,,meals,5,CHF,yes")).toBe("missing employee");
  expect(verdict("2026-09-01,   ,meals,5,CHF,yes")).toBe("missing employee");
  expect(verdict(`2026-09-01,"",meals,5,CHF,yes`)).toBe("missing employee");
});

test("rejects an unknown category", () => {
  for (const category of ["Meals", "food", "", "toString", "constructor"]) {
    expect([category, verdict(`2026-09-01,Anna,${category},5,CHF,yes`)]).toEqual([category, "unknown category"]);
  }
});

test("rejects an invalid amount (bad format, more than two decimals, zero)", () => {
  const bad = ["", "abc", "12.345", "12.", ".5", "-5", "+5", "1e3", "1,5", "0", "0.00", "00.0", " 1 2", "0x10", "Infinity"];
  for (const amount of bad) {
    expect([amount, verdict(`2026-09-01,Anna,meals,"${amount}",CHF,yes`)]).toEqual([amount, "invalid amount"]);
  }
  for (const amount of ["0.01", "7", "12.5", "0012.50"]) {
    expect([amount, verdict(`2026-09-01,Anna,meals,${amount},CHF,yes`)]).toEqual([amount, "accepted"]);
  }
});

test("rejects an unknown currency", () => {
  for (const currency of ["USD", "eur", "chf", "", "toString"]) {
    expect([currency, verdict(`2026-09-01,Anna,meals,5,${currency},yes`)]).toEqual([currency, "unknown currency"]);
  }
  expect(verdict("2026-09-01,Anna,meals,5,EUR,yes")).toBe("accepted");
});

test("rejects an invalid receipt flag and accepts yes or no in any case", () => {
  for (const receipt of ["", "y", "true", "1", "yess", "n o"]) {
    expect([receipt, verdict(`2026-09-01,Anna,meals,5,CHF,${receipt}`)]).toEqual([receipt, "invalid receipt flag"]);
  }
  for (const receipt of ["yes", "YES", "Yes", "no", "No", " NO "]) {
    expect([receipt, verdict(`2026-09-01,Anna,meals,5,CHF,${receipt}`)]).toEqual([receipt, "accepted"]);
  }
});

const limits: Policy = {
  categories: { meals: { perItemLimitCents: 5000 }, hotel: { dailyLimitCents: 20000 }, taxi: {} },
  receiptRequiredAboveCents: 1_000_000,
};

test("flags OVER_ITEM_LIMIT above the per-item limit", () => {
  const report = review(
    ["2026-09-01,Anna,meals,50.00,CHF,yes", "2026-09-01,Anna,meals,50.01,CHF,yes", "2026-09-02,Anna,meals,53.13,EUR,yes", "2026-09-02,Anna,taxi,900,CHF,yes"],
    limits,
  );
  expect(report.lines.map((l) => [l.amountChfCents, l.violations])).toEqual([
    [5000, []],
    [5001, ["OVER_ITEM_LIMIT"]],
    [5001, ["OVER_ITEM_LIMIT"]],
    [90000, []],
  ]);
});

test("flags NO_RECEIPT above the receipt threshold when receipt is no", () => {
  const p: Policy = { categories: { taxi: {} }, receiptRequiredAboveCents: 2000 };
  const report = review(
    ["2026-09-01,Anna,taxi,20.00,CHF,no", "2026-09-01,Anna,taxi,20.01,CHF,No", "2026-09-01,Anna,taxi,99,CHF,yes", "2026-09-01,Anna,taxi,21.25,EUR,NO"],
    p,
  );
  expect(report.lines.map((l) => [l.amountChfCents, l.violations])).toEqual([
    [2000, []],
    [2001, ["NO_RECEIPT"]],
    [9900, []],
    [2000, []],
  ]);
});

test("flags OVER_DAILY_LIMIT on the running total per employee, date and category", () => {
  const report = review(
    [
      "2026-09-01,Anna,hotel,150,CHF,yes", // Anna 09-01 hotel: 150
      "2026-09-01,Ben,hotel,150,CHF,yes", // other employee
      "2026-09-02,Anna,hotel,150,CHF,yes", // other date
      "2026-09-01,Anna,meals,40,CHF,yes", // other category
      "2026-09-01,Anna,hotel,50,CHF,yes", // 200: at the limit
      "2026-09-01,Anna,hotel,0.01,CHF,yes", // 200.01: above
      "2026-09-01,Anna,hotel,10,CHF,yes", // 210.01: still above
    ],
    limits,
  );
  expect(report.lines.map((l) => l.violations)).toEqual([[], [], [], [], [], ["OVER_DAILY_LIMIT"], ["OVER_DAILY_LIMIT"]]);
});

test("flags DUPLICATE of an earlier accepted row, comparing amounts as values", () => {
  const report = review([
    "2026-09-01,Anna,meals,12.5,CHF,yes",
    "2026-09-01,Anna,meals,12.50,CHF,no", // duplicate: amount as value, receipt ignored
    "2026-09-01,Anna,meals,012.5,CHF,yes", // duplicate again
    "2026-09-01,Ben,meals,12.5,CHF,yes", // other employee
    "2026-09-02,Anna,meals,12.5,CHF,yes", // other date
    "2026-09-01,Anna,hotel,12.5,CHF,yes", // other category
    "2026-09-01,Anna,meals,12.51,CHF,yes", // other amount
    "2026-09-01,Anna,meals,12.5,EUR,yes", // other currency
  ]);
  expect(report.lines.map((l) => l.violations)).toEqual([[], ["DUPLICATE"], ["DUPLICATE"], [], [], [], [], []]);
});

test("lists violations in spec order and splits totals into approved and flagged per employee", () => {
  const p: Policy = {
    categories: { meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 }, taxi: {} },
    receiptRequiredAboveCents: 3000,
  };
  const report = review(
    [
      "2026-09-01,Anna,meals,60,CHF,no", // over item, no receipt
      "2026-09-01,Anna,meals,60.00,CHF,no", // all four
      "2026-09-01,Anna,taxi,25,CHF,no", // clean
      "2026-09-01,Ben,taxi,10,CHF,yes", // clean
      "2026-09-01,Ben,taxi,10,CHF,yes", // duplicate
      "2026-09-01,Cleo,taxi,31,CHF,no", // no receipt
    ],
    p,
  );
  expect(report.lines.map((l) => l.violations)).toEqual([
    ["OVER_ITEM_LIMIT", "NO_RECEIPT"],
    ["DUPLICATE", "OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
    [],
    [],
    ["DUPLICATE"],
    ["NO_RECEIPT"],
  ]);
  expect(report.totals).toEqual({
    Anna: { approvedCents: 2500, flaggedCents: 12000 },
    Ben: { approvedCents: 1000, flaggedCents: 1000 },
    Cleo: { approvedCents: 0, flaggedCents: 3100 },
  });
});

test("keeps totals for any employee name, including __proto__", () => {
  const report = review(["2026-09-01,__proto__,meals,5,CHF,yes", "2026-09-01,constructor,meals,7,CHF,yes"]);
  expect(Object.entries(report.totals)).toEqual([
    ["__proto__", { approvedCents: 500, flaggedCents: 0 }],
    ["constructor", { approvedCents: 700, flaggedCents: 0 }],
  ]);
});

test("accepts real dates in years 0000 to 0099", () => {
  for (const date of ["0050-01-01", "0000-02-29", "0004-02-29"]) {
    expect([date, verdict(`${date},Anna,meals,5,CHF,yes`)]).toEqual([date, "accepted"]);
  }
  expect(verdict("0001-02-29,Anna,meals,5,CHF,yes")).toBe("invalid date");
});
