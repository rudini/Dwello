# Design note: `reviewExpenses`

**Hidden decision:** how a raw travel-app CSV export (its dialect, row validation, currency
rounding and company policy rules) becomes a per-employee review report.

**Both designs**
- A: `reviewExpenses(csv, policy, fxRates): ExpenseReport`, throwing `ExpenseFileError`.
- B: `new ExpenseReviewer(policy, fxRates)` with `header()`, `row()`, `report()`, fed by the caller.
- Chosen: A, because the CSV dialect, line counting and running totals stay entirely behind one
  call, while B leaks the file format and call order to every caller.

**Interface:** `reviewExpenses` is the only function exported. It returns accepted lines and rejected
lines in file order plus per-employee totals, and throws `ExpenseFileError` (`Missing header`,
`Missing column: <name>`) when the file as a whole can't be read. The types and the error class
are kept exactly as they were in the stub.

**Inside (private):** `splitFields` (quote-aware field splitter), `readRows` (header and line
numbers), `rejection` (the ordered row checks), `policyChecker` (duplicate and daily-total state),
and `decimal`/`toChfCents` (exact BigInt arithmetic, so a rate like 0.9412 never rounds the wrong
way because of float error).

**Depth:** `src/expenseReview.ts: surface 13, size 154, ratio 11.8, classitis no, pass-through 0,
tests 1, unused 0, duplicate 2 -> deep`. Refactors pulled row reading into `readRows`, collected
the checks into one ordered `rejection` function, and moved the policy state into `policyChecker`.

**Open points**
- Quoted values keep their inner spaces (only unquoted values are trimmed, as the spec says). An
  employee made of whitespace only counts as missing.
- Text after a closing quote in the same field is ignored, and an unterminated quote runs to the
  end of the line. Fields can't span lines.
- Category and currency matching is exact and only looks at the object's own keys (`toString` is
  not a category).

**Proof:** `scripts/tdd_replay 71bea4d..HEAD` printed `REPLAY: ACCEPT`.
