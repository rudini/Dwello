# Expense review: test list

**Hidden decision:** how a raw travel-app CSV export (its dialect, row validation, currency
rounding and company policy rules) becomes a per-employee review report; callers never see rows,
fields, parsing or rule order.

**Design A:** one pure function.
`reviewExpenses(csv, policy, fxRates): ExpenseReport` (throws `ExpenseFileError` on a broken file)
— call site: `const report = reviewExpenses(text, policy, rates);`

**Design B:** a stateful reviewer fed row by row.
`const r = new ExpenseReviewer(policy, fxRates); r.header(cols); r.row(n, fields); r.report()`
— the caller splits the CSV and keeps line numbers itself.

**Chosen:** Design A, because the CSV dialect, line counting and running totals stay entirely
behind one call, while Design B leaks the file format and call order to every caller.

## Behaviours (through `reviewExpenses`)

- [x] reviews a single CHF row into a line with CHF cents, no violations, approved total
- [x] converts a foreign amount with the rate, rounding to the nearest cent, halves up
- [x] finds header columns in any order, case-insensitively, trimmed, ignoring extra columns
- [x] skips blank lines but counts every physical line, with `\n` and `\r\n`
- [x] reads quoted fields with commas and `""`, and trims unquoted values
- [x] throws `Missing header` when the file has no non-blank line
- [x] throws `Missing column: <name>` naming the first missing column in spec order
- [x] rejects a row with the wrong number of fields
- [x] rejects an invalid date (format and calendar, e.g. 2025-02-29)
- [x] rejects a missing employee
- [x] rejects an unknown category
- [x] rejects an invalid amount (bad format, more than two decimals, zero)
- [x] rejects an unknown currency
- [x] rejects an invalid receipt flag; accepts yes/no in any case
- [x] ~~reports only the first failing check of a row~~ (dropped: already guaranteed by the ordered
      checks, so no red was possible; each rejection test exercises a single failing check)
- [x] flags OVER_ITEM_LIMIT above the per-item limit
- [x] flags NO_RECEIPT above the receipt threshold when receipt is no
- [x] flags OVER_DAILY_LIMIT on the running total per employee, date and category
- [x] flags DUPLICATE of an earlier accepted row, comparing amounts as values
- [x] lists violations in spec order and splits totals into approved and flagged per employee
- [x] ~~ignores rejected rows for duplicates and daily totals~~ (dropped: a rejected row leaves the
      loop before any policy state, so no red was possible)
- [x] keeps totals for any employee name, including `__proto__`
- [x] accepts real dates in years 0000 to 0099
