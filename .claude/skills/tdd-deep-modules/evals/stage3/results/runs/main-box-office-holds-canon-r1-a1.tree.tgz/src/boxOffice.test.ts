import { describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOfficeOptions } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

const START = 1_000_000;

function setup(overrides: Partial<BoxOfficeOptions> = {}) {
  let time = START;
  const clock = {
    advanceMinutes(minutes: number) {
      time += minutes * 60_000;
    },
    set(ms: number) {
      time = ms;
    },
  };
  const office = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 5000 },
      { id: "BALKON", capacity: 5, priceCents: 3333 },
    ],
    holdMinutes: 10,
    maxTicketsPerCustomer: 6,
    now: () => time,
    ...overrides,
  });
  return { office, clock };
}

function codeOf(fn: () => unknown): string | undefined {
  try {
    fn();
  } catch (e) {
    if (e instanceof BoxOfficeError) return e.code;
    throw e;
  }
  return undefined;
}

describe("available", () => {
  test("is the capacity of a fresh section", () => {
    const { office } = setup();
    expect(office.available("PARKETT")).toBe(10);
    expect(office.available("BALKON")).toBe(5);
  });

  test("rejects an unknown section", () => {
    const { office } = setup();
    expect(codeOf(() => office.available("LOGE"))).toBe("UNKNOWN_SECTION");
  });
});

describe("hold", () => {
  test("returns the hold and takes the tickets", () => {
    const { office } = setup();
    expect(office.hold("alice", "PARKETT", 3)).toEqual({
      holdId: "H1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 3,
      expiresAt: START + 10 * 60_000,
    });
    expect(office.available("PARKETT")).toBe(7);
    expect(office.available("BALKON")).toBe(5);
  });

  test("rejects an unknown section", () => {
    const { office } = setup();
    expect(codeOf(() => office.hold("alice", "LOGE", 1))).toBe("UNKNOWN_SECTION");
  });

  test.each([0, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY])(
    "rejects quantity %p",
    (quantity) => {
      const { office } = setup();
      expect(codeOf(() => office.hold("alice", "PARKETT", quantity))).toBe("INVALID_QUANTITY");
      expect(office.available("PARKETT")).toBe(10);
    },
  );

  test("rejects more tickets than available, without a partial hold", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 3);
    expect(codeOf(() => office.hold("bob", "BALKON", 3))).toBe("SOLD_OUT");
    expect(office.available("BALKON")).toBe(2);
    expect(office.hold("bob", "BALKON", 2).quantity).toBe(2);
    expect(office.available("BALKON")).toBe(0);
  });

  test("numbers holds consecutively, skipping failed attempts", () => {
    const { office } = setup();
    expect(office.hold("alice", "PARKETT", 1).holdId).toBe("H1");
    codeOf(() => office.hold("bob", "LOGE", 1));
    codeOf(() => office.hold("bob", "PARKETT", 0));
    codeOf(() => office.hold("bob", "BALKON", 6));
    expect(office.hold("bob", "BALKON", 1).holdId).toBe("H2");
  });

  test("limits a customer's tickets across all sections", () => {
    const { office } = setup();
    office.hold("alice", "PARKETT", 4);
    expect(codeOf(() => office.hold("alice", "BALKON", 3))).toBe("CUSTOMER_LIMIT");
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "BALKON", 2).quantity).toBe(2);
    expect(office.hold("bob", "BALKON", 3).quantity).toBe(3);
  });

  test("checks the customer limit before availability", () => {
    const { office } = setup();
    office.hold("bob", "BALKON", 5);
    expect(codeOf(() => office.hold("alice", "BALKON", 7))).toBe("CUSTOMER_LIMIT");
  });

  test("checks the section before the quantity", () => {
    const { office } = setup();
    expect(codeOf(() => office.hold("alice", "LOGE", 0))).toBe("UNKNOWN_SECTION");
  });

  test("checks the quantity before the customer limit", () => {
    const { office } = setup();
    office.hold("alice", "PARKETT", 6);
    expect(codeOf(() => office.hold("alice", "PARKETT", 0.5))).toBe("INVALID_QUANTITY");
  });

  test("stops counting a hold once it expires", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 6);
    clock.set(hold.expiresAt - 1);
    expect(office.available("PARKETT")).toBe(4);
    expect(codeOf(() => office.hold("alice", "BALKON", 1))).toBe("CUSTOMER_LIMIT");
    clock.set(hold.expiresAt);
    expect(office.available("PARKETT")).toBe(10);
    expect(office.hold("alice", "BALKON", 1).expiresAt).toBe(hold.expiresAt + 10 * 60_000);
  });
});

describe("confirm", () => {
  test("turns the hold into an order whose tickets stay taken", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    expect(office.confirm(hold.holdId)).toEqual({
      orderId: "O1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 2,
      totalCents: 10000,
    });
    clock.advanceMinutes(60);
    expect(office.available("PARKETT")).toBe(8);
    expect(codeOf(() => office.hold("alice", "BALKON", 5))).toBe("CUSTOMER_LIMIT");
    expect(office.confirm(office.hold("bob", "BALKON", 1).holdId).orderId).toBe("O2");
  });

  test("rejects an unknown hold", () => {
    const { office } = setup();
    expect(codeOf(() => office.confirm("H1"))).toBe("UNKNOWN_HOLD");
  });

  test("rejects a hold that was already confirmed", () => {
    const { office } = setup();
    const { holdId } = office.hold("alice", "PARKETT", 2);
    office.confirm(holdId);
    expect(codeOf(() => office.confirm(holdId))).toBe("UNKNOWN_HOLD");
    expect(office.available("PARKETT")).toBe(8);
  });

  test("rejects an expired hold without creating an order", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    clock.set(hold.expiresAt);
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("HOLD_EXPIRED");
    expect(office.available("PARKETT")).toBe(10);
    expect(office.confirm(office.hold("bob", "PARKETT", 1).holdId).orderId).toBe("O1");
  });
});

describe("order total", () => {
  function totalFor(priceCents: number, quantity: number): number {
    const { office } = setup({
      sections: [{ id: "S", capacity: 20, priceCents }],
      maxTicketsPerCustomer: 20,
    });
    return office.confirm(office.hold("alice", "S", quantity).holdId).totalCents;
  }

  test.each([
    [5000, 3, 15000], // no discount below 4 tickets
    [5000, 4, 18000], // 10 % group discount from 4 tickets
    [3333, 1, 3335], // rounded to 5 cents without discount: 3333 -> 3335
    [3333, 2, 6665], // 6666 -> 6665
    [3333, 4, 12000], // 13332 * 0.9 = 11998.8 -> 12000
    [1005, 5, 4525], // 5025 * 0.9 = 4522.5, exact half rounds up
    [1001, 4, 3605], // 4004 * 0.9 = 3603.6 -> 3605
    [1007, 4, 3625], // 4028 * 0.9 = 3625.2 -> 3625
  ])("price %p x %p costs %p", (priceCents, quantity, expected) => {
    expect(totalFor(priceCents, quantity)).toBe(expected);
  });
});

describe("release", () => {
  test("frees the tickets of an active hold", () => {
    const { office } = setup();
    const { holdId } = office.hold("alice", "PARKETT", 6);
    office.release(holdId);
    expect(office.available("PARKETT")).toBe(10);
    expect(office.hold("alice", "BALKON", 5).quantity).toBe(5);
  });

  test("ends the hold so it can neither be confirmed nor released again", () => {
    const { office } = setup();
    const { holdId } = office.hold("alice", "PARKETT", 2);
    office.release(holdId);
    expect(codeOf(() => office.release(holdId))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => office.confirm(holdId))).toBe("UNKNOWN_HOLD");
  });

  test("rejects an unknown or confirmed hold", () => {
    const { office } = setup();
    expect(codeOf(() => office.release("H1"))).toBe("UNKNOWN_HOLD");
    const { holdId } = office.hold("alice", "PARKETT", 2);
    office.confirm(holdId);
    expect(codeOf(() => office.release(holdId))).toBe("UNKNOWN_HOLD");
    expect(office.available("PARKETT")).toBe(8);
  });

  test("succeeds without effect on an expired hold", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    clock.set(hold.expiresAt);
    expect(codeOf(() => office.release(hold.holdId))).toBeUndefined();
    expect(office.available("PARKETT")).toBe(10);
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("HOLD_EXPIRED");
  });
});

describe("cancelOrder", () => {
  test("refunds the total minus 200 cents per ticket", () => {
    const { office } = setup();
    const { orderId } = office.confirm(office.hold("alice", "PARKETT", 4).holdId);
    expect(office.cancelOrder(orderId)).toBe(18000 - 800);
  });

  test("never refunds less than 0", () => {
    const { office } = setup({ sections: [{ id: "CHEAP", capacity: 10, priceCents: 150 }] });
    const { orderId } = office.confirm(office.hold("alice", "CHEAP", 2).holdId);
    expect(office.cancelOrder(orderId)).toBe(0);
  });

  test("frees the tickets and the customer's allowance", () => {
    const { office } = setup();
    const { orderId } = office.confirm(office.hold("alice", "BALKON", 5).holdId);
    office.cancelOrder(orderId);
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).quantity).toBe(6);
  });

  test("rejects an unknown or already cancelled order", () => {
    const { office } = setup();
    expect(codeOf(() => office.cancelOrder("O1"))).toBe("UNKNOWN_ORDER");
    const { orderId } = office.confirm(office.hold("alice", "PARKETT", 2).holdId);
    office.cancelOrder(orderId);
    office.hold("bob", "PARKETT", 3);
    expect(codeOf(() => office.cancelOrder(orderId))).toBe("UNKNOWN_ORDER");
    expect(office.available("PARKETT")).toBe(7);
  });
});
