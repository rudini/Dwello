export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const GROUP_DISCOUNT_MIN_TICKETS = 4;
const CANCELLATION_FEE_CENTS_PER_TICKET = 200;

/** Price with group discount, rounded to 5 cents (halves up). Computed in tenths of a cent to stay exact. */
function totalCents(quantity: number, priceCents: number): number {
  const percentPaid = quantity >= GROUP_DISCOUNT_MIN_TICKETS ? 90 : 100;
  const tenths = (quantity * priceCents * percentPaid) / 10;
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const sections = new Map(options.sections.map((s) => [s.id, s]));

  function sectionOf(sectionId: string): SectionConfig {
    const section = sections.get(sectionId);
    if (!section) {
      throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    }
    return section;
  }

  /** `ended` means confirmed or released; expiry is derived from the clock. */
  const holds: { hold: Hold; ended: boolean }[] = [];
  const orders: { order: Order; cancelled: boolean }[] = [];

  function isActive(entry: { hold: Hold; ended: boolean }): boolean {
    return !entry.ended && options.now() < entry.hold.expiresAt;
  }

  function unendedHold(holdId: string): { hold: Hold; ended: boolean } {
    const entry = holds.find((h) => h.hold.holdId === holdId);
    if (!entry || entry.ended) {
      throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    }
    return entry;
  }

  type Tickets = { customerId: string; sectionId: string; quantity: number };

  function ticketsWhere(matches: (t: Tickets) => boolean): number {
    const taken: Tickets[] = [
      ...holds.filter(isActive).map((h) => h.hold),
      ...orders.filter((o) => !o.cancelled).map((o) => o.order),
    ];
    return taken.filter(matches).reduce((sum, t) => sum + t.quantity, 0);
  }

  function takenIn(sectionId: string): number {
    return ticketsWhere((t) => t.sectionId === sectionId);
  }

  function ticketsOf(customerId: string): number {
    return ticketsWhere((t) => t.customerId === customerId);
  }

  function available(sectionId: string): number {
    return sectionOf(sectionId).capacity - takenIn(sectionId);
  }

  return {
    hold(customerId, sectionId, quantity) {
      sectionOf(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      if (ticketsOf(customerId) + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError("CUSTOMER_LIMIT", `Customer ${customerId} exceeds the ticket limit`);
      }
      if (quantity > available(sectionId)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in ${sectionId}`);
      }
      const hold: Hold = {
        holdId: `H${holds.length + 1}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: options.now() + options.holdMinutes * 60_000,
      };
      holds.push({ hold, ended: false });
      return { ...hold };
    },
    confirm(holdId) {
      const entry = unendedHold(holdId);
      if (!isActive(entry)) {
        throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      }
      entry.ended = true;
      const { customerId, sectionId, quantity } = entry.hold;
      const order: Order = {
        orderId: `O${orders.length + 1}`,
        customerId,
        sectionId,
        quantity,
        totalCents: totalCents(quantity, sectionOf(sectionId).priceCents),
      };
      orders.push({ order, cancelled: false });
      return { ...order };
    },
    release(holdId) {
      const entry = unendedHold(holdId);
      if (isActive(entry)) {
        entry.ended = true;
      }
    },
    cancelOrder(orderId) {
      const entry = orders.find((o) => o.order.orderId === orderId);
      if (!entry || entry.cancelled) {
        throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      }
      entry.cancelled = true;
      const { totalCents, quantity } = entry.order;
      return Math.max(0, totalCents - CANCELLATION_FEE_CENTS_PER_TICKET * quantity);
    },
    available,
  };
}
