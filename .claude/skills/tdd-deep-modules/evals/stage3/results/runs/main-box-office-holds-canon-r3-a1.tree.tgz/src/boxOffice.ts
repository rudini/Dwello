export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

const GROUP_DISCOUNT_MIN_TICKETS = 4;
const CANCELLATION_FEE_PER_TICKET_CENTS = 200;

/** Price with group discount, rounded to 5 cents (exact halves up). */
function orderTotal(quantity: number, priceCents: number): number {
  // Work in tenths of a cent so the 10 % discount stays an exact integer.
  const percent = quantity >= GROUP_DISCOUNT_MIN_TICKETS ? 90 : 100;
  const tenthCents = (quantity * priceCents * percent) / 10;
  return Math.floor((tenthCents + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  const sections = new Map(options.sections.map((s) => [s.id, s]));

  function section(sectionId: string): SectionConfig {
    const found = sections.get(sectionId);
    if (!found) throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    return found;
  }

  // Holds and orders are never deleted, so the map sizes double as id counters.
  const holds = new Map<string, Hold & { ended: boolean }>();
  const orders = new Map<string, Order & { cancelled: boolean }>();

  /** Everything that currently takes tickets: active holds and orders. */
  function* takenTickets(
    now: number,
  ): Iterable<{ customerId: string; sectionId: string; quantity: number }> {
    for (const hold of holds.values()) {
      if (!hold.ended && now < hold.expiresAt) yield hold;
    }
    for (const order of orders.values()) {
      if (!order.cancelled) yield order;
    }
  }

  /** A hold that was neither confirmed nor released (it may have expired). */
  function openHold(holdId: string) {
    const hold = holds.get(holdId);
    if (!hold || hold.ended) throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    return hold;
  }

  function available(sectionId: string, now: number): number {
    const { capacity } = section(sectionId);
    let taken = 0;
    for (const t of takenTickets(now)) {
      if (t.sectionId === sectionId) taken += t.quantity;
    }
    return capacity - taken;
  }

  function ticketsOf(customerId: string, now: number): number {
    let tickets = 0;
    for (const t of takenTickets(now)) {
      if (t.customerId === customerId) tickets += t.quantity;
    }
    return tickets;
  }

  return {
    hold(customerId, sectionId, quantity) {
      section(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const now = options.now();
      if (ticketsOf(customerId, now) + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError("CUSTOMER_LIMIT", `Customer ${customerId} would exceed the limit`);
      }
      if (quantity > available(sectionId, now)) {
        throw new BoxOfficeError("SOLD_OUT", `Not enough tickets left in ${sectionId}`);
      }
      const hold: Hold = {
        holdId: `H${holds.size + 1}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: now + options.holdMinutes * 60_000,
      };
      holds.set(hold.holdId, { ...hold, ended: false });
      return hold;
    },
    confirm(holdId) {
      const hold = openHold(holdId);
      if (options.now() >= hold.expiresAt) {
        throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      }
      hold.ended = true;
      const order: Order = {
        orderId: `O${orders.size + 1}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: orderTotal(hold.quantity, section(hold.sectionId).priceCents),
      };
      orders.set(order.orderId, { ...order, cancelled: false });
      return order;
    },
    release(holdId) {
      const hold = openHold(holdId);
      // An expired hold already gave its tickets back; releasing it changes nothing.
      if (options.now() < hold.expiresAt) hold.ended = true;
    },
    cancelOrder(orderId) {
      const order = orders.get(orderId);
      if (!order || order.cancelled) {
        throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      }
      order.cancelled = true;
      return Math.max(0, order.totalCents - order.quantity * CANCELLATION_FEE_PER_TICKET_CENTS);
    },
    available: (sectionId) => available(sectionId, options.now()),
  };
}
