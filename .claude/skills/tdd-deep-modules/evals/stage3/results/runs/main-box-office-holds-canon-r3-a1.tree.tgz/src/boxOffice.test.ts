import { describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOfficeOptions } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

function setup(overrides: Partial<BoxOfficeOptions> = {}) {
  const clock = { time: 1_000_000 };
  const office = createBoxOffice({
    sections: [
      { id: "PARKETT", capacity: 10, priceCents: 5000 },
      { id: "BALKON", capacity: 5, priceCents: 3000 },
    ],
    holdMinutes: 15,
    maxTicketsPerCustomer: 6,
    now: () => clock.time,
    ...overrides,
  });
  return { office, clock };
}

function expectCode(fn: () => unknown, code: string) {
  let caught: unknown;
  try {
    fn();
  } catch (e) {
    caught = e;
  }
  expect(caught).toBeInstanceOf(BoxOfficeError);
  expect((caught as BoxOfficeError).code).toBe(code);
}

describe("available", () => {
  test("fresh section returns its capacity", () => {
    const { office } = setup();
    expect(office.available("PARKETT")).toBe(10);
    expect(office.available("BALKON")).toBe(5);
  });

  test("unknown section is rejected", () => {
    const { office } = setup();
    expectCode(() => office.available("LOGE"), "UNKNOWN_SECTION");
  });
});

describe("hold", () => {
  test("returns the hold and takes the tickets", () => {
    const { office } = setup();
    expect(office.hold("alice", "PARKETT", 3)).toEqual({
      holdId: "H1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 3,
      expiresAt: 1_000_000 + 15 * 60_000,
    });
    expect(office.available("PARKETT")).toBe(7);
    expect(office.available("BALKON")).toBe(5);
  });

  test("unknown section is rejected", () => {
    const { office } = setup();
    expectCode(() => office.hold("alice", "LOGE", 1), "UNKNOWN_SECTION");
  });

  test.each([0, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY])(
    "quantity %p is rejected",
    (quantity) => {
      const { office } = setup();
      expectCode(() => office.hold("alice", "PARKETT", quantity), "INVALID_QUANTITY");
      expect(office.available("PARKETT")).toBe(10);
    },
  );

  test("unknown section is checked before quantity", () => {
    const { office } = setup();
    expectCode(() => office.hold("alice", "LOGE", 0), "UNKNOWN_SECTION");
  });

  test("hold ids are sequential and failed attempts do not use up a number", () => {
    const { office } = setup();
    expect(office.hold("alice", "PARKETT", 1).holdId).toBe("H1");
    expectCode(() => office.hold("alice", "PARKETT", 0), "INVALID_QUANTITY");
    expectCode(() => office.hold("alice", "LOGE", 1), "UNKNOWN_SECTION");
    expect(office.hold("bob", "BALKON", 2).holdId).toBe("H2");
  });

  test("more tickets than available is sold out, without a partial hold", () => {
    const { office } = setup();
    office.hold("alice", "BALKON", 3);
    expectCode(() => office.hold("bob", "BALKON", 3), "SOLD_OUT");
    expect(office.available("BALKON")).toBe(2);
    expect(office.hold("bob", "BALKON", 2).holdId).toBe("H2");
    expect(office.available("BALKON")).toBe(0);
  });

  test("customer limit counts held tickets across all sections", () => {
    const { office } = setup();
    office.hold("alice", "PARKETT", 4);
    expectCode(() => office.hold("alice", "BALKON", 3), "CUSTOMER_LIMIT");
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "BALKON", 2).holdId).toBe("H2");
    expect(office.hold("bob", "BALKON", 3).holdId).toBe("H3");
  });

  test("customer limit is checked before availability", () => {
    const { office } = setup();
    office.hold("bob", "BALKON", 5);
    expectCode(() => office.hold("alice", "BALKON", 7), "CUSTOMER_LIMIT");
    expectCode(() => office.hold("alice", "BALKON", 1), "SOLD_OUT");
  });

  test("quantity is checked before customer limit", () => {
    const { office } = setup({ maxTicketsPerCustomer: 1 });
    office.hold("alice", "BALKON", 1);
    expectCode(() => office.hold("alice", "BALKON", 0), "INVALID_QUANTITY");
  });
});

describe("expiry", () => {
  test("a hold stops counting as soon as now() reaches expiresAt", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "BALKON", 5);
    clock.time = hold.expiresAt - 1;
    expect(office.available("BALKON")).toBe(0);
    expectCode(() => office.hold("alice", "PARKETT", 2), "CUSTOMER_LIMIT");
    clock.time = hold.expiresAt;
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).expiresAt).toBe(hold.expiresAt + 15 * 60_000);
  });
});

describe("confirm", () => {
  test("turns the hold into an order whose tickets stay taken, even after the hold's expiry", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    expect(office.confirm(hold.holdId)).toEqual({
      orderId: "O1",
      customerId: "alice",
      sectionId: "PARKETT",
      quantity: 2,
      totalCents: 10_000,
    });
    clock.time = hold.expiresAt + 1;
    expect(office.available("PARKETT")).toBe(8);
    expectCode(() => office.hold("alice", "BALKON", 5), "CUSTOMER_LIMIT");
  });

  test("order ids are sequential", () => {
    const { office } = setup();
    const h1 = office.hold("alice", "PARKETT", 1);
    const h2 = office.hold("bob", "PARKETT", 1);
    expect(office.confirm(h2.holdId).orderId).toBe("O1");
    expect(office.confirm(h1.holdId).orderId).toBe("O2");
  });

  test.each([
    // [quantity, priceCents, totalCents]
    [1, 1000, 1000], // exact, no discount
    [1, 1003, 1005], // rounded up without discount
    [3, 1002, 3005], // 3006 rounded down without discount
    [4, 5000, 18_000], // 10 % group discount from 4 tickets
    [4, 1001, 3605], // 3603.6 rounded up
    [4, 999, 3595], // 3596.4 rounded down
    [5, 1005, 4525], // 4522.5 is an exact half and rounds up
  ])("%p tickets at %p cents cost %p cents", (quantity, priceCents, totalCents) => {
    const { office } = setup({
      sections: [{ id: "S", capacity: 10, priceCents }],
      maxTicketsPerCustomer: 10,
    });
    const hold = office.hold("alice", "S", quantity);
    expect(office.confirm(hold.holdId).totalCents).toBe(totalCents);
  });

  test("unknown or already confirmed holds are rejected", () => {
    const { office } = setup();
    expectCode(() => office.confirm("H1"), "UNKNOWN_HOLD");
    const hold = office.hold("alice", "PARKETT", 2);
    office.confirm(hold.holdId);
    expectCode(() => office.confirm(hold.holdId), "UNKNOWN_HOLD");
    expect(office.available("PARKETT")).toBe(8);
  });

  test("an expired hold cannot be confirmed and no order number is used up", () => {
    const { office, clock } = setup();
    const expiring = office.hold("alice", "PARKETT", 2);
    clock.time = expiring.expiresAt;
    expectCode(() => office.confirm(expiring.holdId), "HOLD_EXPIRED");
    expect(office.available("PARKETT")).toBe(10);
    expectCode(() => office.confirm(expiring.holdId), "HOLD_EXPIRED");
    const fresh = office.hold("alice", "PARKETT", 1);
    expect(office.confirm(fresh.holdId).orderId).toBe("O1");
  });
});

describe("release", () => {
  test("frees the tickets and the customer's allowance", () => {
    const { office } = setup();
    const hold = office.hold("alice", "BALKON", 5);
    office.release(hold.holdId);
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
  });

  test("unknown, released or confirmed holds are rejected", () => {
    const { office } = setup();
    expectCode(() => office.release("H1"), "UNKNOWN_HOLD");
    const released = office.hold("alice", "PARKETT", 1);
    office.release(released.holdId);
    expectCode(() => office.release(released.holdId), "UNKNOWN_HOLD");
    expectCode(() => office.confirm(released.holdId), "UNKNOWN_HOLD");
    const confirmed = office.hold("alice", "PARKETT", 2);
    office.confirm(confirmed.holdId);
    expectCode(() => office.release(confirmed.holdId), "UNKNOWN_HOLD");
    expect(office.available("PARKETT")).toBe(8);
  });

  test("releasing an expired hold succeeds without effect", () => {
    const { office, clock } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    clock.time = hold.expiresAt;
    office.release(hold.holdId);
    office.release(hold.holdId);
    expectCode(() => office.confirm(hold.holdId), "HOLD_EXPIRED");
    expect(office.available("PARKETT")).toBe(10);
  });
});

describe("returned objects", () => {
  test("mutating them does not change the box office", () => {
    const { office } = setup();
    const hold = office.hold("alice", "PARKETT", 2);
    hold.quantity = 1;
    hold.expiresAt = 0;
    expect(office.available("PARKETT")).toBe(8);
    const order = office.confirm(hold.holdId);
    order.totalCents = 1_000_000;
    order.quantity = 10;
    expect(office.available("PARKETT")).toBe(8);
    expect(office.cancelOrder(order.orderId)).toBe(10_000 - 2 * 200);
  });
});

describe("cancelOrder", () => {
  test("refunds the total minus 200 cents per ticket and frees tickets and allowance", () => {
    const { office } = setup();
    const order = office.confirm(office.hold("alice", "BALKON", 5).holdId); // 13_500
    expect(office.cancelOrder(order.orderId)).toBe(13_500 - 5 * 200);
    expect(office.available("BALKON")).toBe(5);
    expect(office.hold("alice", "PARKETT", 6).holdId).toBe("H2");
  });

  test("the refund is never negative", () => {
    const { office } = setup({ sections: [{ id: "S", capacity: 10, priceCents: 150 }] });
    const order = office.confirm(office.hold("alice", "S", 2).holdId); // 300
    expect(office.cancelOrder(order.orderId)).toBe(0);
  });

  test("unknown or already cancelled orders are rejected", () => {
    const { office } = setup();
    expectCode(() => office.cancelOrder("O1"), "UNKNOWN_ORDER");
    const order = office.confirm(office.hold("alice", "PARKETT", 2).holdId);
    office.cancelOrder(order.orderId);
    expectCode(() => office.cancelOrder(order.orderId), "UNKNOWN_ORDER");
    expect(office.available("PARKETT")).toBe(10);
    expect(office.confirm(office.hold("bob", "PARKETT", 1).holdId).orderId).toBe("O2");
  });
});
