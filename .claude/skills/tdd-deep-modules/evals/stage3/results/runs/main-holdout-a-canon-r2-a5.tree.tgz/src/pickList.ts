export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  line: number;
  items: { sku: string; qty: number }[];
}

/**
 * Whether an order is empty only becomes known after later lines, so the scan
 * keeps going after a problem and the topmost problem is thrown at the end.
 */
function parseOrders(text: string): Order[] {
  const orders: Order[] = [];
  const problems: OrderFormatError[] = [];
  let current: Order | undefined;
  const lines = text.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const lineNo = index + 1;
    const line = lines[index].trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = /^ORDER +([A-Za-z0-9-]+)( +!)?$/.exec(line);
    if (orderMatch) {
      const id = orderMatch[1];
      current = { id, priority: orderMatch[2] !== undefined, line: lineNo, items: [] };
      if (orders.some((o) => o.id === id)) {
        problems.push(new OrderFormatError(lineNo, `order id "${id}" already used`));
      }
      orders.push(current);
      continue;
    }
    const itemMatch = /^([A-Z0-9-]+) +x([1-9][0-9]*)$/.exec(line);
    if (!itemMatch) {
      problems.push(new OrderFormatError(lineNo, `expected "ORDER <id>" or "<sku> x<qty>", got "${line}"`));
      continue;
    }
    if (!current) {
      problems.push(new OrderFormatError(lineNo, "item line before the first ORDER"));
      continue;
    }
    const sku = itemMatch[1];
    const qty = Number(itemMatch[2]);
    const existing = current.items.find((i) => i.sku === sku);
    if (existing) existing.qty += qty;
    else current.items.push({ sku, qty });
  }
  for (const order of orders) {
    if (order.items.length === 0) {
      problems.push(new OrderFormatError(order.line, `order "${order.id}" has no items`));
    }
  }
  if (problems.length > 0) {
    throw problems.reduce((first, p) => (p.line < first.line ? p : first));
  }
  return orders;
}

/** Sorts after every "YYYY-MM-DD" date. */
const NEVER = "9999-99-99";

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const lots = stock
    .map((l) => ({ bin: l.bin, sku: l.sku, expires: l.expires, left: l.qty }))
    .sort((a, b) => compareStrings(a.expires ?? NEVER, b.expires ?? NEVER) || compareStrings(a.bin, b.bin));
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const orders = parseOrders(ordersText);
  const serving = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of serving) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const source of lots) {
        if (needed === 0) break;
        if (source.sku !== item.sku || source.left === 0) continue;
        const taken = Math.min(needed, source.left);
        source.left -= taken;
        needed -= taken;
        picks.push({ bin: source.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}

/**
 * Serpentine walk: visited aisles alphabetically, racks ascending in the 1st,
 * 3rd, ... visited aisle and descending in the others, levels ascending.
 * The sort is stable, so picks at the same bin keep their allocation order.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const location = (bin: string) => {
    const [aisle, rack, level] = bin.split("-");
    return { aisle, rack: Number(rack), level: Number(level) };
  };
  const aisles = [...new Set(picks.map((p) => location(p.bin).aisle))].sort(compareStrings);
  return [...picks].sort((p, q) => {
    const a = location(p.bin);
    const b = location(q.bin);
    if (a.aisle !== b.aisle) return compareStrings(a.aisle, b.aisle);
    const direction = aisles.indexOf(a.aisle) % 2 === 0 ? 1 : -1;
    return (a.rack - b.rack) * direction || a.level - b.level;
  });
}
