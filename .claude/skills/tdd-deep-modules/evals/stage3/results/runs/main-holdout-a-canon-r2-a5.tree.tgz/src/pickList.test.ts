import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("empty orders text gives an empty pick list", () => {
  expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
});

test("a single item is picked from its lot", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("comments and blank lines are ignored", () => {
  const text = "# export 2026-10-12 06:00\n\nORDER 1001\n   \n  # note\n  OLIVE-500 x3\n";
  expect(buildPickList(text, [lot("A-01-1", "OLIVE-500", 10)]).picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
  ]);
});

test("an item takes from the earliest expiring lots first, one pick per lot", () => {
  const stock = [
    lot("A-02-1", "OLIVE-500", 4, "2026-12-01"),
    lot("B-01-1", "PASTA-1KG", 9, "2026-10-20"),
    lot("A-01-1", "OLIVE-500", 3, "2026-11-01"),
  ];
  expect(buildPickList("ORDER 1001\nOLIVE-500 x5", stock).picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    { bin: "A-02-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("undated lots come after dated ones and ties are broken by bin", () => {
  const stock = [
    lot("A-02-1", "SALT", 5, null),
    lot("A-01-2", "SALT", 2, "2027-01-01"),
    lot("A-01-1", "SALT", 2, "2027-01-01"),
  ];
  expect(buildPickList("ORDER 1\nSALT x5", stock).picks).toEqual([
    { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "1" },
    { bin: "A-01-2", sku: "SALT", qty: 2, orderId: "1" },
    { bin: "A-02-1", sku: "SALT", qty: 1, orderId: "1" },
  ]);
});

test("missing stock is still picked as far as possible and reported as shortage", () => {
  const text = "ORDER 1\nSALT x5\nSUGAR x2\nOIL x1";
  const stock = [lot("A-01-1", "SALT", 3), lot("A-01-2", "SUGAR", 0), lot("A-01-3", "OIL", 1)];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-01-1", sku: "SALT", qty: 3, orderId: "1" },
      { bin: "A-01-3", sku: "OIL", qty: 1, orderId: "1" },
    ],
    shortages: [
      { orderId: "1", sku: "SALT", missing: 2 },
      { orderId: "1", sku: "SUGAR", missing: 2 },
    ],
  });
});

test("stock taken by an earlier order is not available to later ones", () => {
  const text = "ORDER 1\nSALT x2\nORDER 2\nSALT x2";
  expect(buildPickList(text, [lot("A-01-1", "SALT", 3)])).toEqual({
    picks: [
      { bin: "A-01-1", sku: "SALT", qty: 2, orderId: "1" },
      { bin: "A-01-1", sku: "SALT", qty: 1, orderId: "2" },
    ],
    shortages: [{ orderId: "2", sku: "SALT", missing: 1 }],
  });
});

test("priority orders are served first, each group in text order", () => {
  const text = "ORDER 1\nSALT x1\nORDER 2 !\nSALT x1\nORDER 3\nSALT x1\nORDER 4   !\nSALT x1";
  const result = buildPickList(text, [lot("A-01-1", "SALT", 2)]);
  expect(result.picks.map((p) => p.orderId)).toEqual(["2", "4"]);
  expect(result.shortages.map((s) => s.orderId)).toEqual(["1", "3"]);
});

test("a repeated SKU in an order is summed and keeps its first position", () => {
  const text = "ORDER 1\nSALT x2\nSUGAR x1\nSALT x3";
  const result = buildPickList(text, [lot("A-01-1", "SALT", 1), lot("A-01-2", "SUGAR", 0)]);
  expect(result.picks).toEqual([{ bin: "A-01-1", sku: "SALT", qty: 1, orderId: "1" }]);
  expect(result.shortages).toEqual([
    { orderId: "1", sku: "SALT", missing: 4 },
    { orderId: "1", sku: "SUGAR", missing: 1 },
  ]);
});

function errorLine(text: string): number | undefined {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  return undefined;
}

test.each(["SALT x0", "SALT x03", "salt x1", "SALT 3", "SALTx3", "SALT x", "SALT x-1", "SALT x1.5", "ORDER", "ORDER 2!", "ORDER a_b"])(
  "an unrecognised line %p is reported with its line number",
  (bad) => {
    expect(errorLine(`# header\nORDER 1\n  SALT x1\n\n  ${bad}\nSUGAR x1`)).toBe(5);
  },
);

test("an item line before the first ORDER is reported", () => {
  expect(errorLine("# header\n\nSALT x1\nORDER 1\nSALT x1")).toBe(3);
});

test("a reused order id is reported at the second ORDER line", () => {
  expect(errorLine("ORDER 1\nSALT x1\nORDER 2\nSALT x1\nORDER 1 !\nSALT x1")).toBe(5);
});

test("an ORDER without items is reported at its ORDER line", () => {
  expect(errorLine("ORDER 1\nSALT x1\nORDER 2\n# nothing\n\nORDER 3\nSALT x1")).toBe(3);
  expect(errorLine("ORDER 1\nSALT x1\nORDER 2 !\n# nothing\n")).toBe(3);
});

test("the first problem from the top is reported", () => {
  expect(errorLine("ORDER 1\nORDER 1\nSALT x1")).toBe(1);
  expect(errorLine("ORDER 1\nsalt x1\nORDER 2\nSALT x1")).toBe(1);
  expect(errorLine("ORDER 1\nsalt x1\nSALT x1\nORDER 1\nSALT x1")).toBe(2);
  expect(errorLine("ORDER 1\nSALT x1\nORDER 1\nSALT x0")).toBe(3);
});

test("picks follow the serpentine walk through the visited aisles", () => {
  const stock = [
    lot("E-02-1", "S1", 1),
    lot("C-01-1", "S2", 1),
    lot("A-10-1", "S3", 1),
    lot("C-12-1", "S4", 1),
    lot("A-02-3", "S5", 1),
    lot("A-02-1", "S6", 1),
    lot("C-12-2", "S7", 1),
    lot("E-01-2", "S8", 1),
  ];
  const text = "ORDER 1\nS1 x1\nS2 x1\nS3 x1\nS4 x1\nS5 x1\nS6 x1\nS7 x1\nS8 x1";
  expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual([
    "A-02-1",
    "A-02-3",
    "A-10-1",
    "C-12-1",
    "C-12-2",
    "C-01-1",
    "E-01-2",
    "E-02-1",
  ]);
});

test("picks at the same bin keep their allocation order", () => {
  const text = "ORDER 1\nSALT x1\nORDER 2 !\nSALT x1\nORDER 3\nSUGAR x1\nSALT x1";
  const stock = [lot("B-01-1", "SALT", 5), lot("A-01-1", "SUGAR", 5)];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-1", sku: "SUGAR", qty: 1, orderId: "3" },
    { bin: "B-01-1", sku: "SALT", qty: 1, orderId: "2" },
    { bin: "B-01-1", sku: "SALT", qty: 1, orderId: "1" },
    { bin: "B-01-1", sku: "SALT", qty: 1, orderId: "3" },
  ]);
});

test("the morning export example", () => {
  const text = "# export 2026-10-12 06:00\r\nORDER 1001\r\n  OLIVE-500 x3\r\n  PASTA-1KG x1\r\nORDER 1002 !\r\n  OLIVE-500 x2\r\n";
  const stock = [
    lot("B-04-1", "OLIVE-500", 3, "2027-03-01"),
    lot("A-01-2", "OLIVE-500", 1, "2026-11-15"),
    lot("B-01-3", "PASTA-1KG", 5, null),
  ];
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-01-2", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-04-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      { bin: "B-04-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "B-01-3", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 1 }],
  });
});

test("the stock array and its lots are left untouched", () => {
  const stock = [lot("A-01-2", "SALT", 3, null), lot("A-01-1", "SALT", 1, "2027-01-01")];
  const before = structuredClone(stock);
  const objects = [...stock];
  buildPickList("ORDER 1\nSALT x4", stock);
  expect(stock).toEqual(before);
  expect(stock[0]).toBe(objects[0]);
  expect(stock[1]).toBe(objects[1]);
});
