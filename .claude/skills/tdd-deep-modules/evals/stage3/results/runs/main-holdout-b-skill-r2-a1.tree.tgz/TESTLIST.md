# Team board: test list

**Hidden decision:** how a card's position, blocking and history are recorded and turned
into cycle time (a per-card timeline of column arrivals and blocked intervals, clipped to
the start..finish window). Callers never see the timeline.

**Sketch A — stateful object (the given `Board` interface):**
`const board = createBoard({ columns, now }); board.move("C1", "Doing"); board.cycleTime("C1")`

**Sketch B — pure reducer over commands:**
`const next = apply(state, { type: "move", card: "C1", to: "Doing", at: now })`,
`cycleTime(state, "C1")`; the caller holds state and passes time.

**Chosen:** A, because the caller never handles board state or timestamps; time and
history stay behind one object with six verbs, while B leaks the state shape and the
clock into every call site.

## Behaviours (through `createBoard`)

- [x] addCard returns "C1" and the card is in the first column
- [x] ids count up and cardsIn lists cards in arrival order
- [x] a blank title throws EMPTY_TITLE and consumes no id
- [x] addCard into a full first column throws WIP_LIMIT
- [x] cardsIn of an unknown column throws UNKNOWN_COLUMN
- [x] move forward one column puts the card at the end of the target
- [x] move of an unknown card throws UNKNOWN_CARD (before an unknown column)
- [x] move to an unknown column throws UNKNOWN_COLUMN
- [x] move to the card's own column throws SAME_COLUMN
- [x] move of a blocked card throws BLOCKED (before SKIP_NOT_ALLOWED)
- [x] moving forward by two columns throws SKIP_NOT_ALLOWED
- [x] moving backwards by several columns is allowed
- [x] move into a full column throws WIP_LIMIT; blocked cards count
- [x] block: UNKNOWN_CARD, ALREADY_BLOCKED
- [x] unblock: UNKNOWN_CARD, NOT_BLOCKED; an unblocked card can move again
- [x] cycleTime: UNKNOWN_CARD; null unless the card is in the last column
- [x] totalMs runs from first leaving the first column to arriving in the last
- [x] start survives trips back to the first column; finish is the latest arrival in the last column
- [x] blockedMs sums blocked intervals inside start..finish
- [x] blocked time before start or after finish is not counted
