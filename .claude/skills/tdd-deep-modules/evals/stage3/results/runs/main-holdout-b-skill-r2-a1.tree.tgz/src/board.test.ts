import { expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode, type ColumnConfig } from "./board";

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

const standardColumns: ColumnConfig[] = [
  { name: "Backlog" },
  { name: "Doing" },
  { name: "Review" },
  { name: "Done" },
];

function setup(columns: ColumnConfig[] = standardColumns) {
  const clock = { time: 1_000 };
  const board = createBoard({ columns, now: () => clock.time });
  return { board, clock };
}

function codeOf(action: () => unknown): BoardErrorCode | "no error" | "other error" {
  try {
    action();
  } catch (error) {
    return error instanceof BoardError ? error.code : "other error";
  }
  return "no error";
}

test("addCard returns C1 and the card is in the first column", () => {
  let id: string | undefined;
  let backlog: string[] = [];
  try {
    const { board } = setup();
    id = board.addCard("Fix login");
    backlog = board.cardsIn("Backlog");
  } catch {}
  expect(id).toBe("C1");
  expect(backlog).toEqual(["C1"]);
});

test("a blank title throws EMPTY_TITLE and consumes no id", () => {
  const { board } = setup();
  expect(codeOf(() => board.addCard("   "))).toBe("EMPTY_TITLE");
  expect(board.addCard("First")).toBe("C1");
  expect(board.addCard("Second")).toBe("C2");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("addCard into a full first column throws WIP_LIMIT", () => {
  const { board } = setup([{ name: "Inbox", wipLimit: 1 }, { name: "Done" }]);
  board.addCard("First");
  expect(codeOf(() => board.addCard("Second"))).toBe("WIP_LIMIT");
  expect(board.cardsIn("Inbox")).toEqual(["C1"]);
});

test("cardsIn of an unknown column throws UNKNOWN_COLUMN", () => {
  const { board } = setup();
  expect(codeOf(() => board.cardsIn("Archive"))).toBe("UNKNOWN_COLUMN");
});

test("move forward one column puts the card at the end of the target", () => {
  const { board } = setup();
  board.addCard("First");
  board.addCard("Second");
  board.move("C2", "Doing");
  board.move("C1", "Doing");
  expect(board.cardsIn("Backlog")).toEqual([]);
  expect(board.cardsIn("Doing")).toEqual(["C2", "C1"]);
});

test("move of an unknown card throws UNKNOWN_CARD, even to an unknown column", () => {
  const { board } = setup();
  expect(codeOf(() => board.move("C9", "Doing"))).toBe("UNKNOWN_CARD");
  expect(codeOf(() => board.move("C9", "Archive"))).toBe("UNKNOWN_CARD");
});

test("move to an unknown column throws UNKNOWN_COLUMN and leaves the card in place", () => {
  const { board } = setup();
  board.addCard("First");
  expect(codeOf(() => board.move("C1", "Archive"))).toBe("UNKNOWN_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("move to the card's own column throws SAME_COLUMN and keeps its position", () => {
  const { board } = setup();
  board.addCard("First");
  board.addCard("Second");
  expect(codeOf(() => board.move("C1", "Backlog"))).toBe("SAME_COLUMN");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
});

test("move of a blocked card throws BLOCKED, even when it would also skip", () => {
  const { board } = setup();
  board.addCard("First");
  board.block("C1", "waiting for customer");
  expect(codeOf(() => board.move("C1", "Doing"))).toBe("BLOCKED");
  expect(codeOf(() => board.move("C1", "Review"))).toBe("BLOCKED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("moving forward by two columns throws SKIP_NOT_ALLOWED", () => {
  const { board } = setup();
  board.addCard("First");
  expect(codeOf(() => board.move("C1", "Review"))).toBe("SKIP_NOT_ALLOWED");
  expect(codeOf(() => board.move("C1", "Done"))).toBe("SKIP_NOT_ALLOWED");
  expect(board.cardsIn("Backlog")).toEqual(["C1"]);
});

test("move into a full column throws WIP_LIMIT; blocked cards count, backwards moves are free", () => {
  const { board } = setup([
    { name: "Backlog" },
    { name: "Doing" },
    { name: "Review", wipLimit: 1 },
    { name: "Done" },
  ]);
  board.addCard("First");
  board.addCard("Second");
  board.move("C1", "Doing");
  board.move("C1", "Review");
  board.move("C1", "Done");
  board.move("C1", "Backlog");
  board.move("C2", "Doing");
  board.move("C2", "Review");
  board.block("C2", "needs a second reviewer");
  board.move("C1", "Doing");
  expect(codeOf(() => board.move("C1", "Review"))).toBe("WIP_LIMIT");
  expect(board.cardsIn("Doing")).toEqual(["C1"]);
  expect(board.cardsIn("Review")).toEqual(["C2"]);
});

test("block throws UNKNOWN_CARD for an unknown card and ALREADY_BLOCKED twice", () => {
  const { board } = setup();
  board.addCard("First");
  expect(codeOf(() => board.block("C9", "?"))).toBe("UNKNOWN_CARD");
  board.block("C1", "waiting");
  expect(codeOf(() => board.block("C1", "still waiting"))).toBe("ALREADY_BLOCKED");
});

test("unblock rejects unknown and unblocked cards, and an unblocked card can move again", () => {
  const { board } = setup();
  board.addCard("First");
  expect(codeOf(() => board.unblock("C9"))).toBe("UNKNOWN_CARD");
  expect(codeOf(() => board.unblock("C1"))).toBe("NOT_BLOCKED");
  board.block("C1", "waiting");
  board.unblock("C1");
  board.move("C1", "Doing");
  expect(board.cardsIn("Doing")).toEqual(["C1"]);
});

test("cycleTime throws UNKNOWN_CARD for an unknown card and is null outside the last column", () => {
  const { board } = setup();
  board.addCard("First");
  expect(codeOf(() => board.cycleTime("C9"))).toBe("UNKNOWN_CARD");
  expect(board.cycleTime("C1")).toBeNull();
  board.move("C1", "Doing");
  expect(board.cycleTime("C1")).toBeNull();
});

test("totalMs runs from leaving the first column to arriving in the last", () => {
  const { board, clock } = setup();
  board.addCard("First");
  clock.time = 1_500;
  board.move("C1", "Doing");
  clock.time = 2_500;
  board.move("C1", "Review");
  clock.time = 4_000;
  board.move("C1", "Done");
  clock.time = 9_000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 2_500, blockedMs: 0 });
});

test("blockedMs sums the blocked intervals between start and finish", () => {
  const { board, clock } = setup();
  board.addCard("First");
  clock.time = 1_500;
  board.move("C1", "Doing");
  clock.time = 2_000;
  board.block("C1", "waiting for customer");
  clock.time = 2_600;
  board.unblock("C1");
  clock.time = 3_000;
  board.move("C1", "Review");
  clock.time = 3_100;
  board.block("C1", "reviewer away");
  clock.time = 3_200;
  board.unblock("C1");
  clock.time = 4_000;
  board.move("C1", "Done");
  expect(board.cycleTime("C1")).toEqual({ totalMs: 2_500, blockedMs: 700 });
});

test("blocked time outside first start..latest finish is not counted, across trips back", () => {
  const { board, clock } = setup();
  board.addCard("First");
  clock.time = 1_200;
  board.block("C1", "not ready");
  clock.time = 1_700;
  board.unblock("C1");
  clock.time = 2_000;
  board.move("C1", "Doing");
  clock.time = 3_000;
  board.move("C1", "Review");
  clock.time = 4_000;
  board.move("C1", "Done");
  clock.time = 4_200;
  board.block("C1", "bug found");
  clock.time = 4_400;
  board.unblock("C1");
  clock.time = 5_000;
  board.move("C1", "Backlog");
  expect(board.cycleTime("C1")).toBeNull();
  clock.time = 5_500;
  board.block("C1", "needs triage");
  clock.time = 6_000;
  board.unblock("C1");
  clock.time = 7_000;
  board.move("C1", "Doing");
  clock.time = 8_000;
  board.move("C1", "Review");
  clock.time = 9_000;
  board.move("C1", "Done");
  clock.time = 9_200;
  board.block("C1", "closed after finish");
  clock.time = 9_400;
  board.unblock("C1");
  clock.time = 9_500;
  board.block("C1", "open after finish");
  clock.time = 10_000;
  expect(board.cycleTime("C1")).toEqual({ totalMs: 7_000, blockedMs: 700 });
});
