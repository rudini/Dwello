export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Column {
  name: string;
  index: number;
  wipLimit: number | undefined;
  cards: string[];
}

interface Card {
  column: Column;
  /** Blocked periods in order; only the last one can still be open. */
  blocks: { from: number; to?: number }[];
  /** First departure from the first column. */
  startedAt?: number;
  /** Latest arrival in the last column. */
  finishedAt?: number;
}

function isBlocked(card: Card): boolean {
  const last = card.blocks.at(-1);
  return last !== undefined && last.to === undefined;
}

/** Blocked time within [started, finished]; a still-open block runs until finished. */
function blockedWithin(card: Card, started: number, finished: number): number {
  let total = 0;
  for (const block of card.blocks) {
    const from = Math.max(block.from, started);
    const to = Math.min(block.to ?? finished, finished);
    if (to > from) total += to - from;
  }
  return total;
}

function assertRoom(column: Column): void {
  if (column.wipLimit !== undefined && column.cards.length >= column.wipLimit) {
    throw new BoardError("WIP_LIMIT", `Column ${column.name} is full`);
  }
}

export function createBoard(options: BoardOptions): Board {
  const columns = options.columns.map(
    ({ name, wipLimit }, index): Column => ({ name, index, wipLimit, cards: [] }),
  );
  const columnsByName = new Map(columns.map((column) => [column.name, column]));
  const cards = new Map<string, Card>();
  let nextId = 1;

  function column(name: string): Column {
    const found = columnsByName.get(name);
    if (!found) throw new BoardError("UNKNOWN_COLUMN", `No column ${name}`);
    return found;
  }

  function card(id: string): Card {
    const found = cards.get(id);
    if (!found) throw new BoardError("UNKNOWN_CARD", `No card ${id}`);
    return found;
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Title must not be empty");
      const first = columns[0]!;
      assertRoom(first);
      const id = `C${nextId++}`;
      first.cards.push(id);
      cards.set(id, { column: first, blocks: [] });
      return id;
    },
    move(cardId, toColumn) {
      const moving = card(cardId);
      const from = moving.column;
      const to = column(toColumn);
      if (from === to) throw new BoardError("SAME_COLUMN", `${cardId} is already in ${toColumn}`);
      if (isBlocked(moving)) throw new BoardError("BLOCKED", `${cardId} is blocked`);
      if (to.index > from.index + 1) {
        throw new BoardError("SKIP_NOT_ALLOWED", `${cardId} cannot skip columns`);
      }
      assertRoom(to);
      from.cards.splice(from.cards.indexOf(cardId), 1);
      to.cards.push(cardId);
      moving.column = to;
      const now = options.now();
      if (moving.startedAt === undefined) moving.startedAt = now;
      if (to === columns.at(-1)) moving.finishedAt = now;
    },
    block(cardId) {
      const blocking = card(cardId);
      if (isBlocked(blocking)) throw new BoardError("ALREADY_BLOCKED", `${cardId} is already blocked`);
      blocking.blocks.push({ from: options.now() });
    },
    unblock(cardId) {
      const unblocking = card(cardId);
      if (!isBlocked(unblocking)) throw new BoardError("NOT_BLOCKED", `${cardId} is not blocked`);
      unblocking.blocks.at(-1)!.to = options.now();
    },
    cardsIn(name) {
      return [...column(name).cards];
    },
    cycleTime(cardId) {
      const measured = card(cardId);
      if (measured.column !== columns.at(-1)) return null;
      const started = measured.startedAt!;
      const finished = measured.finishedAt!;
      return { totalMs: finished - started, blockedMs: blockedWithin(measured, started, finished) };
    },
  };
}
