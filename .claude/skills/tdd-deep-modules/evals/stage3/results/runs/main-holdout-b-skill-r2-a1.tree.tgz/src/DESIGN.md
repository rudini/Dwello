# Board: design note

**Hidden decision:** how a card's position, blocking and history are recorded and turned
into cycle time. Each card keeps its column, its blocked periods, its first departure from
the first column and its latest arrival in the last column; `cycleTime` clips the blocked
periods to that window. Callers never see any of it.

**Both designs**

- A — stateful object: `const board = createBoard({ columns, now }); board.move("C1", "Doing"); board.cycleTime("C1")`.
- B — pure reducer: `apply(state, { type: "move", card: "C1", to: "Doing", at })` plus `cycleTime(state, id)`.

Chosen: A, because the caller never handles board state or timestamps; B leaks the state
shape and the clock into every call site.

**Interface** (`src/board.ts`)

- `createBoard({ columns, now })` — columns in board order; `now()` is read whenever time matters.
- `addCard(title)` — new card at the end of the first column; ids `C1`, `C2`, … for successful adds only.
- `move(id, column)` — checks UNKNOWN_CARD, UNKNOWN_COLUMN, SAME_COLUMN, BLOCKED, SKIP_NOT_ALLOWED, WIP_LIMIT in that order; card goes to the end of the target.
- `block(id, reason)` / `unblock(id)` — toggle the blocked state (ALREADY_BLOCKED / NOT_BLOCKED).
- `cardsIn(column)` — ids in arrival order.
- `cycleTime(id)` — `null` unless in the last column; else `{ totalMs, blockedMs }` over first start..latest finish.
- Every failure throws `BoardError` with its code before any state changes.

**Depth** — `depth_report src/board.ts`:
`surface 10, size 134, ratio 13.4, classitis no, pass-through 0, tests 1, unused 0, duplicate 2 -> deep`.
Refactors merged the two WIP checks into `assertRoom`, replaced parallel maps/sets with
column and card records, and derived "blocked" from the list of block periods instead of
keeping a flag, a start time and a running total in sync. Helpers stay private.

**Open points**

- The block `reason` is accepted but not stored or exposed; nothing in the spec reads it.
- `wipLimit` values are trusted (no validation of negative or fractional limits), as are
  duplicate column names and boards with fewer than two columns.
- "Ids count up" and "backwards moves are allowed" passed as soon as earlier behaviour
  existed, so they are asserted inside other tests (EMPTY_TITLE, WIP_LIMIT) rather than in
  their own cycles; likewise "start survives trips back" is covered by the clipping test.

**Proof:** `scripts/tdd_replay 5c930f1..HEAD` printed `REPLAY: ACCEPT` (phase order, test
counts and exit codes; not assertion strength).
