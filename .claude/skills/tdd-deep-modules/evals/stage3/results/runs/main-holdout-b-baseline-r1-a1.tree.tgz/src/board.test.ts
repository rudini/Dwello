import { expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode } from "./board";

function setup(wip: Record<string, number> = {}) {
  let time = 0;
  const board = createBoard({
    columns: ["Backlog", "Doing", "Review", "Done"].map((name) => ({ name, wipLimit: wip[name] })),
    now: () => time,
  });
  return { board, at: (t: number) => { time = t; } };
}

function expectCode(fn: () => unknown, code: BoardErrorCode) {
  try {
    fn();
  } catch (e) {
    expect(e).toBeInstanceOf(BoardError);
    expect((e as BoardError).code).toBe(code);
    return;
  }
  throw new Error(`expected ${code}`);
}

test("adding cards", () => {
  const { board } = setup({ Backlog: 2 });
  expectCode(() => board.addCard("  "), "EMPTY_TITLE");
  expect(board.addCard("a")).toBe("C1");
  expect(board.addCard("b")).toBe("C2");
  expectCode(() => board.addCard("c"), "WIP_LIMIT");
  expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
  expectCode(() => board.cardsIn("Nope"), "UNKNOWN_COLUMN");
});

test("move checks in order", () => {
  const { board } = setup({ Doing: 1 });
  const a = board.addCard("a");
  const b = board.addCard("b");
  expectCode(() => board.move("C9", "Nope"), "UNKNOWN_CARD");
  expectCode(() => board.move(a, "Nope"), "UNKNOWN_COLUMN");
  expectCode(() => board.move(a, "Backlog"), "SAME_COLUMN");
  board.block(a, "x");
  expectCode(() => board.move(a, "Review"), "BLOCKED");
  board.unblock(a);
  expectCode(() => board.move(a, "Review"), "SKIP_NOT_ALLOWED");
  board.move(a, "Doing");
  expectCode(() => board.move(b, "Doing"), "WIP_LIMIT");
  board.move(a, "Review");
  board.move(a, "Done");
  board.move(b, "Doing");
  expectCode(() => board.move(a, "Doing"), "WIP_LIMIT");
  board.move(a, "Backlog");
  expect(board.cardsIn("Backlog")).toEqual([a]);
  expect(board.cardsIn("Doing")).toEqual([b]);
});

test("block and unblock errors", () => {
  const { board } = setup();
  const a = board.addCard("a");
  expectCode(() => board.block("C2", "x"), "UNKNOWN_CARD");
  expectCode(() => board.unblock("C2"), "UNKNOWN_CARD");
  expectCode(() => board.unblock(a), "NOT_BLOCKED");
  board.block(a, "x");
  expectCode(() => board.block(a, "y"), "ALREADY_BLOCKED");
});

test("cycle time", () => {
  const { board, at } = setup();
  const a = board.addCard("a");
  expectCode(() => board.cycleTime("C5"), "UNKNOWN_CARD");
  expect(board.cycleTime(a)).toBeNull();
  at(10); board.block(a, "x");
  at(20); board.unblock(a);
  at(100); board.move(a, "Doing");
  at(150); board.block(a, "x");
  at(170); board.unblock(a);
  at(200); board.move(a, "Backlog");
  at(300); board.move(a, "Doing");
  board.move(a, "Review");
  at(400); board.move(a, "Done");
  expect(board.cycleTime(a)).toEqual({ totalMs: 300, blockedMs: 20 });
  at(500); board.block(a, "x");
  at(600); expect(board.cycleTime(a)).toEqual({ totalMs: 300, blockedMs: 20 });
  board.unblock(a);
  board.move(a, "Review");
  expect(board.cycleTime(a)).toBeNull();
  at(700); board.move(a, "Done");
  expect(board.cycleTime(a)).toEqual({ totalMs: 600, blockedMs: 120 });
});

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});
