export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface Card {
  column: number;
  blocked: boolean;
  /** Blocked intervals; `end` is null while the card is still blocked. */
  blocks: { start: number; end: number | null }[];
  startedAt: number | null;
  finishedAt: number | null;
}

export function createBoard(options: BoardOptions): Board {
  const columns = options.columns.map((c) => ({ ...c }));
  const lists: string[][] = columns.map(() => []);
  const cards = new Map<string, Card>();
  const last = columns.length - 1;
  let nextId = 1;

  function getCard(cardId: string): Card {
    const card = cards.get(cardId);
    if (!card) throw new BoardError("UNKNOWN_CARD", `Unknown card ${cardId}`);
    return card;
  }

  function columnIndex(name: string): number {
    const index = columns.findIndex((c) => c.name === name);
    if (index < 0) throw new BoardError("UNKNOWN_COLUMN", `Unknown column ${name}`);
    return index;
  }

  function isFull(index: number): boolean {
    const limit = columns[index].wipLimit;
    return limit !== undefined && lists[index].length >= limit;
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Title must not be empty");
      if (isFull(0)) throw new BoardError("WIP_LIMIT", `Column ${columns[0].name} is full`);
      const id = `C${nextId++}`;
      cards.set(id, { column: 0, blocked: false, blocks: [], startedAt: null, finishedAt: null });
      lists[0].push(id);
      return id;
    },

    move(cardId, toColumn) {
      const card = getCard(cardId);
      const to = columnIndex(toColumn);
      if (card.column === to) throw new BoardError("SAME_COLUMN", `Card ${cardId} is already in ${toColumn}`);
      if (card.blocked) throw new BoardError("BLOCKED", `Card ${cardId} is blocked`);
      if (to > card.column + 1) throw new BoardError("SKIP_NOT_ALLOWED", `Card ${cardId} cannot skip columns`);
      if (isFull(to)) throw new BoardError("WIP_LIMIT", `Column ${toColumn} is full`);

      const now = options.now();
      const from = lists[card.column];
      from.splice(from.indexOf(cardId), 1);
      lists[to].push(cardId);
      if (card.column === 0 && card.startedAt === null) card.startedAt = now;
      if (to === last) card.finishedAt = now;
      card.column = to;
    },

    block(cardId, _reason) {
      const card = getCard(cardId);
      if (card.blocked) throw new BoardError("ALREADY_BLOCKED", `Card ${cardId} is already blocked`);
      card.blocked = true;
      card.blocks.push({ start: options.now(), end: null });
    },

    unblock(cardId) {
      const card = getCard(cardId);
      if (!card.blocked) throw new BoardError("NOT_BLOCKED", `Card ${cardId} is not blocked`);
      card.blocked = false;
      card.blocks[card.blocks.length - 1].end = options.now();
    },

    cardsIn(column) {
      return [...lists[columnIndex(column)]];
    },

    cycleTime(cardId) {
      const card = getCard(cardId);
      if (card.column !== last || card.startedAt === null || card.finishedAt === null) return null;
      const started = card.startedAt;
      const finished = card.finishedAt;
      let blockedMs = 0;
      for (const block of card.blocks) {
        // An open block on a done card started after it finished (blocked cards cannot move).
        const end = block.end ?? finished;
        const overlap = Math.min(end, finished) - Math.max(block.start, started);
        if (overlap > 0) blockedMs += overlap;
      }
      return { totalMs: finished - started, blockedMs };
    },
  };
}
