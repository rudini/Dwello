export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

const REQUIRED_COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"] as const;
type Column = (typeof REQUIRED_COLUMNS)[number];

const BYTE_ORDER_MARK = String.fromCharCode(0xfeff);

/**
 * Splits one physical line into trimmed fields. Returns null when the quoting
 * is malformed (unterminated quote or text after a closing quote).
 */
function splitLine(line: string): string[] | null {
  const fields: string[] = [];
  let i = 0;
  for (;;) {
    while (line[i] === " " || line[i] === "\t") i++;
    let value: string;
    if (line[i] === '"') {
      i++;
      value = "";
      for (;;) {
        if (i >= line.length) return null;
        if (line[i] === '"') {
          if (line[i + 1] === '"') {
            value += '"';
            i += 2;
          } else {
            i++;
            break;
          }
        } else {
          value += line[i++];
        }
      }
      while (line[i] === " " || line[i] === "\t") i++;
      if (i < line.length && line[i] !== ",") return null;
    } else {
      const end = line.indexOf(",", i);
      value = line.slice(i, end === -1 ? line.length : end);
      i = end === -1 ? line.length : end;
    }
    fields.push(value.trim());
    if (i >= line.length) return fields;
    i++; // skip the comma
  }
}

function isValidDate(text: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!m) return false;
  const year = Number(m[1]);
  const month = Number(m[2]);
  const day = Number(m[3]);
  if (month < 1 || month > 12 || day < 1) return false;
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return day <= daysInMonth;
}

/** Parses "12", "12.5" or "12.50" into integer cents; null if malformed. */
function parseAmountCents(text: string): bigint | null {
  const m = /^(\d+)(?:\.(\d{1,2}))?$/.exec(text);
  if (!m) return null;
  return BigInt(m[1]) * 100n + BigInt((m[2] ?? "").padEnd(2, "0"));
}

/** Exact decimal form of a non-negative number: value = mantissa / 10^scale. */
function toDecimal(rate: number): { mantissa: bigint; scale: number } {
  const m = /^(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/i.exec(String(rate));
  if (!m) throw new Error(`Invalid exchange rate: ${rate}`);
  const fraction = m[2] ?? "";
  let mantissa = BigInt(m[1] + fraction);
  let scale = fraction.length - Number(m[3] ?? 0);
  if (scale < 0) {
    mantissa *= 10n ** BigInt(-scale);
    scale = 0;
  }
  return { mantissa, scale };
}

/** amountCents * rate, rounded to the nearest cent with halves up, computed exactly. */
function convertCents(amountCents: bigint, rate: number): number {
  const { mantissa, scale } = toDecimal(rate);
  const divisor = 10n ** BigInt(scale);
  return Number((2n * amountCents * mantissa + divisor) / (2n * divisor));
}

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const text = csv.startsWith(BYTE_ORDER_MARK) ? csv.slice(1) : csv;
  const physicalLines = text.split("\n").map((l) => (l.endsWith("\r") ? l.slice(0, -1) : l));

  const headerIndex = physicalLines.findIndex((l) => l.trim() !== "");
  if (headerIndex === -1) throw new ExpenseFileError("Missing header");

  const headerLine = physicalLines[headerIndex];
  const headerFields = splitLine(headerLine) ?? headerLine.split(",").map((f) => f.trim());
  const names = headerFields.map((f) => f.toLowerCase());
  const columnIndex = {} as Record<Column, number>;
  for (const column of REQUIRED_COLUMNS) {
    const index = names.indexOf(column);
    if (index === -1) throw new ExpenseFileError(`Missing column: ${column}`);
    columnIndex[column] = index;
  }

  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const totals: ExpenseReport["totals"] = {};
  const seen = new Set<string>();
  const dailyTotals = new Map<string, number>();

  for (let i = headerIndex + 1; i < physicalLines.length; i++) {
    const raw = physicalLines[i];
    if (raw.trim() === "") continue;
    const line = i + 1;
    const reject = (reason: string) => rejected.push({ line, reason });

    const fields = splitLine(raw);
    if (!fields || fields.length !== headerFields.length) {
      reject("wrong number of fields");
      continue;
    }
    const get = (column: Column) => fields[columnIndex[column]];
    const date = get("date");
    const employee = get("employee");
    const category = get("category");
    const currency = get("currency");
    const receipt = get("receipt").toLowerCase();

    if (!isValidDate(date)) {
      reject("invalid date");
      continue;
    }
    if (employee === "") {
      reject("missing employee");
      continue;
    }
    if (!Object.hasOwn(policy.categories, category)) {
      reject("unknown category");
      continue;
    }
    const amountCents = parseAmountCents(get("amount"));
    if (amountCents === null || amountCents <= 0n) {
      reject("invalid amount");
      continue;
    }
    if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) {
      reject("unknown currency");
      continue;
    }
    if (receipt !== "yes" && receipt !== "no") {
      reject("invalid receipt flag");
      continue;
    }

    const amountChfCents = convertCents(amountCents, currency === "CHF" ? 1 : fxRates[currency]);
    const categoryPolicy = policy.categories[category];
    const violations: Violation[] = [];

    const duplicateKey = JSON.stringify([employee, date, category, amountCents.toString(), currency]);
    if (seen.has(duplicateKey)) violations.push("DUPLICATE");
    seen.add(duplicateKey);

    if (categoryPolicy.perItemLimitCents !== undefined && amountChfCents > categoryPolicy.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }

    const dailyKey = JSON.stringify([employee, date, category]);
    const dailyTotal = (dailyTotals.get(dailyKey) ?? 0) + amountChfCents;
    dailyTotals.set(dailyKey, dailyTotal);
    if (categoryPolicy.dailyLimitCents !== undefined && dailyTotal > categoryPolicy.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }

    if (receipt === "no" && amountChfCents > policy.receiptRequiredAboveCents) {
      violations.push("NO_RECEIPT");
    }

    lines.push({ line, date, employee, category, amountChfCents, violations });

    if (!Object.hasOwn(totals, employee)) {
      // defineProperty so that names like "__proto__" become ordinary keys
      Object.defineProperty(totals, employee, {
        value: { approvedCents: 0, flaggedCents: 0 },
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    const total = totals[employee];
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
  }

  return { lines, rejected, totals };
}
