import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type Policy } from "./expenseReview";

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};
const fx = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";

test("missing header and columns", () => {
  expect(() => reviewExpenses(" \n\r\n", policy, fx)).toThrow(new ExpenseFileError("Missing header"));
  expect(() => reviewExpenses("date,employee,amount,receipt\n", policy, fx)).toThrow("Missing column: category");
});

test("parses quoting, header order, line numbers and conversion", () => {
  const csv = [
    "",
    " Receipt , AMOUNT,currency,Employee,date,category,note",
    '"yes",10.50,EUR,"Muster, Hans",2024-02-29,meals,"say ""hi"", ok"',
    "  ",
    "no , 12.5 , CHF , Anna , 2024-03-01 , taxi , x\r",
  ].join("\n");
  const report = reviewExpenses(csv, policy, fx);
  expect(report.rejected).toEqual([]);
  expect(report.lines).toEqual([
    { line: 3, date: "2024-02-29", employee: "Muster, Hans", category: "meals", amountChfCents: 988, violations: [] },
    { line: 5, date: "2024-03-01", employee: "Anna", category: "taxi", amountChfCents: 1250, violations: [] },
  ]);
});

test("rejections in check order", () => {
  const rows = [
    "2024-01-01,A,meals,1,CHF",
    "2023-02-29,A,meals,1,CHF,yes",
    "2024-01-01, ,meals,1,CHF,yes",
    "2024-01-01,A,Meals,1,CHF,yes",
    "2024-01-01,A,meals,0.00,CHF,yes",
    "2024-01-01,A,meals,1.234,CHF,yes",
    "2024-01-01,A,meals,1,GBP,yes",
    "2024-01-01,A,meals,1,CHF,maybe",
    '2024-01-01,"A,meals,1,CHF,yes',
  ];
  const report = reviewExpenses([HEADER, ...rows].join("\n"), policy, fx);
  expect(report.rejected).toEqual(
    [
      "wrong number of fields",
      "invalid date",
      "missing employee",
      "unknown category",
      "invalid amount",
      "invalid amount",
      "unknown currency",
      "invalid receipt flag",
      "wrong number of fields",
    ].map((reason, i) => ({ line: i + 2, reason })),
  );
  expect(report.lines).toEqual([]);
  expect(report.totals).toEqual({});
});

test("violations and totals", () => {
  const csv = [
    HEADER,
    "2024-01-01,A,meals,40,CHF,yes",
    "2024-01-01,A,meals,40.00,CHF,YES",
    "2024-01-01,A,meals,60,CHF,no",
    "2024-01-02,A,hotel,200,CHF,yes",
    "2024-01-02,B,taxi,0.05,USD,no",
  ].join("\n");
  const report = reviewExpenses(csv, policy, fx);
  expect(report.lines.map((l) => l.violations)).toEqual([
    [],
    ["DUPLICATE"],
    ["OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
    [],
    [],
  ]);
  expect(report.totals).toEqual({
    A: { approvedCents: 24000, flaggedCents: 10000 },
    B: { approvedCents: 4, flaggedCents: 0 },
  });
});

test("rounds halves up without floating point drift", () => {
  const csv = [HEADER, "2024-01-01,A,taxi,0.01,X,yes", "2024-01-01,A,taxi,1.15,Y,yes"].join("\n");
  // 1 * 2.5 = 2.5 cents; 115 * 0.1 = 11.5 cents (11.499... in floating point)
  const report = reviewExpenses(csv, policy, { X: 2.5, Y: 0.1 });
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([3, 12]);
});
