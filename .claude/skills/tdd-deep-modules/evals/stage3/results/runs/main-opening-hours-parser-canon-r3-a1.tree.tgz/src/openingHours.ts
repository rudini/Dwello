export type Day = "Mo" | "Tu" | "We" | "Th" | "Fr" | "Sa" | "Su";

export interface TimeRange {
  from: string;
  to: string;
}

export type WeeklyHours = Record<Day, TimeRange[]>;

export type OpeningHoursErrorCode =
  | "EMPTY"
  | "UNKNOWN_DAY"
  | "INVALID_TIME"
  | "END_BEFORE_START"
  | "OVERLAP"
  | "DUPLICATE_DAY"
  | "UNEXPECTED";

export class OpeningHoursError extends Error {
  readonly code: OpeningHoursErrorCode;
  readonly column: number;

  constructor(code: OpeningHoursErrorCode, column: number, description: string) {
    super(`${description} (column ${column})`);
    this.name = "OpeningHoursError";
    this.code = code;
    this.column = column;
  }
}

const DAYS: Day[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

type TokenKind = "word" | "time" | "-" | "," | ";" | "invalid";

interface Token {
  kind: TokenKind;
  text: string;
  column: number;
}

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  const pattern = /(\p{L}+)|([0-9:]+)|([-,;])|( +)|(.)/gsu;
  for (const match of text.matchAll(pattern)) {
    const [, word, time, punctuation, spaces] = match;
    if (spaces) continue;
    const kind: TokenKind = word ? "word" : time ? "time" : punctuation ? (punctuation as TokenKind) : "invalid";
    tokens.push({ kind, text: match[0], column: match.index + 1 });
  }
  return tokens;
}

class Parser {
  private position = 0;

  constructor(
    private readonly tokens: Token[],
    private readonly endColumn: number,
  ) {}

  parse(): WeeklyHours {
    const hours = Object.fromEntries(DAYS.map((day) => [day, []])) as unknown as WeeklyHours;
    do {
      this.parseRule(hours);
    } while (this.accept(";"));
    if (this.peek()) throw this.unexpected();
    return hours;
  }

  private parseRule(hours: WeeklyHours): void {
    const days: Day[] = [];
    do {
      const item = this.parseDayItem();
      const duplicate = item.days.find((day) => days.includes(day));
      if (duplicate) {
        throw new OpeningHoursError("DUPLICATE_DAY", item.column, `${duplicate} is already named in this rule`);
      }
      days.push(...item.days);
    } while (this.accept(","));

    const ranges: TimeRange[] = [];
    const token = this.peek();
    if (token?.kind === "word" && token.text === "off") {
      this.next();
    } else if (token?.kind === "time") {
      do {
        const { range, column } = this.parseRange();
        if (ranges.some((other) => range.from < other.to && other.from < range.to)) {
          throw new OpeningHoursError("OVERLAP", column, `${range.from}-${range.to} overlaps an earlier range`);
        }
        ranges.push(range);
      } while (this.accept(","));
      ranges.sort((a, b) => a.from.localeCompare(b.from));
    } else {
      throw this.unexpected();
    }
    for (const day of days) hours[day] = ranges.map((range) => ({ ...range }));
  }

  private parseRange(): { range: TimeRange; column: number } {
    const start = this.parseTime("start");
    this.expect("-");
    const end = this.parseTime("end");
    // "HH:MM" strings compare in chronological order.
    if (end.text <= start.text) {
      throw new OpeningHoursError("END_BEFORE_START", start.column, `${end.text} is not later than ${start.text}`);
    }
    return { range: { from: start.text, to: end.text }, column: start.column };
  }

  private parseTime(role: "start" | "end"): Token {
    const token = this.expect("time");
    const match = /^(\d\d):(\d\d)$/.exec(token.text);
    const valid =
      match !== null &&
      (token.text === "24:00" ? role === "end" : Number(match[1]) <= 23 && Number(match[2]) <= 59);
    if (!valid) throw new OpeningHoursError("INVALID_TIME", token.column, `Invalid ${role} time "${token.text}"`);
    return token;
  }

  private parseDayItem(): { days: Day[]; column: number } {
    const column = this.peek()?.column ?? this.endColumn;
    const first = this.parseDay();
    const last = this.accept("-") ? this.parseDay() : first;
    const days: Day[] = [DAYS[first]];
    for (let i = first; i !== last; ) {
      i = (i + 1) % DAYS.length;
      days.push(DAYS[i]);
    }
    return { days, column };
  }

  private parseDay(): number {
    const token = this.expect("word");
    const index = DAYS.indexOf(token.text as Day);
    if (index === -1) throw new OpeningHoursError("UNKNOWN_DAY", token.column, `Unknown day "${token.text}"`);
    return index;
  }

  private peek(): Token | undefined {
    return this.tokens[this.position];
  }

  private next(): Token {
    return this.tokens[this.position++];
  }

  private accept(kind: TokenKind): boolean {
    if (this.peek()?.kind !== kind) return false;
    this.position++;
    return true;
  }

  private expect(kind: TokenKind): Token {
    if (this.peek()?.kind !== kind) throw this.unexpected();
    return this.next();
  }

  private unexpected(): OpeningHoursError {
    const token = this.peek();
    if (!token) return new OpeningHoursError("UNEXPECTED", this.endColumn, "Unexpected end of text");
    return new OpeningHoursError("UNEXPECTED", token.column, `Unexpected "${token.text}"`);
  }
}

export function parseOpeningHours(text: string): WeeklyHours {
  if (/^ *$/.test(text)) throw new OpeningHoursError("EMPTY", 1, "No opening hours given");
  return new Parser(tokenize(text), text.length + 1).parse();
}
