import { describe, expect, test } from "bun:test";
import { OpeningHoursError, parseOpeningHours } from "./openingHours";

test("errors report the column in their message", () => {
  const error = new OpeningHoursError("UNKNOWN_DAY", 4, 'Unknown day "Fx"');
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("UNKNOWN_DAY");
  expect(error.column).toBe(4);
  expect(error.message).toBe('Unknown day "Fx" (column 4)');
});

const closedWeek = () => ({ Mo: [], Tu: [], We: [], Th: [], Fr: [], Sa: [], Su: [] });
const range = (from: string, to: string) => ({ from, to });

describe("parseOpeningHours", () => {
  test("a single day with a single range", () => {
    expect(parseOpeningHours("Mo 08:00-12:00")).toEqual({
      ...closedWeek(),
      Mo: [range("08:00", "12:00")],
    });
  });

  test("a closed day", () => {
    expect(parseOpeningHours("Mo off")).toEqual(closedWeek());
  });

  test("a day range applies to every day in it", () => {
    const morning = [range("08:00", "12:00")];
    expect(parseOpeningHours("Mo-We 08:00-12:00")).toEqual({
      ...closedWeek(),
      Mo: morning,
      Tu: morning,
      We: morning,
    });
  });

  test("a day range wraps around the end of the week", () => {
    const morning = [range("08:00", "12:00")];
    expect(parseOpeningHours("Fr-Mo 08:00-12:00")).toEqual({
      ...closedWeek(),
      Fr: morning,
      Sa: morning,
      Su: morning,
      Mo: morning,
    });
  });

  test("a list of day items", () => {
    const morning = [range("08:00", "12:00")];
    expect(parseOpeningHours("Mo,We-Th,Sa 08:00-12:00")).toEqual({
      ...closedWeek(),
      Mo: morning,
      We: morning,
      Th: morning,
      Sa: morning,
    });
  });

  test("several ranges are returned sorted by start time", () => {
    expect(parseOpeningHours("Mo 13:30-18:30,08:00-12:00,12:00-13:00")).toEqual({
      ...closedWeek(),
      Mo: [range("08:00", "12:00"), range("12:00", "13:00"), range("13:30", "18:30")],
    });
  });

  test("later rules replace the hours of the days they name", () => {
    const allDay = [range("08:00", "20:00")];
    expect(parseOpeningHours("Mo-Su 08:00-20:00; We 14:00-18:00; Su off")).toEqual({
      Mo: allDay,
      Tu: allDay,
      We: [range("14:00", "18:00")],
      Th: allDay,
      Fr: allDay,
      Sa: allDay,
      Su: [],
    });
  });

  test("spaces between tokens and around the text carry no meaning", () => {
    const morning = [range("08:00", "12:00")];
    expect(parseOpeningHours("  Mo , We - Th 08:00 - 12:00 ;Sa  off  ")).toEqual({
      ...closedWeek(),
      Mo: morning,
      We: morning,
      Th: morning,
    });
  });

  test("24:00 is allowed as the end of a range", () => {
    expect(parseOpeningHours("Sa 18:00-24:00")).toEqual({
      ...closedWeek(),
      Sa: [range("18:00", "24:00")],
    });
  });

  test("a whole day from 00:00 to 24:00", () => {
    expect(parseOpeningHours("Su 00:00-24:00").Su).toEqual([range("00:00", "24:00")]);
  });

  test("each day gets its own list of ranges", () => {
    const hours = parseOpeningHours("Mo-Tu 08:00-12:00");
    hours.Mo.push(range("13:00", "14:00"));
    hours.Mo[0].to = "11:00";
    expect(hours.Tu).toEqual([range("08:00", "12:00")]);
  });

  test("the example from the form", () => {
    const weekday = [range("08:00", "12:00"), range("13:30", "18:30")];
    expect(parseOpeningHours("Mo-Fr 08:00-12:00,13:30-18:30; Sa 09:00-16:00; Su off")).toEqual({
      Mo: weekday,
      Tu: weekday,
      We: weekday,
      Th: weekday,
      Fr: weekday,
      Sa: [range("09:00", "16:00")],
      Su: [],
    });
  });

  describe("errors", () => {
    const failure = (text: string) => {
      try {
        parseOpeningHours(text);
      } catch (error) {
        expect(error).toBeInstanceOf(OpeningHoursError);
        const { code, column } = error as OpeningHoursError;
        return { code, column };
      }
      throw new Error(`expected "${text}" to be rejected`);
    };

    test.each(["", "    "])("EMPTY for %p", (text) => {
      expect(failure(text)).toEqual({ code: "EMPTY", column: 1 });
    });

    test.each([
      ["Mo-Fx 08:00-12:00", 4],
      ["mo off", 1],
      ["Mo,Off 08:00-12:00", 4],
      ["Mo off; Xyz off", 9],
    ])("UNKNOWN_DAY for %p", (text, column) => {
      expect(failure(text)).toEqual({ code: "UNKNOWN_DAY", column });
    });

    test.each([
      ["Mo 08:00-", 10],
      ["Mo off;", 8],
      ["Mo", 3],
      ["Mo-", 4],
      ["Mo,", 4],
      ["Mo 08:00", 9],
      ["Mo 08:00-12:00,", 16],
      ["Mo 08:00-  ", 12],
      [";Mo off", 1],
      ["08:00-12:00", 1],
      ["Mo off off", 8],
      ["Mo off 08:00-12:00", 8],
      ["Mo Tu 08:00-12:00", 4],
      ["Mo-08:00", 4],
      ["Mo 08:00-12:00 13:00-14:00", 16],
      ["Mo 08:00-12:00,off", 16],
      ["Mo 08:00-off", 10],
      ["Mo 08:00 12:00", 10],
      ["Mo # off", 4],
      ["Mo\toff", 3],
      ["\t", 1],
      ["Mo off;; Tu off", 8],
      ["Mo off, Tu off", 7],
      ["Mo Off", 4],
    ])("UNEXPECTED for %p", (text, column) => {
      expect(failure(text)).toEqual({ code: "UNEXPECTED", column });
    });

    test.each([
      ["Mo 8:00-12:00", 4],
      ["Mo 08:00-1200", 10],
      ["Mo 0800-12:00", 4],
      ["Mo 08:0-12:00", 4],
      ["Mo 008:00-12:00", 4],
      ["Mo 08:00-25:00", 10],
      ["Mo 08:00-12:60", 10],
      ["Mo 08:00-24:01", 10],
      ["Mo 24:00-24:00", 4],
      ["Mo 08:00-12::00", 10],
      ["Mo 08:00-12:00:00", 10],
      ["Mo :-12:00", 4],
      ["Mo 08:00-12:00, 9:00-10:00", 17],
    ])("INVALID_TIME for %p", (text, column) => {
      expect(failure(text)).toEqual({ code: "INVALID_TIME", column });
    });

    test.each([
      ["Mo 12:00-08:00", 4],
      ["Mo 12:00-12:00", 4],
      ["Mo 08:00-09:00, 12:00-11:00", 17],
      ["Mo 12:00-08:00,08:00-25:00", 4],
    ])("END_BEFORE_START for %p", (text, column) => {
      expect(failure(text)).toEqual({ code: "END_BEFORE_START", column });
    });

    test.each([
      ["Mo 08:00-12:00,11:00-13:00", "OVERLAP", 16],
      ["Mo 11:00-13:00,08:00-12:00", "OVERLAP", 16],
      ["Mo 08:00-18:00,10:00-11:00", "OVERLAP", 16],
      ["Mo 08:00-10:00,14:00-16:00, 09:00-15:00", "OVERLAP", 29],
      ["Mo 08:00-12:00,10:00-11:00,x", "OVERLAP", 16],
      ["Mo 08:00-12:00,10:00-09:00", "END_BEFORE_START", 16],
    ])("OVERLAP for %p", (text, code, column) => {
      expect(failure(text)).toEqual({ code, column });
    });

    test("ranges in different rules may overlap, since the later rule replaces", () => {
      expect(parseOpeningHours("Mo 08:00-12:00; Mo 10:00-14:00").Mo).toEqual([range("10:00", "14:00")]);
    });

    test.each([
      ["Mo,Mo off", "DUPLICATE_DAY", 4],
      ["Mo-Fr,We off", "DUPLICATE_DAY", 7],
      ["We, Mo-Fr off", "DUPLICATE_DAY", 5],
      ["Fr-Mo,Su off", "DUPLICATE_DAY", 7],
      ["Fr-Mo,Tu-Fr off", "DUPLICATE_DAY", 7],
      ["Mo,Mo 25:00", "DUPLICATE_DAY", 4],
      ["Mo,Mo-Fx off", "UNKNOWN_DAY", 7],
    ])("DUPLICATE_DAY for %p", (text, code, column) => {
      expect(failure(text)).toEqual({ code, column });
    });

    test("different rules may name the same day", () => {
      expect(parseOpeningHours("Mo-Fr off; Mo,Tu 08:00-09:00").Tu).toEqual([range("08:00", "09:00")]);
    });

    test("a bad time token where no time is expected is unexpected, not invalid", () => {
      expect(failure("Mo 08:00-12:00 9")).toEqual({ code: "UNEXPECTED", column: 16 });
    });

    test.each([
      ["Mo 25:00", "INVALID_TIME", 4],
      ["Mo 08:00-x", "UNEXPECTED", 10],
    ])("time checks happen as each token is read: %p", (text, code, column) => {
      expect(failure(text)).toEqual({ code, column });
    });
  });

  test("a day range from a day to itself is just that day", () => {
    expect(parseOpeningHours("Mo-Mo 08:00-12:00")).toEqual({
      ...closedWeek(),
      Mo: [range("08:00", "12:00")],
    });
  });
});
