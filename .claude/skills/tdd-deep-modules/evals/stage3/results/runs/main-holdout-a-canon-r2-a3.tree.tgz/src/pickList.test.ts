import { expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

const lot = (bin: string, sku: string, qty: number, expires: string | null = null): StockLot => ({
  bin,
  sku,
  qty,
  expires,
});

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

test("empty orders text yields an empty pick list", () => {
  expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
});

test("a single item covered by a single lot becomes one pick", () => {
  const result = buildPickList("ORDER 1001\n  OLIVE-500 x3", [lot("A-01-1", "OLIVE-500", 10)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
    shortages: [],
  });
});

test("insufficient stock is picked anyway and the rest reported missing", () => {
  const result = buildPickList("ORDER 1001\nOLIVE-500 x5\nPASTA-1KG x2", [lot("A-01-1", "OLIVE-500", 2)]);
  expect(result).toEqual({
    picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
    shortages: [
      { orderId: "1001", sku: "OLIVE-500", missing: 3 },
      { orderId: "1001", sku: "PASTA-1KG", missing: 2 },
    ],
  });
});

const byBin = (picks: { bin: string }[]) => [...picks].sort((a, b) => (a.bin < b.bin ? -1 : 1));

test("stock with the earliest best-before date is taken first, ties broken by bin", () => {
  const stock = [
    lot("A-01-1", "OLIVE-500", 5, null),
    lot("A-02-1", "OLIVE-500", 5, "2027-03-01"),
    lot("A-03-1", "OLIVE-500", 2, "2026-12-01"),
    lot("A-05-1", "OLIVE-500", 2, "2026-11-01"),
    lot("A-04-1", "OLIVE-500", 2, "2026-11-01"),
  ];
  const result = buildPickList("ORDER 1001\nOLIVE-500 x7", stock);
  expect(byBin(result.picks)).toEqual([
    { bin: "A-02-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
    { bin: "A-03-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "A-04-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "A-05-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
  ]);
});

test("lots without best-before date come after all dated lots, ties broken by bin", () => {
  const stock = [
    lot("A-03-1", "OLIVE-500", 5, null),
    lot("A-02-1", "OLIVE-500", 5, null),
    lot("A-04-1", "OLIVE-500", 1, "2099-01-01"),
    lot("A-01-1", "OLIVE-500", 5, null),
  ];
  const result = buildPickList("ORDER 1001\nOLIVE-500 x3", stock);
  expect(byBin(result.picks)).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    { bin: "A-04-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
  ]);
});

test("stock taken by an earlier order is not available to later ones", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 3, "2026-11-01"), lot("A-02-1", "OLIVE-500", 2, "2026-12-01")];
  const result = buildPickList("ORDER 1\nOLIVE-500 x3\nORDER 2\nOLIVE-500 x4", stock);
  expect(result).toEqual({
    picks: [
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1" },
      { bin: "A-02-1", sku: "OLIVE-500", qty: 2, orderId: "2" },
    ],
    shortages: [{ orderId: "2", sku: "OLIVE-500", missing: 2 }],
  });
});

test("the stock array and its lots are left untouched", () => {
  const stock = [lot("B-02-1", "OLIVE-500", 3, "2026-12-01"), lot("A-01-1", "OLIVE-500", 3, "2026-11-01")];
  const snapshot = structuredClone(stock);
  const lots = [...stock];
  buildPickList("ORDER 1\nOLIVE-500 x5", stock);
  expect(stock).toEqual(snapshot);
  expect(stock[0]).toBe(lots[0]!);
  expect(stock[1]).toBe(lots[1]!);
});

test("priority orders are served first in text order, then the others in text order", () => {
  const orders = ["ORDER N1", "OLIVE-500 x1", "ORDER P1 !", "OLIVE-500 x1", "ORDER N2", "OLIVE-500 x1", "ORDER P2   !", "OLIVE-500 x1"];
  const result = buildPickList(orders.join("\n"), [lot("A-01-1", "OLIVE-500", 2)]);
  expect(result.picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "P1" },
    { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "P2" },
  ]);
  expect(result.shortages).toEqual([
    { orderId: "N1", sku: "OLIVE-500", missing: 1 },
    { orderId: "N2", sku: "OLIVE-500", missing: 1 },
  ]);
});

test("a repeated SKU within an order is summed and served at its first position", () => {
  const result = buildPickList("ORDER 1\nOLIVE-500 x1\nPASTA-1KG x2\nOLIVE-500 x3", []);
  expect(result.shortages).toEqual([
    { orderId: "1", sku: "OLIVE-500", missing: 4 },
    { orderId: "1", sku: "PASTA-1KG", missing: 2 },
  ]);
});

test("comments, blank lines and surrounding whitespace are ignored", () => {
  const text = ["# export 2026-10-12 06:00", "", "ORDER 1001", "  OLIVE-500 x3", "   # note", "\tPASTA-1KG   x1  ", "ORDER 1002 !", "  OLIVE-500 x2", ""].join("\r\n");
  const result = buildPickList(text, []);
  expect(result.shortages).toEqual([
    { orderId: "1002", sku: "OLIVE-500", missing: 2 },
    { orderId: "1001", sku: "OLIVE-500", missing: 3 },
    { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
  ]);
});

test("picks follow the serpentine walk through the visited aisles", () => {
  const bins = ["F-05-1", "D-02-1", "B-10-1", "D-07-3", "B-01-2", "F-03-1", "D-07-1", "B-01-1"];
  const stock = bins.map((bin, i) => lot(bin, `SKU-${i}`, 1));
  const text = ["ORDER 1", ...bins.map((_, i) => `SKU-${i} x1`)].join("\n");
  const result = buildPickList(text, stock);
  expect(result.picks.map((pick) => pick.bin)).toEqual([
    "B-01-1",
    "B-01-2",
    "B-10-1",
    "D-07-1",
    "D-07-3",
    "D-02-1",
    "F-03-1",
    "F-05-1",
  ]);
});

test("picks at the same bin keep their allocation order", () => {
  const text = "ORDER N1\nPASTA-1KG x1\nOLIVE-500 x1\nORDER P1 !\nOLIVE-500 x2\nPASTA-1KG x1";
  const stock = [lot("A-01-1", "OLIVE-500", 9), lot("A-01-1", "PASTA-1KG", 9)];
  expect(buildPickList(text, stock).picks).toEqual([
    { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "P1" },
    { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "P1" },
    { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "N1" },
    { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "N1" },
  ]);
});

test("empty lots and lots of other SKUs yield no picks", () => {
  const stock = [lot("A-01-1", "OLIVE-500", 0, "2026-10-20"), lot("A-02-1", "PASTA-1KG", 5), lot("A-03-1", "OLIVE-500", 5)];
  expect(buildPickList("ORDER 1\nOLIVE-500 x1", stock).picks).toEqual([
    { bin: "A-03-1", sku: "OLIVE-500", qty: 1, orderId: "1" },
  ]);
});

test("the morning export example", () => {
  const text = "# export 2026-10-12 06:00\nORDER 1001\n  OLIVE-500 x3\n  PASTA-1KG x1\nORDER 1002 !\n  OLIVE-500 x2\n";
  const stock = [
    lot("C-04-1", "OLIVE-500", 2, "2027-01-15"),
    lot("A-03-2", "OLIVE-500", 2, "2026-11-30"),
    lot("B-01-1", "PASTA-1KG", 10, null),
  ];
  const snapshot = structuredClone(stock);
  expect(buildPickList(text, stock)).toEqual({
    picks: [
      { bin: "A-03-2", sku: "OLIVE-500", qty: 2, orderId: "1002" },
      { bin: "B-01-1", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      { bin: "C-04-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    ],
    shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 1 }],
  });
  expect(stock).toEqual(snapshot);
});

function formatErrorLine(text: string): number {
  try {
    buildPickList(text, []);
  } catch (error) {
    expect(error).toBeInstanceOf(OrderFormatError);
    return (error as OrderFormatError).line;
  }
  throw new Error("expected an OrderFormatError");
}

test("an item line before the first ORDER is an error at that line", () => {
  expect(formatErrorLine("# header\n\nOLIVE-500 x1\nORDER 1\nOLIVE-500 x1")).toBe(3);
});

test("an ORDER line reusing an id is an error at that line", () => {
  expect(formatErrorLine("ORDER A-1\nOLIVE-500 x1\nORDER B\nOLIVE-500 x1\nORDER A-1 !\nOLIVE-500 x1")).toBe(5);
});

test("an ORDER without items is an error at its ORDER line", () => {
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\n# c\nORDER 2 !\n\nORDER 3\nOLIVE-500 x1")).toBe(4);
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\nORDER 2\n# nothing more\n")).toBe(3);
});

test("the topmost problem is reported, even if it is only detected later", () => {
  expect(formatErrorLine("ORDER 1\nORDER 2\nolive x1")).toBe(1);
  expect(formatErrorLine("ORDER 1\nbad line\nORDER 2\nOLIVE-500 x1")).toBe(1);
  expect(formatErrorLine("ORDER 1\nbad line\nOLIVE-500 x1")).toBe(2);
  expect(formatErrorLine("ORDER 1\nOLIVE-500 x1\nORDER 1\nORDER 2")).toBe(3);
});

test.each([
  "OLIVE-500 x0",
  "OLIVE-500 x03",
  "olive-500 x1",
  "OLIVE-500 1",
  "OLIVE-500x1",
  "OLIVE-500 x-1",
  "OLIVE-500 x1.5",
  "OLIVE_500 x1",
  "ORDER",
  "ORDER 1!",
  "ORDER 1 ! !",
  "ORDER 1_2",
  "order 1",
  "hello",
])("an unrecognised line %p is an error at that line", (badLine) => {
  expect(formatErrorLine(`ORDER 1\nOLIVE-500 x1\n${badLine}\nPASTA-1KG x1`)).toBe(3);
});
