export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface OrderItem {
  sku: string;
  qty: number;
}

interface Order {
  id: string;
  priority: boolean;
  items: OrderItem[];
}

function parseOrders(ordersText: string): Order[] {
  const orders: Order[] = [];
  // An empty ORDER is only noticed further down, so problems are collected and the topmost is thrown.
  let firstProblem: OrderFormatError | undefined;
  const report = (line: number, description: string) => {
    if (!firstProblem || line < firstProblem.line) firstProblem = new OrderFormatError(line, description);
  };
  let current: { order: Order; line: number } | undefined;
  const closeCurrentOrder = () => {
    if (current && current.order.items.length === 0) report(current.line, `order ${current.order.id} has no items`);
  };

  const lines = ordersText.split("\n");
  for (let index = 0; index < lines.length; index++) {
    const lineNumber = index + 1;
    const line = lines[index]!.trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = /^ORDER\s+([A-Za-z0-9-]+)(\s+!)?$/.exec(line);
    if (orderMatch) {
      closeCurrentOrder();
      const id = orderMatch[1]!;
      if (orders.some((order) => order.id === id)) report(lineNumber, `duplicate order id ${id}`);
      current = { order: { id, priority: orderMatch[2] !== undefined, items: [] }, line: lineNumber };
      orders.push(current.order);
      continue;
    }
    const itemMatch = /^([A-Z0-9-]+)\s+x([1-9][0-9]*)$/.exec(line);
    if (itemMatch) {
      if (!current) {
        report(lineNumber, "item line before the first ORDER");
        continue;
      }
      const items = current.order.items;
      const sku = itemMatch[1]!;
      const qty = Number(itemMatch[2]);
      const existing = items.find((item) => item.sku === sku);
      if (existing) existing.qty += qty;
      else items.push({ sku, qty });
      continue;
    }
    report(lineNumber, `unrecognised line "${line}"`);
  }
  closeCurrentOrder();

  if (firstProblem) throw firstProblem;
  return orders;
}

/** Earliest best-before first, undated lots last, ties by bin code. */
function compareLots(a: StockLot, b: StockLot): number {
  if (a.expires !== b.expires) {
    if (a.expires === null) return 1;
    if (b.expires === null) return -1;
    return a.expires < b.expires ? -1 : 1;
  }
  if (a.bin === b.bin) return 0;
  return a.bin < b.bin ? -1 : 1;
}

function parseBin(bin: string): { aisle: string; rack: number; level: number } {
  const [aisle = "", rack = "0", level = "0"] = bin.split("-");
  return { aisle, rack: Number(rack), level: Number(level) };
}

/**
 * Serpentine walk: visited aisles alphabetically, racks ascending in the 1st, 3rd, ... visited aisle
 * and descending in the others, levels ascending. The stable sort keeps same-bin picks in allocation order.
 */
function inWalkingOrder(picks: Pick[]): Pick[] {
  const visitedAisles = [...new Set(picks.map((pick) => parseBin(pick.bin).aisle))].sort();
  return [...picks].sort((a, b) => {
    const binA = parseBin(a.bin);
    const binB = parseBin(b.bin);
    if (binA.aisle !== binB.aisle) return binA.aisle < binB.aisle ? -1 : 1;
    if (binA.rack !== binB.rack) {
      const ascending = visitedAisles.indexOf(binA.aisle) % 2 === 0;
      return ascending ? binA.rack - binB.rack : binB.rack - binA.rack;
    }
    return binA.level - binB.level;
  });
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  // Working copies, so the caller's stock is never modified.
  const lots = stock.map((lot) => ({ ...lot })).sort(compareLots);
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const orders = parseOrders(ordersText);
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let needed = item.qty;
      for (const lot of lots) {
        if (lot.sku !== item.sku || lot.qty <= 0 || needed === 0) continue;
        const taken = Math.min(needed, lot.qty);
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
        lot.qty -= taken;
        needed -= taken;
      }
      if (needed > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: needed });
    }
  }
  return { picks: inWalkingOrder(picks), shortages };
}
