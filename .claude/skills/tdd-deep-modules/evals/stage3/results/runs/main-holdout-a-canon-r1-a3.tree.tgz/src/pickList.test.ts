import { describe, expect, test } from "bun:test";
import { buildPickList, OrderFormatError, type StockLot } from "./pickList";

test("format errors name the line", () => {
  const error = new OrderFormatError(7, "quantity must be positive");
  expect(error).toBeInstanceOf(Error);
  expect(error.line).toBe(7);
  expect(error.message).toBe("Line 7: quantity must be positive");
});

describe("allocation", () => {
  test("empty orders text gives an empty pick list", () => {
    expect(buildPickList("", [])).toEqual({ picks: [], shortages: [] });
  });

  test("a single item is picked from a lot that covers it", () => {
    const stock = [lot("A-01-1", "OLIVE-500", 10, "2026-12-01")];
    expect(buildPickList("ORDER 1001\nOLIVE-500 x3", stock)).toEqual({
      picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" }],
      shortages: [],
    });
  });

  test("an item takes from several lots, earliest best-before first", () => {
    const stock = [
      lot("A-01-2", "OLIVE-500", 5, "2026-12-01"),
      lot("A-01-1", "OLIVE-500", 2, "2026-11-01"),
    ];
    expect(buildPickList("ORDER 1001\nOLIVE-500 x4", stock).picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
      { bin: "A-01-2", sku: "OLIVE-500", qty: 2, orderId: "1001" },
    ]);
  });

  test("lots without best-before date are used after all dated lots", () => {
    const stock = [
      lot("A-01-2", "SALT-1KG", 5, null),
      lot("A-01-1", "SALT-1KG", 1, "2030-01-01"),
    ];
    expect(buildPickList("ORDER 1001\nSALT-1KG x2", stock).picks).toEqual([
      { bin: "A-01-1", sku: "SALT-1KG", qty: 1, orderId: "1001" },
      { bin: "A-01-2", sku: "SALT-1KG", qty: 1, orderId: "1001" },
    ]);
  });

  test("lots with the same best-before date are used in bin code order", () => {
    const dated = [
      lot("A-01-2", "OLIVE-500", 5, "2026-12-01"),
      lot("A-01-1", "OLIVE-500", 5, "2026-12-01"),
    ];
    expect(buildPickList("ORDER 1001\nOLIVE-500 x3", dated).picks).toEqual([
      { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ]);
    const undated = [lot("B-02-1", "SALT-1KG", 5, null), lot("B-01-1", "SALT-1KG", 5, null)];
    expect(buildPickList("ORDER 1001\nSALT-1KG x3", undated).picks).toEqual([
      { bin: "B-01-1", sku: "SALT-1KG", qty: 3, orderId: "1001" },
    ]);
  });

  test("empty lots yield no picks", () => {
    const stock = [lot("A-01-1", "OLIVE-500", 0, "2026-10-20"), lot("A-01-2", "OLIVE-500", 9, null)];
    expect(buildPickList("ORDER 1001\nOLIVE-500 x3", stock).picks).toEqual([
      { bin: "A-01-2", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ]);
  });

  test("lots of other SKUs are not used", () => {
    const stock = [
      lot("A-01-1", "PASTA-1KG", 9, "2026-10-20"),
      lot("A-01-2", "OLIVE-500", 9, "2026-12-01"),
    ];
    expect(buildPickList("ORDER 1001\nOLIVE-500 x3", stock).picks).toEqual([
      { bin: "A-01-2", sku: "OLIVE-500", qty: 3, orderId: "1001" },
    ]);
  });

  test("when stock runs short, what is available is picked and the rest reported", () => {
    const stock = [lot("A-01-1", "OLIVE-500", 2, "2026-12-01")];
    expect(buildPickList("ORDER 1001\nOLIVE-500 x5", stock)).toEqual({
      picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
      shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 3 }],
    });
  });

  test("an item without any stock is reported missing in full", () => {
    expect(buildPickList("ORDER 1001\nOLIVE-500 x5", [])).toEqual({
      picks: [],
      shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 5 }],
    });
  });

  test("stock taken by an earlier order is not available to later orders", () => {
    const stock = [lot("A-01-1", "OLIVE-500", 4, "2026-12-01")];
    const text = "ORDER 1001\nOLIVE-500 x3\nORDER 1002\nOLIVE-500 x3";
    expect(buildPickList(text, stock)).toEqual({
      picks: [
        { bin: "A-01-1", sku: "OLIVE-500", qty: 3, orderId: "1001" },
        { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
      ],
      shortages: [{ orderId: "1002", sku: "OLIVE-500", missing: 2 }],
    });
  });

  test("priority orders are served first in text order, then the others in text order", () => {
    const stock = [lot("A-01-1", "OLIVE-500", 4, "2026-12-01")];
    const text = [
      "ORDER 1001",
      "OLIVE-500 x1",
      "ORDER 1002 !",
      "OLIVE-500 x1",
      "ORDER 1003 !",
      "OLIVE-500 x1",
      "ORDER 1004",
      "OLIVE-500 x2",
    ].join("\n");
    expect(buildPickList(text, stock)).toEqual({
      picks: [
        { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1002" },
        { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1003" },
        { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1001" },
        { bin: "A-01-1", sku: "OLIVE-500", qty: 1, orderId: "1004" },
      ],
      shortages: [{ orderId: "1004", sku: "OLIVE-500", missing: 1 }],
    });
  });

  test("the stock array and its lots are left untouched", () => {
    const stock = [
      Object.freeze(lot("A-01-2", "OLIVE-500", 2, "2026-12-01")),
      Object.freeze(lot("A-01-1", "OLIVE-500", 2, "2026-11-01")),
    ];
    Object.freeze(stock);
    const before = structuredClone(stock);
    buildPickList("ORDER 1001\nOLIVE-500 x3", stock);
    expect(stock).toEqual(before);
  });

  test("a repeated SKU in an order is summed up at the position of its first appearance", () => {
    const stock = [lot("A-01-1", "OLIVE-500", 2, "2026-12-01")];
    const text = "ORDER 1001\nOLIVE-500 x1\nPASTA-1KG x1\nOLIVE-500 x3";
    expect(buildPickList(text, stock)).toEqual({
      picks: [{ bin: "A-01-1", sku: "OLIVE-500", qty: 2, orderId: "1001" }],
      shortages: [
        { orderId: "1001", sku: "OLIVE-500", missing: 2 },
        { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
      ],
    });
  });

  test("shortages are listed in serving order", () => {
    const text = "ORDER 1001\nOLIVE-500 x1\nORDER 1002 !\nPASTA-1KG x2";
    expect(buildPickList(text, []).shortages).toEqual([
      { orderId: "1002", sku: "PASTA-1KG", missing: 2 },
      { orderId: "1001", sku: "OLIVE-500", missing: 1 },
    ]);
  });
});

describe("walking order", () => {
  test("aisles are visited in alphabetical order", () => {
    const stock = [
      lot("C-01-1", "OLIVE-500", 1, "2026-11-01"),
      lot("A-01-1", "PASTA-1KG", 1, "2026-11-01"),
      lot("B-01-1", "SALT-1KG", 1, null),
    ];
    const text = "ORDER 1001\nOLIVE-500 x1\nSALT-1KG x1\nPASTA-1KG x1";
    expect(buildPickList(text, stock).picks.map((p) => p.bin)).toEqual(["A-01-1", "B-01-1", "C-01-1"]);
  });

  test("racks alternate ascending and descending over the visited aisles", () => {
    const bins = ["D-07-1", "C-02-1", "A-10-1", "D-03-1", "C-11-1", "A-02-1", "C-05-1"];
    const stock = bins.map((bin) => lot(bin, "OLIVE-500", 1, null));
    expect(buildPickList("ORDER 1001\nOLIVE-500 x7", stock).picks.map((p) => p.bin)).toEqual([
      "A-02-1",
      "A-10-1",
      "C-11-1",
      "C-05-1",
      "C-02-1",
      "D-03-1",
      "D-07-1",
    ]);
  });

  test("levels within a rack are visited ascending, also in descending aisles", () => {
    const bins = ["A-01-3", "B-02-3", "A-01-2", "B-02-2", "B-01-1", "A-01-1", "B-02-1"];
    // earlier position in `bins` = earlier best-before = allocated earlier
    const stock = bins.map((bin, i) => lot(bin, "OLIVE-500", 1, `2026-11-0${i + 1}`));
    expect(buildPickList("ORDER 1001\nOLIVE-500 x7", stock).picks.map((p) => p.bin)).toEqual([
      "A-01-1",
      "A-01-2",
      "A-01-3",
      "B-02-1",
      "B-02-2",
      "B-02-3",
      "B-01-1",
    ]);
  });

  test("picks at the same bin keep their allocation order", () => {
    const stock = [lot("B-01-1", "OLIVE-500", 10, null), lot("A-01-1", "PASTA-1KG", 10, null)];
    const text = "ORDER 1\nOLIVE-500 x1\nPASTA-1KG x1\nORDER 2\nPASTA-1KG x2\nORDER 3 !\nOLIVE-500 x3";
    expect(buildPickList(text, stock).picks).toEqual([
      { bin: "A-01-1", sku: "PASTA-1KG", qty: 1, orderId: "1" },
      { bin: "A-01-1", sku: "PASTA-1KG", qty: 2, orderId: "2" },
      { bin: "B-01-1", sku: "OLIVE-500", qty: 3, orderId: "3" },
      { bin: "B-01-1", sku: "OLIVE-500", qty: 1, orderId: "1" },
    ]);
  });

  test("the example batch from the export", () => {
    const text = [
      "# export 2026-10-12 06:00",
      "ORDER 1001",
      "  OLIVE-500 x3",
      "  PASTA-1KG x1",
      "ORDER 1002 !",
      "  OLIVE-500 x2",
    ].join("\n");
    const stock = [
      lot("B-04-1", "OLIVE-500", 2, "2027-03-01"),
      lot("A-07-2", "OLIVE-500", 2, "2026-11-15"),
      lot("C-01-3", "PASTA-1KG", 5, null),
    ];
    expect(buildPickList(text, stock)).toEqual({
      picks: [
        { bin: "A-07-2", sku: "OLIVE-500", qty: 2, orderId: "1002" },
        { bin: "B-04-1", sku: "OLIVE-500", qty: 2, orderId: "1001" },
        { bin: "C-01-3", sku: "PASTA-1KG", qty: 1, orderId: "1001" },
      ],
      shortages: [{ orderId: "1001", sku: "OLIVE-500", missing: 1 }],
    });
  });
});

describe("parsing", () => {
  test("comments, blank lines and surrounding whitespace are ignored", () => {
    const text = [
      "# export 2026-10-12 06:00",
      "",
      "  ORDER 1001  ",
      "\tOLIVE-500 x3\t",
      "   ",
      "  # a comment between items",
      "  PASTA-1KG x1",
    ].join("\n");
    expect(buildPickList(text, []).shortages).toEqual([
      { orderId: "1001", sku: "OLIVE-500", missing: 3 },
      { orderId: "1001", sku: "PASTA-1KG", missing: 1 },
    ]);
  });

  test("several spaces are allowed before the priority mark and the quantity", () => {
    const text = "ORDER A-1\nOLIVE-500    x1\nORDER b-2    !\nPASTA-1KG  x2";
    expect(buildPickList(text, []).shortages).toEqual([
      { orderId: "b-2", sku: "PASTA-1KG", missing: 2 },
      { orderId: "A-1", sku: "OLIVE-500", missing: 1 },
    ]);
  });
});

describe("format errors", () => {
  test("an item line before the first ORDER line", () => {
    expectFormatError("# header\n\nOLIVE-500 x1\nORDER 1001\nOLIVE-500 x1", 3);
  });

  test("an ORDER line whose id was already used", () => {
    expectFormatError("ORDER 1001\nOLIVE-500 x1\nORDER 1002\nOLIVE-500 x1\nORDER 1001 !\nOLIVE-500 x1", 5);
  });

  test("an ORDER without item lines is reported at its ORDER line", () => {
    expectFormatError("ORDER 1001\n# nothing here\n\nORDER 1002\nOLIVE-500 x1", 1);
    expectFormatError("ORDER 1001\nOLIVE-500 x1\nORDER 1002 !\n# nothing here\n", 3);
  });

  test("an empty order is reported before a later problem", () => {
    expectFormatError("ORDER 1001\nORDER 1001\nOLIVE-500 x1", 1);
  });

  test.each([
    "OLIVE-500 x0",
    "OLIVE-500 x03",
    "OLIVE-500 x-1",
    "OLIVE-500 x1.5",
    "OLIVE-500 x",
    "olive-500 x1",
    "OLIVE_500 x1",
    "OLIVE-500 3",
    "OLIVE-500x3",
    "OLIVE-500 X3",
    "OLIVE-500 x3 extra",
    "x3",
    "hello",
  ])("a malformed item line %p", (bad) => {
    expectFormatError(`ORDER 1001\nOLIVE-500 x1\n${bad}\nPASTA-1KG x1`, 3);
  });

  test.each(["ORDER 1001!", "ORDER 1001 ?", "ORDER 1001 ! !", "ORDER 10_01", "ORDER", "ORDER !", "order 1001"])(
    "a malformed ORDER line %p",
    (bad) => {
      expectFormatError(`ORDER 1000\nOLIVE-500 x1\n${bad}\nPASTA-1KG x1`, 3);
    },
  );
});

function expectFormatError(text: string, line: number) {
  let thrown: unknown;
  try {
    buildPickList(text, []);
  } catch (e) {
    thrown = e;
  }
  expect(thrown).toBeInstanceOf(OrderFormatError);
  expect((thrown as OrderFormatError).line).toBe(line);
}

function lot(bin: string, sku: string, qty: number, expires: string | null): StockLot {
  return { bin, sku, qty, expires };
}
