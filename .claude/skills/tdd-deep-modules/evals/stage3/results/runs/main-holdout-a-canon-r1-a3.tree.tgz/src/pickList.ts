export interface StockLot {
  /** Bin code "A-03-2": aisle letter, two-digit rack, one-digit level. */
  bin: string;
  sku: string;
  qty: number;
  /** Best-before date "YYYY-MM-DD", or null for goods that do not expire. */
  expires: string | null;
}

export interface Pick {
  bin: string;
  sku: string;
  qty: number;
  orderId: string;
}

export interface Shortage {
  orderId: string;
  sku: string;
  missing: number;
}

export interface PickList {
  picks: Pick[];
  shortages: Shortage[];
}

export class OrderFormatError extends Error {
  readonly line: number;

  constructor(line: number, description: string) {
    super(`Line ${line}: ${description}`);
    this.name = "OrderFormatError";
    this.line = line;
  }
}

interface Order {
  id: string;
  priority: boolean;
  items: { sku: string; qty: number }[];
  line: number;
}

const ORDER_LINE = /^ORDER\s+([A-Za-z0-9-]+)(?:\s+(!))?$/;
const ITEM_LINE = /^([A-Z0-9-]+)\s+x([1-9][0-9]*)$/;

function parseOrders(text: string): Order[] {
  const orders: Order[] = [];
  const lines = text.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const lineNumber = i + 1;
    const line = lines[i].trim();
    if (line === "" || line.startsWith("#")) continue;
    const orderMatch = ORDER_LINE.exec(line);
    const itemMatch = ITEM_LINE.exec(line);
    if (orderMatch) {
      const [, id, priorityMark] = orderMatch;
      assertLastOrderHasItems(orders);
      if (orders.some((o) => o.id === id)) {
        throw new OrderFormatError(lineNumber, `duplicate order id ${id}`);
      }
      orders.push({ id, priority: priorityMark !== undefined, items: [], line: lineNumber });
    } else if (itemMatch) {
      if (orders.length === 0) throw new OrderFormatError(lineNumber, "item before first ORDER");
      const items = orders[orders.length - 1].items;
      const sku = itemMatch[1];
      const qty = Number(itemMatch[2]);
      const existing = items.find((i) => i.sku === sku);
      if (existing) existing.qty += qty;
      else items.push({ sku, qty });
    } else {
      throw new OrderFormatError(lineNumber, `unrecognised line "${line}"`);
    }
  }
  assertLastOrderHasItems(orders);
  return orders;
}

function assertLastOrderHasItems(orders: Order[]): void {
  const last = orders[orders.length - 1];
  if (last && last.items.length === 0) {
    throw new OrderFormatError(last.line, `order ${last.id} has no items`);
  }
}

export function buildPickList(ordersText: string, stock: StockLot[]): PickList {
  const { picks, shortages } = allocate(parseOrders(ordersText), stock);
  return { picks: inWalkingOrder(picks), shortages };
}

/** Allocates stock to the orders; picks are returned in allocation order. */
function allocate(orders: Order[], stock: StockLot[]): PickList {
  const picks: Pick[] = [];
  const shortages: Shortage[] = [];
  const lots = stock
    .map((l) => ({ ...l }))
    .sort((a, b) => compareExpiry(a.expires, b.expires) || compareStrings(a.bin, b.bin));
  const servingOrder = [...orders.filter((o) => o.priority), ...orders.filter((o) => !o.priority)];
  for (const order of servingOrder) {
    for (const item of order.items) {
      let wanted = item.qty;
      for (const lot of lots) {
        if (wanted === 0) break;
        if (lot.sku !== item.sku || lot.qty === 0) continue;
        const taken = Math.min(wanted, lot.qty);
        lot.qty -= taken;
        wanted -= taken;
        picks.push({ bin: lot.bin, sku: item.sku, qty: taken, orderId: order.id });
      }
      if (wanted > 0) shortages.push({ orderId: order.id, sku: item.sku, missing: wanted });
    }
  }
  return { picks, shortages };
}

function inWalkingOrder(picks: Pick[]): Pick[] {
  const located = picks.map((pick) => {
    const [aisle, rack, level] = pick.bin.split("-");
    return { pick, aisle, rack: Number(rack), level: Number(level) };
  });
  const visitedAisles = [...new Set(located.map((l) => l.aisle))].sort(compareStrings);
  const descending = new Set(visitedAisles.filter((_, i) => i % 2 === 1));
  return located
    .sort((a, b) => {
      if (a.aisle !== b.aisle) return compareStrings(a.aisle, b.aisle);
      if (a.rack !== b.rack) return descending.has(a.aisle) ? b.rack - a.rack : a.rack - b.rack;
      return a.level - b.level;
    })
    .map((l) => l.pick);
}

function compareExpiry(a: string | null, b: string | null): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return compareStrings(a, b);
}

function compareStrings(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}
