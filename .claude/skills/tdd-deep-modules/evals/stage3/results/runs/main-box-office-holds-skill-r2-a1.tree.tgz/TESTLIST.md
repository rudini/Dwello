# Box office: test list

**Hidden decision:** how ticket occupancy is derived over time — which holds still count
(active vs. expired/confirmed/released), how orders and cancellations feed availability and
per-customer limits, and how prices are discounted and rounded to 5 Rappen. Callers never
track expiry, counters or rounding.

**Design A (chosen, given by the stub):** one stateful object from a factory.
`const office = createBoxOffice(opts); const h = office.hold("c1", "A", 2); office.confirm(h.holdId);`

**Design B:** pure functions over an explicit state value.
`const [state2, h] = hold(state, opts, "c1", "A", 2, now);`

Chosen: A, because the caller never sees or threads state, clock or counters; all ledger
and expiry rules stay behind five methods (B leaks the state shape and the clock into every call).

## Behaviours (through `createBoxOffice`)

- [x] available returns the capacity of an untouched section
- [x] available rejects an unknown section with UNKNOWN_SECTION
- [x] hold returns H1 with customer, section, quantity and expiresAt = now + holdMinutes
- [x] a hold reduces availability of its section only
- [x] hold rejects an unknown section with UNKNOWN_SECTION
- [x] hold rejects quantities that are not whole numbers >= 1 with INVALID_QUANTITY
- [x] hold rejects more than available with SOLD_OUT (no partial hold)
- [x] hold rejects exceeding the customer limit across sections with CUSTOMER_LIMIT
- [x] customer limit is checked before availability (passed on arrival; asserted in the expiry test)
- [x] failed holds do not use up hold ids (passed on arrival; asserted in the expiry test)
- [x] an expired hold (now >= expiresAt) stops counting for availability and customer limit
- [x] confirm creates O1 with quantity * price; tickets stay taken
- [x] confirm rejects unknown, confirmed or released holds with UNKNOWN_HOLD
- [x] confirm rejects an expired hold with HOLD_EXPIRED
- [x] orders of 4+ tickets get 10 % off, rounded to 5 cents (halves up)
- [x] totals without discount are rounded to 5 cents too
- [x] release frees the tickets
- [x] release rejects unknown, confirmed or released holds with UNKNOWN_HOLD
- [x] release of an expired hold succeeds without effect
- [x] cancelOrder refunds total minus 200 per ticket, never below 0
- [x] cancelOrder frees tickets and the customer's limit
- [x] cancelOrder rejects unknown or cancelled orders with UNKNOWN_ORDER
