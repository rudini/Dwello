export type BoxOfficeErrorCode =
  | "UNKNOWN_SECTION"
  | "INVALID_QUANTITY"
  | "SOLD_OUT"
  | "CUSTOMER_LIMIT"
  | "UNKNOWN_HOLD"
  | "HOLD_EXPIRED"
  | "UNKNOWN_ORDER";

export class BoxOfficeError extends Error {
  readonly code: BoxOfficeErrorCode;

  constructor(code: BoxOfficeErrorCode, message: string) {
    super(message);
    this.name = "BoxOfficeError";
    this.code = code;
  }
}

export interface SectionConfig {
  id: string;
  capacity: number;
  priceCents: number;
}

export interface BoxOfficeOptions {
  sections: SectionConfig[];
  holdMinutes: number;
  maxTicketsPerCustomer: number;
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface Hold {
  holdId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  expiresAt: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  sectionId: string;
  quantity: number;
  totalCents: number;
}

export interface BoxOffice {
  hold(customerId: string, sectionId: string, quantity: number): Hold;
  confirm(holdId: string): Order;
  release(holdId: string): void;
  cancelOrder(orderId: string): number;
  available(sectionId: string): number;
}

function totalCents(quantity: number, priceCents: number): number {
  // In tenths of a cent to stay exact; 4+ tickets pay 90 %. Round to 50 tenths (5 cents), halves up.
  const tenths = quantity * priceCents * (quantity >= 4 ? 9 : 10);
  return Math.floor((tenths + 25) / 50) * 5;
}

export function createBoxOffice(options: BoxOfficeOptions): BoxOffice {
  type HoldRecord = Hold & { ended: boolean };
  const holds: HoldRecord[] = [];
  const orders: (Order & { cancelled: boolean })[] = [];

  function sectionOf(sectionId: string): SectionConfig {
    const section = options.sections.find((s) => s.id === sectionId);
    if (!section) throw new BoxOfficeError("UNKNOWN_SECTION", `Unknown section ${sectionId}`);
    return section;
  }

  /** A hold that was neither confirmed nor released (it may have expired). */
  function unendedHold(holdId: string): HoldRecord {
    const hold = holds.find((h) => h.holdId === holdId && !h.ended);
    if (!hold) throw new BoxOfficeError("UNKNOWN_HOLD", `Unknown hold ${holdId}`);
    return hold;
  }

  function isExpired(hold: Hold): boolean {
    return options.now() >= hold.expiresAt;
  }

  /** Tickets currently taken by active holds and non-cancelled orders that match. */
  function takenTickets(matches: (taking: { customerId: string; sectionId: string }) => boolean): number {
    const takings = [...holds.filter((h) => !h.ended && !isExpired(h)), ...orders.filter((o) => !o.cancelled)];
    return takings.filter(matches).reduce((sum, t) => sum + t.quantity, 0);
  }

  const office: BoxOffice = {
    hold(customerId, sectionId, quantity) {
      sectionOf(sectionId);
      if (!Number.isInteger(quantity) || quantity < 1) {
        throw new BoxOfficeError("INVALID_QUANTITY", `Invalid quantity ${quantity}`);
      }
      const customerTickets = takenTickets((h) => h.customerId === customerId);
      if (customerTickets + quantity > options.maxTicketsPerCustomer) {
        throw new BoxOfficeError("CUSTOMER_LIMIT", `Customer ${customerId} would exceed the limit`);
      }
      if (quantity > office.available(sectionId)) {
        throw new BoxOfficeError("SOLD_OUT", `Section ${sectionId} has too few tickets left`);
      }
      const hold = {
        holdId: `H${holds.length + 1}`,
        customerId,
        sectionId,
        quantity,
        expiresAt: options.now() + options.holdMinutes * 60_000,
      };
      holds.push({ ...hold, ended: false });
      return hold;
    },
    confirm(holdId) {
      const hold = unendedHold(holdId);
      if (isExpired(hold)) {
        throw new BoxOfficeError("HOLD_EXPIRED", `Hold ${holdId} has expired`);
      }
      hold.ended = true;
      const order = {
        orderId: `O${orders.length + 1}`,
        customerId: hold.customerId,
        sectionId: hold.sectionId,
        quantity: hold.quantity,
        totalCents: totalCents(hold.quantity, sectionOf(hold.sectionId).priceCents),
      };
      orders.push({ ...order, cancelled: false });
      return order;
    },
    release(holdId) {
      const hold = unendedHold(holdId);
      // Releasing an expired hold succeeds without effect.
      if (!isExpired(hold)) hold.ended = true;
    },
    cancelOrder(orderId) {
      const order = orders.find((o) => o.orderId === orderId && !o.cancelled);
      if (!order) throw new BoxOfficeError("UNKNOWN_ORDER", `Unknown order ${orderId}`);
      order.cancelled = true;
      return Math.max(0, order.totalCents - 200 * order.quantity);
    },
    available(sectionId) {
      return sectionOf(sectionId).capacity - takenTickets((h) => h.sectionId === sectionId);
    },
  };
  return office;
}
