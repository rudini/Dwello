import { describe, expect, test } from "bun:test";
import { BoxOfficeError, createBoxOffice, type BoxOfficeOptions } from "./boxOffice";

describe("BoxOfficeError", () => {
  test("carries a machine-readable code", () => {
    const error = new BoxOfficeError("SOLD_OUT", "Section PARKETT is sold out");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("SOLD_OUT");
    expect(error.message).toBe("Section PARKETT is sold out");
  });
});

const MINUTE = 60_000;
const START = 1_000_000;

function setup(overrides: Partial<BoxOfficeOptions> = {}) {
  const clock = { time: START };
  const office = createBoxOffice({
    sections: [
      { id: "A", capacity: 10, priceCents: 5000 },
      { id: "B", capacity: 3, priceCents: 1233 },
    ],
    holdMinutes: 15,
    maxTicketsPerCustomer: 6,
    now: () => clock.time,
    ...overrides,
  });
  return { office, clock };
}

function codeOf(fn: () => unknown): string | undefined {
  try {
    fn();
  } catch (error) {
    return error instanceof BoxOfficeError ? error.code : `not a BoxOfficeError: ${error}`;
  }
  return undefined;
}

describe("availability", () => {
  test("available returns the capacity of an untouched section", () => {
    const { office } = setup();
    expect(office.available("A")).toBe(10);
    expect(office.available("B")).toBe(3);
  });
});

describe("errors", () => {
  test("available rejects an unknown section with UNKNOWN_SECTION", () => {
    const { office } = setup();
    expect(codeOf(() => office.available("Z"))).toBe("UNKNOWN_SECTION");
  });
});

describe("hold", () => {
  test("hold returns H1 with expiresAt = now + holdMinutes", () => {
    const { office } = setup();
    let hold: unknown;
    try {
      hold = office.hold("c1", "A", 2);
    } catch (error) {
      hold = String(error);
    }
    expect(hold).toEqual({
      holdId: "H1",
      customerId: "c1",
      sectionId: "A",
      quantity: 2,
      expiresAt: START + 15 * MINUTE,
    });
  });
});

describe("hold occupancy", () => {
  test("a hold reduces availability of its section only", () => {
    const { office } = setup();
    office.hold("c1", "A", 2);
    expect(office.available("A")).toBe(8);
    expect(office.available("B")).toBe(3);
  });
});

describe("hold validation", () => {
  test("hold rejects an unknown section with UNKNOWN_SECTION", () => {
    const { office } = setup();
    expect(codeOf(() => office.hold("c1", "Z", 1))).toBe("UNKNOWN_SECTION");
  });
});

describe("hold quantity", () => {
  test("hold rejects quantities that are not whole numbers >= 1 with INVALID_QUANTITY", () => {
    const { office } = setup();
    for (const quantity of [0, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY]) {
      expect(codeOf(() => office.hold("c1", "A", quantity))).toBe("INVALID_QUANTITY");
    }
    expect(codeOf(() => office.hold("c1", "Z", 0))).toBe("UNKNOWN_SECTION");
    expect(office.available("A")).toBe(10);
  });
});

describe("sold out", () => {
  test("hold rejects more than available with SOLD_OUT and holds nothing", () => {
    const { office } = setup();
    office.hold("c1", "B", 2);
    expect(codeOf(() => office.hold("c2", "B", 2))).toBe("SOLD_OUT");
    expect(office.available("B")).toBe(1);
    expect(office.hold("c2", "B", 1).quantity).toBe(1);
    expect(office.available("B")).toBe(0);
  });
});

describe("customer limit", () => {
  test("hold rejects exceeding the customer limit across sections with CUSTOMER_LIMIT", () => {
    const { office } = setup();
    office.hold("c1", "A", 4);
    office.hold("c1", "B", 1);
    expect(codeOf(() => office.hold("c1", "A", 2))).toBe("CUSTOMER_LIMIT");
    expect(office.available("A")).toBe(6);
    expect(office.hold("c1", "A", 1).quantity).toBe(1);
    expect(office.hold("c2", "A", 5).quantity).toBe(5);
  });
});

describe("expiry", () => {
  test("an expired hold stops counting for availability and the customer limit", () => {
    const { office, clock } = setup();
    const first = office.hold("c1", "A", 6);
    expect(codeOf(() => office.hold("c1", "B", 4))).toBe("CUSTOMER_LIMIT");
    clock.time = first.expiresAt - 1;
    expect(office.available("A")).toBe(4);
    clock.time = first.expiresAt;
    expect(office.available("A")).toBe(10);
    const second = office.hold("c1", "A", 6);
    expect(second.holdId).toBe("H2");
    expect(second.expiresAt).toBe(first.expiresAt + 15 * MINUTE);
  });
});

describe("confirm", () => {
  test("confirm creates O1 for quantity * price and the tickets stay taken", () => {
    const { office, clock } = setup();
    const hold = office.hold("c1", "A", 2);
    clock.time += 5 * MINUTE;
    let order: unknown;
    try {
      order = office.confirm(hold.holdId);
    } catch (error) {
      order = String(error);
    }
    expect(order).toEqual({ orderId: "O1", customerId: "c1", sectionId: "A", quantity: 2, totalCents: 10000 });
    clock.time = hold.expiresAt + MINUTE;
    expect(office.available("A")).toBe(8);
    expect(codeOf(() => office.hold("c1", "A", 5))).toBe("CUSTOMER_LIMIT");
  });
});

describe("confirm errors", () => {
  test("confirm rejects unknown or already confirmed holds with UNKNOWN_HOLD", () => {
    const { office } = setup();
    expect(codeOf(() => office.confirm("H1"))).toBe("UNKNOWN_HOLD");
    const hold = office.hold("c1", "A", 2);
    office.confirm(hold.holdId);
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("UNKNOWN_HOLD");
    expect(office.available("A")).toBe(8);
    expect(office.confirm(office.hold("c1", "A", 1).holdId).orderId).toBe("O2");
  });
});

describe("confirm expiry", () => {
  test("confirm rejects an expired hold with HOLD_EXPIRED and creates no order", () => {
    const { office, clock } = setup();
    const hold = office.hold("c1", "A", 2);
    clock.time = hold.expiresAt;
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("HOLD_EXPIRED");
    expect(office.available("A")).toBe(10);
    expect(office.confirm(office.hold("c1", "A", 1).holdId).orderId).toBe("O1");
  });
});

describe("pricing", () => {
  function totalFor(priceCents: number, quantity: number): number {
    const { office } = setup({
      sections: [{ id: "C", capacity: 20, priceCents }],
      maxTicketsPerCustomer: 20,
    });
    return office.confirm(office.hold("c1", "C", quantity).holdId).totalCents;
  }

  test("orders of 4 or more tickets get 10 % off, rounded to 5 cents with halves up", () => {
    // 4 * 1233 = 4932, -10 % = 4438.8 -> 4440
    expect(totalFor(1233, 4)).toBe(4440);
    // 5 * 1005 = 5025, -10 % = 4522.5 -> 4525
    expect(totalFor(1005, 5)).toBe(4525);
    // 4 * 5000 = 20000, -10 % = 18000
    expect(totalFor(5000, 4)).toBe(18000);
  });
});

describe("pricing without discount", () => {
  test("totals of fewer than 4 tickets are rounded to 5 cents too", () => {
    const { office } = setup({
      sections: [
        { id: "C", capacity: 20, priceCents: 1233 },
        { id: "D", capacity: 20, priceCents: 1232 },
      ],
    });
    // 3 * 1233 = 3699 -> 3700
    expect(office.confirm(office.hold("c1", "C", 3).holdId).totalCents).toBe(3700);
    // 1 * 1232 -> 1230
    expect(office.confirm(office.hold("c1", "D", 1).holdId).totalCents).toBe(1230);
  });
});

describe("release", () => {
  test("release frees the tickets of an active hold", () => {
    const { office } = setup();
    const hold = office.hold("c1", "A", 6);
    expect(codeOf(() => office.release(hold.holdId))).toBeUndefined();
    expect(office.available("A")).toBe(10);
    expect(office.hold("c1", "A", 6).holdId).toBe("H2");
  });
});

describe("release errors", () => {
  test("release and confirm reject unknown, released or confirmed holds with UNKNOWN_HOLD", () => {
    const { office } = setup();
    expect(codeOf(() => office.release("H9"))).toBe("UNKNOWN_HOLD");
    const released = office.hold("c1", "A", 1);
    office.release(released.holdId);
    expect(codeOf(() => office.release(released.holdId))).toBe("UNKNOWN_HOLD");
    expect(codeOf(() => office.confirm(released.holdId))).toBe("UNKNOWN_HOLD");
    const confirmed = office.hold("c1", "A", 2);
    office.confirm(confirmed.holdId);
    expect(codeOf(() => office.release(confirmed.holdId))).toBe("UNKNOWN_HOLD");
    expect(office.available("A")).toBe(8);
  });
});

describe("release expiry", () => {
  test("release of an expired hold succeeds without effect", () => {
    const { office, clock } = setup();
    const hold = office.hold("c1", "A", 2);
    clock.time = hold.expiresAt;
    expect(codeOf(() => office.release(hold.holdId))).toBeUndefined();
    expect(codeOf(() => office.release(hold.holdId))).toBeUndefined();
    expect(codeOf(() => office.confirm(hold.holdId))).toBe("HOLD_EXPIRED");
    expect(office.available("A")).toBe(10);
  });
});

describe("cancelOrder", () => {
  test("cancelOrder refunds the total minus 200 cents per ticket, never below 0", () => {
    const { office } = setup({
      sections: [
        { id: "A", capacity: 10, priceCents: 5000 },
        { id: "E", capacity: 10, priceCents: 150 },
      ],
    });
    let refunds: unknown;
    try {
      const expensive = office.confirm(office.hold("c1", "A", 2).holdId);
      const cheap = office.confirm(office.hold("c1", "E", 3).holdId);
      refunds = [office.cancelOrder(expensive.orderId), office.cancelOrder(cheap.orderId)];
    } catch (error) {
      refunds = String(error);
    }
    // 10000 - 2 * 200 = 9600; 450 - 3 * 200 < 0 -> 0
    expect(refunds).toEqual([9600, 0]);
  });
});

describe("cancelOrder frees", () => {
  test("cancelOrder frees the tickets and the customer's limit", () => {
    const { office } = setup();
    const order = office.confirm(office.hold("c1", "A", 6).holdId);
    office.cancelOrder(order.orderId);
    expect(office.available("A")).toBe(10);
    expect(codeOf(() => office.hold("c1", "B", 3))).toBeUndefined();
  });
});

describe("cancelOrder errors", () => {
  test("cancelOrder rejects unknown or already cancelled orders with UNKNOWN_ORDER", () => {
    const { office } = setup();
    expect(codeOf(() => office.cancelOrder("O1"))).toBe("UNKNOWN_ORDER");
    const order = office.confirm(office.hold("c1", "A", 2).holdId);
    office.cancelOrder(order.orderId);
    expect(codeOf(() => office.cancelOrder(order.orderId))).toBe("UNKNOWN_ORDER");
    expect(office.available("A")).toBe(10);
  });
});
