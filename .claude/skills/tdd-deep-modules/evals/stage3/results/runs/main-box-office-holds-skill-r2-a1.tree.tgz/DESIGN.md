# Box office: design note

**Hidden decision:** how ticket occupancy is derived over time (which holds still count, how
orders and cancellations feed availability and per-customer limits) and how totals are
discounted and rounded to 5 Rappen. Callers never track expiry, ids or rounding.

## Both designs

- **A (chosen):** stateful object from `createBoxOffice(options)` with `hold`, `confirm`,
  `release`, `cancelOrder`, `available`.
- **B:** pure functions over an explicit state value, `hold(state, opts, ..., now) -> [state, hold]`.

Chosen: A, because the caller never threads state or the clock; B would leak the state shape
into every call.

## Interface

- `available(sectionId)`: capacity minus active holds minus non-cancelled orders.
- `hold(customer, section, qty)`: validates section, quantity, customer limit, availability (in
  that order); ids `H1, H2, ...` only for successful holds.
- `confirm(holdId)`: turns an active hold into an order `O1, O2, ...`; total with 10 % off for
  4+ tickets, rounded to 5 cents (halves up).
- `release(holdId)`: ends an active hold; an expired hold is accepted without any effect.
- `cancelOrder(orderId)`: refund = total − 200 per ticket, floored at 0; frees the tickets.

## Depth

`depth_report src/boxOffice.ts`: surface 11, size 128, ratio 11.6, classitis no,
pass-through 0. The 5 "duplicated lines" are the stub's `Hold`/`Order` field declarations
(kept as required) plus `const hold = unendedHold(holdId);` / `return hold;`.

Refactors: one `sectionOf` lookup; one `takenTickets(predicate)` over active holds and
orders, so availability and customer limit share the occupancy rule; one `unendedHold`
lookup; one `isExpired` rule. Pricing lives in a private `totalCents` using integer tenths of
a cent, so no floating-point rounding errors.

## Open points

- "Releasing an expired hold succeeds without effect" is read literally: the hold stays
  unended, so it can be released again and `confirm` still answers `HOLD_EXPIRED` rather than
  `UNKNOWN_HOLD`.
- Section configs are trusted (no validation of capacity, price or duplicate ids).
- State is in memory and grows with every hold and order.

## Proof

`scripts/tdd_replay a33a0a3..HEAD` printed `REPLAY: ACCEPT`.
