export type BoardErrorCode =
  | "UNKNOWN_CARD"
  | "UNKNOWN_COLUMN"
  | "SAME_COLUMN"
  | "BLOCKED"
  | "SKIP_NOT_ALLOWED"
  | "WIP_LIMIT"
  | "ALREADY_BLOCKED"
  | "NOT_BLOCKED"
  | "EMPTY_TITLE";

export class BoardError extends Error {
  readonly code: BoardErrorCode;

  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = "BoardError";
    this.code = code;
  }
}

export interface ColumnConfig {
  name: string;
  /** Maximum number of cards in the column; no limit when absent. */
  wipLimit?: number;
}

export interface BoardOptions {
  columns: ColumnConfig[];
  /** Current time in epoch milliseconds. */
  now: () => number;
}

export interface CycleTime {
  totalMs: number;
  blockedMs: number;
}

export interface Board {
  addCard(title: string): string;
  move(cardId: string, toColumn: string): void;
  block(cardId: string, reason: string): void;
  unblock(cardId: string): void;
  cardsIn(column: string): string[];
  cycleTime(cardId: string): CycleTime | null;
}

interface BlockInterval {
  from: number;
  /** End of the block; null while the card is still blocked. */
  to: number | null;
}

interface Card {
  id: string;
  title: string;
  column: number;
  blockedReason: string | null;
  blocks: BlockInterval[];
  /** When the card first left the first column. */
  startedAt: number | null;
  /** When the card most recently arrived in the last column. */
  finishedAt: number | null;
}

export function createBoard(options: BoardOptions): Board {
  const columns = options.columns.map((c) => ({ ...c }));
  const now = options.now;
  const lists: string[][] = columns.map(() => []);
  const cards = new Map<string, Card>();
  const lastIndex = columns.length - 1;
  let nextId = 1;

  function getCard(cardId: string): Card {
    const card = cards.get(cardId);
    if (!card) throw new BoardError("UNKNOWN_CARD", `Unknown card ${cardId}`);
    return card;
  }

  function columnIndex(name: string): number {
    const index = columns.findIndex((c) => c.name === name);
    if (index < 0) throw new BoardError("UNKNOWN_COLUMN", `Unknown column ${name}`);
    return index;
  }

  function isFull(index: number): boolean {
    const limit = columns[index].wipLimit;
    return limit !== undefined && lists[index].length >= limit;
  }

  return {
    addCard(title) {
      if (title.trim() === "") throw new BoardError("EMPTY_TITLE", "Title must not be empty");
      if (isFull(0)) throw new BoardError("WIP_LIMIT", `Column ${columns[0].name} is full`);
      const id = `C${nextId++}`;
      cards.set(id, {
        id,
        title,
        column: 0,
        blockedReason: null,
        blocks: [],
        startedAt: null,
        finishedAt: null,
      });
      lists[0].push(id);
      return id;
    },

    move(cardId, toColumn) {
      const card = getCard(cardId);
      const to = columnIndex(toColumn);
      const from = card.column;
      if (to === from) throw new BoardError("SAME_COLUMN", `Card ${cardId} is already in ${toColumn}`);
      if (card.blockedReason !== null) throw new BoardError("BLOCKED", `Card ${cardId} is blocked`);
      if (to > from + 1) throw new BoardError("SKIP_NOT_ALLOWED", `Card ${cardId} cannot skip columns`);
      if (isFull(to)) throw new BoardError("WIP_LIMIT", `Column ${toColumn} is full`);

      const time = now();
      lists[from].splice(lists[from].indexOf(cardId), 1);
      lists[to].push(cardId);
      card.column = to;
      if (from === 0 && card.startedAt === null) card.startedAt = time;
      if (to === lastIndex) card.finishedAt = time;
    },

    block(cardId, reason) {
      const card = getCard(cardId);
      if (card.blockedReason !== null) {
        throw new BoardError("ALREADY_BLOCKED", `Card ${cardId} is already blocked`);
      }
      card.blockedReason = reason;
      card.blocks.push({ from: now(), to: null });
    },

    unblock(cardId) {
      const card = getCard(cardId);
      if (card.blockedReason === null) throw new BoardError("NOT_BLOCKED", `Card ${cardId} is not blocked`);
      card.blockedReason = null;
      card.blocks[card.blocks.length - 1].to = now();
    },

    cardsIn(column) {
      return [...lists[columnIndex(column)]];
    },

    cycleTime(cardId) {
      const card = getCard(cardId);
      if (card.column !== lastIndex || card.startedAt === null || card.finishedAt === null) return null;
      const start = card.startedAt;
      const end = card.finishedAt;
      let blockedMs = 0;
      for (const block of card.blocks) {
        const from = Math.max(block.from, start);
        const to = Math.min(block.to ?? Infinity, end);
        if (to > from) blockedMs += to - from;
      }
      return { totalMs: end - start, blockedMs };
    },
  };
}
