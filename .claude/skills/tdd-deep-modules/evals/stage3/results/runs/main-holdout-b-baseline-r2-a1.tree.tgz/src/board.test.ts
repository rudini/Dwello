import { describe, expect, test } from "bun:test";
import { BoardError, createBoard, type BoardErrorCode, type ColumnConfig } from "./board";

test("board errors carry a code", () => {
  const error = new BoardError("WIP_LIMIT", "Column Review is full");
  expect(error).toBeInstanceOf(Error);
  expect(error.code).toBe("WIP_LIMIT");
});

function setup(columns: ColumnConfig[] = [
  { name: "Backlog" },
  { name: "Doing", wipLimit: 2 },
  { name: "Review", wipLimit: 1 },
  { name: "Done" },
]) {
  const clock = { t: 1000 };
  const board = createBoard({ columns, now: () => clock.t });
  return { board, clock };
}

function expectCode(fn: () => unknown, code: BoardErrorCode) {
  try {
    fn();
  } catch (e) {
    expect(e).toBeInstanceOf(BoardError);
    expect((e as BoardError).code).toBe(code);
    return;
  }
  throw new Error(`expected ${code}`);
}

describe("adding", () => {
  test("ids are sequential over successful adds", () => {
    const { board } = setup();
    expect(board.addCard("a")).toBe("C1");
    expectCode(() => board.addCard("   "), "EMPTY_TITLE");
    expect(board.addCard("b")).toBe("C2");
    expect(board.cardsIn("Backlog")).toEqual(["C1", "C2"]);
  });

  test("first column WIP limit", () => {
    const { board } = setup([{ name: "In", wipLimit: 1 }, { name: "Out" }]);
    board.addCard("a");
    expectCode(() => board.addCard("b"), "WIP_LIMIT");
    expect(board.cardsIn("In")).toEqual(["C1"]);
    board.move("C1", "Out");
    expect(board.addCard("c")).toBe("C2");
  });
});

describe("moving", () => {
  test("error order", () => {
    const { board } = setup();
    const id = board.addCard("a");
    expectCode(() => board.move("C99", "Nope"), "UNKNOWN_CARD");
    expectCode(() => board.move(id, "Nope"), "UNKNOWN_COLUMN");
    board.block(id, "x");
    expectCode(() => board.move(id, "Backlog"), "SAME_COLUMN");
    expectCode(() => board.move(id, "Done"), "BLOCKED");
    board.unblock(id);
    expectCode(() => board.move(id, "Review"), "SKIP_NOT_ALLOWED");
  });

  test("WIP limit counts blocked cards; backwards moves allowed", () => {
    const { board } = setup();
    const [a, b, c] = [board.addCard("a"), board.addCard("b"), board.addCard("c")];
    board.move(a, "Doing");
    board.move(b, "Doing");
    board.block(a, "waiting");
    expectCode(() => board.move(c, "Doing"), "WIP_LIMIT");
    board.move(b, "Review");
    board.move(b, "Backlog");
    expect(board.cardsIn("Backlog")).toEqual([c, b]);
    expect(board.cardsIn("Doing")).toEqual([a]);
  });

  test("unknown column in cardsIn", () => {
    const { board } = setup();
    expectCode(() => board.cardsIn("Nope"), "UNKNOWN_COLUMN");
  });
});

describe("blocking", () => {
  test("errors", () => {
    const { board } = setup();
    const id = board.addCard("a");
    expectCode(() => board.block("C9", "x"), "UNKNOWN_CARD");
    expectCode(() => board.unblock("C9"), "UNKNOWN_CARD");
    expectCode(() => board.unblock(id), "NOT_BLOCKED");
    board.block(id, "x");
    expectCode(() => board.block(id, "y"), "ALREADY_BLOCKED");
  });
});

describe("cycle time", () => {
  test("null unless in last column", () => {
    const { board } = setup();
    const id = board.addCard("a");
    expectCode(() => board.cycleTime("C9"), "UNKNOWN_CARD");
    expect(board.cycleTime(id)).toBeNull();
    board.move(id, "Doing");
    expect(board.cycleTime(id)).toBeNull();
  });

  test("clips blocked time to the started..finished interval", () => {
    const { board, clock } = setup([{ name: "A" }, { name: "B" }, { name: "C" }]);
    const id = board.addCard("a");
    board.block(id, "x"); // t=1000, before start
    clock.t = 2000;
    board.unblock(id);
    clock.t = 3000;
    board.block(id, "x");
    clock.t = 4000;
    board.unblock(id);
    board.move(id, "B"); // start 4000
    clock.t = 5000;
    board.block(id, "y");
    clock.t = 5500;
    board.unblock(id);
    board.move(id, "A"); // back to first: start unchanged
    clock.t = 6000;
    board.move(id, "B");
    clock.t = 7000;
    board.move(id, "C"); // finish 7000
    board.block(id, "z"); // after finish
    clock.t = 9000;
    expect(board.cycleTime(id)).toEqual({ totalMs: 3000, blockedMs: 500 });
  });

  test("block spanning start and still open across finish", () => {
    const { board, clock } = setup([{ name: "A" }, { name: "B" }, { name: "C" }]);
    const id = board.addCard("a");
    board.move(id, "B"); // start 1000
    clock.t = 1500;
    board.block(id, "x");
    clock.t = 2000;
    board.unblock(id);
    board.move(id, "C"); // finish 2000
    clock.t = 2500;
    board.block(id, "x");
    clock.t = 3000;
    board.unblock(id);
    board.move(id, "B");
    clock.t = 4000;
    board.block(id, "y");
    clock.t = 4100;
    board.unblock(id);
    board.move(id, "C"); // finish 4100
    clock.t = 9999;
    expect(board.cycleTime(id)).toEqual({ totalMs: 3100, blockedMs: 1100 });
  });
});
