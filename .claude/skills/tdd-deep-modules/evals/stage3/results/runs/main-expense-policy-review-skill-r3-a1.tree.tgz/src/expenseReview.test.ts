import { expect, test } from "bun:test";
import { ExpenseFileError, reviewExpenses, type Policy } from "./expenseReview";

const policy: Policy = {
  categories: {
    meals: { perItemLimitCents: 5000, dailyLimitCents: 8000 },
    hotel: { perItemLimitCents: 25000 },
    taxi: {},
  },
  receiptRequiredAboveCents: 2000,
};
const rates = { EUR: 0.9412, USD: 0.8 };
const HEADER = "date,employee,category,amount,currency,receipt";
const csv = (...rows: string[]) => [HEADER, ...rows].join("\n");
const review = (text: string) => reviewExpenses(text, policy, rates);

test("a single CHF row with receipt is reviewed with no violations and totalled as approved", () => {
  expect(review(csv("2026-09-01,Anna,meals,12.50,CHF,yes"))).toEqual({
    lines: [{ line: 2, date: "2026-09-01", employee: "Anna", category: "meals", amountChfCents: 1250, violations: [] }],
    rejected: [],
    totals: { Anna: { approvedCents: 1250, flaggedCents: 0 } },
  });
});

test("foreign currency is converted to CHF cents, rounding halves up", () => {
  const report = review(csv("2026-09-01,Anna,meals,12.50,EUR,yes", "2026-09-02,Anna,meals,10,EUR,yes"));
  // 12.50 * 0.9412 = 11.765 CHF -> 1177 cents; 10 * 0.9412 = 9.412 CHF -> 941 cents
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([1177, 941]);
});

test("header columns may come in any order, any case, padded, with extra columns", () => {
  const text = " Receipt ,AMOUNT,note, Employee,Currency,category,Date\nyes,30,lunch,Ben,CHF,meals,2026-09-03";
  expect(review(text).lines).toEqual([
    { line: 2, date: "2026-09-03", employee: "Ben", category: "meals", amountChfCents: 3000, violations: [] },
  ]);
});

test("blank lines are skipped but counted, and CRLF line ends are accepted", () => {
  const text = `\r\n  \r\n${HEADER}\r\n\r\n2026-09-01,Anna,taxi,10,CHF,yes\r\n \t \r\n2026-09-02,Anna,taxi,20,CHF,yes\r\n`;
  const report = review(text);
  expect(report.lines.map((l) => [l.line, l.amountChfCents])).toEqual([
    [5, 1000],
    [7, 2000],
  ]);
  expect(report.rejected).toEqual([]);
});

test("quoted fields may contain commas and doubled quotes", () => {
  const report = review(
    csv('2026-09-01,"Müller, Hans",taxi,"10.00",CHF,yes', '2026-09-01,"Anna ""Annie"" Frei", taxi ,5,CHF,"yes"'),
  );
  expect(report.rejected).toEqual([]);
  expect(report.lines.map((l) => [l.employee, l.category, l.amountChfCents])).toEqual([
    ["Müller, Hans", "taxi", 1000],
    ['Anna "Annie" Frei', "taxi", 500],
  ]);
});

const fileError = (text: string) => {
  try {
    review(text);
  } catch (error) {
    return error;
  }
  return undefined;
};

test("a file without a header line is a file error", () => {
  for (const text of ["", " \n\r\n  \n"]) {
    const error = fileError(text);
    expect(error).toBeInstanceOf(ExpenseFileError);
    expect((error as Error).message).toBe("Missing header");
  }
});

test("a header without a required column names the first missing one in spec order", () => {
  const cases = [
    ["receipt,currency,amount,category,employee", "Missing column: date"],
    ["date,receipt,amount,note", "Missing column: employee"],
    ["date,employee,category,amount,currency,receipts\n2026-09-01,Anna,taxi,1,CHF,yes", "Missing column: receipt"],
  ];
  for (const [text, message] of cases) {
    const error = fileError(text);
    expect(error).toBeInstanceOf(ExpenseFileError);
    expect((error as Error).message).toBe(message);
  }
});

test("rejects a row with the wrong number of fields", () => {
  const report = review(
    csv("2026-09-01,Anna,taxi,10,CHF", "2026-09-01,Ben,taxi,10,CHF,yes", "2026-09-01,Cleo,taxi,10,CHF,yes,extra"),
  );
  expect(report.rejected).toEqual([
    { line: 2, reason: "wrong number of fields" },
    { line: 4, reason: "wrong number of fields" },
  ]);
  expect(report.lines.map((l) => l.employee)).toEqual(["Ben"]);
  expect(report.totals).toEqual({ Ben: { approvedCents: 1000, flaggedCents: 0 } });
});

const rowWith = (date: string, employee = "Anna", category = "taxi", amount = "10", currency = "CHF", receipt = "yes") =>
  [date, employee, category, amount, currency, receipt].join(",");
const reasons = (...rows: string[]) => review(csv(...rows)).rejected.map((r) => r.reason);

test("rejects dates that are not real calendar dates written YYYY-MM-DD", () => {
  const bad = ["2026-9-01", "26-09-01", "2026/09/01", "2026-09-01x", "", "2026-13-01", "2026-00-10", "2026-01-00",
    "2026-04-31", "2026-02-29", "2100-02-29", "abcd-ef-gh"];
  expect(reasons(...bad.map((d) => rowWith(d)))).toEqual(bad.map(() => "invalid date"));
  const good = ["2024-02-29", "2000-02-29", "2026-12-31", "2026-01-01"];
  expect(reasons(...good.map((d) => rowWith(d)))).toEqual([]);
});

test("rejects a row without employee", () => {
  expect(reasons(rowWith("2026-09-01", ""), rowWith("2026-09-01", "   "), rowWith("2026-09-01", '""'))).toEqual([
    "missing employee",
    "missing employee",
    "missing employee",
  ]);
});

test("rejects a category that is not a policy category", () => {
  const bad = ["Meals", "food", "", "constructor", "toString"];
  expect(reasons(...bad.map((c) => rowWith("2026-09-01", "Anna", c)))).toEqual(bad.map(() => "unknown category"));
});

test("rejects amounts that are not positive numbers with at most two decimals", () => {
  const bad = ["0", "0.00", "-5", "+5", "1.234", "1.", ".5", '"1,5"', "abc", "", "1e3", "1 000", "Infinity"];
  const row = (amount: string) => rowWith("2026-09-01", "Anna", "taxi", amount);
  expect(reasons(...bad.map(row))).toEqual(bad.map(() => "invalid amount"));
  const report = review(csv(...["5", "5.5", "5.55", "0.01", "007"].map(row)));
  expect(report.rejected).toEqual([]);
  expect(report.lines.map((l) => l.amountChfCents)).toEqual([500, 550, 555, 1, 700]);
});

test("rejects a currency that is neither CHF nor in the rates", () => {
  const bad = ["GBP", "chf", "eur", "", "constructor"];
  const row = (currency: string) => rowWith("2026-09-01", "Anna", "taxi", "10", currency);
  expect(reasons(...bad.map(row))).toEqual(bad.map(() => "unknown currency"));
  expect(reasons(row("CHF"), row("EUR"), row("USD"))).toEqual([]);
});

test("rejects a receipt flag other than yes or no, in any case", () => {
  const bad = ["y", "n", "true", "", "ja", "yess"];
  const row = (receipt: string) => rowWith("2026-09-01", "Anna", "taxi", "10", "CHF", receipt);
  expect(reasons(...bad.map(row))).toEqual(bad.map(() => "invalid receipt flag"));
  expect(reasons(row("yes"), row("YES"), row("No"), row("nO"))).toEqual([]);
});

test("flags a row as DUPLICATE when an earlier accepted row has the same employee, date, category, amount and currency", () => {
  const report = review(
    csv(
      "2026-09-01,Anna,taxi,12.5,CHF,maybe", // rejected: does not count
      "2026-09-01,Anna,taxi,12.5,CHF,yes",
      "2026-09-01,Anna,taxi,12.50,CHF,no",
      "2026-09-01,Anna,taxi,12.5,EUR,yes",
      "2026-09-01,Ben,taxi,12.5,CHF,yes",
      "2026-09-02,Anna,taxi,12.5,CHF,yes",
      "2026-09-01,Anna,meals,12.5,CHF,yes",
      "2026-09-01,Anna,taxi,12.51,CHF,yes",
      "2026-09-01,Anna,taxi,012.5,CHF,yes",
    ),
  );
  expect(report.lines.map((l) => [l.line, l.violations])).toEqual([
    [3, []],
    [4, ["DUPLICATE"]],
    [5, []],
    [6, []],
    [7, []],
    [8, []],
    [9, []],
    [10, ["DUPLICATE"]],
  ]);
});

test("flags OVER_ITEM_LIMIT when the CHF amount is above the category's per-item limit", () => {
  const report = review(
    csv(
      "2026-09-01,Anna,meals,50.00,CHF,yes",
      "2026-09-02,Anna,meals,50.01,CHF,yes",
      "2026-09-03,Anna,meals,53.12,EUR,yes",
      "2026-09-04,Anna,meals,53.13,EUR,yes",
      "2026-09-05,Anna,taxi,1000,CHF,yes",
      "2026-09-06,Anna,hotel,250,CHF,yes",
      "2026-09-07,Anna,hotel,250.01,CHF,yes",
    ),
  );
  expect(report.lines.map((l) => l.violations)).toEqual([
    [],
    ["OVER_ITEM_LIMIT"],
    [],
    ["OVER_ITEM_LIMIT"],
    [],
    [],
    ["OVER_ITEM_LIMIT"],
  ]);
});

test("flags OVER_DAILY_LIMIT when the running total of employee, date and category is above the daily limit", () => {
  const report = review(
    csv(
      "2026-09-01,Anna,meals,40,CHF,yes", // running 4000
      "2026-09-01,Anna,meals,40,CHF,yes", // duplicate, running 8000: at the limit
      "2026-09-01,Anna,meals,30,CHF,maybe", // rejected: does not count
      "2026-09-01,Anna,meals,0.01,CHF,yes", // running 8001
      "2026-09-01,Ben,meals,45,CHF,yes",
      "2026-09-02,Anna,meals,45,CHF,yes",
      "2026-09-01,Anna,taxi,100,CHF,yes",
      "2026-09-01,Anna,meals,60,CHF,yes", // running 14001
    ),
  );
  expect(report.lines.map((l) => [l.line, l.violations])).toEqual([
    [2, []],
    [3, ["DUPLICATE"]],
    [5, ["OVER_DAILY_LIMIT"]],
    [6, []],
    [7, []],
    [8, []],
    [9, ["OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT"]],
  ]);
});

test("flags NO_RECEIPT when there is no receipt and the CHF amount is above the threshold", () => {
  const report = review(
    csv(
      "2026-09-01,Anna,taxi,20.00,CHF,no",
      "2026-09-02,Anna,taxi,20.01,CHF,no",
      "2026-09-03,Anna,taxi,20.01,CHF,NO",
      "2026-09-04,Anna,taxi,30,CHF,yes",
      "2026-09-05,Anna,taxi,21.25,EUR,no", // 2000.05 -> 2000
      "2026-09-06,Anna,taxi,21.26,EUR,no", // 2000.99 -> 2001
      "2026-09-09,Anna,meals,60,CHF,no",
      "2026-09-09,Anna,meals,60,CHF,no",
    ),
  );
  expect(report.lines.map((l) => l.violations)).toEqual([
    [],
    ["NO_RECEIPT"],
    ["NO_RECEIPT"],
    [],
    [],
    ["NO_RECEIPT"],
    ["OVER_ITEM_LIMIT", "NO_RECEIPT"],
    ["DUPLICATE", "OVER_ITEM_LIMIT", "OVER_DAILY_LIMIT", "NO_RECEIPT"],
  ]);
});

test("totals split each employee's CHF amounts into approved and flagged", () => {
  const report = review(
    csv(
      "2026-09-01,Anna,taxi,10,CHF,yes",
      "2026-09-01,Anna,meals,60,CHF,yes", // OVER_ITEM_LIMIT
      "2026-09-02,Anna,meals,12.50,EUR,yes", // 1177
      "2026-09-01,Ben,hotel,70,CHF,yes",
      "2026-09-01,Cleo,hotel,70,CHF,maybe", // rejected
    ),
  );
  expect(report.totals).toEqual({
    Anna: { approvedCents: 2177, flaggedCents: 6000 },
    Ben: { approvedCents: 7000, flaggedCents: 0 },
  });
});

test("file errors are recognisable", () => {
  const error = new ExpenseFileError("Missing header");
  expect(error).toBeInstanceOf(Error);
  expect(error.name).toBe("ExpenseFileError");
  expect(error.message).toBe("Missing header");
});
