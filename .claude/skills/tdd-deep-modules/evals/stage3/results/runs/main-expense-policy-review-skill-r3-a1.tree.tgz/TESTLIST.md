# Expense review — test list

**Hidden decision:** how the travel-app CSV is parsed and validated, how amounts
are converted to CHF cents, and how the policy rules are evaluated in file order —
callers hand over the raw text and get a finished report.

**Design A (one general call):**
`reviewExpenses(csv, policy, fxRates): ExpenseReport` —
`const report = reviewExpenses(text, policy, rates);`

**Design B (pipeline of special calls):**
`parseExpenseCsv(csv) -> Row[]`, `validateRows(rows, policy, fx) -> {accepted, rejected}`,
`applyPolicy(accepted, policy) -> ReviewedLine[]`, `totalPerEmployee(lines)` —
`const report = totalPerEmployee(applyPolicy(validateRows(parseExpenseCsv(text), p, fx).accepted, p));`

**Chosen:** Design A, because the caller needs to know only one name and the CSV
format, validation order, rounding and running-total rules stay hidden; Design B
leaks row shapes and the stage order into every caller (and the entry point is
fixed by the task).

## Behaviours (through `reviewExpenses`)

- [x] a single CHF row with receipt is reviewed with no violations and totalled as approved
- [x] foreign currency is converted to CHF cents, rounding halves up
- [x] header columns in any order, case-insensitive, trimmed, extra columns ignored
- [x] blank / whitespace lines are skipped but count for line numbers; `\r\n` accepted
- [x] quoted fields: comma inside quotes, `""` escape; unquoted values trimmed
- [x] missing header throws `ExpenseFileError("Missing header")`
- [x] missing column throws `Missing column: <name>` naming the first missing in spec order
- [x] rejects wrong number of fields
- [x] rejects invalid date (format and impossible calendar dates)
- [x] rejects missing employee
- [x] rejects unknown category
- [x] rejects invalid amount (format, zero, three decimals)
- [x] rejects unknown currency
- [x] rejects invalid receipt flag; accepts receipt flag case-insensitively
- [~] first failing check wins — holds by construction (checks return in order);
      a test would have passed at once, so it cannot be a red
- [x] DUPLICATE when an earlier accepted row matches (amount compared as value)
- [x] OVER_ITEM_LIMIT above perItemLimitCents (not at it)
- [x] OVER_DAILY_LIMIT on running total per employee/date/category, duplicates count
- [x] NO_RECEIPT when receipt is no and amount above threshold
- [x] violations listed in the fixed order; totals split approved vs flagged per employee
