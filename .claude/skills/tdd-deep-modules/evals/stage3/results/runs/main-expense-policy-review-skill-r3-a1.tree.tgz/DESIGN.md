# Design note: `src/expenseReview.ts`

**Hidden decision:** the CSV dialect, the row validation order, the CHF conversion
and rounding, and the order-dependent policy rules (duplicates, running daily
totals). Callers hand over text, policy and rates and get a finished report.

**Both designs:** (A) one call `reviewExpenses(csv, policy, fxRates)`; (B) a
pipeline `parseExpenseCsv` → `validateRows` → `applyPolicy` → `totalPerEmployee`.
Chosen: A, because the caller learns one name while the format, the check order
and the running state stay hidden; B leaks row shapes and the stage order.

**Interface:** `reviewExpenses` returns `lines` (accepted rows in file order with
violations in the fixed order), `rejected` (row number and first failing reason)
and `totals` per employee with at least one accepted row. `ExpenseFileError` is
thrown for `Missing header` and `Missing column: <name>`. All other names are
private.

**Depth:** `depth_report`: `surface 13, size 145, ratio 11.2, classitis no,
pass-through 0, tests 1, unused 0, duplicate 2 -> deep` (the 2 duplicate lines
are in the given stub types). Refactors: row reading returns an expense or a
reason; file reading (`readCsv`), row reading (`readRow`) and the stateful policy
rules (`policyChecker`) became separate private functions along their separate
decisions; `Expense` is derived from `ReviewedLine`; totals are built in a `Map`,
so an employee named `__proto__` is safe.

**Open points:**
- "First failing check wins" holds by construction and has no test of its own:
  a test for it would have passed straight away.
- Rounding: `amountCents * rate` is rounded to 12 significant digits before
  rounding half up, so float noise (e.g. 1176.4999999) does not flip a half.
- A quoted field ends at its closing quote; any text after it, up to the next
  comma, is ignored. Quotes cannot span lines (each physical line is one row).
- Very large amounts (beyond 2^53 cents) are not handled specially.

**Proof:** `scripts/tdd_replay 1fd1b49..HEAD` printed `REPLAY: ACCEPT` for the
history up to the final refactor.
