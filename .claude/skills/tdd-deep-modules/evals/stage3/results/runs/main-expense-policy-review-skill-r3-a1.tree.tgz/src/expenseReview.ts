export interface CategoryPolicy {
  perItemLimitCents?: number;
  dailyLimitCents?: number;
}

export interface Policy {
  categories: Record<string, CategoryPolicy>;
  receiptRequiredAboveCents: number;
}

/** CHF per one unit of the foreign currency, e.g. { EUR: 0.9412 }. */
export type FxRates = Record<string, number>;

export type Violation = "DUPLICATE" | "OVER_ITEM_LIMIT" | "OVER_DAILY_LIMIT" | "NO_RECEIPT";

export interface ReviewedLine {
  line: number;
  date: string;
  employee: string;
  category: string;
  amountChfCents: number;
  violations: Violation[];
}

export interface RejectedLine {
  line: number;
  reason: string;
}

export interface ExpenseReport {
  lines: ReviewedLine[];
  rejected: RejectedLine[];
  totals: Record<string, { approvedCents: number; flaggedCents: number }>;
}

export class ExpenseFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExpenseFileError";
  }
}

const REQUIRED_COLUMNS = ["date", "employee", "category", "amount", "currency", "receipt"];

export function reviewExpenses(csv: string, policy: Policy, fxRates: FxRates): ExpenseReport {
  const { header, rows } = readCsv(csv);
  const lines: ReviewedLine[] = [];
  const rejected: RejectedLine[] = [];
  const totals = new Map<string, { approvedCents: number; flaggedCents: number }>();
  const checkPolicy = policyChecker(policy);
  for (const row of rows) {
    const expense = readRow(row.fields, header, policy, fxRates);
    if (typeof expense === "string") {
      rejected.push({ line: row.number, reason: expense });
      continue;
    }
    const { date, employee, category, amountChfCents } = expense;
    const violations = checkPolicy(expense);
    lines.push({ line: row.number, date, employee, category, amountChfCents, violations });
    const total = totals.get(employee) ?? { approvedCents: 0, flaggedCents: 0 };
    if (violations.length === 0) total.approvedCents += amountChfCents;
    else total.flaggedCents += amountChfCents;
    totals.set(employee, total);
  }
  return { lines, rejected, totals: Object.fromEntries(totals) };
}

/** Splits the file into the normalised header and the numbered non-blank data rows. */
function readCsv(csv: string): { header: string[]; rows: { number: number; fields: string[] }[] } {
  const physical = csv.split(/\r?\n/).map((text, index) => ({ text, number: index + 1 }));
  const [headerLine, ...rows] = physical.filter((line) => line.text.trim() !== "");
  if (!headerLine) throw new ExpenseFileError("Missing header");
  const header = splitFields(headerLine.text).map((name) => name.toLowerCase());
  const missing = REQUIRED_COLUMNS.find((column) => !header.includes(column));
  if (missing) throw new ExpenseFileError(`Missing column: ${missing}`);
  return { header, rows: rows.map((row) => ({ number: row.number, fields: splitFields(row.text) })) };
}

/** Returns a checker that remembers earlier rows for the duplicate and daily-limit rules. */
function policyChecker(policy: Policy): (expense: Expense) => Violation[] {
  const seen = new Set<string>();
  const dayTotals = new Map<string, number>();
  return ({ date, employee, category, amountCents, currency, amountChfCents, receipt }) => {
    const violations: Violation[] = [];
    const key = JSON.stringify([employee, date, category, amountCents, currency]);
    if (seen.has(key)) violations.push("DUPLICATE");
    seen.add(key);
    const limits = policy.categories[category];
    if (limits.perItemLimitCents !== undefined && amountChfCents > limits.perItemLimitCents) {
      violations.push("OVER_ITEM_LIMIT");
    }
    const dayKey = JSON.stringify([employee, date, category]);
    const dayTotal = (dayTotals.get(dayKey) ?? 0) + amountChfCents;
    dayTotals.set(dayKey, dayTotal);
    if (limits.dailyLimitCents !== undefined && dayTotal > limits.dailyLimitCents) {
      violations.push("OVER_DAILY_LIMIT");
    }
    if (!receipt && amountChfCents > policy.receiptRequiredAboveCents) violations.push("NO_RECEIPT");
    return violations;
  };
}

interface Expense extends Omit<ReviewedLine, "line" | "violations"> {
  amountCents: number;
  currency: string;
  receipt: boolean;
}

/** Reads one data row; returns the rejection reason of the first failing check. */
function readRow(fields: string[], header: string[], policy: Policy, fxRates: FxRates): Expense | string {
  if (fields.length !== header.length) return "wrong number of fields";
  const get = (name: string) => fields[header.indexOf(name)];
  const date = get("date");
  if (!isCalendarDate(date)) return "invalid date";
  const employee = get("employee");
  if (employee === "") return "missing employee";
  const category = get("category");
  if (!Object.hasOwn(policy.categories, category)) return "unknown category";
  const amount = /^(\d+)(?:\.(\d{1,2}))?$/.exec(get("amount"));
  if (!amount) return "invalid amount";
  const amountCents = Number(amount[1]) * 100 + Number((amount[2] ?? "").padEnd(2, "0"));
  if (amountCents <= 0) return "invalid amount";
  const currency = get("currency");
  if (currency !== "CHF" && !Object.hasOwn(fxRates, currency)) return "unknown currency";
  const receipt = get("receipt").toLowerCase();
  if (receipt !== "yes" && receipt !== "no") return "invalid receipt flag";
  const rate = currency === "CHF" ? 1 : fxRates[currency];
  const amountChfCents = Math.round(Number((amountCents * rate).toPrecision(12)));
  return { date, employee, category, amountChfCents, amountCents, currency, receipt: receipt === "yes" };
}

function isCalendarDate(text: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const [year, month, day] = match.slice(1).map(Number);
  const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== undefined && day >= 1 && day <= daysInMonth;
}

/** Splits one CSV line; quoted values are kept as written, unquoted ones are trimmed. */
function splitFields(text: string): string[] {
  const fields: string[] = [];
  let value = "";
  let inQuotes = false;
  let wasQuoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"' && text[i + 1] === '"') {
        value += '"';
        i++;
      } else if (ch === '"') inQuotes = false;
      else value += ch;
    } else if (ch === ",") {
      fields.push(wasQuoted ? value : value.trim());
      value = "";
      wasQuoted = false;
    } else if (ch === '"' && !wasQuoted && value === "") {
      inQuotes = wasQuoted = true;
    } else if (!wasQuoted && (value !== "" || ch.trim() !== "")) value += ch;
  }
  fields.push(wasQuoted ? value : value.trim());
  return fields;
}
