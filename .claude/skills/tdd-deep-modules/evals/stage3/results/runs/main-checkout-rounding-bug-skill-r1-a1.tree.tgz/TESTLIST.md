# Checkout fixes: test list

**Hidden decision:** how a cart's money amounts are worked out (exact-cent lines, whether a coupon applies and how far, how the discount is split between VAT rates, and 5-Rappen cash rounding of the amount to pay). Callers only see the finished `Receipt`.

**Design A:** one general call that returns a value (the current interface)
`checkout(cart, catalog, promotions?, couponCode?): Receipt`
call site: `renderReceipt(checkout(cart, catalog, promos, code))`

**Design B:** a stateful till with special-purpose calls
`const till = openTill(catalog, promos); till.scan(sku, qty); till.applyCoupon(code); till.vat(); till.total()`

**Chosen:** A, because callers learn one name and no call order, and every rounding and splitting rule stays behind it. B would make callers know when the coupon is checked and when rounding happens.

## Behaviours (through `checkout` / `renderReceipt`)

- [x] multibuy 3-for-2 gives nothing for 2 items
- [x] multibuy 3-for-2 gives one item free for 4 items (passes already once the 2-item fix lands; no separate red possible)
- [x] line amounts and subtotal are exact to the cent; only the total is rounded to 5 Rappen
- [x] a percent discount is rounded to the cent, not to 5 Rappen
- [x] a fixed voucher is capped at the subtotal, total is 0
- [x] VAT is computed on the discounted amount (single rate)
- [x] the discount is split between VAT rates in proportion to their share of the subtotal
- [x] a coupon below its minimum order gives no discount and carries a notice
- [x] a coupon at its minimum order works and carries no notice (passes already once the minimum check lands; no separate red possible)
- [x] renderReceipt prints the notice as the last line
