import { findProduct, VAT_RATES, type Catalog, type VatCategory } from "./catalog";
import { formatChf, roundToRappen, vatIncluded } from "./money";
import type { Promotion } from "./promotions";

export interface CartLine {
  sku: string;
  qty: number;
}

export interface ReceiptLine {
  sku: string;
  name: string;
  qty: number;
  unitCents: number;
  lineCents: number;
  vat: VatCategory;
}

export interface Receipt {
  lines: ReceiptLine[];
  subtotalCents: number;
  couponCode?: string;
  discountCents: number;
  totalCents: number;
  vat: Record<VatCategory, number>;
  /** A message for the customer, e.g. why a coupon gave no discount. */
  notice?: string;
}

export function checkout(
  cart: CartLine[],
  catalog: Catalog,
  promotions: Promotion[] = [],
  couponCode?: string,
): Receipt {
  const lines: ReceiptLine[] = cart.map(({ sku, qty }) => {
    const product = findProduct(catalog, sku);
    return {
      sku,
      name: product.name,
      qty,
      unitCents: product.priceCents,
      lineCents: product.priceCents * qty,
      vat: product.vat,
    };
  });

  const subtotalCents = lines.reduce((sum, l) => sum + l.lineCents, 0);

  let discountCents = 0;
  let notice: string | undefined;
  if (couponCode !== undefined) {
    const promotion = findPromotion(promotions, couponCode);
    if (promotion.minSubtotalCents !== undefined && subtotalCents < promotion.minSubtotalCents) {
      notice = `Coupon ${couponCode} requires a minimum order of ${formatChf(promotion.minSubtotalCents)}`;
    } else {
      discountCents = Math.min(discountFor(promotion, lines, subtotalCents), subtotalCents);
    }
  }

  return {
    lines,
    subtotalCents,
    couponCode,
    discountCents,
    totalCents: roundToRappen(subtotalCents - discountCents),
    vat: vatAfterDiscount(lines, subtotalCents, discountCents),
    ...(notice !== undefined && { notice }),
  };
}

function findPromotion(promotions: Promotion[], code: string): Promotion {
  const promotion = promotions.find((p) => p.code === code);
  if (!promotion) throw new Error(`Unknown coupon code: ${code}`);
  return promotion;
}

/** Discount in cents that a promotion grants on the given lines. */
function discountFor(promotion: Promotion, lines: ReceiptLine[], subtotalCents: number): number {
  switch (promotion.kind) {
    case "percent":
      return Math.round((subtotalCents * promotion.percent) / 100);
    case "fixed":
      return promotion.amountCents;
    case "multibuy": {
      const line = lines.find((l) => l.sku === promotion.sku);
      if (!line) return 0;
      const groups = Math.floor(line.qty / promotion.buy);
      return groups * (promotion.buy - promotion.pay) * line.unitCents;
    }
  }
}

/**
 * VAT per rate on the discounted amounts. The discount is split by each rate's
 * share of the subtotal: the reduced share is rounded, the standard share is the rest.
 */
function vatAfterDiscount(
  lines: ReceiptLine[],
  subtotalCents: number,
  discountCents: number,
): Record<VatCategory, number> {
  const gross: Record<VatCategory, number> = { standard: 0, reduced: 0 };
  for (const l of lines) gross[l.vat] += l.lineCents;

  const reducedShare =
    subtotalCents > 0 ? Math.round((discountCents * gross.reduced) / subtotalCents) : 0;
  return {
    standard: vatIncluded(gross.standard - (discountCents - reducedShare), VAT_RATES.standard),
    reduced: vatIncluded(gross.reduced - reducedShare, VAT_RATES.reduced),
  };
}
