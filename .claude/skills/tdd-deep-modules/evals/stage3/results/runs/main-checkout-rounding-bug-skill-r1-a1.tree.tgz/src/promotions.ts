export type Promotion = (
  | { code: string; kind: "percent"; percent: number }
  | { code: string; kind: "fixed"; amountCents: number }
  | { code: string; kind: "multibuy"; sku: string; buy: number; pay: number }
) & { minSubtotalCents?: number };
