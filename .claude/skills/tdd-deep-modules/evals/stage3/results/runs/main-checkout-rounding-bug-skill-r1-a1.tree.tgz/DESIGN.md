# Checkout: design note

**Hidden decision:** how a cart's money amounts are worked out: exact-cent lines, whether a coupon applies and how far, how the discount is split between VAT rates, and 5-Rappen cash rounding of the amount to pay.

**Both designs**

- A: `checkout(cart, catalog, promotions?, couponCode?): Receipt`, one call that returns a value.
- B: a stateful till (`scan`, `applyCoupon`, `vat`, `total`).
- Chosen: A, because callers learn one name and no call order, and every rounding and splitting rule stays behind it. The signature was also fixed by the bug report.

**Interface**

- `checkout(...)`: a `Receipt` with exact-cent `lineCents`, `subtotalCents` and `discountCents`. The discount is capped at the subtotal and is 0 below a coupon's `minSubtotalCents`. `totalCents` is rounded to 5 Rappen. `vat` holds the VAT per rate on the discounted amounts. `notice` is set only when a coupon was refused for the minimum order. It throws on unknown products and coupon codes.
- `renderReceipt(receipt)`: fixed-width text, with the notice (if any) as the last line.
- `Promotion` (in `promotions.ts`): the coupon kinds, with an optional `minSubtotalCents` on each.

**Depth** (`depth_report`, final)

```
src/checkout.ts: surface 8, size 95, ratio 11.9 -> deep
src/receipt.ts: surface 2, size 21, ratio 10.5 -> deep
src/promotions.ts: surface 1, size 5, ratio 5.0 -> deep
```

Changes made in refactors: the VAT split moved into one private helper that sums the gross per rate once. `findPromotion` and `discountFor` were exported helpers with a single caller each, so they became private in `checkout.ts`, which now holds every coupon rule (lookup, minimum order, capping) in one place. `promotions.ts` now holds only the type.

**Open points**

- "4 cups → one free" and "coupon exactly at the minimum works" are not tests of their own. Each already passed after the fix before it, so neither could be a valid red.
- `money.ts` and `catalog.ts` remain shallow, small utility modules; they were outside this change.
- The discount split assumes the two Swiss rates (reduced share rounded, standard gets the rest), as accounting specified.

**Proof:** `tdd_replay 6f8898f..HEAD` → see the commit of this note.
