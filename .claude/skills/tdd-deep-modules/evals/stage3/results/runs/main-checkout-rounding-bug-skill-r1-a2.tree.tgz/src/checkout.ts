import { findProduct, VAT_RATES, type Catalog, type VatCategory } from "./catalog";
import { formatChf } from "./money";
import { discountFor, findPromotion, type Promotion } from "./promotions";

export interface CartLine {
  sku: string;
  qty: number;
}

export interface ReceiptLine {
  sku: string;
  name: string;
  qty: number;
  unitCents: number;
  lineCents: number;
  vat: VatCategory;
}

export interface Receipt {
  lines: ReceiptLine[];
  subtotalCents: number;
  couponCode?: string;
  discountCents: number;
  totalCents: number;
  vat: Record<VatCategory, number>;
  notice?: string;
}

export function checkout(
  cart: CartLine[],
  catalog: Catalog,
  promotions: Promotion[] = [],
  couponCode?: string,
): Receipt {
  const lines: ReceiptLine[] = cart.map(({ sku, qty }) => {
    const product = findProduct(catalog, sku);
    return {
      sku,
      name: product.name,
      qty,
      unitCents: product.priceCents,
      lineCents: product.priceCents * qty,
      vat: product.vat,
    };
  });

  const gross: Record<VatCategory, number> = { standard: 0, reduced: 0 };
  for (const l of lines) gross[l.vat] += l.lineCents;
  const subtotalCents = gross.standard + gross.reduced;

  let discountCents = 0;
  let notice: string | undefined;
  if (couponCode !== undefined) {
    const promotion = findPromotion(promotions, couponCode);
    if (promotion.minSubtotalCents !== undefined && subtotalCents < promotion.minSubtotalCents) {
      notice = `Coupon ${couponCode} requires a minimum order of ${formatChf(promotion.minSubtotalCents)}`;
    } else {
      discountCents = Math.min(discountFor(promotion, lines), subtotalCents);
    }
  }

  return {
    lines,
    subtotalCents,
    couponCode,
    discountCents,
    totalCents: roundToRappen(subtotalCents - discountCents),
    vat: vatAfterDiscount(gross, subtotalCents, discountCents),
    notice,
  };
}

/**
 * VAT per rate after the discount. The discount is split in proportion to each rate's share of
 * the subtotal: the reduced share is rounded to the cent (halves up), the standard share is the rest.
 */
function vatAfterDiscount(
  gross: Record<VatCategory, number>,
  subtotalCents: number,
  discountCents: number,
): Record<VatCategory, number> {
  const reducedShare =
    subtotalCents > 0 ? Math.round((discountCents * gross.reduced) / subtotalCents) : 0;
  return {
    standard: vatIncluded(gross.standard - (discountCents - reducedShare), VAT_RATES.standard),
    reduced: vatIncluded(gross.reduced - reducedShare, VAT_RATES.reduced),
  };
}

/** VAT contained in a gross (VAT-inclusive) amount, rounded to the cent. */
function vatIncluded(grossCents: number, ratePercent: number): number {
  return Math.round((grossCents * ratePercent) / (100 + ratePercent));
}

/** Rounds an amount in cents to the nearest 5 Rappen (Swiss cash rounding). */
function roundToRappen(cents: number): number {
  return Math.round(cents / 5) * 5;
}
