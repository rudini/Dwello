# Design note: checkout receipts

**Hidden decision:** how the money on a receipt is computed — exact cents for lines, subtotal and
discount; 5-Rappen rounding only on the amount to pay; discounts capped at the subtotal, gated by a
minimum order, and split between VAT rates. Callers only see the finished `Receipt`.

**Both designs**

- A — one general call: `checkout(cart, catalog, promotions?, couponCode?): Receipt`.
- B — stateful till: `createTill(catalog, promotions)` with `add`, `applyCoupon`, `receipt`.

Chosen: A, because one call that returns a value hides every rounding and allocation rule. B would
make callers learn ordering rules, and the signatures are fixed anyway.

**Interface**

- `checkout(...)` returns a `Receipt` with exact `lineCents`, `subtotalCents` and `discountCents`
  (capped at the subtotal, 0 below a coupon's `minSubtotalCents`). `totalCents` is rounded to
  5 Rappen. `vat` is the VAT per rate after the discount split. `notice` is set only when a coupon
  is below its minimum order.
- `renderReceipt(receipt)` prints the lines, the discount, the total and the VAT, then the notice
  as the last line if there is one.
- `Promotion` gets the optional `minSubtotalCents`.

**Depth** (`scripts/depth_report`, after the refactor)

- `src/checkout.ts`: surface 8, size 82, ratio 10.2 → deep. `roundToRappen` and `vatIncluded`
  moved here from `money.ts` as private helpers, and the discount split is in a private
  `vatAfterDiscount`.
- `src/receipt.ts`: ratio 10.5 → deep. `src/promotions.ts`: ratio 4.0 → deep.
- `src/money.ts`: now only `formatChf` → reported shallow. It stays as it is because both
  `checkout` (for the notice) and `receipt` use the same amount format.

**Open points**

- The reduced-rate share is rounded with `Math.round`. That rounds halves up, which matches the
  spec because amounts are never negative.
- The unused part of a voucher is lost on purpose. A coupon below its minimum order keeps
  `couponCode` on the receipt but prints no discount line.

**Proof:** `scripts/tdd_replay 1166e16..HEAD` printed ACCEPT.
