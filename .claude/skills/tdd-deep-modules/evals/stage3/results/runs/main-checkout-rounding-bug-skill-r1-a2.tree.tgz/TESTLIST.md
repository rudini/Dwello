# Checkout receipts: rounding, coupons, VAT

**Hidden decision:** how the money on a receipt is computed — which amounts are exact to the cent,
where 5-Rappen rounding happens, how a coupon's discount is limited, allocated to VAT rates and
gated by a minimum order. Callers (till, printer) only see the finished `Receipt`.

**Sketch A — one general call (current interface):**
`checkout(cart, catalog, promotions?, couponCode?): Receipt` — e.g.
`renderReceipt(checkout(cart, catalog, promos, "ZEHN"))`.

**Sketch B — stateful till object with special calls:**
`const till = createTill(catalog, promotions); till.add(sku, qty); till.applyCoupon(code); till.receipt()`.

**Chosen: A**, because a single call hides every rounding/allocation rule behind one value-returning
function, while B adds ordering rules (add before coupon? coupon twice?) that callers must learn —
and the signatures are fixed anyway.

## Behaviours (through `checkout` / `renderReceipt`)

- [x] multibuy discounts only complete groups (2 cups: 0; 4 cups: one cup free)
- [x] line amounts and subtotal are exact; only the total is rounded to 5 Rappen (3 x 0.99 → 297 / pays 295)
- [x] percent discount is exact to the cent (10 % of 2.90 → 0.29, pays 2.60)
- [x] fixed voucher is capped at the subtotal (CHF 50 on 5.80 → discount 580, pays 0.00)
- [x] VAT is computed on the amounts after the discount, split by rate share (4 cups −10 % → 4.05; mixed fixed voucher)
- [x] coupon below its minimum order gives no discount and a notice; at the minimum it works without notice
- [x] renderReceipt prints the notice as the last line
