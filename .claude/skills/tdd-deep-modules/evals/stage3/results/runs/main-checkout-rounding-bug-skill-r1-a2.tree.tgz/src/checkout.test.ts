import { describe, expect, test } from "bun:test";
import { createCatalog } from "./catalog";
import { checkout } from "./checkout";
import type { Promotion } from "./promotions";

const catalog = createCatalog([
  { sku: "BROT", name: "Ruchbrot", priceCents: 290, vat: "reduced" },
  { sku: "KAFFEE", name: "Kaffeebohnen 500g", priceCents: 1250, vat: "reduced" },
  { sku: "TASSE", name: "Espressotasse", priceCents: 1500, vat: "standard" },
]);

const promotions: Promotion[] = [
  { code: "ZEHN", kind: "percent", percent: 10 },
  { code: "TASSE3", kind: "multibuy", sku: "TASSE", buy: 3, pay: 2 },
];

describe("checkout", () => {
  test("sums the lines", () => {
    const receipt = checkout(
      [
        { sku: "BROT", qty: 2 },
        { sku: "KAFFEE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.lines.map((l) => l.lineCents)).toEqual([580, 1250]);
    expect(receipt.subtotalCents).toBe(1830);
    expect(receipt.totalCents).toBe(1830);
  });

  test("includes VAT per rate", () => {
    const receipt = checkout(
      [
        { sku: "KAFFEE", qty: 1 },
        { sku: "TASSE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.vat).toEqual({ reduced: 32, standard: 112 });
  });

  test("applies a percent coupon", () => {
    const receipt = checkout([{ sku: "KAFFEE", qty: 4 }], catalog, promotions, "ZEHN");
    expect(receipt.discountCents).toBe(500);
    expect(receipt.totalCents).toBe(4500);
  });

  test("buy three, pay two", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 3 }], catalog, promotions, "TASSE3");
    expect(receipt.discountCents).toBe(1500);
    expect(receipt.totalCents).toBe(3000);
  });

  test("multibuy discounts only complete groups", () => {
    const two = checkout([{ sku: "TASSE", qty: 2 }], catalog, promotions, "TASSE3");
    expect(two.discountCents).toBe(0);
    expect(two.totalCents).toBe(3000);
    const four = checkout([{ sku: "TASSE", qty: 4 }], catalog, promotions, "TASSE3");
    expect(four.discountCents).toBe(1500);
    expect(four.totalCents).toBe(4500);
  });

  test("keeps line amounts exact and rounds only the total to 5 Rappen", () => {
    const gum = createCatalog([{ sku: "GUM", name: "Kaugummi", priceCents: 99, vat: "standard" }]);
    const receipt = checkout([{ sku: "GUM", qty: 3 }], gum);
    expect(receipt.lines[0].lineCents).toBe(297);
    expect(receipt.subtotalCents).toBe(297);
    expect(receipt.totalCents).toBe(295);
  });

  test("keeps a percent discount exact to the cent", () => {
    const receipt = checkout([{ sku: "BROT", qty: 1 }], catalog, promotions, "ZEHN");
    expect(receipt.discountCents).toBe(29);
    expect(receipt.totalCents).toBe(260);
  });

  test("caps a voucher at the subtotal", () => {
    const voucher: Promotion[] = [{ code: "FUENFZIG", kind: "fixed", amountCents: 5000 }];
    const receipt = checkout([{ sku: "BROT", qty: 2 }], catalog, voucher, "FUENFZIG");
    expect(receipt.discountCents).toBe(580);
    expect(receipt.totalCents).toBe(0);
  });

  test("computes VAT on the amounts after the coupon, split by rate share", () => {
    const cups = checkout([{ sku: "TASSE", qty: 4 }], catalog, promotions, "ZEHN");
    expect(cups.totalCents).toBe(5400);
    expect(cups.vat).toEqual({ standard: 405, reduced: 0 });

    const voucher: Promotion[] = [{ code: "FUENF", kind: "fixed", amountCents: 500 }];
    const mixed = checkout(
      [
        { sku: "BROT", qty: 1 },
        { sku: "TASSE", qty: 1 },
      ],
      catalog,
      voucher,
      "FUENF",
    );
    expect(mixed.totalCents).toBe(1290);
    expect(mixed.vat).toEqual({ standard: 81, reduced: 5 });
  });

  test("applies a coupon only from its minimum order value", () => {
    const minimum: Promotion[] = [
      { code: "ZEHN50", kind: "percent", percent: 10, minSubtotalCents: 5000 },
    ];
    const below = checkout([{ sku: "KAFFEE", qty: 3 }], catalog, minimum, "ZEHN50");
    expect(below.subtotalCents).toBe(3750);
    expect(below.discountCents).toBe(0);
    expect(below.totalCents).toBe(3750);
    expect(below.couponCode).toBe("ZEHN50");
    expect(below.notice).toBe("Coupon ZEHN50 requires a minimum order of CHF 50.00");

    const at = checkout([{ sku: "KAFFEE", qty: 4 }], catalog, minimum, "ZEHN50");
    expect(at.discountCents).toBe(500);
    expect(at.totalCents).toBe(4500);
    expect(at.notice).toBeUndefined();
  });

  test("rejects unknown products and coupons", () => {
    expect(() => checkout([{ sku: "TEE", qty: 1 }], catalog)).toThrow("Unknown product: TEE");
    expect(() => checkout([{ sku: "BROT", qty: 1 }], catalog, promotions, "GRATIS")).toThrow(
      "Unknown coupon code: GRATIS",
    );
  });
});
