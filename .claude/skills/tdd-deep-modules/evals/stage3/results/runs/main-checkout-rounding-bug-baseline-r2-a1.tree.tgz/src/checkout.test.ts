import { describe, expect, test } from "bun:test";
import { createCatalog } from "./catalog";
import { checkout } from "./checkout";
import type { Promotion } from "./promotions";

const catalog = createCatalog([
  { sku: "BROT", name: "Ruchbrot", priceCents: 290, vat: "reduced" },
  { sku: "KAFFEE", name: "Kaffeebohnen 500g", priceCents: 1250, vat: "reduced" },
  { sku: "TASSE", name: "Espressotasse", priceCents: 1500, vat: "standard" },
]);

const promotions: Promotion[] = [
  { code: "ZEHN", kind: "percent", percent: 10 },
  { code: "TASSE3", kind: "multibuy", sku: "TASSE", buy: 3, pay: 2 },
];

describe("checkout", () => {
  test("sums the lines", () => {
    const receipt = checkout(
      [
        { sku: "BROT", qty: 2 },
        { sku: "KAFFEE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.lines.map((l) => l.lineCents)).toEqual([580, 1250]);
    expect(receipt.subtotalCents).toBe(1830);
    expect(receipt.totalCents).toBe(1830);
  });

  test("includes VAT per rate", () => {
    const receipt = checkout(
      [
        { sku: "KAFFEE", qty: 1 },
        { sku: "TASSE", qty: 1 },
      ],
      catalog,
    );
    expect(receipt.vat).toEqual({ reduced: 32, standard: 112 });
  });

  test("applies a percent coupon", () => {
    const receipt = checkout([{ sku: "KAFFEE", qty: 4 }], catalog, promotions, "ZEHN");
    expect(receipt.discountCents).toBe(500);
    expect(receipt.totalCents).toBe(4500);
  });

  test("buy three, pay two", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 3 }], catalog, promotions, "TASSE3");
    expect(receipt.discountCents).toBe(1500);
    expect(receipt.totalCents).toBe(3000);
  });

  test("rejects unknown products and coupons", () => {
    expect(() => checkout([{ sku: "TEE", qty: 1 }], catalog)).toThrow("Unknown product: TEE");
    expect(() => checkout([{ sku: "BROT", qty: 1 }], catalog, promotions, "GRATIS")).toThrow(
      "Unknown coupon code: GRATIS",
    );
  });
});

describe("receipt amounts", () => {
  const shop = createCatalog([
    { sku: "TASSE", name: "Espressotasse", priceCents: 1500, vat: "standard" },
    { sku: "KAUGUMMI", name: "Kaugummi", priceCents: 99, vat: "reduced" },
    { sku: "BROT", name: "Ruchbrot", priceCents: 290, vat: "reduced" },
  ]);
  const promos: Promotion[] = [
    { code: "TASSE3", kind: "multibuy", sku: "TASSE", buy: 3, pay: 2 },
    { code: "FUENFZIG", kind: "fixed", amountCents: 5000 },
    { code: "ZEHN", kind: "percent", percent: 10 },
  ];

  test("multibuy only counts complete groups", () => {
    expect(checkout([{ sku: "TASSE", qty: 2 }], shop, promos, "TASSE3").discountCents).toBe(0);
    expect(checkout([{ sku: "TASSE", qty: 4 }], shop, promos, "TASSE3").discountCents).toBe(1500);
    expect(checkout([{ sku: "TASSE", qty: 6 }], shop, promos, "TASSE3").discountCents).toBe(3000);
  });

  test("lines are exact, only the total is rounded to 5 Rappen", () => {
    const receipt = checkout([{ sku: "KAUGUMMI", qty: 3 }], shop);
    expect(receipt.lines[0].lineCents).toBe(297);
    expect(receipt.subtotalCents).toBe(297);
    expect(receipt.totalCents).toBe(295);
  });

  test("fixed voucher is capped at the subtotal", () => {
    const receipt = checkout([{ sku: "BROT", qty: 2 }], shop, promos, "FUENFZIG");
    expect(receipt.discountCents).toBe(580);
    expect(receipt.totalCents).toBe(0);
  });

  test("VAT accounts for the coupon", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 4 }], shop, promos, "ZEHN");
    expect(receipt.totalCents).toBe(5400);
    expect(receipt.vat).toEqual({ standard: 405, reduced: 0 });
  });

  test("VAT splits the discount proportionally between rates", () => {
    // subtotal 1790 (1500 standard, 290 reduced), discount 179:
    // reduced share round(179 * 290 / 1790) = 29, standard share 150
    const receipt = checkout(
      [
        { sku: "TASSE", qty: 1 },
        { sku: "BROT", qty: 1 },
      ],
      shop,
      promos,
      "ZEHN",
    );
    expect(receipt.discountCents).toBe(179);
    expect(receipt.vat).toEqual({ standard: 101, reduced: 7 });
  });
});

describe("minimum order value", () => {
  const shop = createCatalog([
    { sku: "TASSE", name: "Espressotasse", priceCents: 1500, vat: "standard" },
  ]);
  const promos: Promotion[] = [
    { code: "ZEHN50", kind: "percent", percent: 10, minSubtotalCents: 5000 },
  ];

  test("below the minimum no discount is given and a notice is set", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 3 }], shop, promos, "ZEHN50");
    expect(receipt.discountCents).toBe(0);
    expect(receipt.totalCents).toBe(4500);
    expect(receipt.couponCode).toBe("ZEHN50");
    expect(receipt.notice).toBe("Coupon ZEHN50 requires a minimum order of CHF 50.00");
  });

  test("at or above the minimum the coupon applies", () => {
    const receipt = checkout([{ sku: "TASSE", qty: 4 }], shop, promos, "ZEHN50");
    expect(receipt.discountCents).toBe(600);
    expect(receipt.notice).toBeUndefined();
  });

  test("no notice without a coupon", () => {
    expect(checkout([{ sku: "TASSE", qty: 1 }], shop).notice).toBeUndefined();
  });
});
